PIXELWALL — LOCAL STUDIO

Keep this folder with your project backups and Pro ownership license.
Install Node.js 22.13 or newer from nodejs.org, then run:

  node run-local.mjs

Open http://127.0.0.1:4173 in a modern browser. The server stays on your computer; it does not upload artwork. Keep the folder and use this same address to reopen your device library. Save portable .pixelwall files for independent backups.

The browser needs a local HTTP address for secure storage. Do not double-click index.html. After the first visit, the installed browser cache also supports reopening offline.

Editing, scripting, individual PNG/BMP/TGA images and editable project/Aseprite files are free. GIF, sprite atlases and game packages require Pro. Open Pro, Restore Pro, and paste the PW2 code from your downloaded ownership license. This verifies locally with no subscription or expiry. Old PW1 codes need one online conversion in the hosted editor.

No AI runs inside PixelWall. Its public command API and CLI can be controlled by external tools. Aseprite Lua scripts are not supported. Embedded color profiles are preserved; editing uses sRGB values without ICC conversion.
