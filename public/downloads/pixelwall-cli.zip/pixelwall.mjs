#!/usr/bin/env node
import { link, lstat, mkdir, open, readFile, rename, stat, unlink, writeFile } from "node:fs/promises";
import { existsSync, realpathSync } from "node:fs";
import { Worker } from "node:worker_threads";
import { createRequire } from "module";
import { basename, dirname, extname, join, resolve } from "node:path";
import { randomUUID } from "node:crypto";
import { pathToFileURL } from "node:url";
//#region \0rolldown/runtime.js
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJSMin = (cb, mod) => () => (mod || (cb((mod = { exports: {} }).exports, mod), cb = null), mod.exports);
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var __copyProps = (to, from, except, desc) => {
	if (from && typeof from === "object" || typeof from === "function") for (var keys = __getOwnPropNames(from), i = 0, n = keys.length, key; i < n; i++) {
		key = keys[i];
		if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
			get: ((k) => from[k]).bind(null, key),
			enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
		});
	}
	return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", {
	value: mod,
	enumerable: true
}) : target, mod));
//#endregion
//#region node_modules/lcms-wasm/dist/lcms.js
var lcms_exports = /* @__PURE__ */ __exportAll({
	BYTES_SH: () => BYTES_SH,
	CHANNELS_SH: () => CHANNELS_SH,
	COLORSPACE_SH: () => COLORSPACE_SH,
	DOSWAP_SH: () => DOSWAP_SH,
	ENDIAN16_SH: () => ENDIAN16_SH,
	EXTRA_SH: () => EXTRA_SH,
	FLAVOR_SH: () => FLAVOR_SH,
	FLOAT_SH: () => FLOAT_SH,
	INTENT_ABSOLUTE_COLORIMETRIC: () => 3,
	INTENT_PERCEPTUAL: () => 0,
	INTENT_RELATIVE_COLORIMETRIC: () => 1,
	INTENT_SATURATION: () => 2,
	LCMS_VERSION: () => LCMS_VERSION,
	OPTIMIZED_SH: () => OPTIMIZED_SH,
	PLANAR_SH: () => PLANAR_SH,
	PT_ANY: () => 0,
	PT_CMY: () => 5,
	PT_CMYK: () => 6,
	PT_GRAY: () => 3,
	PT_HLS: () => 13,
	PT_HSV: () => 12,
	PT_Lab: () => 10,
	PT_LabV2: () => 30,
	PT_MCH1: () => 15,
	PT_MCH10: () => 24,
	PT_MCH11: () => 25,
	PT_MCH12: () => 26,
	PT_MCH13: () => 27,
	PT_MCH14: () => 28,
	PT_MCH15: () => 29,
	PT_MCH2: () => 16,
	PT_MCH3: () => 17,
	PT_MCH4: () => 18,
	PT_MCH5: () => 19,
	PT_MCH6: () => 20,
	PT_MCH7: () => 21,
	PT_MCH8: () => 22,
	PT_MCH9: () => 23,
	PT_RGB: () => 4,
	PT_XYZ: () => 9,
	PT_YCbCr: () => 7,
	PT_YUV: () => 8,
	PT_YUVK: () => 11,
	PT_Yxy: () => 14,
	SWAPFIRST_SH: () => SWAPFIRST_SH,
	TYPE_ABGR_16: () => TYPE_ABGR_16,
	TYPE_ABGR_16_PLANAR: () => TYPE_ABGR_16_PLANAR,
	TYPE_ABGR_16_SE: () => TYPE_ABGR_16_SE,
	TYPE_ABGR_8: () => TYPE_ABGR_8,
	TYPE_ABGR_8_PLANAR: () => TYPE_ABGR_8_PLANAR,
	TYPE_ALabV2_8: () => TYPE_ALabV2_8,
	TYPE_ALab_8: () => TYPE_ALab_8,
	TYPE_ARGB_16: () => TYPE_ARGB_16,
	TYPE_ARGB_8: () => TYPE_ARGB_8,
	TYPE_ARGB_8_PLANAR: () => TYPE_ARGB_8_PLANAR,
	TYPE_BGRA_16: () => TYPE_BGRA_16,
	TYPE_BGRA_16_SE: () => TYPE_BGRA_16_SE,
	TYPE_BGRA_8: () => TYPE_BGRA_8,
	TYPE_BGRA_8_PLANAR: () => TYPE_BGRA_8_PLANAR,
	TYPE_BGR_16: () => TYPE_BGR_16,
	TYPE_BGR_16_PLANAR: () => TYPE_BGR_16_PLANAR,
	TYPE_BGR_16_SE: () => TYPE_BGR_16_SE,
	TYPE_BGR_8: () => TYPE_BGR_8,
	TYPE_BGR_8_PLANAR: () => TYPE_BGR_8_PLANAR,
	TYPE_BGR_DBL: () => TYPE_BGR_DBL,
	TYPE_CMYK10_16: () => TYPE_CMYK10_16,
	TYPE_CMYK10_16_SE: () => TYPE_CMYK10_16_SE,
	TYPE_CMYK10_8: () => TYPE_CMYK10_8,
	TYPE_CMYK11_16: () => TYPE_CMYK11_16,
	TYPE_CMYK11_16_SE: () => TYPE_CMYK11_16_SE,
	TYPE_CMYK11_8: () => TYPE_CMYK11_8,
	TYPE_CMYK12_16: () => TYPE_CMYK12_16,
	TYPE_CMYK12_16_SE: () => TYPE_CMYK12_16_SE,
	TYPE_CMYK12_8: () => TYPE_CMYK12_8,
	TYPE_CMYK5_16: () => TYPE_CMYK5_16,
	TYPE_CMYK5_16_SE: () => TYPE_CMYK5_16_SE,
	TYPE_CMYK5_8: () => TYPE_CMYK5_8,
	TYPE_CMYK6_16: () => TYPE_CMYK6_16,
	TYPE_CMYK6_16_PLANAR: () => TYPE_CMYK6_16_PLANAR,
	TYPE_CMYK6_16_SE: () => TYPE_CMYK6_16_SE,
	TYPE_CMYK6_8: () => TYPE_CMYK6_8,
	TYPE_CMYK6_8_PLANAR: () => TYPE_CMYK6_8_PLANAR,
	TYPE_CMYK7_16: () => TYPE_CMYK7_16,
	TYPE_CMYK7_16_SE: () => TYPE_CMYK7_16_SE,
	TYPE_CMYK7_8: () => TYPE_CMYK7_8,
	TYPE_CMYK8_16: () => TYPE_CMYK8_16,
	TYPE_CMYK8_16_SE: () => TYPE_CMYK8_16_SE,
	TYPE_CMYK8_8: () => TYPE_CMYK8_8,
	TYPE_CMYK9_16: () => TYPE_CMYK9_16,
	TYPE_CMYK9_16_SE: () => TYPE_CMYK9_16_SE,
	TYPE_CMYK9_8: () => TYPE_CMYK9_8,
	TYPE_CMYKA_8: () => TYPE_CMYKA_8,
	TYPE_CMYK_16: () => TYPE_CMYK_16,
	TYPE_CMYK_16_PLANAR: () => TYPE_CMYK_16_PLANAR,
	TYPE_CMYK_16_REV: () => TYPE_CMYK_16_REV,
	TYPE_CMYK_16_SE: () => TYPE_CMYK_16_SE,
	TYPE_CMYK_8: () => TYPE_CMYK_8,
	TYPE_CMYK_8_PLANAR: () => TYPE_CMYK_8_PLANAR,
	TYPE_CMYK_8_REV: () => TYPE_CMYK_8_REV,
	TYPE_CMYK_DBL: () => TYPE_CMYK_DBL,
	TYPE_CMY_16: () => TYPE_CMY_16,
	TYPE_CMY_16_PLANAR: () => TYPE_CMY_16_PLANAR,
	TYPE_CMY_16_SE: () => TYPE_CMY_16_SE,
	TYPE_CMY_8: () => TYPE_CMY_8,
	TYPE_CMY_8_PLANAR: () => TYPE_CMY_8_PLANAR,
	TYPE_GRAYA_16: () => TYPE_GRAYA_16,
	TYPE_GRAYA_16_PLANAR: () => TYPE_GRAYA_16_PLANAR,
	TYPE_GRAYA_16_SE: () => TYPE_GRAYA_16_SE,
	TYPE_GRAYA_8: () => TYPE_GRAYA_8,
	TYPE_GRAYA_8_PLANAR: () => TYPE_GRAYA_8_PLANAR,
	TYPE_GRAY_16: () => TYPE_GRAY_16,
	TYPE_GRAY_16_REV: () => TYPE_GRAY_16_REV,
	TYPE_GRAY_16_SE: () => TYPE_GRAY_16_SE,
	TYPE_GRAY_8: () => TYPE_GRAY_8,
	TYPE_GRAY_8_REV: () => TYPE_GRAY_8_REV,
	TYPE_GRAY_DBL: () => TYPE_GRAY_DBL,
	TYPE_KCMY_16: () => TYPE_KCMY_16,
	TYPE_KCMY_16_REV: () => TYPE_KCMY_16_REV,
	TYPE_KCMY_16_SE: () => TYPE_KCMY_16_SE,
	TYPE_KCMY_8: () => TYPE_KCMY_8,
	TYPE_KCMY_8_REV: () => TYPE_KCMY_8_REV,
	TYPE_KYMC10_16: () => TYPE_KYMC10_16,
	TYPE_KYMC10_16_SE: () => TYPE_KYMC10_16_SE,
	TYPE_KYMC10_8: () => TYPE_KYMC10_8,
	TYPE_KYMC11_16: () => TYPE_KYMC11_16,
	TYPE_KYMC11_16_SE: () => TYPE_KYMC11_16_SE,
	TYPE_KYMC11_8: () => TYPE_KYMC11_8,
	TYPE_KYMC12_16: () => TYPE_KYMC12_16,
	TYPE_KYMC12_16_SE: () => TYPE_KYMC12_16_SE,
	TYPE_KYMC12_8: () => TYPE_KYMC12_8,
	TYPE_KYMC5_16: () => TYPE_KYMC5_16,
	TYPE_KYMC5_16_SE: () => TYPE_KYMC5_16_SE,
	TYPE_KYMC5_8: () => TYPE_KYMC5_8,
	TYPE_KYMC7_16: () => TYPE_KYMC7_16,
	TYPE_KYMC7_16_SE: () => TYPE_KYMC7_16_SE,
	TYPE_KYMC7_8: () => TYPE_KYMC7_8,
	TYPE_KYMC8_16: () => TYPE_KYMC8_16,
	TYPE_KYMC8_16_SE: () => TYPE_KYMC8_16_SE,
	TYPE_KYMC8_8: () => TYPE_KYMC8_8,
	TYPE_KYMC9_16: () => TYPE_KYMC9_16,
	TYPE_KYMC9_16_SE: () => TYPE_KYMC9_16_SE,
	TYPE_KYMC9_8: () => TYPE_KYMC9_8,
	TYPE_KYMC_16: () => TYPE_KYMC_16,
	TYPE_KYMC_16_SE: () => TYPE_KYMC_16_SE,
	TYPE_KYMC_8: () => TYPE_KYMC_8,
	TYPE_LabV2_16: () => TYPE_LabV2_16,
	TYPE_LabV2_8: () => TYPE_LabV2_8,
	TYPE_Lab_16: () => TYPE_Lab_16,
	TYPE_Lab_8: () => TYPE_Lab_8,
	TYPE_Lab_DBL: () => TYPE_Lab_DBL,
	TYPE_RGBA_16: () => TYPE_RGBA_16,
	TYPE_RGBA_16_PLANAR: () => TYPE_RGBA_16_PLANAR,
	TYPE_RGBA_16_SE: () => TYPE_RGBA_16_SE,
	TYPE_RGBA_8: () => TYPE_RGBA_8,
	TYPE_RGBA_8_PLANAR: () => TYPE_RGBA_8_PLANAR,
	TYPE_RGB_16: () => TYPE_RGB_16,
	TYPE_RGB_16_PLANAR: () => TYPE_RGB_16_PLANAR,
	TYPE_RGB_16_SE: () => TYPE_RGB_16_SE,
	TYPE_RGB_8: () => TYPE_RGB_8,
	TYPE_RGB_8_PLANAR: () => TYPE_RGB_8_PLANAR,
	TYPE_RGB_DBL: () => TYPE_RGB_DBL,
	TYPE_XYZ_16: () => TYPE_XYZ_16,
	TYPE_XYZ_DBL: () => TYPE_XYZ_DBL,
	TYPE_YUVK_16: () => TYPE_YUVK_16,
	TYPE_YUVK_8: () => TYPE_YUVK_8,
	TYPE_Yxy_16: () => TYPE_Yxy_16,
	T_BYTES: () => T_BYTES,
	T_CHANNELS: () => T_CHANNELS,
	T_COLORSPACE: () => T_COLORSPACE,
	T_DOSWAP: () => T_DOSWAP,
	T_ENDIAN16: () => T_ENDIAN16,
	T_EXTRA: () => T_EXTRA,
	T_FLAVOR: () => T_FLAVOR,
	T_FLOAT: () => T_FLOAT,
	T_OPTIMIZED: () => T_OPTIMIZED,
	T_PLANAR: () => T_PLANAR,
	T_SWAPFIRST: () => T_SWAPFIRST,
	cmsFLAGS_BLACKPOINTCOMPENSATION: () => cmsFLAGS_BLACKPOINTCOMPENSATION,
	cmsFLAGS_COPY_ALPHA: () => cmsFLAGS_COPY_ALPHA,
	cmsFLAGS_GAMUTCHECK: () => cmsFLAGS_GAMUTCHECK,
	cmsFLAGS_HIGHRESPRECALC: () => cmsFLAGS_HIGHRESPRECALC,
	cmsFLAGS_LOWRESPRECALC: () => cmsFLAGS_LOWRESPRECALC,
	cmsFLAGS_NOCACHE: () => 64,
	cmsFLAGS_NOOPTIMIZE: () => 256,
	cmsFLAGS_NOWHITEONWHITEFIXUP: () => 4,
	cmsFLAGS_NULLTRANSFORM: () => 512,
	cmsFLAGS_SOFTPROOFING: () => cmsFLAGS_SOFTPROOFING,
	cmsInfoCopyright: () => 3,
	cmsInfoDescription: () => 0,
	cmsInfoManufacturer: () => 1,
	cmsInfoModel: () => 2,
	cmsMAXCHANNELS: () => 16,
	cmsSigBlueColorantTag: () => cmsSigBlueColorantTag,
	cmsSigCmyData: () => cmsSigCmyData,
	cmsSigCmykData: () => cmsSigCmykData,
	cmsSigGrayData: () => cmsSigGrayData,
	cmsSigGreenColorantTag: () => cmsSigGreenColorantTag,
	cmsSigHlsData: () => cmsSigHlsData,
	cmsSigHsvData: () => cmsSigHsvData,
	cmsSigLabData: () => cmsSigLabData,
	cmsSigLuvData: () => cmsSigLuvData,
	cmsSigRedColorantTag: () => cmsSigRedColorantTag,
	cmsSigRgbData: () => cmsSigRgbData,
	cmsSigXYZData: () => cmsSigXYZData,
	cmsSigYCbCrData: () => cmsSigYCbCrData,
	cmsSigYxyData: () => cmsSigYxyData,
	default: () => instantiate,
	instantiate: () => instantiate
});
const LCMS_VERSION = 2160;
const cmsSigRedColorantTag = 1918392666;
const cmsSigGreenColorantTag = 1733843290;
const cmsSigBlueColorantTag = 1649957210;
const cmsSigXYZData = 1482250784;
const cmsSigLabData = 1281450528;
const cmsSigLuvData = 1282766368;
const cmsSigYCbCrData = 1497588338;
const cmsSigYxyData = 1501067552;
const cmsSigRgbData = 1380401696;
const cmsSigGrayData = 1196573017;
const cmsSigHsvData = 1213421088;
const cmsSigHlsData = 1212961568;
const cmsSigCmykData = 1129142603;
const cmsSigCmyData = 1129142560;
const FLOAT_SH = (a) => a << 22;
const OPTIMIZED_SH = (s) => s << 21;
const COLORSPACE_SH = (s) => s << 16;
const SWAPFIRST_SH = (s) => s << 14;
const FLAVOR_SH = (s) => s << 13;
const PLANAR_SH = (p) => p << 12;
const ENDIAN16_SH = (e) => e << 11;
const DOSWAP_SH = (e) => e << 10;
const EXTRA_SH = (e) => e << 7;
const CHANNELS_SH = (c) => c << 3;
const BYTES_SH = (b) => b;
const T_FLOAT = (a) => a >> 22 & 1;
const T_OPTIMIZED = (o) => o >> 21 & 1;
const T_COLORSPACE = (s) => s >> 16 & 31;
const T_SWAPFIRST = (s) => s >> 14 & 1;
const T_FLAVOR = (s) => s >> 13 & 1;
const T_PLANAR = (p) => p >> 12 & 1;
const T_ENDIAN16 = (e) => e >> 11 & 1;
const T_DOSWAP = (e) => e >> 10 & 1;
const T_EXTRA = (e) => e >> 7 & 7;
const T_CHANNELS = (c) => c >> 3 & 15;
const T_BYTES = (b) => b & 7;
const TYPE_GRAY_8 = COLORSPACE_SH(3) | CHANNELS_SH(1) | BYTES_SH(1);
const TYPE_GRAY_8_REV = COLORSPACE_SH(3) | CHANNELS_SH(1) | BYTES_SH(1) | FLAVOR_SH(1);
const TYPE_GRAY_16 = COLORSPACE_SH(3) | CHANNELS_SH(1) | BYTES_SH(2);
const TYPE_GRAY_16_REV = COLORSPACE_SH(3) | CHANNELS_SH(1) | BYTES_SH(2) | FLAVOR_SH(1);
const TYPE_GRAY_16_SE = COLORSPACE_SH(3) | CHANNELS_SH(1) | BYTES_SH(2) | ENDIAN16_SH(1);
const TYPE_GRAYA_8 = COLORSPACE_SH(3) | EXTRA_SH(1) | CHANNELS_SH(1) | BYTES_SH(1);
const TYPE_GRAYA_16 = COLORSPACE_SH(3) | EXTRA_SH(1) | CHANNELS_SH(1) | BYTES_SH(2);
const TYPE_GRAYA_16_SE = COLORSPACE_SH(3) | EXTRA_SH(1) | CHANNELS_SH(1) | BYTES_SH(2) | ENDIAN16_SH(1);
const TYPE_GRAYA_8_PLANAR = COLORSPACE_SH(3) | EXTRA_SH(1) | CHANNELS_SH(1) | BYTES_SH(1) | PLANAR_SH(1);
const TYPE_GRAYA_16_PLANAR = COLORSPACE_SH(3) | EXTRA_SH(1) | CHANNELS_SH(1) | BYTES_SH(2) | PLANAR_SH(1);
const TYPE_RGB_8 = COLORSPACE_SH(4) | CHANNELS_SH(3) | BYTES_SH(1);
const TYPE_RGB_8_PLANAR = COLORSPACE_SH(4) | CHANNELS_SH(3) | BYTES_SH(1) | PLANAR_SH(1);
const TYPE_BGR_8 = COLORSPACE_SH(4) | CHANNELS_SH(3) | BYTES_SH(1) | DOSWAP_SH(1);
const TYPE_BGR_8_PLANAR = COLORSPACE_SH(4) | CHANNELS_SH(3) | BYTES_SH(1) | DOSWAP_SH(1) | PLANAR_SH(1);
const TYPE_RGB_16 = COLORSPACE_SH(4) | CHANNELS_SH(3) | BYTES_SH(2);
const TYPE_RGB_16_PLANAR = COLORSPACE_SH(4) | CHANNELS_SH(3) | BYTES_SH(2) | PLANAR_SH(1);
const TYPE_RGB_16_SE = COLORSPACE_SH(4) | CHANNELS_SH(3) | BYTES_SH(2) | ENDIAN16_SH(1);
const TYPE_BGR_16 = COLORSPACE_SH(4) | CHANNELS_SH(3) | BYTES_SH(2) | DOSWAP_SH(1);
const TYPE_BGR_16_PLANAR = COLORSPACE_SH(4) | CHANNELS_SH(3) | BYTES_SH(2) | DOSWAP_SH(1) | PLANAR_SH(1);
const TYPE_BGR_16_SE = COLORSPACE_SH(4) | CHANNELS_SH(3) | BYTES_SH(2) | DOSWAP_SH(1) | ENDIAN16_SH(1);
const TYPE_RGBA_8 = COLORSPACE_SH(4) | EXTRA_SH(1) | CHANNELS_SH(3) | BYTES_SH(1);
const TYPE_RGBA_8_PLANAR = COLORSPACE_SH(4) | EXTRA_SH(1) | CHANNELS_SH(3) | BYTES_SH(1) | PLANAR_SH(1);
const TYPE_RGBA_16 = COLORSPACE_SH(4) | EXTRA_SH(1) | CHANNELS_SH(3) | BYTES_SH(2);
const TYPE_RGBA_16_PLANAR = COLORSPACE_SH(4) | EXTRA_SH(1) | CHANNELS_SH(3) | BYTES_SH(2) | PLANAR_SH(1);
const TYPE_RGBA_16_SE = COLORSPACE_SH(4) | EXTRA_SH(1) | CHANNELS_SH(3) | BYTES_SH(2) | ENDIAN16_SH(1);
const TYPE_ARGB_8 = COLORSPACE_SH(4) | EXTRA_SH(1) | CHANNELS_SH(3) | BYTES_SH(1) | SWAPFIRST_SH(1);
const TYPE_ARGB_8_PLANAR = COLORSPACE_SH(4) | EXTRA_SH(1) | CHANNELS_SH(3) | BYTES_SH(1) | SWAPFIRST_SH(1) | PLANAR_SH(1);
const TYPE_ARGB_16 = COLORSPACE_SH(4) | EXTRA_SH(1) | CHANNELS_SH(3) | BYTES_SH(2) | SWAPFIRST_SH(1);
const TYPE_ABGR_8 = COLORSPACE_SH(4) | EXTRA_SH(1) | CHANNELS_SH(3) | BYTES_SH(1) | DOSWAP_SH(1);
const TYPE_ABGR_8_PLANAR = COLORSPACE_SH(4) | EXTRA_SH(1) | CHANNELS_SH(3) | BYTES_SH(1) | DOSWAP_SH(1) | PLANAR_SH(1);
const TYPE_ABGR_16 = COLORSPACE_SH(4) | EXTRA_SH(1) | CHANNELS_SH(3) | BYTES_SH(2) | DOSWAP_SH(1);
const TYPE_ABGR_16_PLANAR = COLORSPACE_SH(4) | EXTRA_SH(1) | CHANNELS_SH(3) | BYTES_SH(2) | DOSWAP_SH(1) | PLANAR_SH(1);
const TYPE_ABGR_16_SE = COLORSPACE_SH(4) | EXTRA_SH(1) | CHANNELS_SH(3) | BYTES_SH(2) | DOSWAP_SH(1) | ENDIAN16_SH(1);
const TYPE_BGRA_8 = COLORSPACE_SH(4) | EXTRA_SH(1) | CHANNELS_SH(3) | BYTES_SH(1) | DOSWAP_SH(1) | SWAPFIRST_SH(1);
const TYPE_BGRA_8_PLANAR = COLORSPACE_SH(4) | EXTRA_SH(1) | CHANNELS_SH(3) | BYTES_SH(1) | DOSWAP_SH(1) | SWAPFIRST_SH(1) | PLANAR_SH(1);
const TYPE_BGRA_16 = COLORSPACE_SH(4) | EXTRA_SH(1) | CHANNELS_SH(3) | BYTES_SH(2) | DOSWAP_SH(1) | SWAPFIRST_SH(1);
const TYPE_BGRA_16_SE = COLORSPACE_SH(4) | EXTRA_SH(1) | CHANNELS_SH(3) | BYTES_SH(2) | ENDIAN16_SH(1) | DOSWAP_SH(1) | SWAPFIRST_SH(1);
const TYPE_CMY_8 = COLORSPACE_SH(5) | CHANNELS_SH(3) | BYTES_SH(1);
const TYPE_CMY_8_PLANAR = COLORSPACE_SH(5) | CHANNELS_SH(3) | BYTES_SH(1) | PLANAR_SH(1);
const TYPE_CMY_16 = COLORSPACE_SH(5) | CHANNELS_SH(3) | BYTES_SH(2);
const TYPE_CMY_16_PLANAR = COLORSPACE_SH(5) | CHANNELS_SH(3) | BYTES_SH(2) | PLANAR_SH(1);
const TYPE_CMY_16_SE = COLORSPACE_SH(5) | CHANNELS_SH(3) | BYTES_SH(2) | ENDIAN16_SH(1);
const TYPE_CMYK_8 = COLORSPACE_SH(6) | CHANNELS_SH(4) | BYTES_SH(1);
const TYPE_CMYKA_8 = COLORSPACE_SH(6) | EXTRA_SH(1) | CHANNELS_SH(4) | BYTES_SH(1);
const TYPE_CMYK_8_REV = COLORSPACE_SH(6) | CHANNELS_SH(4) | BYTES_SH(1) | FLAVOR_SH(1);
const TYPE_YUVK_8 = TYPE_CMYK_8_REV;
const TYPE_CMYK_8_PLANAR = COLORSPACE_SH(6) | CHANNELS_SH(4) | BYTES_SH(1) | PLANAR_SH(1);
const TYPE_CMYK_16 = COLORSPACE_SH(6) | CHANNELS_SH(4) | BYTES_SH(2);
const TYPE_CMYK_16_REV = COLORSPACE_SH(6) | CHANNELS_SH(4) | BYTES_SH(2) | FLAVOR_SH(1);
const TYPE_YUVK_16 = TYPE_CMYK_16_REV;
const TYPE_CMYK_16_PLANAR = COLORSPACE_SH(6) | CHANNELS_SH(4) | BYTES_SH(2) | PLANAR_SH(1);
const TYPE_CMYK_16_SE = COLORSPACE_SH(6) | CHANNELS_SH(4) | BYTES_SH(2) | ENDIAN16_SH(1);
const TYPE_KYMC_8 = COLORSPACE_SH(6) | CHANNELS_SH(4) | BYTES_SH(1) | DOSWAP_SH(1);
const TYPE_KYMC_16 = COLORSPACE_SH(6) | CHANNELS_SH(4) | BYTES_SH(2) | DOSWAP_SH(1);
const TYPE_KYMC_16_SE = COLORSPACE_SH(6) | CHANNELS_SH(4) | BYTES_SH(2) | DOSWAP_SH(1) | ENDIAN16_SH(1);
const TYPE_KCMY_8 = COLORSPACE_SH(6) | CHANNELS_SH(4) | BYTES_SH(1) | SWAPFIRST_SH(1);
const TYPE_KCMY_8_REV = COLORSPACE_SH(6) | CHANNELS_SH(4) | BYTES_SH(1) | FLAVOR_SH(1) | SWAPFIRST_SH(1);
const TYPE_KCMY_16 = COLORSPACE_SH(6) | CHANNELS_SH(4) | BYTES_SH(2) | SWAPFIRST_SH(1);
const TYPE_KCMY_16_REV = COLORSPACE_SH(6) | CHANNELS_SH(4) | BYTES_SH(2) | FLAVOR_SH(1) | SWAPFIRST_SH(1);
const TYPE_KCMY_16_SE = COLORSPACE_SH(6) | CHANNELS_SH(4) | BYTES_SH(2) | ENDIAN16_SH(1) | SWAPFIRST_SH(1);
const TYPE_CMYK5_8 = COLORSPACE_SH(19) | CHANNELS_SH(5) | BYTES_SH(1);
const TYPE_CMYK5_16 = COLORSPACE_SH(19) | CHANNELS_SH(5) | BYTES_SH(2);
const TYPE_CMYK5_16_SE = COLORSPACE_SH(19) | CHANNELS_SH(5) | BYTES_SH(2) | ENDIAN16_SH(1);
const TYPE_KYMC5_8 = COLORSPACE_SH(19) | CHANNELS_SH(5) | BYTES_SH(1) | DOSWAP_SH(1);
const TYPE_KYMC5_16 = COLORSPACE_SH(19) | CHANNELS_SH(5) | BYTES_SH(2) | DOSWAP_SH(1);
const TYPE_KYMC5_16_SE = COLORSPACE_SH(19) | CHANNELS_SH(5) | BYTES_SH(2) | DOSWAP_SH(1) | ENDIAN16_SH(1);
const TYPE_CMYK6_8 = COLORSPACE_SH(20) | CHANNELS_SH(6) | BYTES_SH(1);
const TYPE_CMYK6_8_PLANAR = COLORSPACE_SH(20) | CHANNELS_SH(6) | BYTES_SH(1) | PLANAR_SH(1);
const TYPE_CMYK6_16 = COLORSPACE_SH(20) | CHANNELS_SH(6) | BYTES_SH(2);
const TYPE_CMYK6_16_PLANAR = COLORSPACE_SH(20) | CHANNELS_SH(6) | BYTES_SH(2) | PLANAR_SH(1);
const TYPE_CMYK6_16_SE = COLORSPACE_SH(20) | CHANNELS_SH(6) | BYTES_SH(2) | ENDIAN16_SH(1);
const TYPE_CMYK7_8 = COLORSPACE_SH(21) | CHANNELS_SH(7) | BYTES_SH(1);
const TYPE_CMYK7_16 = COLORSPACE_SH(21) | CHANNELS_SH(7) | BYTES_SH(2);
const TYPE_CMYK7_16_SE = COLORSPACE_SH(21) | CHANNELS_SH(7) | BYTES_SH(2) | ENDIAN16_SH(1);
const TYPE_KYMC7_8 = COLORSPACE_SH(21) | CHANNELS_SH(7) | BYTES_SH(1) | DOSWAP_SH(1);
const TYPE_KYMC7_16 = COLORSPACE_SH(21) | CHANNELS_SH(7) | BYTES_SH(2) | DOSWAP_SH(1);
const TYPE_KYMC7_16_SE = COLORSPACE_SH(21) | CHANNELS_SH(7) | BYTES_SH(2) | DOSWAP_SH(1) | ENDIAN16_SH(1);
const TYPE_CMYK8_8 = COLORSPACE_SH(22) | CHANNELS_SH(8) | BYTES_SH(1);
const TYPE_CMYK8_16 = COLORSPACE_SH(22) | CHANNELS_SH(8) | BYTES_SH(2);
const TYPE_CMYK8_16_SE = COLORSPACE_SH(22) | CHANNELS_SH(8) | BYTES_SH(2) | ENDIAN16_SH(1);
const TYPE_KYMC8_8 = COLORSPACE_SH(22) | CHANNELS_SH(8) | BYTES_SH(1) | DOSWAP_SH(1);
const TYPE_KYMC8_16 = COLORSPACE_SH(22) | CHANNELS_SH(8) | BYTES_SH(2) | DOSWAP_SH(1);
const TYPE_KYMC8_16_SE = COLORSPACE_SH(22) | CHANNELS_SH(8) | BYTES_SH(2) | DOSWAP_SH(1) | ENDIAN16_SH(1);
const TYPE_CMYK9_8 = COLORSPACE_SH(23) | CHANNELS_SH(9) | BYTES_SH(1);
const TYPE_CMYK9_16 = COLORSPACE_SH(23) | CHANNELS_SH(9) | BYTES_SH(2);
const TYPE_CMYK9_16_SE = COLORSPACE_SH(23) | CHANNELS_SH(9) | BYTES_SH(2) | ENDIAN16_SH(1);
const TYPE_KYMC9_8 = COLORSPACE_SH(23) | CHANNELS_SH(9) | BYTES_SH(1) | DOSWAP_SH(1);
const TYPE_KYMC9_16 = COLORSPACE_SH(23) | CHANNELS_SH(9) | BYTES_SH(2) | DOSWAP_SH(1);
const TYPE_KYMC9_16_SE = COLORSPACE_SH(23) | CHANNELS_SH(9) | BYTES_SH(2) | DOSWAP_SH(1) | ENDIAN16_SH(1);
const TYPE_CMYK10_8 = COLORSPACE_SH(24) | CHANNELS_SH(10) | BYTES_SH(1);
const TYPE_CMYK10_16 = COLORSPACE_SH(24) | CHANNELS_SH(10) | BYTES_SH(2);
const TYPE_CMYK10_16_SE = COLORSPACE_SH(24) | CHANNELS_SH(10) | BYTES_SH(2) | ENDIAN16_SH(1);
const TYPE_KYMC10_8 = COLORSPACE_SH(24) | CHANNELS_SH(10) | BYTES_SH(1) | DOSWAP_SH(1);
const TYPE_KYMC10_16 = COLORSPACE_SH(24) | CHANNELS_SH(10) | BYTES_SH(2) | DOSWAP_SH(1);
const TYPE_KYMC10_16_SE = COLORSPACE_SH(24) | CHANNELS_SH(10) | BYTES_SH(2) | DOSWAP_SH(1) | ENDIAN16_SH(1);
const TYPE_CMYK11_8 = COLORSPACE_SH(25) | CHANNELS_SH(11) | BYTES_SH(1);
const TYPE_CMYK11_16 = COLORSPACE_SH(25) | CHANNELS_SH(11) | BYTES_SH(2);
const TYPE_CMYK11_16_SE = COLORSPACE_SH(25) | CHANNELS_SH(11) | BYTES_SH(2) | ENDIAN16_SH(1);
const TYPE_KYMC11_8 = COLORSPACE_SH(25) | CHANNELS_SH(11) | BYTES_SH(1) | DOSWAP_SH(1);
const TYPE_KYMC11_16 = COLORSPACE_SH(25) | CHANNELS_SH(11) | BYTES_SH(2) | DOSWAP_SH(1);
const TYPE_KYMC11_16_SE = COLORSPACE_SH(25) | CHANNELS_SH(11) | BYTES_SH(2) | DOSWAP_SH(1) | ENDIAN16_SH(1);
const TYPE_CMYK12_8 = COLORSPACE_SH(26) | CHANNELS_SH(12) | BYTES_SH(1);
const TYPE_CMYK12_16 = COLORSPACE_SH(26) | CHANNELS_SH(12) | BYTES_SH(2);
const TYPE_CMYK12_16_SE = COLORSPACE_SH(26) | CHANNELS_SH(12) | BYTES_SH(2) | ENDIAN16_SH(1);
const TYPE_KYMC12_8 = COLORSPACE_SH(26) | CHANNELS_SH(12) | BYTES_SH(1) | DOSWAP_SH(1);
const TYPE_KYMC12_16 = COLORSPACE_SH(26) | CHANNELS_SH(12) | BYTES_SH(2) | DOSWAP_SH(1);
const TYPE_KYMC12_16_SE = COLORSPACE_SH(26) | CHANNELS_SH(12) | BYTES_SH(2) | DOSWAP_SH(1) | ENDIAN16_SH(1);
const TYPE_XYZ_16 = COLORSPACE_SH(9) | CHANNELS_SH(3) | BYTES_SH(2);
const TYPE_Lab_8 = COLORSPACE_SH(10) | CHANNELS_SH(3) | BYTES_SH(1);
const TYPE_LabV2_8 = COLORSPACE_SH(30) | CHANNELS_SH(3) | BYTES_SH(1);
const TYPE_ALab_8 = COLORSPACE_SH(10) | CHANNELS_SH(3) | BYTES_SH(1) | EXTRA_SH(1) | SWAPFIRST_SH(1);
const TYPE_ALabV2_8 = COLORSPACE_SH(30) | CHANNELS_SH(3) | BYTES_SH(1) | EXTRA_SH(1) | SWAPFIRST_SH(1);
const TYPE_Lab_16 = COLORSPACE_SH(10) | CHANNELS_SH(3) | BYTES_SH(2);
const TYPE_LabV2_16 = COLORSPACE_SH(30) | CHANNELS_SH(3) | BYTES_SH(2);
const TYPE_Yxy_16 = COLORSPACE_SH(14) | CHANNELS_SH(3) | BYTES_SH(2);
const TYPE_XYZ_DBL = FLOAT_SH(1) | COLORSPACE_SH(9) | CHANNELS_SH(3) | BYTES_SH(0);
const TYPE_Lab_DBL = FLOAT_SH(1) | COLORSPACE_SH(10) | CHANNELS_SH(3) | BYTES_SH(0);
const TYPE_GRAY_DBL = FLOAT_SH(1) | COLORSPACE_SH(3) | CHANNELS_SH(1) | BYTES_SH(0);
const TYPE_RGB_DBL = FLOAT_SH(1) | COLORSPACE_SH(4) | CHANNELS_SH(3) | BYTES_SH(0);
const TYPE_BGR_DBL = FLOAT_SH(1) | COLORSPACE_SH(4) | CHANNELS_SH(3) | BYTES_SH(0) | DOSWAP_SH(1);
const TYPE_CMYK_DBL = FLOAT_SH(1) | COLORSPACE_SH(6) | CHANNELS_SH(4) | BYTES_SH(0);
const cmsFLAGS_GAMUTCHECK = 4096;
const cmsFLAGS_SOFTPROOFING = 16384;
const cmsFLAGS_BLACKPOINTCOMPENSATION = 8192;
const cmsFLAGS_HIGHRESPRECALC = 1024;
const cmsFLAGS_LOWRESPRECALC = 2048;
const cmsFLAGS_COPY_ALPHA = 67108864;
var instantiate = (() => {
	var _scriptDir = import.meta.url;
	return (async function(moduleArg = {}) {
		var Module = moduleArg;
		var readyPromiseResolve, readyPromiseReject;
		Module["ready"] = new Promise((resolve, reject) => {
			readyPromiseResolve = resolve;
			readyPromiseReject = reject;
		});
		[
			"_free",
			"_malloc",
			"_cmsXYZ2xyY",
			"_cmsReadTag",
			"_cmsGetHeaderRenderingIntent",
			"_cmsGetTransformOutputFormat",
			"_cmsGetTransformInputFormat",
			"_cmsDoTransform",
			"_cmsDeleteTransform",
			"_cmsCreateProofingTransform",
			"_cmsCreateTransform",
			"_cmsFormatterForColorspaceOfProfile",
			"_cmsGetColorSpace",
			"_cmsGetProfileInfoASCII",
			"_cmsCreateLab4Profile",
			"_cmsCreateXYZProfile",
			"_cmsCreate_sRGBProfile",
			"_cmsCloseProfile",
			"_cmsOpenProfileFromMem",
			"getExceptionMessage",
			"$incrementExceptionRefcount",
			"$decrementExceptionRefcount",
			"_memory",
			"___indirect_function_table",
			"onRuntimeInitialized"
		].forEach((prop) => {
			if (!Object.getOwnPropertyDescriptor(Module["ready"], prop)) Object.defineProperty(Module["ready"], prop, {
				get: () => abort("You are getting " + prop + " on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js"),
				set: () => abort("You are setting " + prop + " on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js")
			});
		});
		var moduleOverrides = Object.assign({}, Module);
		var ENVIRONMENT_IS_WEB = typeof window == "object";
		var ENVIRONMENT_IS_WORKER = typeof importScripts == "function";
		var ENVIRONMENT_IS_NODE = typeof process == "object" && typeof process.versions == "object" && typeof process.versions.node == "string";
		var ENVIRONMENT_IS_SHELL = !ENVIRONMENT_IS_WEB && !ENVIRONMENT_IS_NODE && !ENVIRONMENT_IS_WORKER;
		if (Module["ENVIRONMENT"]) throw new Error("Module.ENVIRONMENT has been deprecated. To force the environment, use the ENVIRONMENT compile-time option (for example, -sENVIRONMENT=web or -sENVIRONMENT=node)");
		var scriptDirectory = "";
		function locateFile(path) {
			if (Module["locateFile"]) return Module["locateFile"](path, scriptDirectory);
			return scriptDirectory + path;
		}
		var read_, readBinary;
		if (ENVIRONMENT_IS_NODE) {
			if (typeof process == "undefined" || !process.release || process.release.name !== "node") throw new Error("not compiled for this environment (did you build to HTML and try to run it not on the web, or set ENVIRONMENT to something - like node - and run it someplace else - like on the web?)");
			var nodeVersion = process.versions.node;
			var numericVersion = nodeVersion.split(".").slice(0, 3);
			numericVersion = numericVersion[0] * 1e4 + numericVersion[1] * 100 + numericVersion[2].split("-")[0] * 1;
			if (numericVersion < 16e4) throw new Error("This emscripten-generated code requires node v16.0.0 (detected v" + nodeVersion + ")");
			const { createRequire } = await import("module");
			var require = createRequire(import.meta.url);
			var fs = require("fs");
			var nodePath = require("path");
			if (ENVIRONMENT_IS_WORKER) scriptDirectory = nodePath.dirname(scriptDirectory) + "/";
			else scriptDirectory = require("url").fileURLToPath(new URL("./", import.meta.url));
			read_ = (filename, binary) => {
				filename = isFileURI(filename) ? new URL(filename) : nodePath.normalize(filename);
				return fs.readFileSync(filename, binary ? void 0 : "utf8");
			};
			readBinary = (filename) => {
				var ret = read_(filename, true);
				if (!ret.buffer) ret = new Uint8Array(ret);
				assert(ret.buffer);
				return ret;
			};
			if (!Module["thisProgram"] && process.argv.length > 1) process.argv[1].replace(/\\/g, "/");
			process.argv.slice(2);
		} else if (ENVIRONMENT_IS_SHELL) {
			if (typeof process == "object" && typeof require === "function" || typeof window == "object" || typeof importScripts == "function") throw new Error("not compiled for this environment (did you build to HTML and try to run it not on the web, or set ENVIRONMENT to something - like node - and run it someplace else - like on the web?)");
			if (typeof read != "undefined") read_ = read;
			readBinary = (f) => {
				if (typeof readbuffer == "function") return new Uint8Array(readbuffer(f));
				let data = read(f, "binary");
				assert(typeof data == "object");
				return data;
			};
			if (typeof clearTimeout == "undefined") globalThis.clearTimeout = (id) => {};
			if (typeof setTimeout == "undefined") globalThis.setTimeout = (f) => typeof f == "function" ? f() : abort();
			if (typeof scriptArgs != "undefined") scriptArgs;
			else if (typeof arguments != "undefined") arguments;
			if (typeof quit == "function") {}
			if (typeof print != "undefined") {
				if (typeof console == "undefined") console = {};
				console.log = print;
				console.warn = console.error = typeof printErr != "undefined" ? printErr : print;
			}
		} else if (ENVIRONMENT_IS_WEB || ENVIRONMENT_IS_WORKER) {
			if (ENVIRONMENT_IS_WORKER) scriptDirectory = self.location.href;
			else if (typeof document != "undefined" && document.currentScript) scriptDirectory = document.currentScript.src;
			if (_scriptDir) scriptDirectory = _scriptDir;
			if (scriptDirectory.startsWith("blob:")) scriptDirectory = "";
			else scriptDirectory = scriptDirectory.substr(0, scriptDirectory.replace(/[?#].*/, "").lastIndexOf("/") + 1);
			if (!(typeof window == "object" || typeof importScripts == "function")) throw new Error("not compiled for this environment (did you build to HTML and try to run it not on the web, or set ENVIRONMENT to something - like node - and run it someplace else - like on the web?)");
			read_ = (url) => {
				var xhr = new XMLHttpRequest();
				xhr.open("GET", url, false);
				xhr.send(null);
				return xhr.responseText;
			};
			if (ENVIRONMENT_IS_WORKER) readBinary = (url) => {
				var xhr = new XMLHttpRequest();
				xhr.open("GET", url, false);
				xhr.responseType = "arraybuffer";
				xhr.send(null);
				return new Uint8Array(xhr.response);
			};
		} else throw new Error("environment detection error");
		var out = Module["print"] || console.log.bind(console);
		var err = Module["printErr"] || console.error.bind(console);
		Object.assign(Module, moduleOverrides);
		moduleOverrides = null;
		checkIncomingModuleAPI();
		if (Module["arguments"]) Module["arguments"];
		legacyModuleProp("arguments", "arguments_");
		if (Module["thisProgram"]) Module["thisProgram"];
		legacyModuleProp("thisProgram", "thisProgram");
		if (Module["quit"]) Module["quit"];
		legacyModuleProp("quit", "quit_");
		assert(typeof Module["memoryInitializerPrefixURL"] == "undefined", "Module.memoryInitializerPrefixURL option was removed, use Module.locateFile instead");
		assert(typeof Module["pthreadMainPrefixURL"] == "undefined", "Module.pthreadMainPrefixURL option was removed, use Module.locateFile instead");
		assert(typeof Module["cdInitializerPrefixURL"] == "undefined", "Module.cdInitializerPrefixURL option was removed, use Module.locateFile instead");
		assert(typeof Module["filePackagePrefixURL"] == "undefined", "Module.filePackagePrefixURL option was removed, use Module.locateFile instead");
		assert(typeof Module["read"] == "undefined", "Module.read option was removed (modify read_ in JS)");
		assert(typeof Module["readAsync"] == "undefined", "Module.readAsync option was removed (modify readAsync in JS)");
		assert(typeof Module["readBinary"] == "undefined", "Module.readBinary option was removed (modify readBinary in JS)");
		assert(typeof Module["setWindowTitle"] == "undefined", "Module.setWindowTitle option was removed (modify emscripten_set_window_title in JS)");
		assert(typeof Module["TOTAL_MEMORY"] == "undefined", "Module.TOTAL_MEMORY has been renamed Module.INITIAL_MEMORY");
		legacyModuleProp("asm", "wasmExports");
		legacyModuleProp("read", "read_");
		legacyModuleProp("readAsync", "readAsync");
		legacyModuleProp("readBinary", "readBinary");
		legacyModuleProp("setWindowTitle", "setWindowTitle");
		assert(!ENVIRONMENT_IS_SHELL, "shell environment detected but not enabled at build time.  Add `shell` to `-sENVIRONMENT` to enable.");
		var wasmBinary;
		if (Module["wasmBinary"]) wasmBinary = Module["wasmBinary"];
		legacyModuleProp("wasmBinary", "wasmBinary");
		if (typeof WebAssembly != "object") abort("no native wasm support detected");
		var wasmMemory;
		var ABORT = false;
		function assert(condition, text) {
			if (!condition) abort("Assertion failed" + (text ? ": " + text : ""));
		}
		var HEAP8, HEAPU8, HEAP16, HEAP32, HEAPU32, HEAPF32, HEAPF64;
		function updateMemoryViews() {
			var b = wasmMemory.buffer;
			Module["HEAP8"] = HEAP8 = new Int8Array(b);
			Module["HEAP16"] = HEAP16 = new Int16Array(b);
			Module["HEAPU8"] = HEAPU8 = new Uint8Array(b);
			Module["HEAPU16"] = new Uint16Array(b);
			Module["HEAP32"] = HEAP32 = new Int32Array(b);
			Module["HEAPU32"] = HEAPU32 = new Uint32Array(b);
			Module["HEAPF32"] = HEAPF32 = new Float32Array(b);
			Module["HEAPF64"] = HEAPF64 = new Float64Array(b);
		}
		assert(!Module["STACK_SIZE"], "STACK_SIZE can no longer be set at runtime.  Use -sSTACK_SIZE at link time");
		assert(typeof Int32Array != "undefined" && typeof Float64Array !== "undefined" && Int32Array.prototype.subarray != void 0 && Int32Array.prototype.set != void 0, "JS engine does not provide full typed array support");
		assert(!Module["wasmMemory"], "Use of `wasmMemory` detected.  Use -sIMPORTED_MEMORY to define wasmMemory externally");
		assert(!Module["INITIAL_MEMORY"], "Detected runtime INITIAL_MEMORY setting.  Use -sIMPORTED_MEMORY to define wasmMemory dynamically");
		function writeStackCookie() {
			var max = _emscripten_stack_get_end();
			assert((max & 3) == 0);
			if (max == 0) max += 4;
			HEAPU32[max >> 2] = 34821223;
			HEAPU32[max + 4 >> 2] = 2310721022;
			HEAPU32[0] = 1668509029;
		}
		function checkStackCookie() {
			if (ABORT) return;
			var max = _emscripten_stack_get_end();
			if (max == 0) max += 4;
			var cookie1 = HEAPU32[max >> 2];
			var cookie2 = HEAPU32[max + 4 >> 2];
			if (cookie1 != 34821223 || cookie2 != 2310721022) abort(`Stack overflow! Stack cookie has been overwritten at ${ptrToString(max)}, expected hex dwords 0x89BACDFE and 0x2135467, but received ${ptrToString(cookie2)} ${ptrToString(cookie1)}`);
			if (HEAPU32[0] != 1668509029) abort("Runtime error: The application has corrupted its heap memory area (address zero)!");
		}
		(function() {
			var h16 = new Int16Array(1);
			var h8 = new Int8Array(h16.buffer);
			h16[0] = 25459;
			if (h8[0] !== 115 || h8[1] !== 99) throw "Runtime error: expected the system to be little-endian! (Run with -sSUPPORT_BIG_ENDIAN to bypass)";
		})();
		var __ATPRERUN__ = [];
		var __ATINIT__ = [];
		var __ATPOSTRUN__ = [];
		var runtimeInitialized = false;
		function preRun() {
			if (Module["preRun"]) {
				if (typeof Module["preRun"] == "function") Module["preRun"] = [Module["preRun"]];
				while (Module["preRun"].length) addOnPreRun(Module["preRun"].shift());
			}
			callRuntimeCallbacks(__ATPRERUN__);
		}
		function initRuntime() {
			assert(!runtimeInitialized);
			runtimeInitialized = true;
			checkStackCookie();
			callRuntimeCallbacks(__ATINIT__);
		}
		function postRun() {
			checkStackCookie();
			if (Module["postRun"]) {
				if (typeof Module["postRun"] == "function") Module["postRun"] = [Module["postRun"]];
				while (Module["postRun"].length) addOnPostRun(Module["postRun"].shift());
			}
			callRuntimeCallbacks(__ATPOSTRUN__);
		}
		function addOnPreRun(cb) {
			__ATPRERUN__.unshift(cb);
		}
		function addOnInit(cb) {
			__ATINIT__.unshift(cb);
		}
		function addOnPostRun(cb) {
			__ATPOSTRUN__.unshift(cb);
		}
		assert(Math.imul, "This browser does not support Math.imul(), build with LEGACY_VM_SUPPORT or POLYFILL_OLD_MATH_FUNCTIONS to add in a polyfill");
		assert(Math.fround, "This browser does not support Math.fround(), build with LEGACY_VM_SUPPORT or POLYFILL_OLD_MATH_FUNCTIONS to add in a polyfill");
		assert(Math.clz32, "This browser does not support Math.clz32(), build with LEGACY_VM_SUPPORT or POLYFILL_OLD_MATH_FUNCTIONS to add in a polyfill");
		assert(Math.trunc, "This browser does not support Math.trunc(), build with LEGACY_VM_SUPPORT or POLYFILL_OLD_MATH_FUNCTIONS to add in a polyfill");
		var runDependencies = 0;
		var runDependencyWatcher = null;
		var dependenciesFulfilled = null;
		var runDependencyTracking = {};
		function addRunDependency(id) {
			runDependencies++;
			Module["monitorRunDependencies"]?.(runDependencies);
			if (id) {
				assert(!runDependencyTracking[id]);
				runDependencyTracking[id] = 1;
				if (runDependencyWatcher === null && typeof setInterval != "undefined") runDependencyWatcher = setInterval(() => {
					if (ABORT) {
						clearInterval(runDependencyWatcher);
						runDependencyWatcher = null;
						return;
					}
					var shown = false;
					for (var dep in runDependencyTracking) {
						if (!shown) {
							shown = true;
							err("still waiting on run dependencies:");
						}
						err(`dependency: ${dep}`);
					}
					if (shown) err("(end of list)");
				}, 1e4);
			} else err("warning: run dependency added without ID");
		}
		function removeRunDependency(id) {
			runDependencies--;
			Module["monitorRunDependencies"]?.(runDependencies);
			if (id) {
				assert(runDependencyTracking[id]);
				delete runDependencyTracking[id];
			} else err("warning: run dependency removed without ID");
			if (runDependencies == 0) {
				if (runDependencyWatcher !== null) {
					clearInterval(runDependencyWatcher);
					runDependencyWatcher = null;
				}
				if (dependenciesFulfilled) {
					var callback = dependenciesFulfilled;
					dependenciesFulfilled = null;
					callback();
				}
			}
		}
		function abort(what) {
			Module["onAbort"]?.(what);
			what = "Aborted(" + what + ")";
			err(what);
			ABORT = true;
			var e = new WebAssembly.RuntimeError(what);
			readyPromiseReject(e);
			throw e;
		}
		var FS = {
			error() {
				abort("Filesystem support (FS) was not included. The problem is that you are using files from JS, but files were not used from C/C++, so filesystem support was not auto-included. You can force-include filesystem support with -sFORCE_FILESYSTEM");
			},
			init() {
				FS.error();
			},
			createDataFile() {
				FS.error();
			},
			createPreloadedFile() {
				FS.error();
			},
			createLazyFile() {
				FS.error();
			},
			open() {
				FS.error();
			},
			mkdev() {
				FS.error();
			},
			registerDevice() {
				FS.error();
			},
			analyzePath() {
				FS.error();
			},
			ErrnoError() {
				FS.error();
			}
		};
		Module["FS_createDataFile"] = FS.createDataFile;
		Module["FS_createPreloadedFile"] = FS.createPreloadedFile;
		var dataURIPrefix = "data:application/octet-stream;base64,";
		var isDataURI = (filename) => filename.startsWith(dataURIPrefix);
		var isFileURI = (filename) => filename.startsWith("file://");
		function createExportWrapper(name) {
			return function() {
				assert(runtimeInitialized, `native function \`${name}\` called before runtime initialization`);
				var f = wasmExports[name];
				assert(f, `exported native function \`${name}\` not found`);
				return f.apply(null, arguments);
			};
		}
		class EmscriptenEH extends Error {}
		class CppException extends EmscriptenEH {
			constructor(excPtr) {
				super(excPtr);
				this.excPtr = excPtr;
				const excInfo = getExceptionMessage(excPtr);
				this.name = excInfo[0];
				this.message = excInfo[1];
			}
		}
		var wasmBinaryFile;
		if (Module["locateFile"]) {
			wasmBinaryFile = "lcms.wasm";
			if (!isDataURI(wasmBinaryFile)) wasmBinaryFile = locateFile(wasmBinaryFile);
		} else wasmBinaryFile = new URL("lcms.wasm", import.meta.url).href;
		function getBinarySync(file) {
			if (file == wasmBinaryFile && wasmBinary) return new Uint8Array(wasmBinary);
			if (readBinary) return readBinary(file);
			throw "both async and sync fetching of the wasm failed";
		}
		function getBinaryPromise(binaryFile) {
			if (!wasmBinary && (ENVIRONMENT_IS_WEB || ENVIRONMENT_IS_WORKER)) {
				if (typeof fetch == "function") return fetch(binaryFile, { credentials: "same-origin" }).then((response) => {
					if (!response["ok"]) throw `failed to load wasm binary file at '${binaryFile}'`;
					return response["arrayBuffer"]();
				}).catch(() => getBinarySync(binaryFile));
			}
			return Promise.resolve().then(() => getBinarySync(binaryFile));
		}
		function instantiateArrayBuffer(binaryFile, imports, receiver) {
			return getBinaryPromise(binaryFile).then((binary) => WebAssembly.instantiate(binary, imports)).then((instance) => instance).then(receiver, (reason) => {
				err(`failed to asynchronously prepare wasm: ${reason}`);
				if (isFileURI(wasmBinaryFile)) err(`warning: Loading from a file URI (${wasmBinaryFile}) is not supported in most browsers. See https://emscripten.org/docs/getting_started/FAQ.html#how-do-i-run-a-local-webserver-for-testing-why-does-my-program-stall-in-downloading-or-preparing`);
				abort(reason);
			});
		}
		function instantiateAsync(binary, binaryFile, imports, callback) {
			if (!binary && typeof WebAssembly.instantiateStreaming == "function" && !isDataURI(binaryFile) && !ENVIRONMENT_IS_NODE && typeof fetch == "function") return fetch(binaryFile, { credentials: "same-origin" }).then((response) => {
				return WebAssembly.instantiateStreaming(response, imports).then(callback, function(reason) {
					err(`wasm streaming compile failed: ${reason}`);
					err("falling back to ArrayBuffer instantiation");
					return instantiateArrayBuffer(binaryFile, imports, callback);
				});
			});
			return instantiateArrayBuffer(binaryFile, imports, callback);
		}
		function createWasm() {
			var info = {
				"env": wasmImports,
				"wasi_snapshot_preview1": wasmImports
			};
			function receiveInstance(instance, module) {
				wasmExports = instance.exports;
				wasmMemory = wasmExports["memory"];
				assert(wasmMemory, "memory not found in wasm exports");
				updateMemoryViews();
				wasmTable = wasmExports["__indirect_function_table"];
				assert(wasmTable, "table not found in wasm exports");
				addOnInit(wasmExports["__wasm_call_ctors"]);
				removeRunDependency("wasm-instantiate");
				return wasmExports;
			}
			addRunDependency("wasm-instantiate");
			var trueModule = Module;
			function receiveInstantiationResult(result) {
				assert(Module === trueModule, "the Module object should not be replaced during async compilation - perhaps the order of HTML elements is wrong?");
				trueModule = null;
				receiveInstance(result["instance"]);
			}
			if (Module["instantiateWasm"]) try {
				return Module["instantiateWasm"](info, receiveInstance);
			} catch (e) {
				err(`Module.instantiateWasm callback failed with error: ${e}`);
				readyPromiseReject(e);
			}
			instantiateAsync(wasmBinary, wasmBinaryFile, info, receiveInstantiationResult).catch(readyPromiseReject);
			return {};
		}
		function legacyModuleProp(prop, newName, incomming = true) {
			if (!Object.getOwnPropertyDescriptor(Module, prop)) Object.defineProperty(Module, prop, {
				configurable: true,
				get() {
					let extra = incomming ? " (the initial value can be provided on Module, but after startup the value is only looked for on a local variable of that name)" : "";
					abort(`\`Module.${prop}\` has been replaced by \`${newName}\`` + extra);
				}
			});
		}
		function ignoredModuleProp(prop) {
			if (Object.getOwnPropertyDescriptor(Module, prop)) abort(`\`Module.${prop}\` was supplied but \`${prop}\` not included in INCOMING_MODULE_JS_API`);
		}
		function isExportedByForceFilesystem(name) {
			return name === "FS_createPath" || name === "FS_createDataFile" || name === "FS_createPreloadedFile" || name === "FS_unlink" || name === "addRunDependency" || name === "FS_createLazyFile" || name === "FS_createDevice" || name === "removeRunDependency";
		}
		function missingGlobal(sym, msg) {
			if (typeof globalThis !== "undefined") Object.defineProperty(globalThis, sym, {
				configurable: true,
				get() {
					warnOnce(`\`${sym}\` is not longer defined by emscripten. ${msg}`);
				}
			});
		}
		missingGlobal("buffer", "Please use HEAP8.buffer or wasmMemory.buffer");
		missingGlobal("asm", "Please use wasmExports instead");
		function missingLibrarySymbol(sym) {
			if (typeof globalThis !== "undefined" && !Object.getOwnPropertyDescriptor(globalThis, sym)) Object.defineProperty(globalThis, sym, {
				configurable: true,
				get() {
					var msg = `\`${sym}\` is a library symbol and not included by default; add it to your library.js __deps or to DEFAULT_LIBRARY_FUNCS_TO_INCLUDE on the command line`;
					var librarySymbol = sym;
					if (!librarySymbol.startsWith("_")) librarySymbol = "$" + sym;
					msg += ` (e.g. -sDEFAULT_LIBRARY_FUNCS_TO_INCLUDE='${librarySymbol}')`;
					if (isExportedByForceFilesystem(sym)) msg += ". Alternatively, forcing filesystem support (-sFORCE_FILESYSTEM) can export this for you";
					warnOnce(msg);
				}
			});
			unexportedRuntimeSymbol(sym);
		}
		function unexportedRuntimeSymbol(sym) {
			if (!Object.getOwnPropertyDescriptor(Module, sym)) Object.defineProperty(Module, sym, {
				configurable: true,
				get() {
					var msg = `'${sym}' was not exported. add it to EXPORTED_RUNTIME_METHODS (see the Emscripten FAQ)`;
					if (isExportedByForceFilesystem(sym)) msg += ". Alternatively, forcing filesystem support (-sFORCE_FILESYSTEM) can export this for you";
					abort(msg);
				}
			});
		}
		var callRuntimeCallbacks = (callbacks) => {
			while (callbacks.length > 0) callbacks.shift()(Module);
		};
		var withStackSave = (f) => {
			var stack = stackSave();
			var ret = f();
			stackRestore(stack);
			return ret;
		};
		var UTF8Decoder = typeof TextDecoder != "undefined" ? new TextDecoder("utf8") : void 0;
		var UTF8ArrayToString = (heapOrArray, idx, maxBytesToRead) => {
			var endIdx = idx + maxBytesToRead;
			var endPtr = idx;
			while (heapOrArray[endPtr] && !(endPtr >= endIdx)) ++endPtr;
			if (endPtr - idx > 16 && heapOrArray.buffer && UTF8Decoder) return UTF8Decoder.decode(heapOrArray.subarray(idx, endPtr));
			var str = "";
			while (idx < endPtr) {
				var u0 = heapOrArray[idx++];
				if (!(u0 & 128)) {
					str += String.fromCharCode(u0);
					continue;
				}
				var u1 = heapOrArray[idx++] & 63;
				if ((u0 & 224) == 192) {
					str += String.fromCharCode((u0 & 31) << 6 | u1);
					continue;
				}
				var u2 = heapOrArray[idx++] & 63;
				if ((u0 & 240) == 224) u0 = (u0 & 15) << 12 | u1 << 6 | u2;
				else {
					if ((u0 & 248) != 240) warnOnce("Invalid UTF-8 leading byte " + ptrToString(u0) + " encountered when deserializing a UTF-8 string in wasm memory to a JS string!");
					u0 = (u0 & 7) << 18 | u1 << 12 | u2 << 6 | heapOrArray[idx++] & 63;
				}
				if (u0 < 65536) str += String.fromCharCode(u0);
				else {
					var ch = u0 - 65536;
					str += String.fromCharCode(55296 | ch >> 10, 56320 | ch & 1023);
				}
			}
			return str;
		};
		var UTF8ToString = (ptr, maxBytesToRead) => {
			assert(typeof ptr == "number", `UTF8ToString expects a number (got ${typeof ptr})`);
			return ptr ? UTF8ArrayToString(HEAPU8, ptr, maxBytesToRead) : "";
		};
		var getExceptionMessageCommon = (ptr) => withStackSave(() => {
			var type_addr_addr = stackAlloc(4);
			var message_addr_addr = stackAlloc(4);
			___get_exception_message(ptr, type_addr_addr, message_addr_addr);
			var type_addr = HEAPU32[type_addr_addr >> 2];
			var message_addr = HEAPU32[message_addr_addr >> 2];
			var type = UTF8ToString(type_addr);
			_free(type_addr);
			var message;
			if (message_addr) {
				message = UTF8ToString(message_addr);
				_free(message_addr);
			}
			return [type, message];
		});
		var getExceptionMessage = (ptr) => getExceptionMessageCommon(ptr);
		Module["getExceptionMessage"] = getExceptionMessage;
		function getValue(ptr, type = "i8") {
			if (type.endsWith("*")) type = "*";
			switch (type) {
				case "i1": return HEAP8[ptr >> 0];
				case "i8": return HEAP8[ptr >> 0];
				case "i16": return HEAP16[ptr >> 1];
				case "i32": return HEAP32[ptr >> 2];
				case "i64": abort("to do getValue(i64) use WASM_BIGINT");
				case "float": return HEAPF32[ptr >> 2];
				case "double": return HEAPF64[ptr >> 3];
				case "*": return HEAPU32[ptr >> 2];
				default: abort(`invalid type for getValue: ${type}`);
			}
		}
		Module["noExitRuntime"];
		var ptrToString = (ptr) => {
			assert(typeof ptr === "number");
			ptr >>>= 0;
			return "0x" + ptr.toString(16).padStart(8, "0");
		};
		function setValue(ptr, value, type = "i8") {
			if (type.endsWith("*")) type = "*";
			switch (type) {
				case "i1":
					HEAP8[ptr >> 0] = value;
					break;
				case "i8":
					HEAP8[ptr >> 0] = value;
					break;
				case "i16":
					HEAP16[ptr >> 1] = value;
					break;
				case "i32":
					HEAP32[ptr >> 2] = value;
					break;
				case "i64": abort("to do setValue(i64) use WASM_BIGINT");
				case "float":
					HEAPF32[ptr >> 2] = value;
					break;
				case "double":
					HEAPF64[ptr >> 3] = value;
					break;
				case "*":
					HEAPU32[ptr >> 2] = value;
					break;
				default: abort(`invalid type for setValue: ${type}`);
			}
		}
		var warnOnce = (text) => {
			warnOnce.shown ||= {};
			if (!warnOnce.shown[text]) {
				warnOnce.shown[text] = 1;
				if (ENVIRONMENT_IS_NODE) text = "warning: " + text;
				err(text);
			}
		};
		var ___assert_fail = (condition, filename, line, func) => {
			abort(`Assertion failed: ${UTF8ToString(condition)}, at: ` + [
				filename ? UTF8ToString(filename) : "unknown filename",
				line,
				func ? UTF8ToString(func) : "unknown function"
			]);
		};
		var exceptionCaught = [];
		var uncaughtExceptionCount = 0;
		var ___cxa_begin_catch = (ptr) => {
			var info = new ExceptionInfo(ptr);
			if (!info.get_caught()) {
				info.set_caught(true);
				uncaughtExceptionCount--;
			}
			info.set_rethrown(false);
			exceptionCaught.push(info);
			___cxa_increment_exception_refcount(info.excPtr);
			return info.get_exception_ptr();
		};
		var exceptionLast = 0;
		class ExceptionInfo {
			constructor(excPtr) {
				this.excPtr = excPtr;
				this.ptr = excPtr - 24;
			}
			set_type(type) {
				HEAPU32[this.ptr + 4 >> 2] = type;
			}
			get_type() {
				return HEAPU32[this.ptr + 4 >> 2];
			}
			set_destructor(destructor) {
				HEAPU32[this.ptr + 8 >> 2] = destructor;
			}
			get_destructor() {
				return HEAPU32[this.ptr + 8 >> 2];
			}
			set_caught(caught) {
				caught = caught ? 1 : 0;
				HEAP8[this.ptr + 12 >> 0] = caught;
			}
			get_caught() {
				return HEAP8[this.ptr + 12 >> 0] != 0;
			}
			set_rethrown(rethrown) {
				rethrown = rethrown ? 1 : 0;
				HEAP8[this.ptr + 13 >> 0] = rethrown;
			}
			get_rethrown() {
				return HEAP8[this.ptr + 13 >> 0] != 0;
			}
			init(type, destructor) {
				this.set_adjusted_ptr(0);
				this.set_type(type);
				this.set_destructor(destructor);
			}
			set_adjusted_ptr(adjustedPtr) {
				HEAPU32[this.ptr + 16 >> 2] = adjustedPtr;
			}
			get_adjusted_ptr() {
				return HEAPU32[this.ptr + 16 >> 2];
			}
			get_exception_ptr() {
				if (___cxa_is_pointer_type(this.get_type())) return HEAPU32[this.excPtr >> 2];
				var adjusted = this.get_adjusted_ptr();
				if (adjusted !== 0) return adjusted;
				return this.excPtr;
			}
		}
		var ___resumeException = (ptr) => {
			if (!exceptionLast) exceptionLast = new CppException(ptr);
			throw exceptionLast;
		};
		var findMatchingCatch = (args) => {
			var thrown = exceptionLast?.excPtr;
			if (!thrown) {
				setTempRet0(0);
				return 0;
			}
			var info = new ExceptionInfo(thrown);
			info.set_adjusted_ptr(thrown);
			var thrownType = info.get_type();
			if (!thrownType) {
				setTempRet0(0);
				return thrown;
			}
			for (var arg in args) {
				var caughtType = args[arg];
				if (caughtType === 0 || caughtType === thrownType) break;
				if (___cxa_can_catch(caughtType, thrownType, info.ptr + 16)) {
					setTempRet0(caughtType);
					return thrown;
				}
			}
			setTempRet0(thrownType);
			return thrown;
		};
		var ___cxa_find_matching_catch_2 = () => findMatchingCatch([]);
		var ___cxa_find_matching_catch_3 = (arg0) => findMatchingCatch([arg0]);
		var SYSCALLS = {
			varargs: void 0,
			get() {
				assert(SYSCALLS.varargs != void 0);
				var ret = HEAP32[+SYSCALLS.varargs >> 2];
				SYSCALLS.varargs += 4;
				return ret;
			},
			getp() {
				return SYSCALLS.get();
			},
			getStr(ptr) {
				return UTF8ToString(ptr);
			}
		};
		function ___syscall_fcntl64(fd, cmd, varargs) {
			SYSCALLS.varargs = varargs;
			return 0;
		}
		function ___syscall_ioctl(fd, op, varargs) {
			SYSCALLS.varargs = varargs;
			return 0;
		}
		function ___syscall_openat(dirfd, path, flags, varargs) {
			SYSCALLS.varargs = varargs;
			abort("it should not be possible to operate on streams when !SYSCALLS_REQUIRE_FILESYSTEM");
		}
		var ___syscall_rmdir = (path) => {
			abort("it should not be possible to operate on streams when !SYSCALLS_REQUIRE_FILESYSTEM");
		};
		var ___syscall_unlinkat = (dirfd, path, flags) => {
			abort("it should not be possible to operate on streams when !SYSCALLS_REQUIRE_FILESYSTEM");
		};
		var convertI32PairToI53Checked = (lo, hi) => {
			assert(lo == lo >>> 0 || lo == (lo | 0));
			assert(hi === (hi | 0));
			return hi + 2097152 >>> 0 < 4194305 - !!lo ? (lo >>> 0) + hi * 4294967296 : NaN;
		};
		function __gmtime_js(time_low, time_high, tmPtr) {
			var time = convertI32PairToI53Checked(time_low, time_high);
			var date = /* @__PURE__ */ new Date(time * 1e3);
			HEAP32[tmPtr >> 2] = date.getUTCSeconds();
			HEAP32[tmPtr + 4 >> 2] = date.getUTCMinutes();
			HEAP32[tmPtr + 8 >> 2] = date.getUTCHours();
			HEAP32[tmPtr + 12 >> 2] = date.getUTCDate();
			HEAP32[tmPtr + 16 >> 2] = date.getUTCMonth();
			HEAP32[tmPtr + 20 >> 2] = date.getUTCFullYear() - 1900;
			HEAP32[tmPtr + 24 >> 2] = date.getUTCDay();
			var start = Date.UTC(date.getUTCFullYear(), 0, 1, 0, 0, 0, 0);
			var yday = (date.getTime() - start) / (1e3 * 60 * 60 * 24) | 0;
			HEAP32[tmPtr + 28 >> 2] = yday;
		}
		var lengthBytesUTF8 = (str) => {
			var len = 0;
			for (var i = 0; i < str.length; ++i) {
				var c = str.charCodeAt(i);
				if (c <= 127) len++;
				else if (c <= 2047) len += 2;
				else if (c >= 55296 && c <= 57343) {
					len += 4;
					++i;
				} else len += 3;
			}
			return len;
		};
		var stringToUTF8Array = (str, heap, outIdx, maxBytesToWrite) => {
			assert(typeof str === "string", `stringToUTF8Array expects a string (got ${typeof str})`);
			if (!(maxBytesToWrite > 0)) return 0;
			var startIdx = outIdx;
			var endIdx = outIdx + maxBytesToWrite - 1;
			for (var i = 0; i < str.length; ++i) {
				var u = str.charCodeAt(i);
				if (u >= 55296 && u <= 57343) {
					var u1 = str.charCodeAt(++i);
					u = 65536 + ((u & 1023) << 10) | u1 & 1023;
				}
				if (u <= 127) {
					if (outIdx >= endIdx) break;
					heap[outIdx++] = u;
				} else if (u <= 2047) {
					if (outIdx + 1 >= endIdx) break;
					heap[outIdx++] = 192 | u >> 6;
					heap[outIdx++] = 128 | u & 63;
				} else if (u <= 65535) {
					if (outIdx + 2 >= endIdx) break;
					heap[outIdx++] = 224 | u >> 12;
					heap[outIdx++] = 128 | u >> 6 & 63;
					heap[outIdx++] = 128 | u & 63;
				} else {
					if (outIdx + 3 >= endIdx) break;
					if (u > 1114111) warnOnce("Invalid Unicode code point " + ptrToString(u) + " encountered when serializing a JS string to a UTF-8 string in wasm memory! (Valid unicode code points should be in range 0-0x10FFFF).");
					heap[outIdx++] = 240 | u >> 18;
					heap[outIdx++] = 128 | u >> 12 & 63;
					heap[outIdx++] = 128 | u >> 6 & 63;
					heap[outIdx++] = 128 | u & 63;
				}
			}
			heap[outIdx] = 0;
			return outIdx - startIdx;
		};
		var stringToUTF8 = (str, outPtr, maxBytesToWrite) => {
			assert(typeof maxBytesToWrite == "number", "stringToUTF8(str, outPtr, maxBytesToWrite) is missing the third parameter that specifies the length of the output buffer!");
			return stringToUTF8Array(str, HEAPU8, outPtr, maxBytesToWrite);
		};
		var stringToNewUTF8 = (str) => {
			var size = lengthBytesUTF8(str) + 1;
			var ret = _malloc(size);
			if (ret) stringToUTF8(str, ret, size);
			return ret;
		};
		var __tzset_js = (timezone, daylight, tzname) => {
			var currentYear = (/* @__PURE__ */ new Date()).getFullYear();
			var winter = new Date(currentYear, 0, 1);
			var summer = new Date(currentYear, 6, 1);
			var winterOffset = winter.getTimezoneOffset();
			var summerOffset = summer.getTimezoneOffset();
			var stdTimezoneOffset = Math.max(winterOffset, summerOffset);
			HEAPU32[timezone >> 2] = stdTimezoneOffset * 60;
			HEAP32[daylight >> 2] = Number(winterOffset != summerOffset);
			function extractZone(date) {
				var match = date.toTimeString().match(/\(([A-Za-z ]+)\)$/);
				return match ? match[1] : "GMT";
			}
			var winterName = extractZone(winter);
			var summerName = extractZone(summer);
			var winterNamePtr = stringToNewUTF8(winterName);
			var summerNamePtr = stringToNewUTF8(summerName);
			if (summerOffset < winterOffset) {
				HEAPU32[tzname >> 2] = winterNamePtr;
				HEAPU32[tzname + 4 >> 2] = summerNamePtr;
			} else {
				HEAPU32[tzname >> 2] = summerNamePtr;
				HEAPU32[tzname + 4 >> 2] = winterNamePtr;
			}
		};
		var _abort = () => {
			abort("native code called abort()");
		};
		var _emscripten_date_now = () => Date.now();
		var _emscripten_memcpy_js = (dest, src, num) => HEAPU8.copyWithin(dest, src, src + num);
		var getHeapMax = () => 2147483648;
		var growMemory = (size) => {
			var b = wasmMemory.buffer;
			var pages = (size - b.byteLength + 65535) / 65536;
			try {
				wasmMemory.grow(pages);
				updateMemoryViews();
				return 1;
			} catch (e) {
				err(`growMemory: Attempted to grow heap from ${b.byteLength} bytes to ${size} bytes, but got error: ${e}`);
			}
		};
		var _emscripten_resize_heap = (requestedSize) => {
			var oldSize = HEAPU8.length;
			requestedSize >>>= 0;
			assert(requestedSize > oldSize);
			var maxHeapSize = getHeapMax();
			if (requestedSize > maxHeapSize) {
				err(`Cannot enlarge memory, requested ${requestedSize} bytes, but the limit is ${maxHeapSize} bytes!`);
				return false;
			}
			var alignUp = (x, multiple) => x + (multiple - x % multiple) % multiple;
			for (var cutDown = 1; cutDown <= 4; cutDown *= 2) {
				var overGrownHeapSize = oldSize * (1 + .2 / cutDown);
				overGrownHeapSize = Math.min(overGrownHeapSize, requestedSize + 100663296);
				var newSize = Math.min(maxHeapSize, alignUp(Math.max(requestedSize, overGrownHeapSize), 65536));
				if (growMemory(newSize)) return true;
			}
			err(`Failed to grow the heap from ${oldSize} bytes to ${newSize} bytes, not enough memory!`);
			return false;
		};
		var _fd_close = (fd) => {
			abort("fd_close called without SYSCALLS_REQUIRE_FILESYSTEM");
		};
		var _fd_read = (fd, iov, iovcnt, pnum) => {
			abort("fd_read called without SYSCALLS_REQUIRE_FILESYSTEM");
		};
		function _fd_seek(fd, offset_low, offset_high, whence, newOffset) {
			convertI32PairToI53Checked(offset_low, offset_high);
			return 70;
		}
		var printCharBuffers = [
			null,
			[],
			[]
		];
		var printChar = (stream, curr) => {
			var buffer = printCharBuffers[stream];
			assert(buffer);
			if (curr === 0 || curr === 10) {
				(stream === 1 ? out : err)(UTF8ArrayToString(buffer, 0));
				buffer.length = 0;
			} else buffer.push(curr);
		};
		var _fd_write = (fd, iov, iovcnt, pnum) => {
			var num = 0;
			for (var i = 0; i < iovcnt; i++) {
				var ptr = HEAPU32[iov >> 2];
				var len = HEAPU32[iov + 4 >> 2];
				iov += 8;
				for (var j = 0; j < len; j++) printChar(fd, HEAPU8[ptr + j]);
				num += len;
			}
			HEAPU32[pnum >> 2] = num;
			return 0;
		};
		var wasmTableMirror = [];
		var wasmTable;
		var getWasmTableEntry = (funcPtr) => {
			var func = wasmTableMirror[funcPtr];
			if (!func) {
				if (funcPtr >= wasmTableMirror.length) wasmTableMirror.length = funcPtr + 1;
				wasmTableMirror[funcPtr] = func = wasmTable.get(funcPtr);
			}
			assert(wasmTable.get(funcPtr) == func, "JavaScript-side Wasm function table mirror is out of date!");
			return func;
		};
		var getCFunc = (ident) => {
			var func = Module["_" + ident];
			assert(func, "Cannot call unknown function " + ident + ", make sure it is exported");
			return func;
		};
		var writeArrayToMemory = (array, buffer) => {
			assert(array.length >= 0, "writeArrayToMemory array must have a length (should be an array or typed array)");
			HEAP8.set(array, buffer);
		};
		var stringToUTF8OnStack = (str) => {
			var size = lengthBytesUTF8(str) + 1;
			var ret = stackAlloc(size);
			stringToUTF8(str, ret, size);
			return ret;
		};
		var ccall = (ident, returnType, argTypes, args, opts) => {
			var toC = {
				"string": (str) => {
					var ret = 0;
					if (str !== null && str !== void 0 && str !== 0) ret = stringToUTF8OnStack(str);
					return ret;
				},
				"array": (arr) => {
					var ret = stackAlloc(arr.length);
					writeArrayToMemory(arr, ret);
					return ret;
				}
			};
			function convertReturnValue(ret) {
				if (returnType === "string") return UTF8ToString(ret);
				if (returnType === "boolean") return Boolean(ret);
				return ret;
			}
			var func = getCFunc(ident);
			var cArgs = [];
			var stack = 0;
			assert(returnType !== "array", "Return type should not be \"array\".");
			if (args) for (var i = 0; i < args.length; i++) {
				var converter = toC[argTypes[i]];
				if (converter) {
					if (stack === 0) stack = stackSave();
					cArgs[i] = converter(args[i]);
				} else cArgs[i] = args[i];
			}
			var ret = func.apply(null, cArgs);
			function onDone(ret) {
				if (stack !== 0) stackRestore(stack);
				return convertReturnValue(ret);
			}
			ret = onDone(ret);
			return ret;
		};
		var cwrap = (ident, returnType, argTypes, opts) => function() {
			return ccall(ident, returnType, argTypes, arguments, opts);
		};
		function checkIncomingModuleAPI() {
			ignoredModuleProp("fetchSettings");
		}
		var wasmImports = {
			__assert_fail: ___assert_fail,
			__cxa_begin_catch: ___cxa_begin_catch,
			__cxa_find_matching_catch_2: ___cxa_find_matching_catch_2,
			__cxa_find_matching_catch_3: ___cxa_find_matching_catch_3,
			__resumeException: ___resumeException,
			__syscall_fcntl64: ___syscall_fcntl64,
			__syscall_ioctl: ___syscall_ioctl,
			__syscall_openat: ___syscall_openat,
			__syscall_rmdir: ___syscall_rmdir,
			__syscall_unlinkat: ___syscall_unlinkat,
			_gmtime_js: __gmtime_js,
			_tzset_js: __tzset_js,
			abort: _abort,
			emscripten_date_now: _emscripten_date_now,
			emscripten_memcpy_js: _emscripten_memcpy_js,
			emscripten_resize_heap: _emscripten_resize_heap,
			fd_close: _fd_close,
			fd_read: _fd_read,
			fd_seek: _fd_seek,
			fd_write: _fd_write,
			invoke_ii,
			invoke_iii,
			invoke_v,
			invoke_vi,
			invoke_vii,
			invoke_viii,
			invoke_viiii
		};
		var wasmExports = createWasm();
		Module["_cmsGetColorSpace"] = createExportWrapper("cmsGetColorSpace");
		Module["_cmsXYZ2xyY"] = createExportWrapper("cmsXYZ2xyY");
		Module["_cmsCloseProfile"] = createExportWrapper("cmsCloseProfile");
		Module["_cmsDeleteTransform"] = createExportWrapper("cmsDeleteTransform");
		Module["_cmsDoTransform"] = createExportWrapper("cmsDoTransform");
		var _malloc = Module["_malloc"] = createExportWrapper("malloc");
		var _free = Module["_free"] = createExportWrapper("free");
		Module["_cmsFormatterForColorspaceOfProfile"] = createExportWrapper("cmsFormatterForColorspaceOfProfile");
		Module["_cmsGetHeaderRenderingIntent"] = createExportWrapper("cmsGetHeaderRenderingIntent");
		Module["_cmsOpenProfileFromMem"] = createExportWrapper("cmsOpenProfileFromMem");
		Module["_cmsReadTag"] = createExportWrapper("cmsReadTag");
		Module["_cmsGetProfileInfoASCII"] = createExportWrapper("cmsGetProfileInfoASCII");
		Module["_cmsCreateTransform"] = createExportWrapper("cmsCreateTransform");
		Module["_cmsCreateXYZProfile"] = createExportWrapper("cmsCreateXYZProfile");
		Module["_cmsCreateLab4Profile"] = createExportWrapper("cmsCreateLab4Profile");
		Module["_cmsCreate_sRGBProfile"] = createExportWrapper("cmsCreate_sRGBProfile");
		Module["_cmsCreateProofingTransform"] = createExportWrapper("cmsCreateProofingTransform");
		Module["_cmsGetTransformInputFormat"] = createExportWrapper("cmsGetTransformInputFormat");
		Module["_cmsGetTransformOutputFormat"] = createExportWrapper("cmsGetTransformOutputFormat");
		var _setThrew = createExportWrapper("setThrew");
		var setTempRet0 = createExportWrapper("setTempRet0");
		var _emscripten_stack_init = () => (_emscripten_stack_init = wasmExports["emscripten_stack_init"])();
		var _emscripten_stack_get_free = () => (_emscripten_stack_get_free = wasmExports["emscripten_stack_get_free"])();
		var _emscripten_stack_get_base = () => (_emscripten_stack_get_base = wasmExports["emscripten_stack_get_base"])();
		var _emscripten_stack_get_end = () => (_emscripten_stack_get_end = wasmExports["emscripten_stack_get_end"])();
		var stackSave = createExportWrapper("stackSave");
		var stackRestore = createExportWrapper("stackRestore");
		var stackAlloc = createExportWrapper("stackAlloc");
		var _emscripten_stack_get_current = () => (_emscripten_stack_get_current = wasmExports["emscripten_stack_get_current"])();
		var ___cxa_increment_exception_refcount = createExportWrapper("__cxa_increment_exception_refcount");
		var ___get_exception_message = createExportWrapper("__get_exception_message");
		var ___cxa_can_catch = createExportWrapper("__cxa_can_catch");
		var ___cxa_is_pointer_type = createExportWrapper("__cxa_is_pointer_type");
		Module["dynCall_jiji"] = createExportWrapper("dynCall_jiji");
		function invoke_ii(index, a1) {
			var sp = stackSave();
			try {
				return getWasmTableEntry(index)(a1);
			} catch (e) {
				stackRestore(sp);
				if (!(e instanceof EmscriptenEH)) throw e;
				_setThrew(1, 0);
			}
		}
		function invoke_v(index) {
			var sp = stackSave();
			try {
				getWasmTableEntry(index)();
			} catch (e) {
				stackRestore(sp);
				if (!(e instanceof EmscriptenEH)) throw e;
				_setThrew(1, 0);
			}
		}
		function invoke_vii(index, a1, a2) {
			var sp = stackSave();
			try {
				getWasmTableEntry(index)(a1, a2);
			} catch (e) {
				stackRestore(sp);
				if (!(e instanceof EmscriptenEH)) throw e;
				_setThrew(1, 0);
			}
		}
		function invoke_vi(index, a1) {
			var sp = stackSave();
			try {
				getWasmTableEntry(index)(a1);
			} catch (e) {
				stackRestore(sp);
				if (!(e instanceof EmscriptenEH)) throw e;
				_setThrew(1, 0);
			}
		}
		function invoke_viiii(index, a1, a2, a3, a4) {
			var sp = stackSave();
			try {
				getWasmTableEntry(index)(a1, a2, a3, a4);
			} catch (e) {
				stackRestore(sp);
				if (!(e instanceof EmscriptenEH)) throw e;
				_setThrew(1, 0);
			}
		}
		function invoke_iii(index, a1, a2) {
			var sp = stackSave();
			try {
				return getWasmTableEntry(index)(a1, a2);
			} catch (e) {
				stackRestore(sp);
				if (!(e instanceof EmscriptenEH)) throw e;
				_setThrew(1, 0);
			}
		}
		function invoke_viii(index, a1, a2, a3) {
			var sp = stackSave();
			try {
				getWasmTableEntry(index)(a1, a2, a3);
			} catch (e) {
				stackRestore(sp);
				if (!(e instanceof EmscriptenEH)) throw e;
				_setThrew(1, 0);
			}
		}
		Module["ccall"] = ccall;
		Module["cwrap"] = cwrap;
		[
			"writeI53ToI64",
			"writeI53ToI64Clamped",
			"writeI53ToI64Signaling",
			"writeI53ToU64Clamped",
			"writeI53ToU64Signaling",
			"readI53FromI64",
			"readI53FromU64",
			"convertI32PairToI53",
			"convertU32PairToI53",
			"zeroMemory",
			"exitJS",
			"isLeapYear",
			"ydayFromDate",
			"arraySum",
			"addDays",
			"inetPton4",
			"inetNtop4",
			"inetPton6",
			"inetNtop6",
			"readSockaddr",
			"writeSockaddr",
			"initRandomFill",
			"randomFill",
			"getCallstack",
			"emscriptenLog",
			"convertPCtoSourceLocation",
			"readEmAsmArgs",
			"jstoi_q",
			"getExecutableName",
			"listenOnce",
			"autoResumeAudioContext",
			"dynCallLegacy",
			"getDynCaller",
			"dynCall",
			"handleException",
			"keepRuntimeAlive",
			"runtimeKeepalivePush",
			"runtimeKeepalivePop",
			"callUserCallback",
			"maybeExit",
			"asmjsMangle",
			"asyncLoad",
			"alignMemory",
			"mmapAlloc",
			"HandleAllocator",
			"getNativeTypeSize",
			"STACK_SIZE",
			"STACK_ALIGN",
			"POINTER_SIZE",
			"ASSERTIONS",
			"uleb128Encode",
			"sigToWasmTypes",
			"generateFuncType",
			"convertJsFunctionToWasm",
			"getEmptyTableSlot",
			"updateTableMap",
			"getFunctionAddress",
			"addFunction",
			"removeFunction",
			"reallyNegative",
			"unSign",
			"strLen",
			"reSign",
			"formatString",
			"intArrayFromString",
			"intArrayToString",
			"AsciiToString",
			"stringToAscii",
			"UTF16ToString",
			"stringToUTF16",
			"lengthBytesUTF16",
			"UTF32ToString",
			"stringToUTF32",
			"lengthBytesUTF32",
			"registerKeyEventCallback",
			"maybeCStringToJsString",
			"findEventTarget",
			"getBoundingClientRect",
			"fillMouseEventData",
			"registerMouseEventCallback",
			"registerWheelEventCallback",
			"registerUiEventCallback",
			"registerFocusEventCallback",
			"fillDeviceOrientationEventData",
			"registerDeviceOrientationEventCallback",
			"fillDeviceMotionEventData",
			"registerDeviceMotionEventCallback",
			"screenOrientation",
			"fillOrientationChangeEventData",
			"registerOrientationChangeEventCallback",
			"fillFullscreenChangeEventData",
			"registerFullscreenChangeEventCallback",
			"JSEvents_requestFullscreen",
			"JSEvents_resizeCanvasForFullscreen",
			"registerRestoreOldStyle",
			"hideEverythingExceptGivenElement",
			"restoreHiddenElements",
			"setLetterbox",
			"softFullscreenResizeWebGLRenderTarget",
			"doRequestFullscreen",
			"fillPointerlockChangeEventData",
			"registerPointerlockChangeEventCallback",
			"registerPointerlockErrorEventCallback",
			"requestPointerLock",
			"fillVisibilityChangeEventData",
			"registerVisibilityChangeEventCallback",
			"registerTouchEventCallback",
			"fillGamepadEventData",
			"registerGamepadEventCallback",
			"registerBeforeUnloadEventCallback",
			"fillBatteryEventData",
			"battery",
			"registerBatteryEventCallback",
			"setCanvasElementSize",
			"getCanvasElementSize",
			"demangle",
			"jsStackTrace",
			"stackTrace",
			"getEnvStrings",
			"checkWasiClock",
			"wasiRightsToMuslOFlags",
			"wasiOFlagsToMuslOFlags",
			"createDyncallWrapper",
			"safeSetTimeout",
			"setImmediateWrapped",
			"clearImmediateWrapped",
			"polyfillSetImmediate",
			"getPromise",
			"makePromise",
			"idsToPromises",
			"makePromiseCallback",
			"Browser_asyncPrepareDataCounter",
			"setMainLoop",
			"getSocketFromFD",
			"getSocketAddress",
			"heapObjectForWebGLType",
			"heapAccessShiftForWebGLHeap",
			"webgl_enable_ANGLE_instanced_arrays",
			"webgl_enable_OES_vertex_array_object",
			"webgl_enable_WEBGL_draw_buffers",
			"webgl_enable_WEBGL_multi_draw",
			"emscriptenWebGLGet",
			"computeUnpackAlignedImageSize",
			"colorChannelsInGlTextureFormat",
			"emscriptenWebGLGetTexPixelData",
			"__glGenObject",
			"emscriptenWebGLGetUniform",
			"webglGetUniformLocation",
			"webglPrepareUniformLocationsBeforeFirstUse",
			"webglGetLeftBracePos",
			"emscriptenWebGLGetVertexAttrib",
			"__glGetActiveAttribOrUniform",
			"writeGLArray",
			"registerWebGlEventCallback",
			"runAndAbortIfError",
			"SDL_unicode",
			"SDL_ttfContext",
			"SDL_audio",
			"ALLOC_NORMAL",
			"ALLOC_STACK",
			"allocate",
			"writeStringToMemory",
			"writeAsciiToMemory",
			"setErrNo"
		].forEach(missingLibrarySymbol);
		[
			"run",
			"addOnPreRun",
			"addOnInit",
			"addOnPreMain",
			"addOnExit",
			"addOnPostRun",
			"addRunDependency",
			"removeRunDependency",
			"FS_createFolder",
			"FS_createPath",
			"FS_createLazyFile",
			"FS_createLink",
			"FS_createDevice",
			"FS_readFile",
			"out",
			"err",
			"callMain",
			"abort",
			"wasmMemory",
			"wasmExports",
			"stackAlloc",
			"stackSave",
			"stackRestore",
			"getTempRet0",
			"setTempRet0",
			"writeStackCookie",
			"checkStackCookie",
			"convertI32PairToI53Checked",
			"ptrToString",
			"getHeapMax",
			"growMemory",
			"ENV",
			"MONTH_DAYS_REGULAR",
			"MONTH_DAYS_LEAP",
			"MONTH_DAYS_REGULAR_CUMULATIVE",
			"MONTH_DAYS_LEAP_CUMULATIVE",
			"ERRNO_CODES",
			"ERRNO_MESSAGES",
			"DNS",
			"Protocols",
			"Sockets",
			"timers",
			"warnOnce",
			"UNWIND_CACHE",
			"readEmAsmArgsArray",
			"jstoi_s",
			"wasmTable",
			"noExitRuntime",
			"getCFunc",
			"freeTableIndexes",
			"functionsInTableMap",
			"setValue",
			"getValue",
			"PATH",
			"PATH_FS",
			"UTF8Decoder",
			"UTF8ArrayToString",
			"UTF8ToString",
			"stringToUTF8Array",
			"stringToUTF8",
			"lengthBytesUTF8",
			"UTF16Decoder",
			"stringToNewUTF8",
			"stringToUTF8OnStack",
			"writeArrayToMemory",
			"JSEvents",
			"specialHTMLTargets",
			"findCanvasEventTarget",
			"currentFullscreenStrategy",
			"restoreOldWindowedStyle",
			"ExitStatus",
			"flush_NO_FILESYSTEM",
			"promiseMap",
			"uncaughtExceptionCount",
			"exceptionLast",
			"exceptionCaught",
			"ExceptionInfo",
			"findMatchingCatch",
			"getExceptionMessageCommon",
			"incrementExceptionRefcount",
			"decrementExceptionRefcount",
			"getExceptionMessage",
			"Browser",
			"wget",
			"SYSCALLS",
			"tempFixedLengthArray",
			"miniTempWebGLFloatBuffers",
			"miniTempWebGLIntBuffers",
			"GL",
			"emscripten_webgl_power_preferences",
			"AL",
			"GLUT",
			"EGL",
			"GLEW",
			"IDBStore",
			"SDL",
			"SDL_gfx",
			"allocateUTF8",
			"allocateUTF8OnStack"
		].forEach(unexportedRuntimeSymbol);
		var calledRun;
		dependenciesFulfilled = function runCaller() {
			if (!calledRun) run();
			if (!calledRun) dependenciesFulfilled = runCaller;
		};
		function stackCheckInit() {
			_emscripten_stack_init();
			writeStackCookie();
		}
		function run() {
			if (runDependencies > 0) return;
			stackCheckInit();
			preRun();
			if (runDependencies > 0) return;
			function doRun() {
				if (calledRun) return;
				calledRun = true;
				Module["calledRun"] = true;
				if (ABORT) return;
				initRuntime();
				readyPromiseResolve(Module);
				if (Module["onRuntimeInitialized"]) Module["onRuntimeInitialized"]();
				assert(!Module["_main"], "compiled without a main, but one is present. if you added it from JS, use Module[\"onRuntimeInitialized\"]");
				postRun();
			}
			if (Module["setStatus"]) {
				Module["setStatus"]("Running...");
				setTimeout(function() {
					setTimeout(function() {
						Module["setStatus"]("");
					}, 1);
					doRun();
				}, 1);
			} else doRun();
			checkStackCookie();
		}
		if (Module["preInit"]) {
			if (typeof Module["preInit"] == "function") Module["preInit"] = [Module["preInit"]];
			while (Module["preInit"].length > 0) Module["preInit"].pop()();
		}
		run();
		Module.cmsOpenProfileFromMem = cwrap("cmsOpenProfileFromMem", "number", ["array", "number"]);
		Module.cmsCloseProfile = cwrap("cmsCloseProfile", void 0, ["number"]);
		Module.cmsCreate_sRGBProfile = cwrap("cmsCreate_sRGBProfile", "number", []);
		Module.cmsCreateXYZProfile = cwrap("cmsCreateXYZProfile", "number", [], []);
		Module.cmsGetHeaderRenderingIntent = cwrap("cmsGetHeaderRenderingIntent", "number", ["number"]);
		Module.cmsCreateLab4Profile = cmsCreateLab4Profile;
		function cmsCreateLab4Profile(wpArr) {
			var whitePoint = 0;
			if (wpArr) {
				whitePoint = _malloc(24);
				for (var i = 0; i < 3; i++) setValue(whitePoint + i * 8, wpArr[i], "double");
			}
			var prof = ccall("cmsCreateLab4Profile", "number", ["number"], [whitePoint]);
			if (whitePoint) _free(whitePoint);
			return prof;
		}
		Module.cmsGetProfileInfoASCII = cmsGetProfileInfoASCII;
		function cmsGetProfileInfoASCII(hProfile, info, languageCode, countryCode) {
			var len = ccall("cmsGetProfileInfoASCII", "number", [
				"number",
				"number",
				"string",
				"string",
				"number",
				"number"
			], [
				hProfile,
				info,
				languageCode,
				countryCode,
				0,
				0
			]);
			var ptr = _malloc(len);
			var len = ccall("cmsGetProfileInfoASCII", "number", [
				"number",
				"number",
				"string",
				"string",
				"number",
				"number"
			], [
				hProfile,
				info,
				languageCode,
				countryCode,
				ptr,
				len
			]);
			var text = UTF8ToString(ptr, len);
			_free(ptr);
			return text;
		}
		Module.cmsGetColorSpace = cwrap("cmsGetColorSpace", "number", ["number"]);
		Module.cmsGetColorSpaceASCII = (profile) => {
			return {
				1482250784: "XYZ",
				1281450528: "Lab",
				1282766368: "Luv",
				1497588338: "YCbr",
				1501067552: "Yxy",
				1380401696: "RGB",
				1196573017: "GRAY",
				1213421088: "HSV",
				1212961568: "HLS",
				1129142603: "CMYK",
				1129142560: "CMY"
			}[Module.cmsGetColorSpace(profile)] || null;
		};
		Module.cmsFormatterForColorspaceOfProfile = cmsFormatterForColorspaceOfProfile;
		function cmsFormatterForColorspaceOfProfile(hProfile, nBytes, isFloat) {
			return ccall("cmsFormatterForColorspaceOfProfile", "number", [
				"number",
				"number",
				"number"
			], [
				hProfile,
				nBytes,
				isFloat
			]);
		}
		Module.cmsCreateTransform = cmsCreateTransform;
		function cmsCreateTransform(hInput, inputFormat, hOutput, outputFormat, intent, flags) {
			return ccall("cmsCreateTransform", "number", [
				"number",
				"number",
				"number",
				"number",
				"number",
				"number"
			], [
				hInput,
				inputFormat,
				hOutput,
				outputFormat,
				intent,
				flags
			]);
		}
		Module.cmsCreateProofingTransform = cmsCreateProofingTransform;
		function cmsCreateProofingTransform(hInput, inputFormat, hOutput, outputFormat, proofing, intent, proofingIntent, flags) {
			return ccall("cmsCreateProofingTransform", "number", [
				"number",
				"number",
				"number",
				"number",
				"number",
				"number",
				"number",
				"number"
			], [
				hInput,
				inputFormat,
				hOutput,
				outputFormat,
				proofing,
				intent,
				proofingIntent,
				flags
			]);
		}
		Module.cmsDeleteTransform = cmsDeleteTransform;
		function cmsDeleteTransform(transform) {
			if (!transform) throw new Error("cmsDeleteTransform expects a non-false transform parameter");
			ccall("cmsDeleteTransform", void 0, ["number"], [transform]);
		}
		Module.cmsGetTransformInputFormat = cmsGetTransformInputFormat;
		function cmsGetTransformInputFormat(transform) {
			return ccall("cmsGetTransformInputFormat", "number", ["number"], [transform]);
		}
		Module.cmsGetTransformOutputFormat = cmsGetTransformOutputFormat;
		function cmsGetTransformOutputFormat(transform) {
			return ccall("cmsGetTransformOutputFormat", "number", ["number"], [transform]);
		}
		function getArrayType(bytes, float) {
			if (float) {
				if (bytes == 8) throw new Error("Float64Array not supported by LittleCMS");
				if (bytes == 2) throw new Error("Float16Array not supported by LittleCMS");
				return Float32Array;
			}
			if (bytes === 4) throw new Error("Uint32Array not supported by LittleCMS");
			if (bytes === 2) return Uint16Array;
			return Uint8Array;
		}
		Module.cmsDoTransform = cmsDoTransform;
		function cmsDoTransform(transform, inputArr, size) {
			var inputFormat = cmsGetTransformInputFormat(transform);
			var outputFormat = cmsGetTransformOutputFormat(transform);
			var inputIsFloat = Boolean(T_FLOAT(inputFormat));
			var outputIsFloat = Boolean(T_FLOAT(outputFormat));
			var inputChannels = T_CHANNELS(inputFormat) + T_EXTRA(inputFormat);
			var outputChannels = T_CHANNELS(outputFormat) + T_EXTRA(inputFormat);
			var inputBytes = T_BYTES(inputFormat);
			var outputBytes = T_BYTES(outputFormat);
			inputBytes = inputBytes < 1 ? 4 : inputBytes;
			outputBytes = outputBytes < 1 ? 4 : outputBytes;
			var inputLength = inputChannels * size;
			var inputBuffer = _malloc(inputLength * inputBytes);
			var dataOnHeap;
			const InputType = getArrayType(inputBytes, inputIsFloat);
			const OutputType = getArrayType(outputBytes, outputIsFloat);
			dataOnHeap = new InputType(Module.HEAPU8.buffer, inputBuffer, inputLength);
			dataOnHeap.set(inputArr);
			var outputLength = outputChannels * size;
			var outputBuffer = _malloc(outputLength * outputBytes);
			ccall("cmsDoTransform", void 0, [
				"number",
				"number",
				"number",
				"number"
			], [
				transform,
				inputBuffer,
				outputBuffer,
				size
			]);
			var outputArr = new OutputType(Module.HEAPU8.buffer, outputBuffer, outputLength).slice();
			_free(inputBuffer);
			_free(outputBuffer);
			return outputArr;
		}
		Module.cmsReadTag = cmsReadTag;
		function cmsReadTag(hProfile, sig) {
			return ccall("cmsReadTag", void 0, ["number", "number"], [hProfile, sig]);
		}
		Module.cmsReadTag_XYZ = cmsReadTag_XYZ;
		function cmsReadTag_XYZ(hProfile, sig) {
			var ptr = cmsReadTag(hProfile, sig);
			if (!ptr) return null;
			var xyz = new Float64Array(3);
			xyz[0] = getValue(ptr, "double");
			xyz[1] = getValue(ptr + 8, "double");
			xyz[2] = getValue(ptr + 16, "double");
			return xyz;
		}
		Module.cmsXYZ2xyY = cmsXYZ2xyY;
		function cmsXYZ2xyY(xyz) {
			var srcPtr = _malloc(24);
			var dstPtr = _malloc(24);
			setValue(srcPtr, xyz[0], "double");
			setValue(srcPtr + 8, xyz[1], "double");
			setValue(srcPtr + 16, xyz[2], "double");
			ccall("cmsXYZ2xyY", void 0, ["number", "number"], [dstPtr, srcPtr]);
			var xyY = new Float64Array(3);
			xyY[0] = getValue(dstPtr, "double");
			xyY[1] = getValue(dstPtr + 8, "double");
			xyY[2] = getValue(dstPtr + 16, "double");
			_free(srcPtr);
			_free(dstPtr);
			return xyY;
		}
		return moduleArg.ready;
	});
})();
//#endregion
//#region app/tile-render-flags.mjs
const TILE_BACKDROP_CLEAR = Symbol("temporary tile backdrop clearing");
//#endregion
//#region app/color-profile-command.mjs
/** Pure command validation. Color transforms are computed in a bounded worker;
* the shared engine replays only profile/pixel/palette changes, never a snapshot. */
const own$4 = (value, key) => Object.prototype.hasOwnProperty.call(value, key);
const record$3 = (value) => value && typeof value === "object" && !Array.isArray(value) && [Object.prototype, null].includes(Object.getPrototypeOf(value));
const fail$13 = (message) => {
	throw Error(`Color profile: ${message}`);
};
function fields(value, allowed, label) {
	if (!record$3(value) || Object.keys(value).some((key) => !allowed.includes(key))) fail$13(`Invalid ${label}.`);
}
function normalizeColorProfile(input = {
	type: 1,
	flags: 0,
	gamma: 0
}) {
	if (input === "sRGB") input = {
		type: 1,
		flags: 0,
		gamma: 0
	};
	fields(input, [
		"type",
		"flags",
		"gamma",
		"icc",
		"name"
	], "profile");
	const { type, flags = 0, gamma = 0 } = input;
	if (![
		0,
		1,
		2
	].includes(type) || ![0, 1].includes(flags) || flags && type !== 1 || !Number.isFinite(gamma) || gamma < 0 || gamma > 10 || flags && gamma < .1) fail$13("Unsupported profile type, flags or gamma.");
	const profile = {
		type,
		flags,
		gamma
	};
	if (own$4(input, "name")) {
		if (typeof input.name !== "string" || input.name.includes("\0") || new TextEncoder().encode(input.name).length > 4096) fail$13("Profile names must be text of at most 4096 bytes.");
		profile.name = input.name;
	}
	if (type === 2) {
		const data = input.icc;
		if (!Array.isArray(data) || data.length < 132 || data.length > 4 * 1024 * 1024 || data.some((value) => !Number.isInteger(value) || value < 0 || value > 255)) fail$13("ICC data must contain 132 bytes to 4 MB.");
		const bytes = Uint8Array.from(data), view = new DataView(bytes.buffer);
		if (view.getUint32(0) !== bytes.length || String.fromCharCode(...bytes.subarray(36, 40)) !== "acsp") fail$13("Invalid ICC header.");
		if (!["RGB ", "GRAY"].includes(String.fromCharCode(...bytes.subarray(16, 20)))) fail$13("Only RGB and grayscale ICC profiles are supported.");
		const count = view.getUint32(128);
		if (count > 4096 || 132 + count * 12 > bytes.length) fail$13("Invalid ICC tag table.");
		for (let i = 0; i < count; i++) {
			const start = view.getUint32(136 + i * 12), length = view.getUint32(140 + i * 12);
			if (start < 128 || start + length > bytes.length) fail$13("ICC tag lies outside the profile.");
		}
		profile.icc = [...data];
	} else if (own$4(input, "icc")) fail$13("Only embedded ICC profiles can contain ICC data.");
	return profile;
}
function colors(value, length, mode, label) {
	if (!Array.isArray(value) || value.length !== length) fail$13(`${label} must keep its original length.`);
	return value.map((color) => {
		if (color === null && label === "Image pixels") return null;
		if (typeof color !== "string" || !/^#[\da-f]{8}$/i.test(color)) fail$13(`${label} must contain RGBA colors.`);
		color = color.toLowerCase();
		if (mode === "grayscale" && (color.slice(1, 3) !== color.slice(3, 5) || color.slice(3, 5) !== color.slice(5, 7))) fail$13("Grayscale conversion must keep equal RGB channels.");
		return color.slice(7) === "00" && label === "Image pixels" ? null : color;
	});
}
function applyColorProfileCommand(document, command) {
	fields(command, [
		"type",
		"profile",
		"replacements",
		"frameId",
		"layerId"
	], "profile command");
	const profile = normalizeColorProfile(command.profile);
	if (profile.type === 2 && String.fromCharCode(...profile.icc.slice(16, 20)) === "GRAY" && document.colorMode !== "grayscale") fail$13("A gray profile requires a grayscale sprite.");
	if (document.layers.some((layer) => layer.locked)) fail$13("Unlock every layer before changing the working color profile.");
	const changes = command.replacements;
	if (changes !== void 0) {
		fields(changes, [
			"images",
			"palette",
			"framePalettes"
		], "conversion changes");
		const raster = Object.entries(document.images).filter(([, image]) => !image.tilemap);
		if (document.colorMode === "indexed") {
			if (changes.images !== void 0 && (!Array.isArray(changes.images) || changes.images.length)) fail$13("Indexed conversion must preserve pixel indices.");
		} else {
			if (!Array.isArray(changes.images) || changes.images.length !== raster.length) fail$13("Conversion must include every existing raster image once.");
			const seen = /* @__PURE__ */ new Set();
			for (const entry of changes.images) {
				fields(entry, ["id", "pixels"], "image replacement");
				const image = document.images[entry.id];
				if (typeof entry.id !== "string" || !own$4(document.images, entry.id) || !image || image.tilemap || seen.has(entry.id)) fail$13("Conversion contains an invalid or duplicate image ID.");
				seen.add(entry.id);
				document.images[entry.id] = {
					...image,
					pixels: colors(entry.pixels, image.width * image.height, document.colorMode, "Image pixels")
				};
			}
		}
		if (document.colorMode === "grayscale") {
			if (own$4(changes, "palette") || own$4(changes, "framePalettes")) fail$13("Grayscale conversion must preserve palettes.");
		} else {
			document.palette = colors(changes.palette, document.palette.length, "rgba", "Palette");
			const frames = document.frames.filter((frame) => frame.palette);
			if (!Array.isArray(changes.framePalettes) || changes.framePalettes.length !== frames.length) fail$13("Conversion must preserve every frame palette.");
			const seen = /* @__PURE__ */ new Set();
			for (const entry of changes.framePalettes) {
				fields(entry, ["frameId", "palette"], "frame palette replacement");
				const frame = frames.find((frame) => frame.id === entry.frameId);
				if (!frame || seen.has(entry.frameId)) fail$13("Invalid or duplicate frame palette.");
				seen.add(entry.frameId);
				frame.palette = colors(entry.palette, frame.palette.length, "rgba", "Frame palette");
			}
		}
	}
	document.metadata.aseprite = {
		...document.metadata.aseprite,
		colorProfile: profile
	};
}
//#endregion
//#region app/tileset-access.mjs
/** Native tile numbering for commands and scripting, matching native export. No I/O. */
function tilesetSlots(document, tileset) {
	const native = Number.isInteger(tileset.asepriteId) && (!!document.images[tileset.imageId] || !!(tileset.flags & 1));
	let count = native ? tileset.tileCount ?? 0 : 1;
	if (!Number.isSafeInteger(count) || count < 0 || count > 65536) throw Error("Invalid native tileset count.");
	const entries = /* @__PURE__ */ new Map();
	for (const tile of tileset.tiles ?? []) {
		const index = native && Number.isInteger(tile.asepriteTileId) ? tile.asepriteTileId : count++;
		if (!Number.isSafeInteger(index) || index < 0 || index >= 65536 || entries.has(index)) throw Error("Invalid or duplicate native tile index.");
		count = Math.max(count, index + 1);
		entries.set(index, tile);
	}
	return {
		native,
		count,
		entries
	};
}
function assertTilesetEditable(document, tilesetId) {
	for (const item of document.layers) if (item.tilesetId === tilesetId || Object.values(item.tilemaps ?? {}).some((map) => map.tilesetId === tilesetId)) {
		let layer = item;
		while (layer) {
			if (layer.locked) throw Error(`Layer “${layer.name}” is locked.`);
			layer = document.layers.find((value) => value.id === layer.parentId);
		}
	}
}
//#endregion
//#region app/tileset-structure.mjs
const copy$2 = (value) => structuredClone(value);
const integer$4 = (value, min, max, label) => {
	if (!Number.isSafeInteger(value) || value < min || value > max) throw Error(`${label} must be an integer from ${min} to ${max}.`);
	return value;
};
const find = (doc, id) => {
	const ts = doc.tilesets.find((item) => item.id === id);
	if (!ts) throw Error("Tileset not found.");
	return ts;
};
const blank = (doc) => doc.colorMode === "indexed" ? 0 : null;
function atlasSize(width, height, count, limits) {
	integer$4(width, 1, limits.imageEdge, "Tile width");
	integer$4(height, 1, limits.imageEdge, "Tile height");
	integer$4(count, 1, 65536, "Tile count");
	integer$4(height * count, 1, limits.imageEdge, "Tileset atlas height");
	if (width * height * count > limits.pixels) throw Error("Tileset exceeds the stored pixel budget.");
	return width * height * count;
}
function numericId(doc) {
	const used = new Set(doc.tilesets.map((ts) => ts.asepriteId));
	let value = 0;
	while (used.has(value)) value++;
	return value;
}
function tileId(entries) {
	const used = new Set(entries.map((entry) => entry.id));
	let value = 1;
	while (used.has(`tile-created-${value}`)) value++;
	return `tile-created-${value}`;
}
function raster(doc, ts, tile) {
	if (!tile) return Array(ts.tileWidth * ts.tileHeight).fill(doc.colorMode === "indexed" ? doc.metadata?.aseprite?.transparentIndex ?? 0 : null);
	const image = doc.images[tile.imageId];
	if (!image || image.tilemap) throw Error("Tileset artwork must be embedded before structural editing.");
	const r = tile.sourceRect ?? {
		x: 0,
		y: 0,
		width: image.width,
		height: image.height
	};
	return Array.from({ length: ts.tileWidth * ts.tileHeight }, (_, index) => {
		const x = index % ts.tileWidth, y = Math.floor(index / ts.tileWidth);
		return image.pixels[(r.y + Math.min(r.height - 1, Math.floor(y * r.height / ts.tileHeight))) * image.width + r.x + Math.min(r.width - 1, Math.floor(x * r.width / ts.tileWidth))];
	});
}
function entriesFor(doc, ts, limits) {
	if (ts.flags & 1) throw Error("Embed external tileset artwork before structural editing.");
	const slots = tilesetSlots(doc, ts);
	atlasSize(ts.tileWidth, ts.tileHeight, slots.count, limits);
	const result = [];
	for (let index = 0; index < slots.count; index++) {
		const tile = slots.entries.get(index);
		if (!tile && (slots.native || index !== 0)) throw Error("Tileset has missing tile artwork.");
		result.push({
			id: tile?.id ?? tileId(ts.tiles ?? []),
			pixels: raster(doc, ts, tile),
			userData: copy$2(tile?.userData ?? ts.tileUserData?.[index])
		});
	}
	return result;
}
function installAtlas(doc, ts, entries, api) {
	const native = Number.isInteger(ts.asepriteId) && !!ts.imageId;
	const count = entries.length, size = atlasSize(ts.tileWidth, ts.tileHeight, count, api.limits);
	api.reserve(doc, size);
	const imageId = api.fresh(doc, "image");
	doc.images[imageId] = {
		width: ts.tileWidth,
		height: ts.tileHeight * count,
		pixels: entries.flatMap((entry) => entry.pixels)
	};
	ts.imageId = imageId;
	ts.tileCount = count;
	ts.asepriteId ??= numericId(doc);
	ts.flags = (ts.flags ?? 0) | 2 | (native ? 0 : 4);
	ts.tiles = entries.map((entry, index) => ({
		id: entry.id,
		imageId,
		asepriteTileId: index,
		sourceRect: {
			x: 0,
			y: index * ts.tileHeight,
			width: ts.tileWidth,
			height: ts.tileHeight
		},
		...entry.userData ? { userData: copy$2(entry.userData) } : {}
	}));
	if (entries.some((entry) => entry.userData)) ts.tileUserData = entries.map((entry) => copy$2(entry.userData) ?? null);
	else delete ts.tileUserData;
}
function bits$1(cell, ids, flags) {
	if (cell == null) return flags & 4 ? 0 : 4294967295;
	const index = ids.get(cell.tileId);
	if (index == null) throw Error("Tilemap references an unknown tile.");
	let x = !!cell.flipX, y = !!cell.flipY, diagonal = false;
	const rotation = cell.rotate ?? 0;
	if (rotation === 90) {
		diagonal = true;
		[x, y] = [!y, x];
	} else if (rotation === 180) {
		x = !x;
		y = !y;
	} else if (rotation === 270) {
		diagonal = true;
		[x, y] = [y, !x];
	} else if (rotation !== 0) throw Error("Unsupported tile rotation.");
	return (index | (x ? 2147483648 : 0) | (y ? 1073741824 : 0) | (diagonal ? 536870912 : 0)) >>> 0;
}
/** Encode engine maps before changing resource slots. Native Lua leaves tile words unchanged. */
function nativeMaps(doc, layers, api) {
	const links = /* @__PURE__ */ new Map();
	for (const layer of layers) {
		if (!layer.tilemaps) continue;
		for (const [frameId, map] of Object.entries(layer.tilemaps)) {
			const ts = find(doc, map.tilesetId), slots = tilesetSlots(doc, ts), ids = new Map([...slots.entries].map(([index, tile]) => [tile.id, index]));
			const frame = doc.frames.find((frame) => frame.id === frameId);
			if (!frame) throw Error("Tilemap frame not found.");
			const tilemap = {
				bitsPerTile: 32,
				idMask: 536870911,
				xFlipMask: 2147483648,
				yFlipMask: 1073741824,
				diagonalFlipMask: 536870912,
				tiles: map.cells.map((cell) => bits$1(cell, ids, slots.native ? ts.flags : 4))
			};
			const previous = frame.cels[layer.id], sourceId = map.sourceImageId ?? previous?.imageId, source = doc.images[sourceId], key = sourceId ? `${sourceId}:${JSON.stringify([
				map.columns,
				map.rows,
				tilemap
			])}` : null;
			let imageId = source?.tilemap && source.width === map.columns && source.height === map.rows && JSON.stringify(source.tilemap) === JSON.stringify(tilemap) ? sourceId : key ? links.get(key) : null;
			if (!imageId) {
				api.reserve(doc, map.columns * map.rows);
				imageId = api.fresh(doc, "image");
				doc.images[imageId] = {
					width: map.columns,
					height: map.rows,
					pixels: [],
					tilemap
				};
				if (key) links.set(key, imageId);
			}
			frame.cels[layer.id] = {
				...previous,
				imageId,
				x: map.x ?? previous?.x ?? 0,
				y: map.y ?? previous?.y ?? 0,
				opacity: map.opacity ?? previous?.opacity ?? 1
			};
		}
		delete layer.tilemaps;
	}
}
function createNativeTileset(doc, command, api) {
	if (doc.tilesets.length >= 256) throw Error("Too many tilesets.");
	const source = command.copyTilesetId == null ? null : find(doc, command.copyTilesetId);
	const width = source?.tileWidth ?? command.tileWidth, height = source?.tileHeight ?? command.tileHeight, count = source ? tilesetSlots(doc, source).count : command.tileCount ?? 1;
	const size = atlasSize(width, height, count, api.limits);
	api.reserve(doc, size);
	const id = command.tilesetId ?? api.fresh(doc, "tileset");
	if (doc.tilesets.some((ts) => ts.id === id)) throw Error("Tileset ID already exists.");
	const origin = command.gridOrigin ?? source?.gridOrigin ?? {
		x: 0,
		y: 0
	};
	integer$4(origin.x, -65535, 65535, "Grid origin x");
	integer$4(origin.y, -65535, 65535, "Grid origin y");
	const ts = {
		id,
		name: source?.name ?? "",
		tileWidth: width,
		tileHeight: height,
		baseIndex: 1,
		flags: 6,
		asepriteId: numericId(doc),
		...source?.userData ? { userData: copy$2(source.userData) } : {},
		...origin.x || origin.y ? { gridOrigin: { ...origin } } : {}
	};
	installAtlas(doc, ts, source ? entriesFor(doc, source, api.limits) : Array.from({ length: count }, (_, index) => ({
		id: `tile-${index}`,
		pixels: Array(width * height).fill(blank(doc))
	})), api);
	doc.tilesets.push(ts);
	return ts;
}
function changeTilesetSlots(doc, command, api) {
	const ts = find(doc, command.tilesetId);
	assertTilesetEditable(doc, ts.id);
	const entries = entriesFor(doc, ts, api.limits), insert = command.type === "tileset.tileInsert", index = integer$4(command.tileIndex ?? entries.length, 1, insert ? entries.length : entries.length - 1, "Tile index");
	atlasSize(ts.tileWidth, ts.tileHeight, entries.length + (insert ? 1 : -1), api.limits);
	const layers = doc.layers.filter((layer) => layer.tilesetId === ts.id || Object.values(layer.tilemaps ?? {}).some((map) => map.tilesetId === ts.id));
	if (layers.some((layer) => [layer.tilesetId, ...Object.values(layer.tilemaps ?? {}).map((map) => map.tilesetId)].filter(Boolean).some((id) => id !== ts.id))) throw Error("Structural edits require each tilemap layer to use one tileset across frames.");
	nativeMaps(doc, layers, api);
	for (const layer of layers) layer.tilesetId = ts.id;
	if (insert && entries.some((entry) => entry.id === command.tileId)) throw Error("Tile ID already exists.");
	if (insert) entries.splice(index, 0, {
		id: command.tileId ?? tileId(entries),
		pixels: Array(ts.tileWidth * ts.tileHeight).fill(blank(doc))
	});
	else entries.splice(index, 1);
	installAtlas(doc, ts, entries, api);
}
function assignLayerTileset(doc, command, api) {
	const layer = api.layerFor(doc, command.layerId, true);
	if (layer.type !== "tilemap") throw Error("Tileset assignment requires a tilemap layer.");
	const ts = find(doc, command.tilesetId);
	if (ts.flags & 1) throw Error("Embed external tileset artwork before assigning it to a layer.");
	if (!ts.imageId || !Number.isInteger(ts.asepriteId) || ts.tiles?.some((tile) => !Number.isInteger(tile.asepriteTileId))) installAtlas(doc, ts, entriesFor(doc, ts, api.limits), api);
	nativeMaps(doc, [layer], api);
	layer.tilesetId = ts.id;
}
//#endregion
//#region app/rotation-raster.mjs
/*! PixelWall portable adaptation of the MIT Aseprite Document Library rotation
* algorithms. Copyright (c) 2018-present Igara Studio S.A.; 2001-2018 David Capello.
* RotSprite source: Copyright (c) 2020-2023 Igara Studio S.A.; 2001-2018 David Capello.
* Original Allegro rotation: Shawn Hargreaves; flipping: Andrew Geers;
* optimization: Sven Sandberg; C++ templates: David Capello.
* Full MIT permission and upstream notices: docs/rotation-NOTICES.txt,
* distributed as runtimes/rotation-NOTICES.txt. This JavaScript adaptation is
* modified from upstream: bounded owned buffers, explicit validation, pure output,
* no image-library dependencies, no global scratch storage, no mutable destination.
*
* Copyright (c) 2018-present Igara Studio S.A.
* Copyright (c) 2001-2018 David Capello
* 
* Permission is hereby granted, free of charge, to any person obtaining
* a copy of this software and associated documentation files (the
* "Software"), to deal in the Software without restriction, including
* without limitation the rights to use, copy, modify, merge, publish,
* distribute, sublicense, and/or sell copies of the Software, and to
* permit persons to whom the Software is furnished to do so, subject to
* the following conditions:
* 
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
* 
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
* LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
* OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
* WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
const UNIT = 65536, MAX_FIXED = 2147483647;
const fail$12 = (message) => {
	throw Error(message);
};
const int = (value, label, min, max) => {
	if (!Number.isSafeInteger(value) || value < min || value > max) fail$12(`${label} must be an integer from ${min} to ${max}.`);
	return value;
};
const fixed = (value) => value > 32767 ? MAX_FIXED : value < -32767 ? -MAX_FIXED : Math.trunc(value * UNIT + (value < 0 ? -.5 : .5));
const multiply = (a, b) => fixed(a / UNIT * (b / UNIT));
const divide = (a, b) => b === 0 ? a < 0 ? -MAX_FIXED : MAX_FIXED : fixed(a / b);
const rounded = (value) => (value >> 16) + ((value & 32768) >>> 15);
const outOf = (value, size) => value >> 16 < 0 || value >> 16 >= size;
/** MIT scanline parallelogram port. Coordinates are outer pixel corners, TL/TR/BR/BL.
* Fixed-point ties, endpoint adjustments and edge repair deliberately match upstream. */
function mapParallelogram(sw, sh, dw, dh, points, draw) {
	const xs = points.map((p) => p[0] * UNIT), ys = points.map((p) => p[1] * UNIT);
	let top = 0;
	for (let i = 1; i < 4; i++) if (ys[i] < ys[top]) top = i;
	const right = multiply(xs[top + 1 & 3] - xs[top], ys[top - 1 & 3] - ys[top]) > multiply(xs[top - 1 & 3] - xs[top], ys[top + 1 & 3] - ys[top]) ? 1 : -1;
	const bx = [], by = [], px = [], py = [];
	for (let i = 0, index = top; i < 4; i++, index = index + right & 3) {
		bx[i] = xs[index];
		by[i] = ys[index];
		px[i] = index === 0 || index === 3 ? 0 : sw * UNIT - 1;
		py[i] = index < 2 ? 0 : sh * UNIT - 1;
	}
	const clipRight = dw * UNIT - 1;
	if (bx[3] > clipRight && bx[0] > clipRight && bx[2] > clipRight || bx[1] < 0 && bx[0] < 0 && bx[2] < 0) return;
	const bottom = Math.min(dh, by[2] + 32768 >> 16);
	let y = Math.max(0, by[0] + 32768 >> 16);
	if (y >= bottom) return;
	let extra = y * UNIT + 32768 - by[0];
	let ldx = divide(bx[3] - bx[0], by[3] - by[0]), lx = bx[0] + multiply(extra, ldx) | 0;
	let spdx = divide(px[3] - px[0], by[3] - by[0]), spx = px[0] + multiply(extra, spdx) | 0;
	let spdy = divide(py[3] - py[0], by[3] - by[0]), spy = py[0] + multiply(extra, spdy) | 0;
	let leftBottom = Math.min(bottom, by[3] + 32768 >> 16);
	let rdx = divide(bx[1] - bx[0], by[1] - by[0]), rx = bx[0] + multiply(extra, rdx) | 0, rightBottom = by[1] + 32768 >> 16;
	const determinant = (xs[1] - xs[0]) * (ys[3] - ys[0]) - (xs[3] - xs[0]) * (ys[1] - ys[0]);
	if (!determinant) return;
	const dx = Math.trunc((ys[3] - ys[0]) * UNIT * (UNIT * sw) / determinant) | 0;
	const dy = Math.trunc((ys[1] - ys[0]) * UNIT * (UNIT * sh) / -determinant) | 0;
	while (true) {
		if (y >= leftBottom) {
			if (y >= bottom) break;
			extra = y * UNIT + 32768 - by[3];
			ldx = divide(bx[2] - bx[3], by[2] - by[3]);
			lx = bx[3] + multiply(extra, ldx) | 0;
			spdx = divide(px[2] - px[3], by[2] - by[3]);
			spx = px[3] + multiply(extra, spdx) | 0;
			spdy = divide(py[2] - py[3], by[2] - by[3]);
			spy = py[3] + multiply(extra, spdy) | 0;
			leftBottom = Math.min(bottom, by[2] + 32768 >> 16);
		}
		if (y >= rightBottom) {
			extra = y * UNIT + 32768 - by[1];
			rdx = divide(bx[2] - bx[1], by[2] - by[1]);
			rx = bx[1] + multiply(extra, rdx) | 0;
			rightBottom = bottom;
		}
		let left = Math.max(0, lx + 32768 & -65536), right = Math.min(clipRight, rx - 32768 & -65536);
		let u = spx + multiply(left + 32767 - lx, dx) | 0, v = spy + multiply(left + 32767 - lx, dy) | 0;
		scanline: {
			if (left > right) break scanline;
			if (outOf(u, sw)) {
				if (u < 0 && dx <= 0 || u > 0 && dx >= 0) break scanline;
				do {
					u = u + dx | 0;
					left += UNIT;
					if (left > right) break scanline;
				} while (outOf(u, sw));
			}
			let edge = u + (right - left >> 16) * dx | 0;
			if (outOf(edge, sw)) if (edge < 0 && dx <= 0 || edge > 0 && dx >= 0) do {
				right -= UNIT;
				edge = edge - dx | 0;
				if (left > right) break scanline;
			} while (outOf(edge, sw));
			else break scanline;
			if (outOf(v, sh)) {
				if (v < 0 && dy <= 0 || v > 0 && dy >= 0) break scanline;
				do {
					v = v + dy | 0;
					left += UNIT;
					if (left > right) break scanline;
				} while (outOf(v, sh));
			}
			edge = v + (right - left >> 16) * dy | 0;
			if (outOf(edge, sh)) if (edge < 0 && dy <= 0 || edge > 0 && dy >= 0) do {
				right -= UNIT;
				edge = edge - dy | 0;
				if (left > right) break scanline;
			} while (outOf(edge, sh));
			else break scanline;
			for (let x = left >> 16, last = right >> 16; x <= last; x++, u = u + dx | 0, v = v + dy | 0) {
				const ix = u >> 16, iy = v >> 16;
				if (ix >= 0 && iy >= 0 && ix < sw && iy < sh) draw(x, y, ix, iy);
			}
		}
		y++;
		lx = lx + ldx | 0;
		spx = spx + spdx | 0;
		spy = spy + spdy | 0;
		rx = rx + rdx | 0;
	}
}
function scale2x(source, width, height) {
	const pixels = new Uint32Array(width * height * 4), row = width * 2;
	for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
		const p = source[y * width + x], a = y ? source[(y - 1) * width + x] : p, b = x < width - 1 ? source[y * width + x + 1] : p, c = x ? source[y * width + x - 1] : p, d = y < height - 1 ? source[(y + 1) * width + x] : p, at = y * 2 * row + x * 2;
		pixels[at] = c === a && c !== d && a !== b ? a : p;
		pixels[at + 1] = a === b && a !== c && b !== d ? b : p;
		pixels[at + row] = d === c && d !== b && c !== a ? c : p;
		pixels[at + row + 1] = b === d && b !== a && d !== c ? d : p;
	}
	return pixels;
}
function endpointAxis(sourceSize, destinationSize) {
	const step = divide((sourceSize - 1) * UNIT, (destinationSize - 1) * UNIT), indices = new Uint32Array(destinationSize);
	for (let i = 0, coordinate = 0; i < destinationSize; i++, coordinate = Math.min(MAX_FIXED, coordinate + step)) indices[i] = Math.min(sourceSize - 1, rounded(coordinate));
	return indices;
}
/** Pure Fast/RotSprite image mapping onto a transparent destination.
* Pixels are Aseprite-packed RGBA (R in low byte), gray+alpha, or palette indices.
* Corners are integer outer corners, not an angle: UI corner rounding is separate.
* Optional source-size 0/1 mask retains irregular selection geometry.
* Values mode carries arbitrary uint32 IDs with a reserved transparent sentinel.
* No destination blending occurs; callers composite the returned patch once. */
function rasterizeRotation({ pixels, width, height, destinationWidth, destinationHeight, corners, method = "fast", pixelFormat = "rgba", maskColor = 0, mask = null }) {
	width = int(width, "Source width", 1, 32767);
	height = int(height, "Source height", 1, 32767);
	const dw = int(destinationWidth, "Destination width", 1, 32767), dh = int(destinationHeight, "Destination height", 1, 32767);
	if (!["fast", "rotsprite"].includes(method)) fail$12("Rotation method must be fast or rotsprite.");
	if (![
		"rgba",
		"grayscale",
		"indexed",
		"bitmap",
		"values"
	].includes(pixelFormat)) fail$12("Unsupported rotation pixel format.");
	const sourceCount = width * height, destinationCount = dw * dh;
	if (sourceCount > 16777216 || destinationCount > 16777216) fail$12("Rotation exceeds its pixel budget.");
	if (!(Array.isArray(pixels) || pixels instanceof Uint32Array) || pixels.length !== sourceCount) fail$12("Rotation source pixels do not match its dimensions.");
	const maxPixel = pixelFormat === "indexed" ? 255 : pixelFormat === "bitmap" ? 1 : pixelFormat === "grayscale" ? 65535 : 4294967295;
	for (const value of pixels) int(value, "Rotation pixel", 0, maxPixel);
	int(maskColor, "Transparent mask color", 0, maxPixel);
	if (pixelFormat === "rgba" && maskColor >>> 24 || pixelFormat === "grayscale" && maskColor >>> 8) fail$12("RGBA and grayscale rotation require a transparent mask color.");
	if (mask && (!(Array.isArray(mask) || mask instanceof Uint8Array) || mask.length !== sourceCount || mask.some((value) => value !== 0 && value !== 1))) fail$12("Rotation mask must contain one 0/1 value per source pixel.");
	if (!Array.isArray(corners) || corners.length !== 4 || corners.some((p) => !Array.isArray(p) || p.length !== 2)) fail$12("Rotation requires four XY corner pairs.");
	for (const point of corners) for (const value of point) int(value, "Rotation corner", -32767, 32767);
	const xmin = Math.min(...corners.map((p) => p[0])), xmax = Math.max(...corners.map((p) => p[0])), ymin = Math.min(...corners.map((p) => p[1])), ymax = Math.max(...corners.map((p) => p[1])), rw = xmax - xmin, rh = ymax - ymin;
	if (rw > 32767 || rh > 32767) fail$12("Rotation corner span exceeds fixed-point range.");
	if (corners[0][0] + corners[2][0] !== corners[1][0] + corners[3][0] || corners[0][1] + corners[2][1] !== corners[1][1] + corners[3][1]) fail$12("Rotation corners must form a parallelogram.");
	const bytes = (sourceCount + destinationCount) * 5 + (method === "rotsprite" ? sourceCount * 84 * 4 + rw * rh * 64 * 5 + (mask ? (width + height) * 8 * 4 : 0) + (rw + rh) * 4 : 0);
	if (method === "rotsprite" && (Math.max(width, height, rw, rh) > 4095 || bytes > 16777216 * 4)) fail$12("RotSprite exceeds its 8x temporary pixel budget; reduce the selection or choose Fast.");
	if (bytes > 16777216 * 4) fail$12("Rotation exceeds its temporary pixel budget.");
	const output = new Uint32Array(destinationCount).fill(maskColor), coverage = new Uint8Array(destinationCount);
	const accepts = (value) => pixelFormat === "rgba" ? !(maskColor >>> 24) || (value & 16777215) !== (maskColor & 16777215) : pixelFormat === "grayscale" ? !(maskColor >>> 8) || (value & 255) !== (maskColor & 255) : value !== maskColor;
	if (!rw || !rh) return {
		width: dw,
		height: dh,
		pixels: output,
		coverage
	};
	if (method === "fast") mapParallelogram(width, height, dw, dh, corners, (x, y, ix, iy) => {
		const at = iy * width + ix, value = pixels[at];
		if ((!mask || mask[at]) && accepts(value)) {
			output[y * dw + x] = value;
			coverage[y * dw + x] = 1;
		}
	});
	else {
		let enlarged = pixels, w = width, h = height;
		for (let i = 0; i < 3; i++) {
			enlarged = scale2x(enlarged, w, h);
			w *= 2;
			h *= 2;
		}
		const high = new Uint32Array(rw * rh * 64).fill(maskColor), highCoverage = new Uint8Array(rw * rh * 64);
		const mx = mask ? endpointAxis(width, w) : null, my = mask ? endpointAxis(height, h) : null;
		mapParallelogram(w, h, rw * 8, rh * 8, corners.map(([x, y]) => [(x - xmin) * 8, (y - ymin) * 8]), (x, y, ix, iy) => {
			const value = enlarged[iy * w + ix];
			if ((!mask || mask[my[iy] * width + mx[ix]]) && accepts(value)) {
				high[y * rw * 8 + x] = value;
				highCoverage[y * rw * 8 + x] = 1;
			}
		});
		const left = Math.max(0, xmin), top = Math.max(0, ymin), targetW = Math.max(0, Math.min(rw, dw - left)), targetH = Math.max(0, Math.min(rh, dh - top));
		if (targetW && targetH) {
			const xx = endpointAxis(rw * 8, targetW), yy = endpointAxis(rh * 8, targetH);
			for (let y = 0; y < targetH; y++) for (let x = 0; x < targetW; x++) {
				const at = yy[y] * rw * 8 + xx[x], target = (y + top) * dw + x + left;
				output[target] = high[at];
				coverage[target] = highCoverage[at];
			}
		}
	}
	return {
		width: dw,
		height: dh,
		pixels: output,
		coverage
	};
}
//#endregion
//#region app/native-indexed.mjs
/*! Portable modified adaptation of the separately MIT-licensed Aseprite Document
* and Render Libraries, v1.3.18.5. Copyright (c) 2018-present Igara Studio S.A.;
* Copyright (c) 2001-2018 David Capello. File-specific copyright includes
* 2020-2024 Igara Studio S.A. (octree), 2019-2022 Igara Studio S.A. and
* 2017 David Capello (dithering), 2001-2017 David Capello (median cut).
* Modifications: JavaScript sparse storage, resource validation, pure inputs and
* outputs, integer arithmetic and explicit modes. Full provenance:
* docs/indexed-NOTICES.txt, distributed as runtimes/indexed-NOTICES.txt.
*
* Permission is hereby granted, free of charge, to any person obtaining
* a copy of this software and associated documentation files (the
* "Software"), to deal in the Software without restriction, including
* without limitation the rights to use, copy, modify, merge, publish,
* distribute, sublicense, and/or sell copies of the Software, and to
* permit persons to whom the Software is furnished to do so, subject to
* the following conditions:
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
* IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
* DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
* ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
* DEALINGS IN THE SOFTWARE.
*/
const MAX_WORK$1 = 67108864, MAX_PIXELS$2 = 16777216, MAX_NODES = 1048576;
const fail$11 = (message) => {
	throw Error(`Native indexed conversion: ${message}`);
};
const integer$3 = (n, low, high, label) => {
	if (!Number.isSafeInteger(n) || n < low || n > high) fail$11(`invalid ${label}.`);
	return n;
};
const clamp$2 = (n) => Math.max(0, Math.min(255, n));
const div = (n, d) => Math.trunc(n / d);
const packed = (c) => (c[0] | c[1] << 8 | c[2] << 16 | c[3] << 24) >>> 0;
const unpack = (n) => [
	n & 255,
	n >>> 8 & 255,
	n >>> 16 & 255,
	n >>> 24
];
const hex$3 = (c) => "#" + c.map((v) => v.toString(16).padStart(2, "0")).join("");
const parse = (c) => {
	if (c === null) return [
		0,
		0,
		0,
		0
	];
	if (typeof c !== "string" || !/^#[0-9a-f]{8}$/i.test(c)) fail$11("colors must be RGBA hex strings or null.");
	return [
		1,
		3,
		5,
		7
	].map((i) => parseInt(c.slice(i, i + 2), 16));
};
function meter(input) {
	const budget = input ?? { remaining: MAX_WORK$1 };
	integer$3(budget.remaining, 0, MAX_WORK$1, "work budget");
	return (n) => {
		budget.remaining -= n;
		if (budget.remaining < 0) fail$11("work limit exceeded.");
	};
}
/** Exact palette-search arithmetic. Octree preserves last exact duplicate entries;
* RGB5A3 first expands quantized channels, then searches. No premultiplication. */
function createNativeRgbMap(palette, input = {}) {
	if (!Array.isArray(palette) || !palette.length || palette.length > 256) fail$11("palette must contain 1–256 entries.");
	const colors = palette.map(parse), mask = input.transparentIndex == null ? -1 : integer$3(input.transparentIndex, 0, palette.length - 1, "transparent index");
	const algorithm = input.rgbmap ?? "octree", fit = input.fitCriteria ?? "default", spend = meter(input.budget);
	if (!["octree", "rgb5a3"].includes(algorithm)) fail$11("unsupported RGB map.");
	if (![
		"default",
		"rgb",
		"linearizedRGB",
		"ciexyz",
		"cielab"
	].includes(fit)) fail$11("unsupported fitting criterion.");
	function space(c) {
		if (fit === "rgb" || fit === "default") return c;
		const lin = c.slice(0, 3).map((v) => {
			v /= 255;
			return v <= .04045 ? v / 12.92 : ((v + .055) / 1.055) ** 2.4;
		});
		if (fit === "linearizedRGB") return lin;
		const [r, g, b] = lin, x = 41.24564 * r + 35.75761 * g + 18.04375 * b, y = 21.26729 * r + 71.51522 * g + 7.2175 * b, z = 1.93339 * r + 11.9192 * g + 95.03041 * b;
		if (fit === "ciexyz") return [
			x,
			y,
			z
		];
		const f = (t) => t > .00885645171 ? t ** .3333333333333333 : t / .12841855 + .137931034, fy = f(y / 100);
		return [
			116 * fy - 16,
			500 * (f(x / 95.0489) - fy),
			200 * (fy - f(z / 108.884))
		];
	}
	const spaces = colors.map(space), exact = /* @__PURE__ */ new Map(), cache = /* @__PURE__ */ new Map();
	function best(c) {
		spend(colors.length);
		if ((fit === "default" ? c[3] >> 3 : c[3]) === 0 && mask >= 0) return mask;
		let result = 0, least = Infinity;
		const v = space(c);
		for (let i = 0; i < colors.length; i++) {
			if (i === mask) continue;
			const p = colors[i];
			const distance = fit === "default" ? ((c[0] >> 3) - (p[0] >> 3)) ** 2 * 900 + ((c[1] >> 3) - (p[1] >> 3)) ** 2 * 3481 + ((c[2] >> 3) - (p[2] >> 3)) ** 2 * 121 + ((c[3] >> 3) - (p[3] >> 3)) ** 2 * 64 : (v[0] - spaces[i][0]) ** 2 + (v[1] - spaces[i][1]) ** 2 + (v[2] - spaces[i][2]) ** 2 + ((c[3] - p[3]) / 128) ** 2;
			if (distance < least) {
				least = distance;
				result = i;
			}
		}
		return result;
	}
	if (algorithm === "octree") for (let i = 0; i < colors.length; i++) exact.set(packed(colors[i]), i === mask ? best(colors[i]) : i);
	function map(c) {
		spend(1);
		let key;
		if (algorithm === "octree") {
			key = packed(c);
			if (exact.has(key)) return exact.get(key);
		} else {
			c = c.map((v, i) => i < 3 ? v >> 3 << 3 | v >> 5 : v >> 5 << 5 | v >> 5 << 2 | v >> 6);
			key = packed(c);
		}
		if (cache.has(key)) return cache.get(key);
		const index = best(c);
		if (cache.size < 65536) cache.set(key, index);
		return index;
	}
	return {
		map,
		colors,
		transparentIndex: mask
	};
}
function bayer$1(n) {
	let m = [[0, 2], [3, 1]];
	for (let size = 2; size < n; size *= 2) {
		const next = Array.from({ length: size * 2 }, () => []);
		for (let y = 0; y < size * 2; y++) for (let x = 0; x < size * 2; x++) next[y][x] = 4 * m[y % size][x % size] + [[0, 2], [3, 1]][Math.floor(y / size)][Math.floor(x / size)];
		m = next;
	}
	return m;
}
const colorDistance = (a, b) => (a[3] && b[3] ? Math.abs(a[0] - b[0]) * 2126 + Math.abs(a[1] - b[1]) * 7152 + Math.abs(a[2] - b[2]) * 722 : 0) + Math.abs(a[3] - b[3]) * 2e4;
function mapNativeIndexedImage(image, palette, input = {}) {
	const width = integer$3(image.width, 1, 65535, "width"), height = integer$3(image.height, 1, 65535, "height");
	if (width * height > MAX_PIXELS$2 || !Array.isArray(image.pixels) || image.pixels.length !== width * height) fail$11("invalid raster pixels.");
	const budget = input.budget ?? { remaining: MAX_WORK$1 };
	const { map, colors, transparentIndex: mask } = createNativeRgbMap(palette, {
		...input,
		budget
	}), spend = meter(budget), output = Array(width * height);
	let mode = input.dithering ?? "none";
	if (![
		"none",
		"aseprite-ordered",
		"aseprite-old",
		"aseprite-error-diffusion"
	].includes(mode)) fail$11("unsupported native dithering.");
	const strength = input.ditherStrength ?? 1;
	if (typeof strength !== "number" || !Number.isFinite(strength) || strength < 0 || strength > 1) fail$11("invalid dither strength.");
	if (mode.startsWith("aseprite-") && mode !== "aseprite-error-diffusion" && strength !== 1) fail$11("native ordered dithering does not have a strength control.");
	if (input.sourceColorMode === "grayscale") mode = "none";
	const matrixName = input.ditherMatrix ?? "bayer4x4";
	if (![
		"bayer2x2",
		"bayer4x4",
		"bayer8x8"
	].includes(matrixName)) fail$11("unsupported Bayer matrix.");
	const size = Number(matrixName[5]), matrix = bayer$1(size), maximum = size * size - 1;
	const tw = integer$3(input.tileWidth ?? width, 1, width, "tile width"), th = integer$3(input.tileHeight ?? height, 1, height, "tile height");
	if (width % tw || height % th) fail$11("atlas dimensions must be multiples of the tile grid.");
	const orderedCache = /* @__PURE__ */ new Map();
	function ordered(c) {
		const key = packed(c);
		if (orderedCache.has(key)) return orderedCache.get(key);
		const index = map(c), c0 = colors[index];
		let alternate = index, mix = 0;
		if (mode === "aseprite-old") {
			alternate = map(c.map((v, i) => clamp$2(2 * v - c0[i])));
			const D = colorDistance(c0, colors[alternate]);
			mix = D ? div(maximum * colorDistance(c0, c), D) : 0;
		} else {
			let closest = Infinity;
			spend(colors.length);
			for (let i = 0; i < colors.length; i++) {
				if (i === mask) continue;
				const c1 = colors[i];
				let m = 0, divisor = 0;
				for (let k = 0; k < 4; k++) if ((k === 3 || c[3] && c0[3] && c1[3]) && c1[k] !== c0[k]) {
					const weight = [
						2126,
						7152,
						722,
						2e4
					][k];
					m += div(weight * maximum * (c[k] - c0[k]), c1[k] - c0[k]);
					divisor += weight;
				}
				if (m) m = Math.max(0, Math.min(maximum, divisor ? div(m, divisor) : m));
				const distance = colorDistance(c, c0.map((v, k) => v + div((c1[k] - v) * m, maximum))) + div(colorDistance(c0, c1), 10);
				if (distance < closest) {
					closest = distance;
					alternate = i;
					mix = m;
				}
			}
		}
		const result = {
			index,
			alternate,
			mix
		};
		if (orderedCache.size < 65536) orderedCache.set(key, result);
		return result;
	}
	for (let top = 0; top < height; top += th) for (let left = 0; left < width; left += tw) {
		const stride = tw + 2;
		let row = Array.from({ length: 4 }, () => new Int32Array(stride)), next = Array.from({ length: 4 }, () => new Int32Array(stride));
		for (let y = 0; y < th; y++) {
			const reverse = mode === "aseprite-error-diffusion" && y & 1;
			for (let step = 0; step < tw; step++) {
				const x = reverse ? tw - 1 - step : step, at = (top + y) * width + left + x, c = parse(image.pixels[at]);
				spend(1);
				let index;
				if (mode === "aseprite-error-diffusion") {
					const v = c.map((n, k) => clamp$2(n + row[k][x + 1]));
					index = map(v);
					const p = index === mask || colors[index][3] === 0 ? [...c.slice(0, 3), 0] : colors[index];
					for (let k = 0; k < 4; k++) {
						const q = div((v[k] - p[k]) * Math.trunc(strength * 100), 100), sign = reverse ? -1 : 1;
						row[k][x + 1 + sign] += div(q * 7, 16);
						next[k][x + 1 - sign] += div(q * 3, 16);
						next[k][x + 1] += div(q * 5, 16);
						next[k][x + 1 + sign] += div(q, 16);
					}
				} else if (c[3] === 0 && (mask >= 0 || mode === "none")) index = mask < 0 ? 0 : mask;
				else if (mode === "none") index = map(c);
				else {
					const choice = ordered(c);
					index = matrix[y % size][x % size] < choice.mix ? choice.alternate : choice.index;
				}
				output[at] = index === mask ? null : index;
			}
			row = next;
			next = Array.from({ length: 4 }, () => new Int32Array(stride));
		}
	}
	return output;
}
function histogram(samples, withAlpha, spend) {
	const colors = /* @__PURE__ */ new Map();
	let count = 0;
	for (const sample of samples) {
		spend(1);
		const c = parse(sample);
		if (++count > MAX_PIXELS$2) fail$11("sample pixel limit exceeded.");
		if (!c[3]) continue;
		if (!withAlpha) c[3] = 255;
		const key = packed(c), entry = colors.get(key);
		if (entry) entry.count++;
		else {
			if (colors.size >= MAX_NODES) fail$11("distinct color limit exceeded.");
			colors.set(key, {
				c,
				count: 1
			});
		}
	}
	return [...colors.values()];
}
function octreePalette(entries, count, maskColor, spend) {
	function build(depth) {
		let nodes = 1;
		const root = {
			parent: null,
			children: [],
			sum: [
				0,
				0,
				0,
				0
			],
			count: 0
		};
		for (const entry of entries) {
			let node = root;
			for (let level = 0; level < depth; level++) {
				spend(1);
				const bit = 128 >> level, i = entry.c.reduce((v, c, k) => v | (c & bit ? 1 << k : 0), 0);
				if (!node.children[i]) {
					if (++nodes > MAX_NODES) fail$11("octree node limit exceeded.");
					node.children[i] = {
						parent: node,
						children: [],
						sum: [
							0,
							0,
							0,
							0
						],
						count: 0
					};
				}
				node = node.children[i];
			}
			node.count += entry.count;
			for (let k = 0; k < 4; k++) node.sum[k] += entry.c[k] * entry.count;
		}
		const leaves = [];
		function collect(node) {
			for (const child of node.children) if (child) if (child.count) leaves.push(child);
			else collect(child);
		}
		collect(root);
		return leaves;
	}
	const available = count - (maskColor === null ? 0 : 1);
	let depth = 7, leaves = build(depth);
	if (leaves.length < available) {
		depth = 8;
		leaves = build(depth);
	}
	let aux = [], reducing = true;
	for (let level = depth; level >= 0; level--) {
		for (let i = leaves.length - 1; i >= 0; i--) {
			spend(1);
			if (leaves.length + aux.length <= available) {
				leaves.push(...aux.reverse());
				reducing = false;
				break;
			}
			if (!leaves.length) {
				if (aux.length <= 16 && available < 16 && available > 0) {
					aux.sort((a, b) => b.count - a.count);
					leaves = aux.slice(0, available);
					reducing = false;
				}
				break;
			}
			const parent = leaves[leaves.length - 1].parent;
			for (let c = 15; c >= 0; c--) {
				const child = parent.children[c];
				if (child?.count) {
					parent.count += child.count;
					for (let k = 0; k < 4; k++) parent.sum[k] += child.sum[k];
					if (leaves[leaves.length - 1] === child) leaves.pop();
				}
			}
			aux.push(parent);
		}
		if (!reducing) break;
		leaves.push(...aux.reverse());
		aux = [];
	}
	const colors = leaves.map((node) => node.sum.map((sum) => {
		if (sum > 2147483647) fail$11("octree accumulator exceeds verified signed-integer range.");
		return div(sum, node.count) + (sum % node.count > Math.floor(node.count / 2) ? 1 : 0);
	}));
	return [...maskColor === null ? [] : [unpack(maskColor)], ...colors].map(hex$3);
}
function rgb5Palette(entries, count, mask, withAlpha, spend) {
	const reserve = count > 1 && mask >= 0 && mask < count, available = count - (reserve ? 1 : 0);
	let colors;
	if (entries.length <= 256 && entries.length <= available) colors = entries.map((e) => e.c);
	else {
		const histogram = /* @__PURE__ */ new Map();
		for (const e of entries) {
			spend(1);
			const c = [
				e.c[0] >> 3,
				e.c[1] >> 2,
				e.c[2] >> 3,
				e.c[3] >> 3
			], key = c[0] | c[1] << 5 | c[2] << 11 | c[3] << 16, previous = histogram.get(key);
			if (previous) previous.count += e.count;
			else histogram.set(key, {
				c,
				count: e.count
			});
		}
		const make = (items, low, high) => ({
			items,
			low,
			high,
			volume: high.reduce((v, n, k) => v * (n - low[k] + 1), 1)
		});
		const queue = [];
		function push(value) {
			queue.push(value);
			let i = queue.length - 1;
			while (i > 0) {
				const parent = i - 1 >> 1;
				if (queue[parent].volume >= value.volume) break;
				queue[i] = queue[parent];
				i = parent;
			}
			queue[i] = value;
		}
		function pop() {
			const result = queue[0], last = queue.pop();
			if (queue.length) {
				let i = 0;
				while (i * 2 + 1 < queue.length) {
					let child = i * 2 + 1;
					if (child + 1 < queue.length && queue[child].volume < queue[child + 1].volume) child++;
					queue[i] = queue[child];
					i = child;
				}
				queue[i] = last;
				while (i > 0) {
					const parent = i - 1 >> 1;
					if (queue[parent].volume >= last.volume) break;
					queue[i] = queue[parent];
					i = parent;
					queue[i] = last;
				}
			}
			return result;
		}
		function mean(box) {
			const sums = [
				0,
				0,
				0,
				0
			];
			let n = 0;
			for (const e of box.items) {
				spend(1);
				n += e.count;
				for (let k = 0; k < 4; k++) sums[k] += e.c[k] * e.count;
			}
			return n ? sums.map((s, k) => div(255 * div(s, n), [
				31,
				63,
				31,
				31
			][k])) : [
				0,
				0,
				0,
				255
			];
		}
		push(make([...histogram.values()], [
			0,
			0,
			0,
			0
		], [
			31,
			63,
			31,
			31
		]));
		colors = [];
		while (queue.length && queue.length < available) {
			const box = pop(), low = [
				31,
				63,
				31,
				31
			], high = [
				0,
				0,
				0,
				0
			];
			let points = 0;
			for (const e of box.items) {
				spend(1);
				points += e.count;
				for (let k = 0; k < 4; k++) {
					low[k] = Math.min(low[k], e.c[k]);
					high[k] = Math.max(high[k], e.c[k]);
				}
			}
			let axis = 0;
			for (let k = 1; k < 4; k++) if (high[k] - low[k] > high[axis] - low[axis]) axis = k;
			const planes = /* @__PURE__ */ new Map();
			for (const e of box.items) planes.set(e.c[axis], (planes.get(e.c[axis]) ?? 0) + e.count);
			let first = 0, cut = null;
			for (let i = low[axis]; i <= high[axis]; i++) {
				const plane = planes.get(i) ?? 0;
				first += plane;
				const second = points - first;
				if (first > second) {
					if (second > 0) cut = i;
					else if (first - plane > 0) cut = i - 1;
					break;
				}
			}
			if (cut === null) if (colors.length < available) colors.push(mean(box));
			else break;
			else {
				const h = [...high], l = [...low];
				h[axis] = cut;
				l[axis] = cut + 1;
				push(make(box.items.filter((e) => e.c[axis] <= cut), low, h));
				push(make(box.items.filter((e) => e.c[axis] > cut), l, high));
			}
		}
		while (queue.length && colors.length < available) colors.push(mean(pop()));
	}
	if (reserve) colors.splice(Math.min(mask, colors.length), 0, [
		0,
		0,
		0,
		withAlpha ? 0 : 255
	]);
	else if (!colors.length) colors = [[
		0,
		0,
		0,
		255
	]];
	return colors.map(hex$3);
}
/** Samples must be full composited frames for native sprite quantization. */
function quantizeNativePalette(samples, input = {}) {
	const algorithm = input.quantization ?? "octree", max = integer$3(input.maxColors ?? 256, 2, 256, "palette color limit");
	if (!["octree", "rgb5a3"].includes(algorithm)) fail$11("unsupported native quantizer.");
	const alpha = input.withAlpha ?? true;
	if (typeof alpha !== "boolean") fail$11("withAlpha must be boolean.");
	const mask = input.transparentIndex === null ? -1 : integer$3(input.transparentIndex ?? 0, 0, max - 1, "transparent index"), spend = meter(input.budget);
	const entries = histogram(samples, alpha, spend);
	if (mask > 0) fail$11("native palette generation with a nonzero transparent index is not yet supported.");
	const result = algorithm === "octree" ? octreePalette(entries, max, mask < 0 ? null : mask, spend) : rgb5Palette(entries, max, mask, alpha, spend);
	if (!result.length) fail$11("native quantizer produced an empty palette.");
	return result;
}
//#endregion
//#region app/indexed-color.mjs
/** Original, deterministic palette reduction and dithering. No host access or document mutation. */
const MAX_PIXELS$1 = 16777216, MAX_WORK = 67108864, MAX_HISTOGRAM = 65536;
const fail$10 = (message) => {
	throw Error(`Indexed conversion: ${message}`);
};
const clamp$1 = (value, low = 0, high = 255) => Math.max(low, Math.min(high, value));
const integer$2 = (value, low, high, label) => {
	if (!Number.isSafeInteger(value) || value < low || value > high) fail$10(`invalid ${label}.`);
	return value;
};
const color$1 = (value) => {
	if (value === null) return [
		0,
		0,
		0,
		0
	];
	if (typeof value !== "string" || !/^#[0-9a-f]{8}$/i.test(value)) fail$10("pixels and palette entries must be RGBA hex strings or null.");
	return [
		1,
		3,
		5,
		7
	].map((at) => parseInt(value.slice(at, at + 2), 16));
};
const hex$2 = (values) => "#" + values.map((value) => Math.round(clamp$1(value)).toString(16).padStart(2, "0")).join("");
const vector = (c) => [
	c[0] * c[3] / 255,
	c[1] * c[3] / 255,
	c[2] * c[3] / 255,
	c[3]
];
const distance = (a, b) => (a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2 + (a[2] - b[2]) ** 2 + 2 * (a[3] - b[3]) ** 2;
function workBudget(value) {
	const budget = value ?? { remaining: MAX_WORK };
	integer$2(budget.remaining, 0, MAX_WORK, "remaining work budget");
	return budget;
}
function spend(budget, amount) {
	budget.remaining -= amount;
	if (budget.remaining < 0) fail$10("work limit exceeded; reduce the image, palette, or frame count.");
}
function indexedConversionOptions(input = {}) {
	const options = {
		paletteMode: input.paletteMode ?? "existing",
		maxColors: input.maxColors ?? 256,
		quantization: input.quantization ?? "median-cut",
		withAlpha: input.withAlpha ?? true,
		dithering: input.dithering ?? "none",
		ditherMatrix: input.ditherMatrix ?? "bayer4x4",
		ditherStrength: input.ditherStrength ?? 1,
		rgbmap: input.rgbmap ?? (["octree", "rgb5a3"].includes(input.quantization) || input.dithering?.startsWith("aseprite-") ? "octree" : "pixelwall"),
		fitCriteria: input.fitCriteria ?? "default"
	};
	if (!["existing", "generate"].includes(options.paletteMode)) fail$10("palette mode must be existing or generate.");
	integer$2(options.maxColors, 2, 256, "palette color limit");
	if (![
		"median-cut",
		"octree",
		"rgb5a3"
	].includes(options.quantization)) fail$10("quantization must be median-cut, octree, or rgb5a3.");
	if (![
		"pixelwall",
		"octree",
		"rgb5a3"
	].includes(options.rgbmap)) fail$10("RGB map must be pixelwall, octree, or rgb5a3.");
	if (![
		"default",
		"rgb",
		"linearizedRGB",
		"ciexyz",
		"cielab"
	].includes(options.fitCriteria)) fail$10("unsupported fitting criterion.");
	if (options.rgbmap === "pixelwall" && options.fitCriteria !== "default") fail$10("fitting criteria require a native RGB map.");
	if (typeof options.withAlpha !== "boolean") fail$10("withAlpha must be boolean.");
	if (![
		"none",
		"ordered",
		"floyd-steinberg",
		"aseprite-ordered",
		"aseprite-old",
		"aseprite-error-diffusion"
	].includes(options.dithering)) fail$10("unsupported dithering algorithm.");
	if (options.rgbmap !== "pixelwall" && ["ordered", "floyd-steinberg"].includes(options.dithering)) fail$10("legacy dithering requires the pixelwall RGB map; choose a native dithering mode.");
	if (options.rgbmap === "pixelwall" && options.dithering.startsWith("aseprite-")) fail$10("native dithering requires an octree or rgb5a3 RGB map.");
	if (["aseprite-ordered", "aseprite-old"].includes(options.dithering) && options.ditherStrength !== 1) fail$10("native ordered dithering does not have a strength control.");
	if (![
		"bayer2x2",
		"bayer4x4",
		"bayer8x8"
	].includes(options.ditherMatrix)) fail$10("unsupported Bayer matrix.");
	if (typeof options.ditherStrength !== "number" || !Number.isFinite(options.ditherStrength) || options.ditherStrength < 0 || options.ditherStrength > 1) fail$10("dither strength must be from 0 to 1.");
	return options;
}
/** Weighted median cut in premultiplied RGBA. The reserved transparent slot counts toward maxColors. */
function quantizePalette(samples, input = {}) {
	const options = indexedConversionOptions({
		...input,
		paletteMode: "generate"
	});
	if (options.quantization !== "median-cut") return quantizeNativePalette(samples, {
		...input,
		...options
	});
	const transparentIndex = integer$2(input.transparentIndex ?? 0, 0, options.maxColors - 1, "transparent index"), budget = workBudget(input.budget);
	let histogram = /* @__PURE__ */ new Map(), binned = false;
	function keyOf(c) {
		return binned ? c.map((value) => Math.floor(value / 16)).join(",") : c.join(",");
	}
	function add(c, count = 1, sums = null) {
		const key = keyOf(c), entry = histogram.get(key), v = vector(c);
		const sum = sums ?? v.map((value) => value * count);
		if (entry) {
			entry.count += count;
			for (let k = 0; k < 4; k++) entry.sum[k] += sum[k];
		} else histogram.set(key, {
			count,
			sum,
			first: c
		});
	}
	for (const sample of samples) {
		spend(budget, 1);
		const c = color$1(sample);
		if (c[3] === 0) continue;
		if (!options.withAlpha) c[3] = 255;
		add(c);
		if (!binned && histogram.size > MAX_HISTOGRAM) {
			const entries = [...histogram.values()];
			histogram = /* @__PURE__ */ new Map();
			binned = true;
			for (const entry of entries) add(entry.first, entry.count, entry.sum);
		}
	}
	const entries = [...histogram.values()].map((entry, order) => ({
		...entry,
		order,
		v: entry.sum.map((value) => value / entry.count)
	}));
	function box(items) {
		const low = [
			Infinity,
			Infinity,
			Infinity,
			Infinity
		], high = [
			-Infinity,
			-Infinity,
			-Infinity,
			-Infinity
		];
		let count = 0;
		for (const entry of items) {
			count += entry.count;
			for (let k = 0; k < 4; k++) {
				low[k] = Math.min(low[k], entry.v[k]);
				high[k] = Math.max(high[k], entry.v[k]);
			}
		}
		let axis = 0, spread = 0;
		for (let k = 0; k < 4; k++) {
			const value = (high[k] - low[k]) ** 2 * (k === 3 ? 2 : 1);
			if (value > spread) {
				axis = k;
				spread = value;
			}
		}
		return {
			items,
			count,
			axis,
			score: items.length > 1 ? spread * count : 0
		};
	}
	const boxes = entries.length ? [box(entries)] : [], available = options.maxColors - 1;
	while (boxes.length < available) {
		let best = -1;
		for (let i = 0; i < boxes.length; i++) if (boxes[i].score > 0 && (best < 0 || boxes[i].score > boxes[best].score)) best = i;
		if (best < 0) break;
		const current = boxes[best], items = [...current.items].sort((a, b) => a.v[current.axis] - b.v[current.axis] || a.order - b.order);
		spend(budget, items.length);
		let count = 0, cut = 0;
		while (cut < items.length - 1) {
			count += items[cut++].count;
			if (count >= current.count / 2) break;
		}
		boxes.splice(best, 1, box(items.slice(0, cut)), box(items.slice(cut)));
	}
	const colors = boxes.map((item) => {
		const sum = [
			0,
			0,
			0,
			0
		];
		for (const entry of item.items) for (let k = 0; k < 4; k++) sum[k] += entry.sum[k];
		const a = sum[3] / item.count;
		return hex$2([
			sum[0] / item.count * 255 / a,
			sum[1] / item.count * 255 / a,
			sum[2] / item.count * 255 / a,
			a
		]);
	});
	const palette = [];
	const unique = [...new Set(colors)];
	const length = Math.max(transparentIndex + 1, unique.length + 1);
	for (let index = 0; index < length; index++) palette.push(index === transparentIndex ? "#00000000" : unique.shift() ?? "#00000000");
	return palette;
}
function bayer(size) {
	let matrix = [[0]];
	while (matrix.length < size) {
		const n = matrix.length, next = Array.from({ length: n * 2 }, () => Array(n * 2));
		for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) {
			next[y][x] = 4 * matrix[y][x];
			next[y][x + n] = 4 * matrix[y][x] + 2;
			next[y + n][x] = 4 * matrix[y][x] + 3;
			next[y + n][x + n] = 4 * matrix[y][x] + 1;
		}
		matrix = next;
	}
	return matrix;
}
/** Dither an RGBA raster into a palette. Regions reset both Bayer origin and diffusion for native atlas tiles. */
function mapIndexedImage(image, palette, input = {}) {
	const options = indexedConversionOptions(input);
	if (options.rgbmap !== "pixelwall") return mapNativeIndexedImage(image, palette, {
		...input,
		...options
	});
	const width = integer$2(image.width, 1, 65535, "image width"), height = integer$2(image.height, 1, 65535, "image height");
	if (width * height > MAX_PIXELS$1 || !Array.isArray(image.pixels) || image.pixels.length !== width * height) fail$10("invalid image pixel count.");
	if (!Array.isArray(palette) || !palette.length || palette.length > 256) fail$10("indexed conversion requires a palette of 1–256 colors.");
	const transparentIndex = input.transparentIndex == null ? null : integer$2(input.transparentIndex, 0, palette.length - 1, "transparent index");
	const colors = palette.map(color$1);
	if (transparentIndex !== null) colors[transparentIndex] = [
		0,
		0,
		0,
		0
	];
	const vectors = colors.map(vector), budget = workBudget(input.budget), output = new Array(width * height), cache = /* @__PURE__ */ new Map();
	const tileWidth = integer$2(input.tileWidth ?? width, 1, width, "tile width"), tileHeight = integer$2(input.tileHeight ?? height, 1, height, "tile height");
	if (width % tileWidth || height % tileHeight) fail$10("atlas dimensions must be multiples of the tile grid.");
	const matrixSize = Number(options.ditherMatrix[5]), matrix = bayer(matrixSize), algorithm = options.ditherStrength === 0 ? "none" : options.dithering;
	function nearest(v, opaque, pair) {
		let a = -1, b = -1, da = Infinity, db = Infinity;
		spend(budget, colors.length);
		for (let index = 0; index < colors.length; index++) {
			if (opaque && (index === transparentIndex || colors[index][3] === 0)) continue;
			const d = distance(v, vectors[index]);
			if (d < da) {
				b = a;
				db = da;
				a = index;
				da = d;
			} else if (d < db) {
				b = index;
				db = d;
			}
		}
		if (a < 0) fail$10("palette has no visible color for an opaque pixel.");
		return pair ? [a, b < 0 ? a : b] : a;
	}
	for (let top = 0; top < height; top += tileHeight) for (let left = 0; left < width; left += tileWidth) {
		let errors = new Float64Array((tileWidth + 2) * 4), next = new Float64Array(errors.length);
		for (let y = 0; y < tileHeight; y++) {
			for (let x = 0; x < tileWidth; x++) {
				const at = (top + y) * width + left + x, c = color$1(image.pixels[at]);
				spend(budget, 1);
				if (c[3] === 0) {
					output[at] = null;
					continue;
				}
				const v = vector(c), opaque = c[3] === 255, slot = (x + 1) * 4;
				let chosen;
				if (algorithm === "floyd-steinberg") {
					for (let k = 0; k < 4; k++) v[k] = clamp$1(v[k] + errors[slot + k]);
					for (let k = 0; k < 3; k++) v[k] = Math.min(v[k], v[3]);
					chosen = nearest(v, opaque, false);
					for (let k = 0; k < 4; k++) {
						const error = (v[k] - vectors[chosen][k]) * options.ditherStrength;
						errors[slot + 4 + k] += error * 7 / 16;
						next[slot - 4 + k] += error * 3 / 16;
						next[slot + k] += error * 5 / 16;
						next[slot + 4 + k] += error / 16;
					}
				} else {
					const key = hex$2(c);
					let candidates = cache.get(key);
					if (!candidates) {
						candidates = nearest(v, opaque, true);
						if (cache.size < MAX_HISTOGRAM) cache.set(key, candidates);
					}
					chosen = candidates[0];
					if (algorithm === "ordered" && candidates[0] !== candidates[1]) {
						const [a, b] = [...candidates].sort((one, two) => one - two), start = vectors[a], end = vectors[b], nearestVector = vectors[chosen];
						let numerator = 0, denominator = 0;
						for (let k = 0; k < 4; k++) {
							const step = end[k] - start[k], weight = k === 3 ? 2 : 1, value = nearestVector[k] + (v[k] - nearestVector[k]) * options.ditherStrength;
							numerator += (value - start[k]) * step * weight;
							denominator += step * step * weight;
						}
						chosen = (denominator ? clamp$1(numerator / denominator, 0, 1) : 0) > (matrix[y % matrixSize][x % matrixSize] + .5) / (matrixSize * matrixSize) ? b : a;
					}
				}
				output[at] = chosen === transparentIndex || colors[chosen][3] === 0 ? null : chosen;
			}
			errors = next;
			next = new Float64Array(errors.length);
		}
	}
	return output;
}
//#endregion
//#region app/aseprite-properties.mjs
/** Native property maps from the published Aseprite file format; bounded JSON value subset. */
const MAX_BYTES = 1024 * 1024, MAX_ITEMS = 16384, MAX_DEPTH = 24;
const encoder$2 = new TextEncoder(), decoder$1 = new TextDecoder("utf-8", { fatal: true });
const fail$9 = (message) => {
	throw Error(`Sprite properties: ${message}`);
};
const plain = (value) => value && typeof value === "object" && !Array.isArray(value) && [Object.prototype, null].includes(Object.getPrototypeOf(value));
function decodeAsepriteProperties(input) {
	if (input == null) return {};
	if (!Array.isArray(input) && !(input instanceof Uint8Array)) fail$9("expected bytes.");
	if (input.length > MAX_BYTES || !Array.from(input).every((v) => Number.isInteger(v) && v >= 0 && v <= 255)) fail$9("invalid bytes or size limit.");
	const bytes = Uint8Array.from(input), view = new DataView(bytes.buffer);
	let at = 0, items = 0;
	const take = (n) => {
		if (n < 0 || at + n > bytes.length) fail$9("truncated data.");
		const start = at;
		at += n;
		return start;
	};
	const u8 = () => view.getUint8(take(1)), u16 = () => view.getUint16(take(2), true), u32 = () => view.getUint32(take(4), true);
	const text = () => {
		const length = u16();
		return decoder$1.decode(bytes.subarray(take(length), at));
	};
	function value(type, depth) {
		if (++items > MAX_ITEMS || depth > MAX_DEPTH) fail$9("item or nesting limit.");
		let result;
		if (type === 1) return u8() !== 0;
		if (type === 2) return view.getInt8(take(1));
		if (type === 3) return u8();
		if (type === 4) return view.getInt16(take(2), true);
		if (type === 5) return u16();
		if (type === 6) return view.getInt32(take(4), true);
		if (type === 7) return u32();
		if (type === 8 || type === 9) {
			const offset = take(8), big = type === 8 ? view.getBigInt64(offset, true) : view.getBigUint64(offset, true);
			result = Number(big);
			if (!Number.isSafeInteger(result)) fail$9("64-bit integer exceeds exact JavaScript range.");
			return result;
		}
		if (type === 10) return view.getInt32(take(4), true) / 65536;
		if (type === 11 || type === 12) {
			result = type === 11 ? view.getFloat32(take(4), true) : view.getFloat64(take(8), true);
			if (!Number.isFinite(result)) fail$9("nonfinite number.");
			return result;
		}
		if (type === 13) return text();
		if (type === 17) {
			const count = u32(), elementType = u16();
			if (count > MAX_ITEMS - items) fail$9("vector item limit.");
			return Array.from({ length: count }, () => value(elementType || u16(), depth + 1));
		}
		if (type === 18) return map(depth + 1);
		fail$9(`unsupported value type 0x${type.toString(16)}; existing bytes are preserved until this object is edited.`);
	}
	function map(depth) {
		if (depth > MAX_DEPTH) fail$9("nesting limit.");
		const count = u32(), result = Object.create(null);
		if (count > MAX_ITEMS - items) fail$9("map item limit.");
		for (let i = 0; i < count; i++) {
			const key = text();
			if (Object.hasOwn(result, key)) fail$9("duplicate property name.");
			result[key] = value(u16(), depth);
		}
		return result;
	}
	if (u32() !== bytes.length) fail$9("declared block size mismatch.");
	const count = u32(), result = Object.create(null);
	if (count > MAX_ITEMS) fail$9("too many property maps.");
	for (let i = 0; i < count; i++) {
		const key = u32();
		if (Object.hasOwn(result, key)) fail$9("duplicate property map.");
		result[key] = map(0);
	}
	if (at !== bytes.length) fail$9("trailing data.");
	return result;
}
function validateAsepriteUserData(value) {
	if (!plain(value) || Object.keys(value).some((key) => ![
		"text",
		"color",
		"propertiesBytes"
	].includes(key))) fail$9("invalid user data fields.");
	if (value.text != null && (typeof value.text !== "string" || encoder$2.encode(value.text).length > 65535)) fail$9("text exceeds native limit.");
	if (value.color != null && (typeof value.color !== "string" || !/^#[0-9a-f]{8}$/i.test(value.color))) fail$9("invalid user color.");
	if (value.propertiesBytes != null) decodeAsepriteProperties(value.propertiesBytes);
	return structuredClone(value);
}
//#endregion
//#region app/editor-core.mjs
/** PixelWall v4: a portable, transactional 2D document and raster engine. No DOM. */
const LIMITS = Object.freeze({
	edge: 65535,
	canvasPixels: 4194304,
	imageEdge: 65535,
	pixels: 16777216,
	layers: 256,
	frames: 2048,
	palette: 65536,
	operations: 67108864
});
const BLEND_MODES = Object.freeze([
	"normal",
	"multiply",
	"screen",
	"overlay",
	"darken",
	"lighten",
	"color-dodge",
	"color-burn",
	"hard-light",
	"soft-light",
	"difference",
	"exclusion",
	"addition",
	"subtract",
	"divide",
	"hue",
	"saturation",
	"color",
	"luminosity"
]);
const DEFAULT_PALETTE = [
	"#16152bff",
	"#3c315fff",
	"#7059c7ff",
	"#ff6b57ff",
	"#ffb34bff",
	"#ffe66dff",
	"#70d6b2ff",
	"#218c89ff",
	"#f8f0dfff"
];
const DIRECTIONS$2 = [
	"forward",
	"reverse",
	"pingpong",
	"pingpong_reverse"
];
const validatedImages = /* @__PURE__ */ new WeakMap();
const clamp = (v, lo = 0, hi = 1) => Math.max(lo, Math.min(hi, v));
const own$3 = (o, k) => Object.prototype.hasOwnProperty.call(o, k);
const record$2 = (o) => o !== null && typeof o === "object" && !Array.isArray(o);
var EditorError = class extends Error {
	constructor(message, code = "INVALID_DOCUMENT") {
		super(message);
		this.name = "EditorError";
		this.code = code;
	}
};
function fail$8(message, code) {
	throw new EditorError(message, code);
}
function integer$1(v, label, min = 0, max = Number.MAX_SAFE_INTEGER) {
	if (!Number.isSafeInteger(v) || v < min || v > max) fail$8(`${label} must be an integer from ${min} to ${max}`);
	return v;
}
function finite(v, label, min = -1e6, max = 1e6) {
	if (typeof v !== "number" || !Number.isFinite(v) || v < min || v > max) fail$8(`${label} is outside ${min}…${max}`);
	return v;
}
function id(v, label = "Id") {
	if (typeof v !== "string" || !/^[a-zA-Z0-9][a-zA-Z0-9_.:-]{0,127}$/.test(v) || [
		"constructor",
		"prototype",
		"__proto__"
	].includes(v)) fail$8(`${label} is invalid`);
	return v;
}
function name(v, fallback) {
	const n = typeof v === "string" && v.trim() ? v.trim() : fallback;
	if (n.length > 240) fail$8("Name is too long");
	return n;
}
function jsonCopy(v) {
	if (v === void 0) return void 0;
	try {
		const s = JSON.stringify(v);
		if (s.length > 64 * 1024 * 1024) fail$8("Metadata is too large");
		return JSON.parse(s);
	} catch (e) {
		if (e instanceof EditorError) throw e;
		fail$8("Value must be serializable");
	}
}
function unique(items, label) {
	const s = /* @__PURE__ */ new Set();
	for (const item of items) {
		id(item.id, label);
		if (s.has(item.id)) fail$8(`Duplicate ${label}: ${item.id}`);
		s.add(item.id);
	}
	return s;
}
function rgba(value) {
	if (value === null || value === void 0) return [
		0,
		0,
		0,
		0
	];
	if (typeof value !== "string") fail$8("Color must be a hex string");
	let s = value.trim().toLowerCase();
	if (/^#[0-9a-f]{3,4}$/.test(s)) s = "#" + [...s.slice(1)].map((c) => c + c).join("");
	if (/^#[0-9a-f]{6}$/.test(s)) s += "ff";
	if (!/^#[0-9a-f]{8}$/.test(s)) fail$8(`Invalid RGBA color: ${String(value).slice(0, 30)}`);
	return [
		1,
		3,
		5,
		7
	].map((i) => parseInt(s.slice(i, i + 2), 16));
}
const hex$1 = (c) => "#" + c.map((v) => Math.round(clamp(v, 0, 255)).toString(16).padStart(2, "0")).join("");
const normalizeColor = (value) => hex$1(rgba(value));
function pixelRGBA(doc, pixel) {
	return rgba(typeof pixel === "number" ? doc.palette[pixel] : pixel);
}
/** Effective palette at a frame. Pass a layer to apply Aseprite transparent-index semantics. */
function getFramePalette(doc, frameId = doc.frames[0]?.id, layerId) {
	const frame = frameFor(doc, frameId);
	let palette = doc.palette;
	for (const current of doc.frames) {
		if (current.palette) palette = current.palette;
		if (current.id === frame.id) break;
	}
	const layer = layerId == null ? null : layerFor(doc, layerId), transparent = doc.metadata?.aseprite?.transparentIndex;
	if (doc.colorMode === "indexed" && layer && !(layer.asepriteFlags & 8) && Number.isInteger(transparent) && transparent < palette.length) {
		palette = [...palette];
		palette[transparent] = "#00000000";
	}
	return [...palette];
}
function colorContext(doc, frameId, layerId) {
	return {
		...doc,
		palette: getFramePalette(doc, frameId, layerId)
	};
}
function nearest(palette, c) {
	let result = 0, d = Infinity;
	for (let i = 0; i < palette.length; i++) {
		const p = rgba(palette[i]);
		const q = (p[0] - c[0]) ** 2 + (p[1] - c[1]) ** 2 + (p[2] - c[2]) ** 2 + 2 * (p[3] - c[3]) ** 2;
		if (q < d) {
			result = i;
			d = q;
		}
	}
	return result;
}
function encodeColor(doc, color) {
	if (color === null || color === void 0) return null;
	if (typeof color === "number") {
		integer$1(color, "Palette index", 0, doc.palette.length - 1);
		return doc.colorMode === "indexed" ? color : encodeColor(doc, doc.palette[color]);
	}
	const c = rgba(color);
	if (c[3] === 0) return null;
	if (doc.colorMode === "indexed") return nearest(doc.palette, c);
	if (doc.colorMode === "grayscale") c[0] = c[1] = c[2] = Math.round(.2126 * c[0] + .7152 * c[1] + .0722 * c[2]);
	return hex$1(c);
}
function validatePixels(image, doc, label, copy = true) {
	integer$1(image.width, `${label} width`, 1, LIMITS.imageEdge);
	integer$1(image.height, `${label} height`, 1, LIMITS.imageEdge);
	const count = image.width * image.height;
	if (count > LIMITS.pixels) fail$8("Image exceeds pixel budget");
	if (image.tilemap) {
		if (!Array.isArray(image.tilemap.tiles) || image.tilemap.tiles.length !== count) fail$8("Tilemap image size mismatch");
		for (const value of image.tilemap.tiles) integer$1(value, "Tile data", 0, 4294967295);
		if (!Array.isArray(image.pixels) || image.pixels.length !== 0 && image.pixels.length !== count) fail$8("Tilemap pixels are invalid");
		return copy ? [...image.pixels] : image.pixels;
	}
	if (!Array.isArray(image.pixels) || image.pixels.length !== count) fail$8(`${label} pixel count does not match dimensions`);
	const convert = (p) => {
		if (p === null) return null;
		if (doc.colorMode === "indexed") return integer$1(p, "Indexed pixel", 0, doc.palette.length - 1);
		if (typeof p !== "string") fail$8("RGBA pixels must be strings or null");
		const c = rgba(p);
		if (doc.colorMode === "grayscale" && (c[0] !== c[1] || c[1] !== c[2])) fail$8("Grayscale pixels must have equal RGB channels");
		return c[3] === 0 ? null : hex$1(c);
	};
	if (copy) return image.pixels.map(convert);
	for (const p of image.pixels) convert(p);
	return image.pixels;
}
function createDocument(options = {}) {
	const width = integer$1(options.width ?? options.size ?? 32, "Width", 1, LIMITS.edge), height = integer$1(options.height ?? options.size ?? width, "Height", 1, LIMITS.edge);
	return normalizeDocument({
		format: "pixelwall-document",
		version: 4,
		id: options.id ?? globalThis.crypto?.randomUUID?.() ?? `document-${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`,
		name: options.name ?? "Untitled Sprite",
		width,
		height,
		colorMode: options.colorMode ?? "rgba",
		colorProfile: "sRGB",
		palette: options.palette ?? DEFAULT_PALETTE,
		layers: [{
			id: "layer-1",
			name: "Layer 1",
			type: "image",
			parentId: null,
			visible: true,
			locked: false,
			opacity: 1,
			blendMode: "normal"
		}],
		frames: [{
			id: "frame-1",
			durationMs: options.durationMs ?? 125,
			cels: {}
		}],
		images: {},
		clips: [{
			id: "clip-1",
			name: "default",
			frameIds: ["frame-1"],
			direction: "forward",
			loop: true
		}],
		slices: [],
		tilesets: [],
		metadata: {}
	});
}
function normalizeDocument(input, options = {}) {
	if (typeof input === "string") try {
		input = JSON.parse(input);
	} catch {
		fail$8("Invalid document JSON");
	}
	if (!record$2(input)) fail$8("Document must be an object");
	if (input.format !== "pixelwall-document" || input.version !== 4) return migrateLegacy(input);
	const width = integer$1(input.width, "Width", 1, LIMITS.edge), height = integer$1(input.height, "Height", 1, LIMITS.edge);
	if (width * height > LIMITS.canvasPixels) fail$8("Canvas exceeds the 4,194,304 pixel budget", "MEMORY_BUDGET");
	if (![
		"rgba",
		"indexed",
		"grayscale"
	].includes(input.colorMode)) fail$8("Unsupported color mode");
	if (input.colorProfile && input.colorProfile !== "sRGB") fail$8("Only the sRGB working profile is supported");
	if (!Array.isArray(input.palette) || input.palette.length < 1 || input.palette.length > LIMITS.palette) fail$8("Palette must have 1–65536 colors");
	const doc = {
		...input,
		id: id(input.id ?? "document-1"),
		name: name(input.name, "Untitled Sprite"),
		width,
		height,
		colorMode: input.colorMode,
		colorProfile: "sRGB",
		palette: input.palette.map(normalizeColor)
	};
	let paletteCapacity = doc.palette.length;
	if (Array.isArray(input.frames)) {
		for (const frame of input.frames) if (frame?.palette !== void 0) {
			if (!Array.isArray(frame.palette) || frame.palette.length < 1 || frame.palette.length > LIMITS.palette) fail$8("Frame palette must have 1–65536 colors");
			for (const color of frame.palette) normalizeColor(color);
			paletteCapacity = Math.max(paletteCapacity, frame.palette.length);
		}
	}
	const pixelDocument = doc.colorMode === "indexed" && paletteCapacity !== doc.palette.length ? {
		...doc,
		palette: { length: paletteCapacity }
	} : doc;
	if (!Array.isArray(input.layers) || input.layers.length < 1 || input.layers.length > LIMITS.layers) fail$8("Document must have 1–256 layers");
	doc.layers = input.layers.map((layer, i) => {
		if (!record$2(layer)) fail$8("Invalid layer");
		const type = layer.type ?? "image";
		if (![
			"image",
			"group",
			"reference",
			"tilemap"
		].includes(type)) fail$8("Unsupported layer type");
		const blendMode = layer.blendMode ?? "normal";
		if (!BLEND_MODES.includes(blendMode)) fail$8(`Unsupported blend mode: ${blendMode}`);
		return {
			...jsonCopy(layer),
			id: id(layer.id),
			name: name(layer.name, `Layer ${i + 1}`),
			type,
			parentId: layer.parentId == null ? null : id(layer.parentId),
			visible: layer.visible !== false,
			locked: !!layer.locked,
			opacity: finite(layer.opacity ?? 1, "Layer opacity", 0, 1),
			blendMode
		};
	});
	const layerIds = unique(doc.layers, "layer id");
	const layerMap = new Map(doc.layers.map((l) => [l.id, l]));
	for (const layer of doc.layers) {
		let current = layer;
		const seen = /* @__PURE__ */ new Set();
		while (current.parentId !== null) {
			if (seen.has(current.id)) fail$8("Layer groups cannot contain cycles");
			seen.add(current.id);
			const p = layerMap.get(current.parentId);
			if (!p || p.type !== "group") fail$8("Layer parent must be an existing group");
			current = p;
		}
	}
	if (!record$2(input.images)) fail$8("Images must be an object");
	if (Object.keys(input.images).length > 131072) fail$8("Too many stored images");
	doc.images = {};
	let pixels = 0;
	const validationKey = doc.colorMode === "indexed" ? `indexed:${paletteCapacity}` : doc.colorMode;
	for (const [key, image] of Object.entries(input.images)) {
		id(key, "Image id");
		if (!record$2(image)) fail$8("Invalid image");
		pixels += image.width * image.height;
		if (pixels > LIMITS.pixels) fail$8("Document exceeds the 16,777,216 stored pixel budget");
		if (options.shareImages) {
			if (validatedImages.get(image) !== validationKey) validatePixels(image, pixelDocument, `Image ${key}`, false);
			doc.images[key] = image;
		} else doc.images[key] = {
			...image,
			...image.tilemap ? { tilemap: jsonCopy(image.tilemap) } : {},
			pixels: validatePixels(image, pixelDocument, `Image ${key}`)
		};
		validatedImages.set(doc.images[key], validationKey);
	}
	if (!Array.isArray(input.frames) || input.frames.length < 1 || input.frames.length > LIMITS.frames) fail$8("Document must have 1–2048 frames");
	let celCount = 0;
	doc.frames = input.frames.map((frame) => {
		if (!record$2(frame) || !record$2(frame.cels)) fail$8("Invalid frame");
		const cels = {};
		for (const [layerId, cel] of Object.entries(frame.cels)) {
			if (!layerIds.has(layerId) || layerMap.get(layerId).type === "group") fail$8("Cel references missing or group layer");
			if (!record$2(cel) || !own$3(doc.images, cel.imageId)) fail$8("Cel references missing image");
			if (++celCount > 131072) fail$8("Too many cels");
			cels[layerId] = {
				...jsonCopy(cel),
				imageId: id(cel.imageId),
				x: integer$1(cel.x ?? 0, "Cel x", -65535, 65535),
				y: integer$1(cel.y ?? 0, "Cel y", -65535, 65535),
				opacity: finite(cel.opacity ?? 1, "Cel opacity", 0, 1),
				...cel.zIndex !== void 0 ? { zIndex: integer$1(cel.zIndex, "Cel z-index", -2147483648, 2147483647) } : {}
			};
		}
		return {
			...jsonCopy({
				...frame,
				cels: void 0
			}),
			...frame.palette ? { palette: frame.palette.map(normalizeColor) } : {},
			id: id(frame.id),
			durationMs: integer$1(frame.durationMs ?? 125, "Frame duration", 1, 65535),
			cels
		};
	});
	const frameIds = unique(doc.frames, "frame id");
	doc.clips = (input.clips ?? []).map((clip, i) => {
		if (!record$2(clip) || !Array.isArray(clip.frameIds) || !clip.frameIds.length) fail$8("Invalid clip");
		for (const f of clip.frameIds) if (!frameIds.has(f)) fail$8("Clip references missing frame");
		if (!DIRECTIONS$2.includes(clip.direction ?? "forward")) fail$8("Invalid clip direction");
		if (clip.repeat !== void 0) integer$1(clip.repeat, "Tag repeats", 0, 65535);
		if (clip.color !== void 0) normalizeColor(clip.color);
		return {
			...jsonCopy(clip),
			id: id(clip.id),
			name: name(clip.name, `Clip ${i + 1}`),
			direction: clip.direction ?? "forward",
			loop: clip.loop !== false
		};
	});
	unique(doc.clips, "clip id");
	if (doc.clips.length > 512) fail$8("Too many clips");
	doc.slices = jsonCopy(input.slices ?? []);
	if (!Array.isArray(doc.slices) || doc.slices.length > 1024) fail$8("Too many slices");
	for (const slice of doc.slices) {
		id(slice.id);
		const b = slice.bounds;
		if (record$2(b)) {
			integer$1(b.x, "Slice x", 0, width - 1);
			integer$1(b.y, "Slice y", 0, height - 1);
			integer$1(b.width, "Slice width", 1, width - b.x);
			integer$1(b.height, "Slice height", 1, height - b.y);
		} else if (Array.isArray(slice.keys)) for (const key of slice.keys) {
			if (key.frameId && !frameIds.has(key.frameId)) fail$8("Slice key references missing frame");
			integer$1(key.x, "Slice key x", -2147483648, 2147483647);
			integer$1(key.y, "Slice key y", -2147483648, 2147483647);
			integer$1(key.width, "Slice key width", 0, 65535);
			integer$1(key.height, "Slice key height", 0, 65535);
		}
		else fail$8("Invalid slice");
	}
	unique(doc.slices, "slice id");
	doc.tilesets = jsonCopy(input.tilesets ?? []);
	if (!Array.isArray(doc.tilesets) || doc.tilesets.length > 256) fail$8("Too many tilesets");
	unique(doc.tilesets, "Tileset id");
	if (doc.tilesets.reduce((s, t) => s + (t.tiles?.length ?? t.tileCount ?? 0), 0) > 131072) fail$8("Too many tile definitions");
	for (const ts of doc.tilesets) {
		integer$1(ts.tileWidth, "Tile width", 1, LIMITS.edge);
		integer$1(ts.tileHeight, "Tile height", 1, LIMITS.edge);
		if (ts.imageId && !own$3(doc.images, ts.imageId)) fail$8("Tileset atlas image is missing");
		if (!ts.tiles && ts.imageId) {
			const atlas = doc.images[ts.imageId], columns = Math.floor(atlas.width / ts.tileWidth), count = ts.tileCount ?? columns * Math.floor(atlas.height / ts.tileHeight);
			integer$1(count, "Native tile count", 0, 65536);
			if (columns < 1 || count > columns * Math.floor(atlas.height / ts.tileHeight)) fail$8("Native atlas dimensions mismatch");
			ts.tiles = Array.from({ length: count }, (_, i) => ({
				id: `ase-tile-${i}`,
				imageId: ts.imageId,
				asepriteTileId: i,
				sourceRect: {
					x: i % columns * ts.tileWidth,
					y: Math.floor(i / columns) * ts.tileHeight,
					width: ts.tileWidth,
					height: ts.tileHeight
				}
			}));
		}
		if (ts.tiles) {
			if (!Array.isArray(ts.tiles) || ts.tiles.length > 65536) fail$8("Invalid tileset");
			unique(ts.tiles, "tile id");
			for (const t of ts.tiles) {
				if (!own$3(doc.images, t.imageId)) fail$8("Tile image missing");
				if (t.sourceRect) {
					const image = doc.images[t.imageId], r = t.sourceRect;
					integer$1(r.x, "Tile source x", 0, image.width - 1);
					integer$1(r.y, "Tile source y", 0, image.height - 1);
					integer$1(r.width, "Tile source width", 1, image.width - r.x);
					integer$1(r.height, "Tile source height", 1, image.height - r.y);
				}
			}
		}
	}
	for (const layer of doc.layers) {
		if (layer.tilesetId && !doc.tilesets.some((t) => t.id === layer.tilesetId)) fail$8("Layer tileset missing");
		for (const [fid, map] of Object.entries(layer.tilemaps ?? {})) {
			if (!frameIds.has(fid)) fail$8("Tilemap frame missing");
			validateTilemap(doc, map);
		}
	}
	doc.metadata = jsonCopy(input.metadata ?? {});
	if (!record$2(doc.metadata)) fail$8("Metadata must be an object");
	return doc;
}
function decodeLegacyPixels(data, bpi, colors, total) {
	if (typeof data !== "string" || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(data)) fail$8("Invalid legacy pixel encoding");
	if (bpi !== 1 && bpi !== 2) fail$8("Invalid legacy color index size");
	let bytes;
	if (typeof atob === "function") bytes = Uint8Array.from(atob(data), (c) => c.charCodeAt(0));
	else if (globalThis.Buffer) bytes = new Uint8Array(globalThis.Buffer.from(data, "base64"));
	else fail$8("Base64 decoding unavailable");
	if (bytes.length !== total * bpi) fail$8("Legacy pixel size mismatch");
	return Array.from({ length: total }, (_, i) => {
		const n = bytes[i * bpi] + (bpi === 2 ? bytes[i * bpi + 1] * 256 : 0);
		if (n > colors.length) fail$8("Legacy palette index missing");
		return n ? normalizeColor(colors[n - 1]) : null;
	});
}
function migrateLegacy(input) {
	if (typeof input === "string") try {
		input = JSON.parse(input);
	} catch {
		fail$8("Invalid document JSON");
	}
	const p = input?.project ?? input;
	if (!record$2(p) || !Array.isArray(p.frames) || !p.frames.length) fail$8("Unsupported document");
	if (p.version !== void 0 && ![
		1,
		2,
		3
	].includes(p.version)) fail$8("Unsupported document version");
	const width = integer$1(p.size ?? p.width, "Legacy width", 1, LIMITS.edge), height = integer$1(p.height ?? width, "Legacy height", 1, LIMITS.edge), total = width * height;
	if (total > LIMITS.canvasPixels) fail$8("Canvas exceeds the 4,194,304 pixel budget", "MEMORY_BUDGET");
	const doc = createDocument({
		width,
		height,
		name: p.name,
		palette: p.palette?.length ? p.palette : DEFAULT_PALETTE
	});
	doc.layers = (p.layers?.length ? p.layers : [{
		id: 1,
		name: "Layer 1"
	}]).map((l, i) => ({
		...l,
		id: `layer-${l.id ?? i + 1}`,
		name: l.name ?? `Layer ${i + 1}`,
		type: "image",
		parentId: null,
		visible: l.visible !== false,
		locked: !!l.locked,
		opacity: (l.opacity ?? 100) / 100,
		blendMode: "normal"
	}));
	doc.images = {};
	const used = /* @__PURE__ */ new Set();
	doc.frames = p.frames.map((f, i) => {
		let fid = `frame-${f.id ?? i + 1}`;
		if (used.has(fid)) fid = `frame-migrated-${i}`;
		used.add(fid);
		const cels = {};
		const source = Array.isArray(f.cels) ? f.cels : [{
			layerId: p.layers?.[0]?.id ?? 1,
			pixels: f.pixels,
			data: f.data
		}];
		for (const [j, c] of source.entries()) {
			let pix;
			if (Array.isArray(c.pixels)) pix = c.pixels.map((v) => v == null ? null : normalizeColor(v));
			else if (c.data !== void 0) pix = decodeLegacyPixels(c.data, c.bytesPerIndex ?? f.bytesPerIndex ?? p.bytesPerIndex, p.colors ?? [], total);
			else continue;
			if (pix.length !== total) fail$8("Legacy pixel count mismatch");
			const imageId = `image-migrated-${i}-${j}`;
			doc.images[imageId] = {
				width,
				height,
				pixels: pix
			};
			cels[`layer-${c.layerId ?? 1}`] = {
				imageId,
				x: 0,
				y: 0,
				opacity: 1
			};
		}
		return {
			id: fid,
			durationMs: f.durationMs ?? 125,
			cels
		};
	});
	const oldFrameMap = new Map(p.frames.map((f, i) => [String(f.id ?? i + 1), doc.frames[i].id]));
	doc.clips = p.clips?.length ? p.clips.map((c, i) => ({
		id: `clip-${c.id ?? i + 1}`,
		name: c.name ?? `Clip ${i + 1}`,
		frameIds: c.frameIds.map((fid) => oldFrameMap.get(String(fid))),
		direction: c.direction ?? "forward",
		loop: c.loop !== false
	})) : [{
		id: "clip-1",
		name: "default",
		frameIds: doc.frames.map((f) => f.id),
		direction: "forward",
		loop: true
	}];
	doc.slices = (p.slices ?? []).map((s, i) => ({
		...s,
		id: `slice-${s.id ?? i + 1}`
	}));
	doc.metadata = {
		migratedFrom: p.version ?? "runtime",
		legacy: {
			pivot: jsonCopy(p.pivot),
			tile: jsonCopy(p.tile),
			tilemap: jsonCopy(p.tilemap),
			projector: jsonCopy(p.projector),
			editor: jsonCopy(input.editor ?? p.editor)
		}
	};
	return normalizeDocument(doc);
}
function describeDocument(doc) {
	return {
		id: doc.id,
		name: doc.name,
		width: doc.width,
		height: doc.height,
		colorMode: doc.colorMode,
		layers: doc.layers.length,
		frames: doc.frames.length,
		images: Object.keys(doc.images).length,
		storedPixels: Object.values(doc.images).reduce((s, i) => s + i.width * i.height, 0),
		durationMs: doc.frames.reduce((s, f) => s + f.durationMs, 0),
		linkedCels: doc.frames.reduce((s, f) => s + Object.keys(f.cels).length, 0) - new Set(doc.frames.flatMap((f) => Object.values(f.cels).map((c) => c.imageId))).size,
		tilesets: doc.tilesets.length,
		layerList: doc.layers.map(({ id, name, type, parentId, visible, locked, opacity, blendMode, tilesetId }) => ({
			id,
			name,
			type,
			parentId,
			visible,
			locked,
			opacity,
			blendMode,
			...tilesetId ? { tilesetId } : {}
		})),
		frameList: doc.frames.map((f) => ({
			id: f.id,
			durationMs: f.durationMs,
			cels: Object.fromEntries(Object.entries(f.cels).map(([lid, c]) => [lid, {
				imageId: c.imageId,
				x: c.x,
				y: c.y,
				opacity: c.opacity
			}]))
		})),
		clipList: doc.clips.map((c) => ({
			...c,
			frameIds: [...c.frameIds]
		})),
		sliceList: doc.slices.map((s) => ({
			id: s.id,
			name: s.name,
			...s.bounds ? { bounds: { ...s.bounds } } : {},
			...s.keys ? { keyFrames: s.keys.map((k) => k.frameId) } : {}
		})),
		tilesetList: doc.tilesets.map((t) => ({
			id: t.id,
			name: t.name,
			tileWidth: t.tileWidth,
			tileHeight: t.tileHeight,
			tileCount: t.tiles?.length ?? t.tileCount ?? 0,
			tileIds: t.tiles?.map((t) => t.id) ?? []
		}))
	};
}
function validateTilemap(doc, map) {
	const ts = doc.tilesets.find((t) => t.id === map.tilesetId);
	if (!ts) fail$8("Tilemap tileset missing");
	integer$1(map.columns, "Tilemap columns", 1, 2048);
	integer$1(map.rows, "Tilemap rows", 1, 2048);
	integer$1(map.x ?? 0, "Tilemap x", -65535, 65535);
	integer$1(map.y ?? 0, "Tilemap y", -65535, 65535);
	finite(map.opacity ?? 1, "Tilemap opacity", 0, 1);
	if (map.columns * map.rows > 1048576 || !Array.isArray(map.cells) || map.cells.length !== map.columns * map.rows) fail$8("Invalid tilemap dimensions");
	const ids = new Set((ts.tiles ?? []).map((t) => t.id));
	for (const c of map.cells) if (c !== null && (!record$2(c) || !ids.has(c.tileId) || ![
		0,
		90,
		180,
		270
	].includes(c.rotate ?? 0))) fail$8("Tilemap tile is invalid");
}
function rgbHsl(rgb) {
	const r = rgb[0] / 255, g = rgb[1] / 255, b = rgb[2] / 255, max = Math.max(r, g, b), min = Math.min(r, g, b), d = max - min, l = (max + min) / 2;
	let h = 0, s = 0;
	if (d) {
		s = d / (1 - Math.abs(2 * l - 1));
		h = max === r ? (g - b) / d % 6 : max === g ? (b - r) / d + 2 : (r - g) / d + 4;
		h = (h / 6 % 1 + 1) % 1;
	}
	return [
		h,
		s,
		l
	];
}
function hslRgb([h, s, l]) {
	h = (h % 1 + 1) % 1;
	s = clamp(s);
	l = clamp(l);
	const a = s * Math.min(l, 1 - l);
	return [
		0,
		8,
		4
	].map((n) => {
		const k = (n + h * 12) % 12;
		return 255 * (l - a * Math.max(-1, Math.min(k - 3, 9 - k, 1)));
	});
}
function blendChannel(b, s, mode) {
	switch (mode) {
		case "multiply": return b * s;
		case "screen": return b + s - b * s;
		case "overlay": return b < .5 ? 2 * b * s : 1 - 2 * (1 - b) * (1 - s);
		case "darken": return Math.min(b, s);
		case "lighten": return Math.max(b, s);
		case "color-dodge": return s >= 1 ? 1 : Math.min(1, b / (1 - s));
		case "color-burn": return s <= 0 ? 0 : 1 - Math.min(1, (1 - b) / s);
		case "hard-light": return s < .5 ? 2 * b * s : 1 - 2 * (1 - b) * (1 - s);
		case "soft-light": return s <= .5 ? b - (1 - 2 * s) * b * (1 - b) : b + (2 * s - 1) * ((b <= .25 ? ((16 * b - 12) * b + 4) * b : Math.sqrt(b)) - b);
		case "difference": return Math.abs(b - s);
		case "exclusion": return b + s - 2 * b * s;
		case "addition": return Math.min(1, b + s);
		case "subtract": return Math.max(0, b - s);
		case "divide": return s === 0 ? 1 : Math.min(1, b / s);
		default: return s;
	}
}
function colorMultiplyAdd(a, b, c) {
	const split = 134217729, as = split * a, bs = split * b, ah = as - (as - a), al = a - ah, bh = bs - (bs - b), bl = b - bh, product = a * b, error = ah * bh - product + ah * bl + al * bh + al * bl, sum = product + c, z = sum - product;
	return sum + (error + (product - (sum - z) + (c - z)));
}
const luminosity = (c) => colorMultiplyAdd(.11, c[2], .3 * c[0] + .59 * c[1]), saturation = (c) => Math.max(...c) - Math.min(...c);
function setLuminosity(c, l) {
	const delta = l - luminosity(c);
	let result = c.map((v) => v + delta);
	const mid = luminosity(result), min = Math.min(...result), max = Math.max(...result);
	if (min < 0) result = result.map((v) => mid + (v - mid) * mid / (mid - min));
	if (max > 1) result = result.map((v) => mid + (v - mid) * (1 - mid) / (max - mid));
	return result;
}
function setSaturation(c, s) {
	const order = [
		0,
		1,
		2
	].sort((a, b) => c[a] - c[b]), result = [
		0,
		0,
		0
	], [lo, mid, hi] = order;
	if (c[hi] > c[lo]) {
		result[mid] = (c[mid] - c[lo]) * s / (c[hi] - c[lo]);
		result[hi] = s;
	}
	return result;
}
function coverageProduct(a, b) {
	const value = a * b + 128;
	return value + (value >> 8) >> 8;
}
function blendAt(out, index, source, opacity = 1, mode = "normal") {
	const sourceAlpha = coverageProduct(source[3], Math.round(opacity * 255));
	if (sourceAlpha <= 0) return;
	const backdropAlpha = out[index + 3], alpha = sourceAlpha + backdropAlpha - coverageProduct(sourceAlpha, backdropAlpha);
	if (mode === "normal" || !backdropAlpha) {
		for (let k = 0; k < 3; k++) out[index + k] = backdropAlpha ? out[index + k] + Math.trunc((source[k] - out[index + k]) * sourceAlpha / alpha) : source[k];
		out[index + 3] = alpha;
		return;
	}
	const backdrop = Array.from(out.subarray(index, index + 3)), foreground = Array.from(source).slice(0, 3);
	const over = (color) => backdrop.map((value, k) => value + Math.trunc((color[k] - value) * sourceAlpha / alpha));
	const normal = backdropAlpha ? over(foreground) : foreground;
	let result = normal;
	if (mode !== "normal" && backdropAlpha) {
		const b = backdrop.map((v) => v / 255), s = foreground.map((v) => v / 255);
		let color;
		if ([
			"hue",
			"saturation",
			"color",
			"luminosity"
		].includes(mode)) color = mode === "hue" ? setLuminosity(setSaturation(s, saturation(b)), luminosity(b)) : mode === "saturation" ? setLuminosity(setSaturation(b, saturation(s)), luminosity(b)) : mode === "color" ? setLuminosity(s, luminosity(b)) : setLuminosity(b, luminosity(s));
		else if (mode === "exclusion") color = backdrop.map((v, k) => (v + foreground[k] - 2 * coverageProduct(v, foreground[k])) / 255);
		else if (mode === "color-dodge") color = backdrop.map((v, k) => v === 0 ? 0 : foreground[k] === 255 ? 1 : Math.min(255, Math.floor((v * 255 + (255 - foreground[k]) / 2) / (255 - foreground[k]))) / 255);
		else if (mode === "color-burn") color = backdrop.map((v, k) => v === 255 ? 1 : foreground[k] === 0 ? 0 : 1 - Math.min(255, Math.floor(((255 - v) * 255 + foreground[k] / 2) / foreground[k])) / 255);
		else if (mode === "divide") color = backdrop.map((v, k) => v === 0 ? 0 : foreground[k] === 0 ? 1 : Math.min(255, Math.floor((v * 255 + foreground[k] / 2) / foreground[k])) / 255);
		else color = b.map((value, k) => blendChannel(value, s[k], mode));
		const blended = over(color.map((v) => [
			"hue",
			"saturation",
			"color",
			"luminosity"
		].includes(mode) ? Math.floor(clamp(v) * 255) : Math.round(clamp(v) * 255))), intersection = coverageProduct(backdropAlpha, sourceAlpha);
		result = normal.map((value, k) => {
			const mixed = value + coverageProduct(blended[k] - value, backdropAlpha);
			return mixed + coverageProduct(blended[k] - mixed, intersection);
		});
	}
	for (let k = 0; k < 3; k++) out[index + k] = result[k];
	out[index + 3] = alpha;
}
function renderImage(doc, out, image, cel, opacity, mode) {
	if (!image || image.tilemap) return;
	if (cel.preciseBounds?.flags & 1) {
		const b = cel.preciseBounds;
		if (![
			b.x,
			b.y,
			b.width,
			b.height
		].every(Number.isFinite) || b.width <= 0 || b.height <= 0) return;
		for (let y = Math.max(0, Math.ceil(b.y - .5)); y < Math.min(doc.height, Math.ceil(b.y + b.height - .5)); y++) for (let x = Math.max(0, Math.ceil(b.x - .5)); x < Math.min(doc.width, Math.ceil(b.x + b.width - .5)); x++) {
			const ix = clamp(Math.floor((x + .5 - b.x) / b.width * image.width), 0, image.width - 1), iy = clamp(Math.floor((y + .5 - b.y) / b.height * image.height), 0, image.height - 1), p = image.pixels[iy * image.width + ix];
			if (p !== null) blendAt(out, (y * doc.width + x) * 4, pixelRGBA(doc, p), opacity, mode);
		}
		return;
	}
	const x0 = Math.max(0, cel.x), y0 = Math.max(0, cel.y), x1 = Math.min(doc.width, cel.x + image.width), y1 = Math.min(doc.height, cel.y + image.height);
	for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x++) {
		const p = image.pixels[(y - cel.y) * image.width + x - cel.x];
		if (p !== null) blendAt(out, (y * doc.width + x) * 4, pixelRGBA(doc, p), opacity, mode);
	}
}
function renderTile(doc, out, image, sx, sy, sw, sh, dx, dy, dw, dh, flipX, flipY, rotate, opacity, mode) {
	let fx = !!flipX, fy = !!flipY, diagonal = false;
	if (rotate === 90) {
		diagonal = true;
		[fx, fy] = [!fy, fx];
	} else if (rotate === 180) {
		fx = !fx;
		fy = !fy;
	} else if (rotate === 270) {
		diagonal = true;
		[fx, fy] = [fy, !fx];
	}
	for (let y = Math.max(0, dy); y < Math.min(doc.height, dy + dh); y++) for (let x = Math.max(0, dx); x < Math.min(doc.width, dx + dw); x++) {
		let u = fx ? dw - 1 - (x - dx) : x - dx, v = fy ? dh - 1 - (y - dy) : y - dy;
		if (diagonal) [u, v] = [v, u];
		if (u < 0 || v < 0 || u >= dw || v >= dh) {
			out.fill(0, (y * doc.width + x) * 4, (y * doc.width + x) * 4 + 4);
			continue;
		}
		const ix = sx + Math.min(sw - 1, Math.floor((u + .5) * sw / dw)), iy = sy + Math.min(sh - 1, Math.floor((v + .5) * sh / dh));
		if (ix < 0 || iy < 0 || ix >= image.width || iy >= image.height) continue;
		if (image[TILE_BACKDROP_CLEAR]?.[iy * image.width + ix]) {
			out.fill(0, (y * doc.width + x) * 4, (y * doc.width + x) * 4 + 4);
			continue;
		}
		const p = image.pixels[iy * image.width + ix];
		if (p != null) blendAt(out, (y * doc.width + x) * 4, pixelRGBA(doc, p), opacity, mode);
	}
}
function renderTilemap(doc, out, layer, frame, opacity, mode) {
	const map = layer.tilemaps?.[frame.id];
	if (map) {
		const ts = doc.tilesets.find((t) => t.id === map.tilesetId);
		if (!ts) return;
		const tiles = new Map((ts.tiles ?? []).map((t) => [t.id, t]));
		for (let i = 0; i < map.cells.length; i++) {
			const cell = map.cells[i];
			if (!cell) continue;
			const tile = tiles.get(cell.tileId), image = doc.images[tile?.imageId], rect = tile?.sourceRect;
			if (image) renderTile(doc, out, image, rect?.x ?? 0, rect?.y ?? 0, rect?.width ?? image.width, rect?.height ?? image.height, (map.x ?? 0) + i % map.columns * ts.tileWidth, (map.y ?? 0) + Math.floor(i / map.columns) * ts.tileHeight, ts.tileWidth, ts.tileHeight, cell.flipX, cell.flipY, cell.rotate ?? 0, opacity * (map.opacity ?? 1), mode);
		}
		return;
	}
	const cel = frame.cels[layer.id], image = doc.images[cel?.imageId], tilemap = image?.tilemap, ts = doc.tilesets.find((t) => t.id === layer.tilesetId), atlas = doc.images[ts?.imageId];
	if (!tilemap || !ts || !atlas) return;
	const tw = ts.tileWidth, th = ts.tileHeight, cols = Math.floor(atlas.width / tw);
	if (cols < 1) return;
	for (let i = 0; i < tilemap.tiles.length; i++) {
		const value = tilemap.tiles[i] >>> 0, index = (value & (tilemap.idMask ?? 536870911)) >>> 0;
		if (ts.flags & 4 ? index === 0 : value === 4294967295) continue;
		if (index >= (ts.tileCount ?? Math.floor(atlas.height / th) * cols)) continue;
		const diagonal = !!(value & (tilemap.diagonalFlipMask ?? 536870912)), flipX = !!(value & (tilemap.xFlipMask ?? 2147483648)), flipY = !!(value & (tilemap.yFlipMask ?? 1073741824));
		renderTile(doc, out, atlas, index % cols * tw, Math.floor(index / cols) * th, tw, th, cel.x + i % image.width * tw, cel.y + Math.floor(i / image.width) * th, tw, th, diagonal ? flipY : flipX, diagonal ? !flipX : flipY, diagonal ? 90 : 0, opacity * cel.opacity, mode);
	}
}
/** Layers are ordered bottom-to-top. Groups composite their children in isolation. */
function renderFrame(doc, frameId = doc.frames[0]?.id) {
	if (!Number.isSafeInteger(doc.width) || !Number.isSafeInteger(doc.height) || doc.width < 1 || doc.height < 1 || doc.width > LIMITS.edge || doc.height > LIMITS.edge || doc.width * doc.height > LIMITS.canvasPixels) fail$8("Invalid canvas dimensions or pixel budget", "MEMORY_BUDGET");
	const frame = doc.frames.find((f) => f.id === frameId);
	if (!frame) fail$8("Frame not found");
	let palette = doc.palette;
	for (const f of doc.frames) {
		if (f.palette) palette = f.palette;
		if (f.id === frame.id) break;
	}
	const working = palette === doc.palette ? doc : {
		...doc,
		palette
	};
	const children = /* @__PURE__ */ new Map(), positions = new Map(doc.layers.map((l, i) => [l.id, i]));
	for (const l of doc.layers) {
		const key = l.parentId ?? null;
		if (!children.has(key)) children.set(key, []);
		children.get(key).push(l);
	}
	for (const list of children.values()) list.sort((a, b) => {
		const za = frame.cels[a.id]?.zIndex ?? 0, zb = frame.cels[b.id]?.zIndex ?? 0;
		return positions.get(a.id) + za - positions.get(b.id) - zb || za - zb || positions.get(a.id) - positions.get(b.id);
	});
	function renderGroup(parent, depth) {
		if (depth > 24) fail$8("Layer nesting exceeds rendering limit");
		const out = new Uint8ClampedArray(doc.width * doc.height * 4);
		for (const layer of children.get(parent) ?? []) {
			if (!layer.visible || layer.opacity === 0 && layer.type !== "tilemap") continue;
			let display = working;
			const transparent = doc.metadata?.aseprite?.transparentIndex;
			if (doc.colorMode === "indexed" && Number.isInteger(transparent) && !(layer.asepriteFlags & 8)) {
				display = {
					...working,
					palette: [...working.palette]
				};
				if (transparent < display.palette.length) display.palette[transparent] = "#00000000";
			}
			if (layer.type === "group") {
				const sub = renderGroup(layer.id, depth + 1);
				for (let i = 0; i < sub.length; i += 4) if (sub[i + 3]) blendAt(out, i, sub.subarray(i, i + 4), layer.opacity, layer.blendMode);
			} else if (layer.type === "tilemap") renderTilemap(display, out, layer, frame, layer.opacity, layer.blendMode);
			else {
				const cel = frame.cels[layer.id];
				if (cel) renderImage(display, out, doc.images[cel.imageId], cel, layer.opacity * cel.opacity, layer.blendMode);
			}
		}
		return out;
	}
	return renderGroup(null, 0);
}
function shallowDocument(doc) {
	return {
		...doc,
		palette: [...doc.palette],
		layers: doc.layers.map((l) => ({ ...l })),
		frames: doc.frames.map((f) => ({
			...f,
			cels: Object.fromEntries(Object.entries(f.cels).map(([k, c]) => [k, { ...c }]))
		})),
		images: { ...doc.images },
		clips: doc.clips.map((c) => ({
			...c,
			frameIds: [...c.frameIds]
		})),
		slices: doc.slices.map((s) => ({
			...s,
			...s.bounds ? { bounds: { ...s.bounds } } : {}
		})),
		tilesets: doc.tilesets.map((t) => ({
			...t,
			...t.tiles ? { tiles: t.tiles.map((a) => ({ ...a })) } : {}
		})),
		metadata: { ...doc.metadata }
	};
}
function fresh(doc, prefix) {
	const keys = new Set([
		doc.id,
		...doc.layers.map((l) => l.id),
		...doc.frames.map((f) => f.id),
		...Object.keys(doc.images),
		...doc.clips.map((c) => c.id),
		...doc.slices.map((s) => s.id),
		...doc.tilesets.map((t) => t.id)
	]);
	let n = 1;
	while (keys.has(`${prefix}-${n}`)) n++;
	return `${prefix}-${n}`;
}
function frameFor(doc, fid) {
	const f = doc.frames.find((f) => f.id === (fid ?? doc.frames[0].id));
	if (!f) fail$8("Frame not found");
	return f;
}
function layerFor(doc, lid, write = false) {
	const l = doc.layers.find((l) => l.id === (lid ?? doc.layers.find((l) => l.type === "image")?.id));
	if (!l) fail$8("Layer not found");
	if (write) {
		let a = l;
		while (a) {
			if (a.locked) fail$8("Layer is locked", "LOCKED_LAYER");
			a = a.parentId ? doc.layers.find((l) => l.id === a.parentId) : null;
		}
	}
	return l;
}
function targetFrames(doc, c) {
	const ids = c.frameIds ?? (c.frameId ? [c.frameId] : [doc.frames[0].id]);
	if (!Array.isArray(ids) || !ids.length || new Set(ids).size !== ids.length) fail$8("Frame range must be a nonempty list of unique ids");
	return ids.map((fid) => frameFor(doc, fid));
}
function reserve(doc, count, replacing) {
	if (Object.values(doc.images).reduce((s, i) => s + i.width * i.height, 0) - (replacing ? doc.images[replacing].width * doc.images[replacing].height : 0) + count > LIMITS.pixels) fail$8("Document exceeds the stored pixel budget", "MEMORY_BUDGET");
}
function writable(doc, c, changed) {
	const layer = layerFor(doc, c.layerId, true);
	if (!["image", "reference"].includes(layer.type)) fail$8("Drawing requires an image or reference layer");
	const frame = frameFor(doc, c.frameId);
	let cel = frame.cels[layer.id];
	if (!cel) {
		reserve(doc, doc.width * doc.height);
		const imageId = fresh(doc, "image");
		doc.images[imageId] = {
			width: doc.width,
			height: doc.height,
			pixels: Array(doc.width * doc.height).fill(null)
		};
		cel = frame.cels[layer.id] = {
			imageId,
			x: 0,
			y: 0,
			opacity: 1
		};
		changed.add(imageId);
	}
	let image = doc.images[cel.imageId];
	if (image.tilemap) fail$8("Raster drawing cannot edit tile indices");
	if (cel.preciseBounds?.flags & 1) {
		const b = cel.preciseBounds, x = integer$1(Math.floor(b.x), "Rasterized cel x", -65535, 65535), y = integer$1(Math.floor(b.y), "Rasterized cel y", -65535, 65535), width = integer$1(Math.ceil(b.x + b.width) - x, "Rasterized width", 1, LIMITS.imageEdge), height = integer$1(Math.ceil(b.y + b.height) - y, "Rasterized height", 1, LIMITS.imageEdge), source = image, imageId = fresh(doc, "image");
		delete frame.cels[layer.id];
		gcImages(doc);
		reserve(doc, width * height);
		const pixels = Array(width * height).fill(null);
		for (let py = 0; py < height; py++) for (let px = 0; px < width; px++) {
			const wx = x + px + .5, wy = y + py + .5;
			if (wx < b.x || wy < b.y || wx >= b.x + b.width || wy >= b.y + b.height) continue;
			const ix = clamp(Math.floor((wx - b.x) / b.width * source.width), 0, source.width - 1), iy = clamp(Math.floor((wy - b.y) / b.height * source.height), 0, source.height - 1);
			pixels[py * width + px] = source.pixels[iy * source.width + ix];
		}
		image = doc.images[imageId] = {
			width,
			height,
			pixels
		};
		cel = frame.cels[layer.id] = {
			...cel,
			imageId,
			x,
			y,
			preciseBounds: {
				...b,
				flags: b.flags & -2
			}
		};
		changed.add(imageId);
	}
	if (!changed.has(cel.imageId)) {
		image = doc.images[cel.imageId] = {
			...image,
			pixels: [...image.pixels]
		};
		changed.add(cel.imageId);
	}
	const x0 = Math.min(cel.x, 0), y0 = Math.min(cel.y, 0), w = Math.max(cel.x + image.width, doc.width) - x0, h = Math.max(cel.y + image.height, doc.height) - y0;
	if (w !== image.width || h !== image.height) {
		if (w > LIMITS.imageEdge || h > LIMITS.imageEdge) fail$8("Image expansion exceeds bounds");
		reserve(doc, w * h, cel.imageId);
		const pixels = Array(w * h).fill(null), ox = cel.x - x0, oy = cel.y - y0;
		for (let y = 0; y < image.height; y++) for (let x = 0; x < image.width; x++) pixels[(y + oy) * w + x + ox] = image.pixels[y * image.width + x];
		image = doc.images[cel.imageId] = {
			...image,
			width: w,
			height: h,
			pixels
		};
		for (const f of doc.frames) for (const linked of Object.values(f.cels)) if (linked.imageId === cel.imageId) {
			linked.x -= ox;
			linked.y -= oy;
		}
	}
	return {
		frame,
		layer,
		cel,
		image
	};
}
function selectionMask(doc, mask) {
	if (mask === void 0 || mask === null) return null;
	if (!Array.isArray(mask) && !(mask instanceof Uint8Array) || mask.length !== doc.width * doc.height) fail$8("Selection must match canvas dimensions");
	for (const x of mask) if (x !== 0 && x !== 1 && x !== false && x !== true) fail$8("Selection values must be 0 or 1");
	return mask;
}
function point(p, label = "Point") {
	if (!record$2(p)) fail$8(`${label} is missing`);
	return {
		x: Math.round(finite(p.x, `${label} x`, -65535, 65535)),
		y: Math.round(finite(p.y, `${label} y`, -65535, 65535)),
		...p.pressure === void 0 ? {} : { pressure: finite(p.pressure, "Pressure", 0, 1) }
	};
}
function points(ps, min = 1, max = 65536) {
	if (!Array.isArray(ps) || ps.length < min || ps.length > max) fail$8(`Expected ${min}–${max} points`);
	return ps.map((p) => point(p));
}
function context(doc, c, changed) {
	const t = writable(doc, c, changed), mask = selectionMask(doc, c.selection), wrap = c.wrap === true ? "both" : c.wrap ?? "none";
	if (![
		"none",
		"x",
		"y",
		"both"
	].includes(wrap)) fail$8("Invalid drawing wrap mode");
	let ops = 0;
	return {
		...t,
		doc: colorContext(doc, t.frame.id, t.layer.id),
		command: c,
		mask,
		put(x, y, color) {
			if (++ops > LIMITS.operations) fail$8("Drawing operation exceeds work budget");
			x = Math.round(x);
			y = Math.round(y);
			if (wrap === "x" || wrap === "both") x = (x % doc.width + doc.width) % doc.width;
			if (wrap === "y" || wrap === "both") y = (y % doc.height + doc.height) % doc.height;
			if (x < 0 || y < 0 || x >= doc.width || y >= doc.height || mask && !mask[y * doc.width + x]) return;
			const ix = x - t.cel.x, iy = y - t.cel.y;
			if (ix >= 0 && iy >= 0 && ix < t.image.width && iy < t.image.height) t.image.pixels[iy * t.image.width + ix] = color;
		},
		get(x, y) {
			if (wrap === "x" || wrap === "both") x = (x % doc.width + doc.width) % doc.width;
			if (wrap === "y" || wrap === "both") y = (y % doc.height + doc.height) % doc.height;
			x = Math.round(x) - t.cel.x;
			y = Math.round(y) - t.cel.y;
			return x < 0 || y < 0 || x >= t.image.width || y >= t.image.height ? null : t.image.pixels[y * t.image.width + x];
		}
	};
}
function clippedLine(a, b, width, height, pad = 0) {
	let lo = 0, hi = 1;
	const dx = b.x - a.x, dy = b.y - a.y;
	for (const [p, q] of [
		[-dx, a.x + pad],
		[dx, width - 1 + pad - a.x],
		[-dy, a.y + pad],
		[dy, height - 1 + pad - a.y]
	]) if (p === 0) {
		if (q < 0) return null;
	} else {
		const r = q / p;
		if (p < 0) lo = Math.max(lo, r);
		else hi = Math.min(hi, r);
		if (lo > hi) return null;
	}
	return [{
		x: Math.round(a.x + lo * dx),
		y: Math.round(a.y + lo * dy)
	}, {
		x: Math.round(a.x + hi * dx),
		y: Math.round(a.y + hi * dy)
	}];
}
function linePoints(a, b, width, height, pad = 0) {
	const clip = clippedLine(a, b, width, height, pad);
	if (!clip) return [];
	let [{ x: x0, y: y0 }, { x: x1, y: y1 }] = clip;
	const out = [], dx = Math.abs(x1 - x0), sx = x0 < x1 ? 1 : -1, dy = -Math.abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
	let e = dx + dy;
	for (;;) {
		out.push({
			x: x0,
			y: y0
		});
		if (x0 === x1 && y0 === y1) break;
		const e2 = 2 * e;
		if (e2 >= dy) {
			e += dy;
			x0 += sx;
		}
		if (e2 <= dx) {
			e += dx;
			y0 += sy;
		}
	}
	return out;
}
function brush(c, doc) {
	const size = integer$1(c.size ?? 1, "Brush size", 1, 256);
	let mask = null;
	if (c.mask) {
		const m = c.mask;
		integer$1(m.width, "Mask width", 1, 256);
		integer$1(m.height, "Mask height", 1, 256);
		if (!Array.isArray(m.pixels) || m.pixels.length !== m.width * m.height) fail$8("Brush mask dimensions mismatch");
		if (m.colors && (!Array.isArray(m.colors) || m.colors.length !== m.pixels.length)) fail$8("Brush colors dimensions mismatch");
		mask = {
			...m,
			colors: m.colors?.map((p) => encodeColor(doc, p))
		};
	}
	const symmetry = c.symmetry ?? "none";
	if (![
		"none",
		"x",
		"y",
		"both"
	].includes(symmetry)) fail$8("Invalid symmetry");
	if (![
		"paint",
		"lighten",
		"darken",
		"shading"
	].includes(c.ink ?? "paint")) fail$8("Unsupported ink");
	let shading = null;
	if (c.ink === "shading") {
		const entries = c.ramp ?? doc.palette.map((_color, index) => index);
		if (!Array.isArray(entries) || !entries.length || entries.length > LIMITS.palette) fail$8("Shading ramp must contain palette indices or colors");
		const ramp = entries.map((color) => encodeColor(doc, color)), step = integer$1(c.shadeStep ?? -1, "Shading step", -65535, 65535);
		shading = /* @__PURE__ */ new Map();
		ramp.forEach((color, index) => {
			if (!shading.has(color)) shading.set(color, ramp[clamp(index + step, 0, ramp.length - 1)]);
		});
	}
	return {
		size,
		mask,
		symmetry,
		shading,
		round: c.brush === "circle",
		color: c.erase ? null : encodeColor(doc, c.color === void 0 ? doc.palette[0] : c.color)
	};
}
function stamp(ctx, p, b) {
	if (p.pressure === 0) return;
	const pressure = p.pressure ?? 1, size = Math.max(1, Math.round(b.size * pressure)), w = b.mask ? b.mask.width : size, h = b.mask ? b.mask.height : size;
	const xs = b.symmetry === "x" || b.symmetry === "both" ? [p.x, ctx.doc.width - 1 - p.x] : [p.x], ys = b.symmetry === "y" || b.symmetry === "both" ? [p.y, ctx.doc.height - 1 - p.y] : [p.y];
	for (const cx of new Set(xs)) for (const cy of new Set(ys)) for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
		if (b.mask && !b.mask.pixels[y * w + x]) continue;
		if (!b.mask && b.round && (x - (w - 1) / 2) ** 2 + (y - (h - 1) / 2) ** 2 > (size / 2) ** 2) continue;
		const dx = cx + x - Math.floor(w / 2), dy = cy + y - Math.floor(h / 2);
		let color = b.mask?.colors ? b.mask.colors[y * w + x] : b.color;
		if (b.shading) {
			const old = ctx.get(dx, dy);
			if (!pixelRGBA(ctx.doc, old)[3] || !b.shading.has(old)) continue;
			const wrap = ctx.command.wrap === true ? "both" : ctx.command.wrap, px = wrap === "x" || wrap === "both" ? (dx % ctx.doc.width + ctx.doc.width) % ctx.doc.width : dx;
			const key = (wrap === "y" || wrap === "both" ? (dy % ctx.doc.height + ctx.doc.height) % ctx.doc.height : dy) * ctx.doc.width + px;
			ctx.shaded ??= /* @__PURE__ */ new Set();
			if (ctx.shaded.has(key)) continue;
			ctx.shaded.add(key);
			color = b.shading.get(old);
		} else if (ctx.command.ink === "lighten" || ctx.command.ink === "darken") {
			const old = pixelRGBA(ctx.doc, ctx.get(dx, dy)), delta = 255 * finite(ctx.command.amount ?? .12, "Shade amount", 0, 1) * (ctx.command.ink === "lighten" ? 1 : -1);
			color = old[3] ? encodeColor(ctx.doc, hex$1([
				old[0] + delta,
				old[1] + delta,
				old[2] + delta,
				old[3]
			])) : null;
		}
		ctx.put(dx, dy, color);
	}
}
function drawStroke(ctx, ps, c) {
	if (c.pressure === false) ps = ps.map((p) => ({
		...p,
		pressure: 1
	}));
	const b = brush(c, ctx.doc), path = [];
	for (let i = 0; i < ps.length; i++) {
		if (i === 0) {
			path.push(ps[i]);
			continue;
		}
		const segment = c.wrap && c.wrap !== "none" ? linePoints({
			x: ps[i - 1].x + 65535,
			y: ps[i - 1].y + 65535
		}, {
			x: ps[i].x + 65535,
			y: ps[i].y + 65535
		}, 131071, 131071).map((p) => ({
			x: p.x - 65535,
			y: p.y - 65535
		})) : linePoints(ps[i - 1], ps[i], ctx.doc.width, ctx.doc.height, Math.max(b.size, b.mask?.width ?? 0, b.mask?.height ?? 0));
		for (let j = 0; j < segment.length; j++) {
			if (path.at(-1)?.x === segment[j].x && path.at(-1)?.y === segment[j].y) continue;
			path.push({
				...segment[j],
				pressure: (ps[i - 1].pressure ?? 1) + ((ps[i].pressure ?? 1) - (ps[i - 1].pressure ?? 1)) * j / Math.max(1, segment.length - 1)
			});
			if (path.length > 1048576) fail$8("Stroke exceeds work budget");
		}
	}
	const filtered = [];
	for (const p of path) {
		const a = filtered.at(-2), b0 = filtered.at(-1);
		if (c.pixelPerfect && b.size === 1 && !b.mask && a && b0 && Math.abs(a.x - p.x) === 1 && Math.abs(a.y - p.y) === 1 && Math.abs(a.x - b0.x) + Math.abs(a.y - b0.y) === 1 && Math.abs(p.x - b0.x) + Math.abs(p.y - b0.y) === 1) filtered.pop();
		filtered.push(p);
	}
	for (const p of filtered) stamp(ctx, p, b);
}
function bounds(c) {
	return {
		x: integer$1(c.x, "X", -65535, 65535),
		y: integer$1(c.y, "Y", -65535, 65535),
		width: integer$1(c.width, "Shape width", 1, 65535),
		height: integer$1(c.height, "Shape height", 1, 65535)
	};
}
function drawShape(ctx, c, ellipse = false) {
	const b = bounds(c), color = encodeColor(ctx.doc, c.color === void 0 ? ctx.doc.palette[0] : c.color), thickness = integer$1(c.size ?? 1, "Outline size", 1, 256);
	const x1 = Math.max(0, b.x), y1 = Math.max(0, b.y), x2 = Math.min(ctx.doc.width, b.x + b.width), y2 = Math.min(ctx.doc.height, b.y + b.height);
	for (let y = y1; y < y2; y++) for (let x = x1; x < x2; x++) {
		const dx = x - b.x + .5 - b.width / 2, dy = y - b.y + .5 - b.height / 2;
		const outer = ellipse ? (dx / (b.width / 2)) ** 2 + (dy / (b.height / 2)) ** 2 <= 1 : true;
		const iw = b.width / 2 - thickness, ih = b.height / 2 - thickness;
		const inner = ellipse ? iw > 0 && ih > 0 && (dx / iw) ** 2 + (dy / ih) ** 2 < 1 : x >= b.x + thickness && y >= b.y + thickness && x < b.x + b.width - thickness && y < b.y + b.height - thickness;
		if (outer && (c.filled || !inner)) ctx.put(x, y, color);
	}
}
function floodMask(doc, get, c) {
	const seed = point(c), mask = Array(doc.width * doc.height).fill(0);
	if (seed.x < 0 || seed.y < 0 || seed.x >= doc.width || seed.y >= doc.height) return mask;
	const target = pixelRGBA(doc, get(seed.x, seed.y)), tolerance = finite(c.tolerance ?? 0, "Tolerance", 0, 255);
	const matches = (x, y) => {
		const p = pixelRGBA(doc, get(x, y));
		return Math.max(...p.map((v, k) => Math.abs(v - target[k]))) <= tolerance;
	};
	if (c.contiguous === false) {
		for (let y = 0; y < doc.height; y++) for (let x = 0; x < doc.width; x++) if (matches(x, y)) mask[y * doc.width + x] = 1;
		return mask;
	}
	const queue = new Int32Array(doc.width * doc.height);
	let read = 0, write = 0;
	const enqueue = (x, y) => {
		if (x < 0 || y < 0 || x >= doc.width || y >= doc.height) return;
		const i = y * doc.width + x;
		if (mask[i] !== 0) return;
		mask[i] = 2;
		if (matches(x, y)) {
			mask[i] = 1;
			queue[write++] = i;
		}
	};
	enqueue(seed.x, seed.y);
	while (read < write) {
		const i = queue[read++], x = i % doc.width, y = Math.floor(i / doc.width);
		enqueue(x - 1, y);
		enqueue(x + 1, y);
		enqueue(x, y - 1);
		enqueue(x, y + 1);
	}
	return mask.map((v) => v === 1 ? 1 : 0);
}
const BITMAP_FONT = Object.freeze({
	width: 5,
	height: 7,
	glyphs: Object.freeze(Object.fromEntries(Object.entries({
		"A": [
			"01110",
			"10001",
			"10001",
			"11111",
			"10001",
			"10001",
			"10001"
		],
		"B": [
			"11110",
			"10001",
			"10001",
			"11110",
			"10001",
			"10001",
			"11110"
		],
		"C": [
			"01111",
			"10000",
			"10000",
			"10000",
			"10000",
			"10000",
			"01111"
		],
		"D": [
			"11110",
			"10001",
			"10001",
			"10001",
			"10001",
			"10001",
			"11110"
		],
		"E": [
			"11111",
			"10000",
			"10000",
			"11110",
			"10000",
			"10000",
			"11111"
		],
		"F": [
			"11111",
			"10000",
			"10000",
			"11110",
			"10000",
			"10000",
			"10000"
		],
		"G": [
			"01111",
			"10000",
			"10000",
			"10111",
			"10001",
			"10001",
			"01111"
		],
		"H": [
			"10001",
			"10001",
			"10001",
			"11111",
			"10001",
			"10001",
			"10001"
		],
		"I": [
			"11111",
			"00100",
			"00100",
			"00100",
			"00100",
			"00100",
			"11111"
		],
		"J": [
			"00111",
			"00010",
			"00010",
			"00010",
			"10010",
			"10010",
			"01100"
		],
		"K": [
			"10001",
			"10010",
			"10100",
			"11000",
			"10100",
			"10010",
			"10001"
		],
		"L": [
			"10000",
			"10000",
			"10000",
			"10000",
			"10000",
			"10000",
			"11111"
		],
		"M": [
			"10001",
			"11011",
			"10101",
			"10101",
			"10001",
			"10001",
			"10001"
		],
		"N": [
			"10001",
			"11001",
			"10101",
			"10011",
			"10001",
			"10001",
			"10001"
		],
		"O": [
			"01110",
			"10001",
			"10001",
			"10001",
			"10001",
			"10001",
			"01110"
		],
		"P": [
			"11110",
			"10001",
			"10001",
			"11110",
			"10000",
			"10000",
			"10000"
		],
		"Q": [
			"01110",
			"10001",
			"10001",
			"10001",
			"10101",
			"10010",
			"01101"
		],
		"R": [
			"11110",
			"10001",
			"10001",
			"11110",
			"10100",
			"10010",
			"10001"
		],
		"S": [
			"01111",
			"10000",
			"10000",
			"01110",
			"00001",
			"00001",
			"11110"
		],
		"T": [
			"11111",
			"00100",
			"00100",
			"00100",
			"00100",
			"00100",
			"00100"
		],
		"U": [
			"10001",
			"10001",
			"10001",
			"10001",
			"10001",
			"10001",
			"01110"
		],
		"V": [
			"10001",
			"10001",
			"10001",
			"10001",
			"10001",
			"01010",
			"00100"
		],
		"W": [
			"10001",
			"10001",
			"10001",
			"10101",
			"10101",
			"10101",
			"01010"
		],
		"X": [
			"10001",
			"10001",
			"01010",
			"00100",
			"01010",
			"10001",
			"10001"
		],
		"Y": [
			"10001",
			"10001",
			"01010",
			"00100",
			"00100",
			"00100",
			"00100"
		],
		"Z": [
			"11111",
			"00001",
			"00010",
			"00100",
			"01000",
			"10000",
			"11111"
		],
		"0": [
			"01110",
			"10001",
			"10011",
			"10101",
			"11001",
			"10001",
			"01110"
		],
		"1": [
			"00100",
			"01100",
			"00100",
			"00100",
			"00100",
			"00100",
			"01110"
		],
		"2": [
			"01110",
			"10001",
			"00001",
			"00010",
			"00100",
			"01000",
			"11111"
		],
		"3": [
			"11110",
			"00001",
			"00001",
			"01110",
			"00001",
			"00001",
			"11110"
		],
		"4": [
			"00010",
			"00110",
			"01010",
			"10010",
			"11111",
			"00010",
			"00010"
		],
		"5": [
			"11111",
			"10000",
			"10000",
			"11110",
			"00001",
			"00001",
			"11110"
		],
		"6": [
			"01110",
			"10000",
			"10000",
			"11110",
			"10001",
			"10001",
			"01110"
		],
		"7": [
			"11111",
			"00001",
			"00010",
			"00100",
			"01000",
			"01000",
			"01000"
		],
		"8": [
			"01110",
			"10001",
			"10001",
			"01110",
			"10001",
			"10001",
			"01110"
		],
		"9": [
			"01110",
			"10001",
			"10001",
			"01111",
			"00001",
			"00001",
			"01110"
		],
		"?": [
			"01110",
			"10001",
			"00010",
			"00100",
			"00100",
			"00000",
			"00100"
		],
		"!": [
			"00100",
			"00100",
			"00100",
			"00100",
			"00100",
			"00000",
			"00100"
		],
		".": [
			"00000",
			"00000",
			"00000",
			"00000",
			"00000",
			"00110",
			"00110"
		],
		",": [
			"00000",
			"00000",
			"00000",
			"00000",
			"00110",
			"00110",
			"00100"
		],
		":": [
			"00000",
			"00110",
			"00110",
			"00000",
			"00110",
			"00110",
			"00000"
		],
		";": [
			"00000",
			"00110",
			"00110",
			"00000",
			"00110",
			"00110",
			"00100"
		],
		"-": [
			"00000",
			"00000",
			"00000",
			"11111",
			"00000",
			"00000",
			"00000"
		],
		"_": [
			"00000",
			"00000",
			"00000",
			"00000",
			"00000",
			"00000",
			"11111"
		],
		"+": [
			"00000",
			"00100",
			"00100",
			"11111",
			"00100",
			"00100",
			"00000"
		],
		"=": [
			"00000",
			"00000",
			"11111",
			"00000",
			"11111",
			"00000",
			"00000"
		],
		"/": [
			"00001",
			"00010",
			"00010",
			"00100",
			"01000",
			"01000",
			"10000"
		],
		"\\": [
			"10000",
			"01000",
			"01000",
			"00100",
			"00010",
			"00010",
			"00001"
		],
		"(": [
			"00010",
			"00100",
			"01000",
			"01000",
			"01000",
			"00100",
			"00010"
		],
		")": [
			"01000",
			"00100",
			"00010",
			"00010",
			"00010",
			"00100",
			"01000"
		],
		"[": [
			"01110",
			"01000",
			"01000",
			"01000",
			"01000",
			"01000",
			"01110"
		],
		"]": [
			"01110",
			"00010",
			"00010",
			"00010",
			"00010",
			"00010",
			"01110"
		],
		"<": [
			"00010",
			"00100",
			"01000",
			"10000",
			"01000",
			"00100",
			"00010"
		],
		">": [
			"01000",
			"00100",
			"00010",
			"00001",
			"00010",
			"00100",
			"01000"
		],
		"#": [
			"01010",
			"01010",
			"11111",
			"01010",
			"11111",
			"01010",
			"01010"
		],
		"*": [
			"00000",
			"10101",
			"01110",
			"11111",
			"01110",
			"10101",
			"00000"
		],
		"\"": [
			"01010",
			"01010",
			"00000",
			"00000",
			"00000",
			"00000",
			"00000"
		],
		"'": [
			"00100",
			"00100",
			"00000",
			"00000",
			"00000",
			"00000",
			"00000"
		],
		" ": [
			"00000",
			"00000",
			"00000",
			"00000",
			"00000",
			"00000",
			"00000"
		]
	}).map(([k, v]) => [k, Object.freeze(v.join("").split("").map(Number))])))
});
function drawText(ctx, c) {
	const pos = point(c), scale = integer$1(c.scale ?? 1, "Text scale", 1, 64), font = c.font ?? BITMAP_FONT, w = integer$1(font.width, "Glyph width", 1, 64), h = integer$1(font.height, "Glyph height", 1, 64);
	if (typeof c.text !== "string" || c.text.length > 4096) fail$8("Text must contain at most 4096 characters");
	const spacing = integer$1(c.spacing ?? 1, "Text spacing", 0, 64), lineHeight = integer$1(c.lineHeight ?? h + 1, "Line height", 1, 128), color = encodeColor(ctx.doc, c.color === void 0 ? ctx.doc.palette[0] : c.color);
	let x = pos.x, y = pos.y;
	for (const ch of c.text) {
		if (ch === "\n") {
			x = pos.x;
			y += lineHeight * scale;
			continue;
		}
		const glyph = font.glyphs[ch] ?? font.glyphs[ch.toUpperCase()] ?? font.glyphs["?"];
		if (!Array.isArray(glyph) || glyph.length !== w * h) fail$8(`Missing or invalid glyph: ${ch}`);
		for (let gy = 0; gy < h; gy++) for (let gx = 0; gx < w; gx++) if (glyph[gy * w + gx]) for (let py = 0; py < scale; py++) for (let px = 0; px < scale; px++) ctx.put(x + gx * scale + px, y + gy * scale + py, color);
		x += (w + spacing) * scale;
	}
}
function gradient(ctx, c) {
	const a = point(c.from, "Gradient start"), b = point(c.to, "Gradient end"), ac = pixelRGBA(ctx.doc, encodeColor(ctx.doc, c.color === void 0 ? ctx.doc.palette[0] : c.color)), bc = pixelRGBA(ctx.doc, encodeColor(ctx.doc, c.endColor === void 0 ? ctx.doc.palette.at(-1) : c.endColor)), dx = b.x - a.x, dy = b.y - a.y, den = dx * dx + dy * dy;
	if (!den) fail$8("Gradient endpoints must differ");
	const bayer = [
		0,
		8,
		2,
		10,
		12,
		4,
		14,
		6,
		3,
		11,
		1,
		9,
		15,
		7,
		13,
		5
	];
	for (let y = 0; y < ctx.doc.height; y++) for (let x = 0; x < ctx.doc.width; x++) {
		let t = clamp(((x - a.x) * dx + (y - a.y) * dy) / den);
		if (c.dither) {
			const threshold = (bayer[y % 4 * 4 + x % 4] + .5) / 16;
			ctx.put(x, y, encodeColor(ctx.doc, hex$1(t >= threshold ? bc : ac)));
		} else ctx.put(x, y, encodeColor(ctx.doc, hex$1(ac.map((v, k) => v + (bc[k] - v) * t))));
	}
}
function drawCurve(ctx, c) {
	const ps = points(c.points, 3, 4);
	if (ps.length !== 3 && ps.length !== 4) fail$8("Curve requires 3 or 4 control points");
	const length = ps.slice(1).reduce((s, p, i) => s + Math.hypot(p.x - ps[i].x, p.y - ps[i].y), 0), steps = Math.max(4, Math.min(16384, Math.ceil(length * 2))), path = [];
	for (let i = 0; i <= steps; i++) {
		const t = i / steps, u = 1 - t;
		path.push(ps.length === 3 ? {
			x: Math.round(u * u * ps[0].x + 2 * u * t * ps[1].x + t * t * ps[2].x),
			y: Math.round(u * u * ps[0].y + 2 * u * t * ps[1].y + t * t * ps[2].y)
		} : {
			x: Math.round(u ** 3 * ps[0].x + 3 * u * u * t * ps[1].x + 3 * u * t * t * ps[2].x + t ** 3 * ps[3].x),
			y: Math.round(u ** 3 * ps[0].y + 3 * u * u * t * ps[1].y + 3 * u * t * t * ps[2].y + t ** 3 * ps[3].y)
		});
	}
	drawStroke(ctx, path, c);
}
function drawPolygon(ctx, c) {
	const ps = points(c.points, c.filled ? 3 : 2, 4096), color = encodeColor(ctx.doc, c.color === void 0 ? ctx.doc.palette[0] : c.color);
	if (c.filled) {
		const minY = Math.max(0, Math.min(...ps.map((p) => p.y))), maxY = Math.min(ctx.doc.height - 1, Math.max(...ps.map((p) => p.y)));
		for (let y = minY; y <= maxY; y++) {
			const scan = y + .5, intersections = [];
			for (let i = 0, j = ps.length - 1; i < ps.length; j = i++) {
				const a = ps[i], b = ps[j];
				if (a.y > scan !== b.y > scan) intersections.push(a.x + (scan - a.y) * (b.x - a.x) / (b.y - a.y));
			}
			intersections.sort((a, b) => a - b);
			for (let i = 0; i + 1 < intersections.length; i += 2) for (let x = Math.max(0, Math.ceil(intersections[i] - .5)); x < Math.min(ctx.doc.width, Math.ceil(intersections[i + 1] - .5)); x++) ctx.put(x, y, color);
		}
	}
	drawStroke(ctx, [...ps, ps[0]], c);
}
function maskBounds(mask, width, height) {
	let x = width, y = height, x2 = -1, y2 = -1;
	for (let i = 0; i < mask.length; i++) if (mask[i]) {
		const px = i % width, py = Math.floor(i / width);
		x = Math.min(x, px);
		y = Math.min(y, py);
		x2 = Math.max(x2, px);
		y2 = Math.max(y2, py);
	}
	return x2 < 0 ? null : {
		x,
		y,
		width: x2 - x + 1,
		height: y2 - y + 1
	};
}
function selectionTransform(doc, c, changed) {
	const mask = selectionMask(doc, c.selection);
	if (!mask) fail$8("Transform requires a selection");
	const b = maskBounds(mask, doc.width, doc.height);
	if (!b) return;
	const ctx = context(doc, {
		...c,
		selection: null
	}, changed), snapshot = [...ctx.image.pixels], get = (x, y) => {
		const ix = x - ctx.cel.x, iy = y - ctx.cel.y;
		return ix < 0 || iy < 0 || ix >= ctx.image.width || iy >= ctx.image.height ? null : snapshot[iy * ctx.image.width + ix];
	}, op = c.operation ?? "move", method = c.method ?? "nearest";
	if (![
		"move",
		"scale",
		"rotate",
		"flipX",
		"flipY"
	].includes(op)) fail$8("Unsupported selection transform");
	if (![
		"nearest",
		"pixel-safe",
		"fast",
		"rotsprite"
	].includes(method)) fail$8("Unsupported transform sampling method");
	if (method !== "nearest" && op !== "rotate") fail$8("Fast and RotSprite sampling are only used for rotation");
	const dx = finite(c.dx ?? 0, "Move x", -65535, 65535), dy = finite(c.dy ?? 0, "Move y", -65535, 65535), sx = op === "scale" ? finite(c.scaleX ?? 1, "Scale x", .01, 64) : op === "flipX" ? -1 : 1, sy = op === "scale" ? finite(c.scaleY ?? c.scaleX ?? 1, "Scale y", .01, 64) : op === "flipY" ? -1 : 1, angle = op === "rotate" ? finite(c.angle ?? 0, "Angle", -36e3, 36e3) * Math.PI / 180 : 0, cos = Math.cos(angle), sin = Math.sin(angle), cx = c.pivot?.x ?? b.x + b.width / 2, cy = c.pivot?.y ?? b.y + b.height / 2;
	finite(cx, "Pivot x", -65535, 65535);
	finite(cy, "Pivot y", -65535, 65535);
	if (op === "rotate") {
		const corner = (x, y) => [Math.round((x - cx) * cos - (y - cy) * sin + cx + dx), Math.round((x - cx) * sin + (y - cy) * cos + cy + dy)], q0 = corner(b.x, b.y), q1 = corner(b.x + b.width, b.y), q3 = corner(b.x, b.y + b.height), corners = [
			q0,
			q1,
			[q1[0] + q3[0] - q0[0], q1[1] + q3[1] - q0[1]],
			q3
		];
		const left = Math.min(...corners.map((p) => p[0])), top = Math.min(...corners.map((p) => p[1])), width = Math.max(...corners.map((p) => p[0])) - left, height = Math.max(...corners.map((p) => p[1])) - top;
		let transformed = null;
		if (width && height && left < doc.width && top < doc.height && left + width > 0 && top + height > 0) {
			const pixels = new Uint32Array(b.width * b.height), selection = new Uint8Array(pixels.length), indexed = doc.colorMode === "indexed", gray = doc.colorMode === "grayscale";
			for (let y = 0; y < b.height; y++) for (let x = 0; x < b.width; x++) {
				const at = y * b.width + x;
				if (!mask[(y + b.y) * doc.width + x + b.x]) continue;
				selection[at] = 1;
				const raw = get(x + b.x, y + b.y), rgba = pixelRGBA(ctx.doc, raw);
				pixels[at] = indexed ? raw == null || !rgba[3] ? 0 : raw + 1 : gray ? rgba[0] | rgba[3] << 8 : (rgba[0] | rgba[1] << 8 | rgba[2] << 16 | rgba[3] << 24) >>> 0;
			}
			transformed = rasterizeRotation({
				pixels,
				width: b.width,
				height: b.height,
				destinationWidth: width,
				destinationHeight: height,
				corners: corners.map(([x, y]) => [x - left, y - top]),
				method: ["pixel-safe", "rotsprite"].includes(method) ? "rotsprite" : "fast",
				pixelFormat: indexed ? "values" : gray ? "grayscale" : "rgba",
				mask: selection
			});
		}
		if (!c.copy) {
			for (let y = b.y; y < b.y + b.height; y++) for (let x = b.x; x < b.x + b.width; x++) if (mask[y * doc.width + x]) ctx.put(x, y, null);
		}
		if (transformed) {
			const back = new Uint8ClampedArray(4);
			for (let y = Math.max(0, -top); y < Math.min(height, doc.height - top); y++) for (let x = Math.max(0, -left); x < Math.min(width, doc.width - left); x++) {
				const at = y * width + x;
				if (!transformed.coverage[at]) continue;
				const value = transformed.pixels[at];
				if (doc.colorMode === "indexed") {
					if (value) ctx.put(x + left, y + top, value - 1);
					continue;
				}
				const rgba = doc.colorMode === "grayscale" ? [
					value & 255,
					value & 255,
					value & 255,
					value >>> 8 & 255
				] : [
					value & 255,
					value >>> 8 & 255,
					value >>> 16 & 255,
					value >>> 24
				];
				if (!rgba[3]) continue;
				back.set(pixelRGBA(ctx.doc, ctx.get(x + left, y + top)));
				blendAt(back, 0, rgba, 1, "normal");
				ctx.put(x + left, y + top, encodeColor(ctx.doc, hex$1([...back])));
			}
		}
		return;
	}
	if (!c.copy) {
		for (let y = b.y; y < b.y + b.height; y++) for (let x = b.x; x < b.x + b.width; x++) if (mask[y * doc.width + x]) ctx.put(x, y, null);
	}
	for (let y = 0; y < doc.height; y++) for (let x = 0; x < doc.width; x++) {
		const tx = x + .5 - cx - dx, ty = y + .5 - cy - dy, sourceX = Math.floor((tx * cos + ty * sin) / sx + cx + 1e-9), sourceY = Math.floor((-tx * sin + ty * cos) / sy + cy + 1e-9);
		if (sourceX >= 0 && sourceY >= 0 && sourceX < doc.width && sourceY < doc.height && mask[sourceY * doc.width + sourceX]) ctx.put(x, y, get(sourceX, sourceY));
	}
}
function separateEffectContexts(doc, c) {
	const selected = targetFrames(doc, c);
	if (doc.colorMode !== "indexed" || selected.length < 2) return;
	const layer = layerFor(doc, c.layerId, true), selectedImages = new Set(selected.map((frame) => frame.cels[layer.id]?.imageId).filter(Boolean)), groups = /* @__PURE__ */ new Map();
	for (const frame of doc.frames) {
		const cel = frame.cels[layer.id];
		if (!cel || !selectedImages.has(cel.imageId)) continue;
		const originalId = cel.imageId, key = JSON.stringify(getFramePalette(doc, frame.id, layer.id));
		let contexts = groups.get(originalId);
		if (!contexts) {
			contexts = /* @__PURE__ */ new Map();
			groups.set(originalId, contexts);
		}
		if (!contexts.has(key)) if (!contexts.size) contexts.set(key, originalId);
		else {
			const image = doc.images[originalId];
			reserve(doc, image.width * image.height);
			const imageId = fresh(doc, "image");
			doc.images[imageId] = {
				...image,
				pixels: [...image.pixels]
			};
			contexts.set(key, imageId);
		}
		cel.imageId = contexts.get(key);
	}
}
function applyEffect(doc, c, changed) {
	separateEffectContexts(doc, c);
	const effect = c.effect;
	if (![
		"replace",
		"outline",
		"brightness",
		"contrast",
		"hue",
		"saturation",
		"convolution",
		"despeckle"
	].includes(effect)) fail$8("Unsupported effect");
	const handled = /* @__PURE__ */ new Set();
	for (const frame of targetFrames(doc, c)) {
		const cel0 = frame.cels[c.layerId ?? doc.layers.find((l) => l.type === "image")?.id];
		if (cel0 && handled.has(cel0.imageId)) continue;
		const ctx = context(doc, {
			...c,
			frameId: frame.id
		}, changed);
		handled.add(ctx.cel.imageId);
		const source = [...ctx.image.pixels], sample = (x, y) => {
			x = clamp(x, 0, doc.width - 1) - ctx.cel.x;
			y = clamp(y, 0, doc.height - 1) - ctx.cel.y;
			return x < 0 || y < 0 || x >= ctx.image.width || y >= ctx.image.height ? null : source[y * ctx.image.width + x];
		};
		const color = ["replace", "outline"].includes(effect) ? encodeColor(ctx.doc, c.toColor === void 0 ? c.color === void 0 ? doc.palette[0] : c.color : c.toColor) : null, from = effect === "replace" && c.fromColor !== void 0 ? encodeColor(ctx.doc, c.fromColor) : void 0, amount = [
			"brightness",
			"contrast",
			"hue",
			"saturation"
		].includes(effect) ? finite(c.amount ?? (effect === "hue" ? 30 : .1), "Effect amount", effect === "hue" ? -360 : effect === "contrast" ? -.99 : -1, effect === "hue" ? 360 : effect === "contrast" ? .99 : 1) : 0, radius = effect === "outline" ? integer$1(c.radius ?? 1, "Outline radius", 1, 64) : 1;
		let kernel, size, divisor;
		if (effect === "convolution") {
			kernel = c.kernel;
			if (!Array.isArray(kernel) || kernel.length < 1 || kernel.length > 225 || !Number.isInteger(Math.sqrt(kernel.length)) || Math.sqrt(kernel.length) % 2 !== 1) fail$8("Convolution requires an odd square kernel up to 15×15");
			for (const n of kernel) finite(n, "Kernel coefficient", -1e3, 1e3);
			size = Math.sqrt(kernel.length);
			divisor = finite(c.divisor ?? (kernel.reduce((a, b) => a + b, 0) || 1), "Kernel divisor", -1e6, 1e6);
			if (divisor === 0) fail$8("Kernel divisor cannot be zero");
			finite(c.bias ?? 0, "Kernel bias", -255, 255);
		}
		if ((ctx.mask ? ctx.mask.reduce((sum, v) => sum + (v ? 1 : 0), 0) : doc.width * doc.height) * (effect === "outline" ? (radius * 2 + 1) ** 2 : effect === "convolution" ? kernel.length : effect === "despeckle" ? 9 : 1) > LIMITS.operations) fail$8("Effect exceeds work budget; use a smaller canvas or radius");
		for (let y = 0; y < doc.height; y++) for (let x = 0; x < doc.width; x++) {
			if (ctx.mask && !ctx.mask[y * doc.width + x]) continue;
			const p = sample(x, y), v = pixelRGBA(ctx.doc, p);
			let result = p;
			if (effect === "replace") {
				if (from === void 0 ? p !== null : hex$1(pixelRGBA(ctx.doc, from)) === hex$1(v)) result = color;
			} else if (effect === "outline") {
				if (v[3] === 0) {
					let hit = false;
					for (let oy = -radius; oy <= radius && !hit; oy++) for (let ox = -radius; ox <= radius; ox++) {
						if (c.diagonal === false && Math.abs(ox) + Math.abs(oy) > radius) continue;
						if (x + ox < 0 || y + oy < 0 || x + ox >= doc.width || y + oy >= doc.height) continue;
						if (pixelRGBA(ctx.doc, sample(x + ox, y + oy))[3]) {
							hit = true;
							break;
						}
					}
					if (hit) result = color;
				}
			} else if (effect === "convolution") {
				const sum = [
					0,
					0,
					0,
					0
				];
				for (let ky = 0; ky < size; ky++) for (let kx = 0; kx < size; kx++) {
					const q = pixelRGBA(ctx.doc, sample(x + kx - (size - 1) / 2, y + ky - (size - 1) / 2)), weight = kernel[ky * size + kx];
					for (let k = 0; k < 4; k++) sum[k] += q[k] * weight;
				}
				result = encodeColor(ctx.doc, hex$1(sum.map((n, k) => k === 3 && !c.affectAlpha ? v[3] : n / divisor + (k === 3 ? 0 : c.bias ?? 0))));
			} else if (effect === "despeckle") {
				const samples = [];
				for (let oy = -1; oy <= 1; oy++) for (let ox = -1; ox <= 1; ox++) samples.push(pixelRGBA(ctx.doc, sample(x + ox, y + oy)));
				result = encodeColor(ctx.doc, hex$1([
					0,
					1,
					2,
					3
				].map((k) => samples.map((p) => p[k]).sort((a, b) => a - b)[4])));
			} else if (v[3]) {
				if (effect === "brightness") for (let k = 0; k < 3; k++) v[k] += amount * 255;
				else if (effect === "contrast") {
					const factor = (1 + amount) / (1 - amount);
					for (let k = 0; k < 3; k++) v[k] = (v[k] - 127.5) * factor + 127.5;
				} else {
					const hsl = rgbHsl(v);
					if (effect === "hue") hsl[0] += amount / 360;
					else hsl[1] = clamp(hsl[1] + amount);
					v.splice(0, 3, ...hslRgb(hsl));
				}
				result = encodeColor(ctx.doc, hex$1(v));
			}
			ctx.put(x, y, result);
		}
	}
}
function gcImages(doc) {
	const used = new Set(doc.frames.flatMap((f) => Object.values(f.cels).map((c) => c.imageId)));
	for (const ts of doc.tilesets) {
		if (ts.imageId) used.add(ts.imageId);
		for (const t of ts.tiles ?? []) used.add(t.imageId);
	}
	for (const key of Object.keys(doc.images)) if (!used.has(key)) delete doc.images[key];
}
function resizeImage(image, width, height) {
	const pixels = Array(width * height).fill(null);
	for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) pixels[y * width + x] = image.pixels[Math.min(image.height - 1, Math.floor(y * image.height / height)) * image.width + Math.min(image.width - 1, Math.floor(x * image.width / width))];
	return {
		...image,
		width,
		height,
		pixels
	};
}
function resizeDocument(doc, c) {
	const width = integer$1(c.width, "Width", 1, LIMITS.edge), height = integer$1(c.height, "Height", 1, LIMITS.edge), mode = c.mode ?? "canvas";
	if (width * height > LIMITS.canvasPixels) fail$8("Canvas exceeds the 4,194,304 pixel budget", "MEMORY_BUDGET");
	if (!["canvas", "scale"].includes(mode)) fail$8("Invalid resize mode");
	const sx = width / doc.width, sy = height / doc.height, dx = c.anchor === "center" ? Math.floor((width - doc.width) / 2) : 0, dy = c.anchor === "center" ? Math.floor((height - doc.height) / 2) : 0;
	if (mode === "scale") {
		const referenced = new Set(doc.frames.flatMap((f) => Object.values(f.cels).map((c) => c.imageId))), plans = [];
		let pixels = 0;
		for (const [key, image] of Object.entries(doc.images)) if (referenced.has(key) && !image.tilemap) {
			const w = Math.max(1, Math.round(image.width * sx)), h = Math.max(1, Math.round(image.height * sy));
			integer$1(w, "Scaled image width", 1, LIMITS.imageEdge);
			integer$1(h, "Scaled image height", 1, LIMITS.imageEdge);
			pixels += w * h;
			plans.push([
				key,
				w,
				h
			]);
		} else pixels += image.width * image.height;
		if (pixels > LIMITS.pixels) fail$8("Scaled document exceeds pixel budget");
		for (const [key, w, h] of plans) doc.images[key] = resizeImage(doc.images[key], w, h);
		for (const frame of doc.frames) for (const cel of Object.values(frame.cels)) {
			cel.x = Math.round(cel.x * sx);
			cel.y = Math.round(cel.y * sy);
		}
	} else for (const frame of doc.frames) for (const cel of Object.values(frame.cels)) {
		cel.x += dx;
		cel.y += dy;
	}
	doc.slices = doc.slices.map((s) => {
		if (!s.bounds) return {
			...s,
			keys: s.keys.map((k) => ({
				...k,
				x: Math.round(mode === "scale" ? k.x * sx : k.x + dx),
				y: Math.round(mode === "scale" ? k.y * sy : k.y + dy),
				width: Math.round(k.width * (mode === "scale" ? sx : 1)),
				height: Math.round(k.height * (mode === "scale" ? sy : 1))
			}))
		};
		const x = clamp(Math.round(mode === "scale" ? s.bounds.x * sx : s.bounds.x + dx), 0, width - 1), y = clamp(Math.round(mode === "scale" ? s.bounds.y * sy : s.bounds.y + dy), 0, height - 1);
		return {
			...s,
			bounds: {
				x,
				y,
				width: clamp(Math.round(s.bounds.width * (mode === "scale" ? sx : 1)), 1, width - x),
				height: clamp(Math.round(s.bounds.height * (mode === "scale" ? sy : 1)), 1, height - y)
			}
		};
	});
	doc.width = width;
	doc.height = height;
}
function easing(t, name = "linear") {
	t = clamp(t);
	switch (name) {
		case "linear": return t;
		case "easeIn": return t * t;
		case "easeOut": return 1 - (1 - t) ** 2;
		case "easeInOut": return t < .5 ? 2 * t * t : 1 - (-2 * t + 2) ** 2 / 2;
		case "bounce": {
			const n = 7.5625, d = 2.75;
			if (t < 1 / d) return n * t * t;
			if (t < 2 / d) return n * (t -= 1.5 / d) * t + .75;
			if (t < 2.5 / d) return n * (t -= 2.25 / d) * t + .9375;
			return n * (t -= 2.625 / d) * t + .984375;
		}
		default: fail$8("Unsupported easing");
	}
}
function tween(doc, c) {
	const layer = layerFor(doc, c.layerId, true);
	if (layer.type === "group" || layer.type === "tilemap") fail$8("Tween requires a raster layer");
	const frames = targetFrames(doc, c), source = frameFor(doc, c.sourceFrameId ?? frames[0].id).cels[layer.id];
	if (!source) fail$8("Tween source cel is empty");
	const from = c.from ?? {}, to = c.to ?? {}, start = {
		x: finite(from.x ?? source.x, "Start x", -65535, 65535),
		y: finite(from.y ?? source.y, "Start y", -65535, 65535),
		opacity: finite(from.opacity ?? source.opacity, "Start opacity", 0, 1)
	}, end = {
		x: finite(to.x ?? start.x, "End x", -65535, 65535),
		y: finite(to.y ?? start.y, "End y", -65535, 65535),
		opacity: finite(to.opacity ?? start.opacity, "End opacity", 0, 1)
	};
	frames.forEach((f, i) => {
		const t = easing(frames.length === 1 ? 0 : i / (frames.length - 1), c.easing ?? "linear");
		const cel = {
			...source,
			x: Math.round(start.x + (end.x - start.x) * t),
			y: Math.round(start.y + (end.y - start.y) * t),
			opacity: start.opacity + (end.opacity - start.opacity) * t
		};
		if (c.bake !== false) {
			const image = doc.images[source.imageId];
			reserve(doc, image.width * image.height);
			const key = fresh(doc, "image");
			doc.images[key] = {
				...image,
				pixels: [...image.pixels]
			};
			cel.imageId = key;
		}
		f.cels[layer.id] = cel;
	});
	doc.metadata.motion = {
		...doc.metadata.motion ?? {},
		[c.id ?? "last-tween"]: {
			type: "tween",
			layerId: layer.id,
			frameIds: frames.map((f) => f.id),
			from: start,
			to: end,
			easing: c.easing ?? "linear",
			bake: c.bake !== false
		}
	};
}
function seededRandom(seed) {
	let n = seed >>> 0;
	return () => {
		n += 1831565813;
		let t = n;
		t = Math.imul(t ^ t >>> 15, t | 1);
		t ^= t + Math.imul(t ^ t >>> 7, t | 61);
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
function particles(doc, c, changed) {
	const layer = layerFor(doc, c.layerId, true);
	if (layer.type !== "image") fail$8("Particles require an image layer");
	const frames = targetFrames(doc, c), seed = integer$1(c.seed ?? 1, "Seed", 0, 4294967295), count = integer$1(c.count ?? 32, "Particle count", 1, 4096), x = finite(c.x ?? doc.width / 2, "Emitter x", -65535, 65535), y = finite(c.y ?? doc.height / 2, "Emitter y", -65535, 65535), speed = finite(c.speed ?? 20, "Speed", 0, 4096), spread = finite(c.spread ?? 360, "Spread", 0, 360), angle = finite(c.angle ?? -90, "Direction", -36e3, 36e3), gravity = finite(c.gravity ?? 12, "Gravity", -4096, 4096), lifetime = finite(c.lifetime ?? 2, "Lifetime seconds", .01, 3600), size = integer$1(c.size ?? 1, "Particle size", 1, 64), random = seededRandom(seed), emission = finite(c.emission ?? 0, "Emission seconds", 0, 3600), color = c.color === void 0 ? doc.palette[0] : c.color;
	const ps = Array.from({ length: count }, () => {
		const a = (angle + (random() - .5) * spread) * Math.PI / 180, v = speed * (.5 + random() * .5);
		return {
			vx: Math.cos(a) * v,
			vy: Math.sin(a) * v,
			birth: random() * emission,
			life: lifetime * (.7 + .3 * random())
		};
	});
	let time = 0;
	for (const frame of frames) {
		if (c.clear !== false) {
			delete frame.cels[layer.id];
			gcImages(doc);
		}
		const ctx = context(doc, {
			...c,
			frameId: frame.id
		}, changed), b = brush({
			size,
			color,
			brush: c.brush ?? "square"
		}, ctx.doc);
		for (const p of ps) {
			const t = time - p.birth;
			if (t < 0 || t > p.life) continue;
			const a = c.fade === false ? 1 : 1 - t / p.life, base = pixelRGBA(ctx.doc, b.color);
			stamp(ctx, {
				x: Math.round(x + p.vx * t),
				y: Math.round(y + p.vy * t + .5 * gravity * t * t)
			}, {
				...b,
				color: encodeColor(ctx.doc, hex$1([
					base[0],
					base[1],
					base[2],
					base[3] * a
				]))
			});
		}
		time += frame.durationMs / 1e3;
	}
	doc.metadata.motion = {
		...doc.metadata.motion ?? {},
		[c.id ?? "last-particles"]: {
			type: "particles",
			layerId: layer.id,
			frameIds: frames.map((f) => f.id),
			seed,
			count,
			x,
			y,
			speed,
			spread,
			angle,
			gravity,
			lifetime,
			size,
			emission,
			color,
			fade: c.fade !== false
		}
	};
}
function setCel(doc, c) {
	const frame = frameFor(doc, c.frameId), layer = layerFor(doc, c.layerId, true);
	if (!["image", "reference"].includes(layer.type)) fail$8("Set cel requires a raster layer");
	const width = integer$1(c.width ?? doc.width, "Image width", 1, LIMITS.imageEdge), height = integer$1(c.height ?? doc.height, "Image height", 1, LIMITS.imageEdge);
	if (width * height > LIMITS.pixels || !Array.isArray(c.pixels) || c.pixels.length !== width * height) fail$8("Imported image dimensions mismatch");
	const working = colorContext(doc, frame.id, layer.id), pixels = c.pixels.map((v) => encodeColor(working, v));
	const existing = frame.cels[layer.id], key = c.editLinked && existing ? existing.imageId : fresh(doc, "image");
	if (existing && !c.editLinked) delete frame.cels[layer.id];
	gcImages(doc);
	reserve(doc, width * height, own$3(doc.images, key) ? key : void 0);
	doc.images[key] = {
		width,
		height,
		pixels
	};
	frame.cels[layer.id] = {
		...existing?.userData ? { userData: jsonCopy(existing.userData) } : {},
		...existing?.zIndex !== void 0 ? { zIndex: existing.zIndex } : {},
		imageId: key,
		x: integer$1(c.x ?? 0, "Cel x", -65535, 65535),
		y: integer$1(c.y ?? 0, "Cel y", -65535, 65535),
		opacity: finite(c.opacity ?? 1, "Cel opacity", 0, 1)
	};
}
/** Convert each image in its actual frame/layer color context. Tile variants stay in
* the same tileset, so palette animation remains exportable as a native tilemap. */
function convertColorMode(doc, colorMode, options = {}) {
	if (![
		"rgba",
		"indexed",
		"grayscale"
	].includes(colorMode)) fail$8("Unsupported color mode");
	if (colorMode === doc.colorMode && !options.remap && !options.indexedOptions) return;
	const source = shallowDocument(doc), images = {}, variants = /* @__PURE__ */ new Map(), tilesetVariants = /* @__PURE__ */ new Map();
	const usedIds = new Set(Object.keys(source.images));
	let nextImage = 1, storedPixels = 0;
	const framePalettes = /* @__PURE__ */ new Map(), contexts = /* @__PURE__ */ new WeakMap();
	let palette = source.palette, workPixels = 0;
	const indexedOptions = options.indexedOptions, indexedBudget = { remaining: LIMITS.operations };
	const nativeMapping = indexedOptions && indexedOptions.rgbmap !== "pixelwall", nativeGeneration = indexedOptions?.paletteMode === "generate" && indexedOptions.quantization !== "median-cut";
	const backgroundOnly = source.layers.length === 1 && !!(source.layers[0].asepriteFlags & 8);
	let destinationTransparent = indexedOptions ? source.metadata?.aseprite?.transparentIndex ?? 0 : source.metadata?.aseprite?.transparentIndex;
	if (nativeMapping && source.colorMode !== "indexed") destinationTransparent = Math.max(0, source.palette.indexOf("#00000000"));
	let generatedPalette;
	for (const frame of source.frames) {
		if (frame.palette) palette = frame.palette;
		framePalettes.set(frame.id, palette);
	}
	if (indexedOptions?.paletteMode === "generate") {
		function* samples() {
			const seen = /* @__PURE__ */ new Set(), usedTilesets = /* @__PURE__ */ new Set();
			function* imageSamples(imageId, frameId, layerId) {
				const image = source.images[imageId];
				if (!image || image.tilemap) return;
				const effective = getFramePalette(source, frameId, layerId), key = JSON.stringify([imageId, source.colorMode === "indexed" ? effective : null]);
				if (seen.has(key)) return;
				seen.add(key);
				const working = {
					...source,
					palette: effective
				};
				for (const pixel of image.pixels) yield pixel == null ? null : hex$1(pixelRGBA(working, pixel));
			}
			function* tileSamples(tilesetId, frameId, layerId) {
				const ts = source.tilesets.find((value) => value.id === tilesetId);
				if (!ts) return;
				usedTilesets.add(ts.id);
				if (!ts.tiles?.length && ts.externalFileId != null) fail$8("Embed external tileset pixels before converting color mode");
				for (const imageId of new Set([ts.imageId, ...(ts.tiles ?? []).map((tile) => tile.imageId)].filter(Boolean))) yield* imageSamples(imageId, frameId, layerId);
			}
			for (const frame of source.frames) for (const layer of source.layers) {
				const cel = frame.cels[layer.id];
				if (cel) yield* imageSamples(cel.imageId, frame.id, layer.id);
				if (layer.type === "tilemap") yield* tileSamples(layer.tilemaps?.[frame.id]?.tilesetId ?? layer.tilesetId, frame.id, layer.id);
			}
			for (const ts of source.tilesets) if (!usedTilesets.has(ts.id)) yield* tileSamples(ts.id, source.frames[0].id);
		}
		function* renderedSamples() {
			for (const frame of source.frames) {
				const cost = source.width * source.height * Math.max(1, source.layers.length);
				indexedBudget.remaining -= cost;
				if (indexedBudget.remaining < 0) fail$8("Native indexed palette sampling exceeds the work budget");
				const rendered = renderFrame(source, frame.id);
				for (let at = 0; at < rendered.length; at += 4) yield hex$1([...rendered.subarray(at, at + 4)]);
			}
		}
		generatedPalette = quantizePalette(nativeGeneration ? renderedSamples() : samples(), {
			...indexedOptions,
			transparentIndex: nativeGeneration ? backgroundOnly ? null : source.colorMode === "indexed" ? destinationTransparent : 0 : destinationTransparent,
			budget: indexedBudget
		});
		if (nativeGeneration) destinationTransparent = Math.max(0, generatedPalette.indexOf("#00000000"));
	}
	function contextFor(frameId, layerId) {
		const palette = framePalettes.get(frameId), layer = layerId == null ? null : source.layers.find((item) => item.id === layerId);
		const transparent = source.metadata?.aseprite?.transparentIndex, maskTransparent = (!layer || !(layer.asepriteFlags & 8)) && Number.isInteger(transparent), selected = options.selected?.has(frameId) ?? false;
		const targetTransparent = (!layer || !(layer.asepriteFlags & 8)) && Number.isInteger(destinationTransparent) ? destinationTransparent : null;
		const contextKey = `${maskTransparent}:${targetTransparent}:${selected}`;
		let byTransparency = contexts.get(palette);
		if (!byTransparency) {
			byTransparency = /* @__PURE__ */ new Map();
			contexts.set(palette, byTransparency);
		}
		if (!byTransparency.has(contextKey)) {
			const effective = (mode, entries, index) => {
				if (mode !== "indexed" || index == null || index >= entries.length) return entries;
				const copy = [...entries];
				copy[index] = "#00000000";
				return copy;
			};
			const from = {
				...source,
				palette: effective(source.colorMode, palette, maskTransparent ? transparent : null)
			}, to = {
				...source,
				colorMode,
				palette: effective(colorMode, generatedPalette ?? (selected ? options.palette : palette), nativeMapping ? null : targetTransparent)
			};
			const signature = JSON.stringify([
				source.colorMode === "indexed" || options.remap ? from.palette : null,
				colorMode === "indexed" || options.remap ? to.palette : null,
				selected
			]);
			byTransparency.set(contextKey, {
				from,
				to,
				signature,
				selected,
				originalPalette: palette,
				transparent: maskTransparent ? transparent : null,
				targetTransparent
			});
		}
		return byTransparency.get(contextKey);
	}
	function addImage(imageId, image) {
		storedPixels += image.width * image.height;
		if (storedPixels > LIMITS.pixels) fail$8("Color conversion exceeds the stored pixel budget", "MEMORY_BUDGET");
		images[imageId] = image;
		return imageId;
	}
	function convertImage(imageId, context) {
		const image = source.images[imageId];
		if (!image) fail$8("Color conversion references a missing image");
		if (image.tilemap) {
			if (!images[imageId]) addImage(imageId, image);
			return imageId;
		}
		let byContext = variants.get(imageId);
		if (!byContext) {
			byContext = /* @__PURE__ */ new Map();
			variants.set(imageId, byContext);
		}
		if (byContext.has(context.signature)) return byContext.get(context.signature);
		let convertedId;
		workPixels += image.pixels.length;
		if (workPixels > LIMITS.operations) fail$8("Color conversion exceeds the work budget", "MEMORY_BUDGET");
		const pixels = indexedOptions ? mapIndexedImage({
			...image,
			pixels: image.pixels.map((pixel) => pixel == null ? null : hex$1(pixelRGBA(context.from, pixel)))
		}, context.to.palette, {
			...indexedOptions,
			transparentIndex: context.targetTransparent,
			sourceColorMode: source.colorMode,
			budget: indexedBudget,
			...context.tileGrid ?? {}
		}) : image.pixels.map((pixel) => {
			if (pixel == null) return null;
			if (!options.remap) return encodeColor(context.to, hex$1(pixelRGBA(context.from, pixel)));
			if (!context.selected) return pixel;
			if (source.colorMode === "indexed") {
				if (pixel === context.transparent) return null;
				return options.mapping ? options.mapping[pixel] : encodeColor(context.to, hex$1(pixelRGBA(context.from, pixel)));
			}
			const oldIndex = context.originalPalette.indexOf(pixel);
			const mapped = options.mapping && oldIndex >= 0 ? options.mapping[oldIndex] : nearest(context.to.palette, rgba(pixel));
			return mapped == null ? null : encodeColor(context.to, context.to.palette[mapped]);
		});
		if (pixels.every((pixel, i) => pixel === image.pixels[i])) {
			convertedId = imageId;
			if (!images[convertedId]) addImage(convertedId, image);
			else if (!images[convertedId].pixels.every((pixel, i) => pixel === pixels[i])) convertedId = null;
		} else convertedId = null;
		if (convertedId == null) {
			for (const candidate of new Set(byContext.values())) if (images[candidate].pixels.every((pixel, i) => pixel === pixels[i])) {
				convertedId = candidate;
				break;
			}
			if (convertedId == null) {
				convertedId = imageId;
				if (images[convertedId]) {
					while (usedIds.has(`image-color-${nextImage}`)) nextImage++;
					convertedId = `image-color-${nextImage++}`;
					usedIds.add(convertedId);
				}
				addImage(convertedId, {
					...image,
					pixels
				});
			}
		}
		byContext.set(context.signature, convertedId);
		return convertedId;
	}
	function convertTileset(tilesetId, context) {
		const original = source.tilesets.find((ts) => ts.id === tilesetId);
		if (!original) fail$8("Tileset missing");
		if (!original.tiles?.length && original.externalFileId != null) fail$8("Embed external tileset pixels before converting color mode");
		let state = tilesetVariants.get(tilesetId);
		if (!state) {
			state = {
				tileset: {
					...original,
					tiles: []
				},
				contexts: /* @__PURE__ */ new Map(),
				usedIds: new Set((original.tiles ?? []).map((t) => t.id)),
				next: 1
			};
			tilesetVariants.set(tilesetId, state);
		}
		if (state.contexts.has(context.signature)) return state.contexts.get(context.signature);
		const first = state.contexts.size === 0, ids = /* @__PURE__ */ new Map();
		const atlasContext = indexedOptions && original.imageId ? {
			...context,
			tileGrid: {
				tileWidth: original.tileWidth,
				tileHeight: original.tileHeight
			},
			signature: context.signature + JSON.stringify([original.tileWidth, original.tileHeight])
		} : context;
		if (first && original.imageId) state.tileset.imageId = convertImage(original.imageId, atlasContext);
		for (const tile of original.tiles ?? []) {
			let tileId = tile.id;
			if (!first) {
				while (state.usedIds.has(`tile-color-${state.next}`)) state.next++;
				tileId = `tile-color-${state.next++}`;
				state.usedIds.add(tileId);
			}
			const converted = {
				...tile,
				id: tileId,
				imageId: convertImage(tile.imageId, tile.imageId === original.imageId ? atlasContext : context)
			};
			if (!first) delete converted.asepriteTileId;
			state.tileset.tiles.push(converted);
			ids.set(tile.id, tileId);
			if (state.tileset.tiles.length > 65536) fail$8("Color conversion exceeds the tileset limit", "MEMORY_BUDGET");
		}
		state.contexts.set(context.signature, ids);
		return ids;
	}
	for (const frame of doc.frames) {
		const originalFrame = frameFor(source, frame.id);
		for (const layer of doc.layers) {
			const cel = originalFrame.cels[layer.id];
			if (layer.type === "tilemap") {
				const originalLayer = source.layers.find((item) => item.id === layer.id), originalMap = originalLayer.tilemaps?.[frame.id];
				const tilesetId = originalMap?.tilesetId ?? originalLayer.tilesetId, ts = source.tilesets.find((item) => item.id === tilesetId);
				const map = originalMap ?? (ts ? nativeMap(source, originalLayer, originalFrame, ts) : null);
				if (map) {
					const ids = convertTileset(tilesetId, contextFor(frame.id, layer.id));
					if (!(nativeMapping && !originalMap && map.cells.every((cell) => !cell || ids.get(cell.tileId) === cell.tileId))) layer.tilemaps = {
						...layer.tilemaps ?? {},
						[frame.id]: {
							...map,
							cells: map.cells.map((cell) => cell ? {
								...cell,
								tileId: ids.get(cell.tileId)
							} : null)
						}
					};
				}
			}
			if (cel) frame.cels[layer.id] = {
				...cel,
				imageId: convertImage(cel.imageId, contextFor(frame.id, layer.id))
			};
		}
	}
	for (const tileset of source.tilesets) if (!tilesetVariants.has(tileset.id)) convertTileset(tileset.id, contextFor(source.frames[0].id));
	doc.images = images;
	doc.tilesets = source.tilesets.map((ts) => tilesetVariants.get(ts.id).tileset);
	doc.colorMode = colorMode;
	if (generatedPalette) {
		doc.palette = [...generatedPalette];
		for (const frame of doc.frames) frame.palette = [...generatedPalette];
	}
	if (indexedOptions) doc.metadata = {
		...doc.metadata,
		aseprite: {
			...doc.metadata?.aseprite,
			transparentIndex: destinationTransparent
		}
	};
}
function paletteEdit(doc, c, remap) {
	if (!Array.isArray(c.palette) || !c.palette.length || c.palette.length > LIMITS.palette) fail$8("Invalid palette");
	const palette = c.palette.map(normalizeColor), scope = c.scope ?? (c.frameIds ? "range" : c.frameId ? "frame" : "all");
	if (![
		"all",
		"frame",
		"range"
	].includes(scope)) fail$8("Palette scope must be all, frame, or range");
	if (scope === "range" && (!Array.isArray(c.frameIds) || !c.frameIds.length)) fail$8("Palette range requires frameIds");
	const selected = new Set((scope === "all" ? doc.frames : targetFrames(doc, scope === "frame" ? { frameId: c.frameId ?? doc.frames[0].id } : { frameIds: c.frameIds })).map((frame) => frame.id));
	const palettes = /* @__PURE__ */ new Map();
	let previous = doc.palette;
	for (const frame of doc.frames) {
		if (frame.palette) previous = frame.palette;
		palettes.set(frame.id, [...previous]);
	}
	let mapping = c.mapping;
	if (remap && mapping) {
		if (!Array.isArray(mapping)) fail$8("Palette mapping must include every old index");
		for (const frameId of selected) if (mapping.length !== palettes.get(frameId).length) fail$8("Palette mapping must include every old index in each selected frame");
		mapping = mapping.map((index) => index == null ? null : integer$1(index, "Remapped index", 0, palette.length - 1));
	}
	if (remap) convertColorMode(doc, doc.colorMode, {
		remap: true,
		selected,
		palette,
		mapping
	});
	else if (doc.colorMode === "indexed") {
		const checked = /* @__PURE__ */ new Set();
		function checkImage(imageId) {
			if (checked.has(imageId)) return;
			checked.add(imageId);
			const image = doc.images[imageId];
			if (!image || image.tilemap) return;
			for (const pixel of image.pixels) if (pixel != null && pixel >= palette.length) fail$8("Removing used palette entries requires remapping");
		}
		for (const frame of doc.frames) if (selected.has(frame.id)) {
			for (const cel of Object.values(frame.cels)) checkImage(cel.imageId);
			for (const layer of doc.layers) if (layer.type === "tilemap") {
				const tilesetId = layer.tilemaps?.[frame.id]?.tilesetId ?? layer.tilesetId, tileset = doc.tilesets.find((item) => item.id === tilesetId);
				if (tileset?.imageId) checkImage(tileset.imageId);
				for (const tile of tileset?.tiles ?? []) checkImage(tile.imageId);
			}
		}
		if (scope === "all") for (const tileset of doc.tilesets) {
			if (tileset.imageId) checkImage(tileset.imageId);
			for (const tile of tileset.tiles ?? []) checkImage(tile.imageId);
		}
	}
	for (const frame of doc.frames) frame.palette = selected.has(frame.id) ? [...palette] : palettes.get(frame.id);
	doc.palette = [...doc.frames[0].palette];
	const capacity = Math.max(...doc.frames.map((frame) => frame.palette.length));
	while (doc.palette.length < capacity) doc.palette.push("#00000000");
}
function addTileset(doc, c) {
	const input = c.tileset, working = colorContext(doc, c.frameId, c.layerId);
	if (!record$2(input)) fail$8("Tileset is missing");
	const ts = {
		...jsonCopy(input),
		id: input.id ?? fresh(doc, "tileset"),
		name: input.name ?? "Tileset",
		tileWidth: integer$1(input.tileWidth, "Tile width", 1, LIMITS.edge),
		tileHeight: integer$1(input.tileHeight, "Tile height", 1, LIMITS.edge),
		tiles: []
	};
	if (doc.tilesets.some((t) => t.id === ts.id)) fail$8("Tileset id exists");
	if (!Array.isArray(input.tiles) || input.tiles.length > 65536) fail$8("Tileset requires a tile list");
	for (const [i, t] of input.tiles.entries()) {
		let imageId = t.imageId;
		if (t.pixels) {
			if (!Array.isArray(t.pixels) || t.pixels.length !== ts.tileWidth * ts.tileHeight) fail$8("Tile pixels size mismatch");
			reserve(doc, t.pixels.length);
			imageId = fresh(doc, "image");
			doc.images[imageId] = {
				width: ts.tileWidth,
				height: ts.tileHeight,
				pixels: t.pixels.map((p) => encodeColor(working, p))
			};
		}
		if (!own$3(doc.images, imageId)) fail$8("Tile image missing");
		ts.tiles.push({
			id: t.id ?? `tile-${i + 1}`,
			imageId
		});
	}
	doc.tilesets.push(ts);
}
function nativeMap(doc, layer, frame, ts) {
	const cel = frame.cels[layer.id], image = doc.images[cel?.imageId], raw = image?.tilemap;
	if (!raw) return null;
	const ids = new Map((ts.tiles ?? []).filter((t) => Number.isInteger(t.asepriteTileId)).map((t) => [t.asepriteTileId, t.id]));
	const cells = raw.tiles.map((rawValue) => {
		const value = rawValue >>> 0, index = (value & (raw.idMask ?? 536870911)) >>> 0;
		if (ts.flags & 4 ? index === 0 : value === 4294967295) return null;
		const tileId = ids.get(index);
		if (!tileId) return null;
		const diagonal = !!(value & (raw.diagonalFlipMask ?? 536870912)), flipY = !!(value & (raw.yFlipMask ?? 1073741824)), flipX = !!(value & (raw.xFlipMask ?? 2147483648));
		return {
			tileId,
			flipX: diagonal ? flipY : flipX,
			flipY: diagonal ? !flipX : flipY,
			rotate: diagonal ? 90 : 0
		};
	});
	return {
		tilesetId: ts.id,
		columns: image.width,
		rows: image.height,
		cells,
		x: cel.x,
		y: cel.y,
		opacity: cel.opacity,
		sourceImageId: cel.imageId
	};
}
function getTile(doc, tilesetId, tileId) {
	const ts = doc.tilesets.find((t) => t.id === tilesetId), tile = ts?.tiles?.find((t) => t.id === tileId);
	if (!tile) fail$8("Tile not found");
	const image = doc.images[tile.imageId], r = tile.sourceRect ?? {
		x: 0,
		y: 0,
		width: image.width,
		height: image.height
	}, pixels = Array(ts.tileWidth * ts.tileHeight);
	for (let y = 0; y < ts.tileHeight; y++) for (let x = 0; x < ts.tileWidth; x++) pixels[y * ts.tileWidth + x] = image.pixels[(r.y + Math.min(r.height - 1, Math.floor(y * r.height / ts.tileHeight))) * image.width + r.x + Math.min(r.width - 1, Math.floor(x * r.width / ts.tileWidth))];
	return {
		width: ts.tileWidth,
		height: ts.tileHeight,
		pixels
	};
}
function replaceTilesetImage(doc, c) {
	const ts = doc.tilesets.find((t) => t.id === c.tilesetId);
	if (!ts) fail$8("Tileset missing");
	assertTilesetEditable(doc, ts.id);
	const slots = tilesetSlots(doc, ts), index = integer$1(c.tileIndex, "Tile index", 0, slots.count - 1), tile = slots.entries.get(index);
	if (!tile) fail$8(ts.flags & 1 ? "External tileset artwork must be embedded before editing" : "Virtual or missing tile artwork cannot be edited");
	if (c.width !== ts.tileWidth || c.height !== ts.tileHeight) fail$8("Tile image dimensions must match the tileset grid");
	const capacity = Math.max(doc.palette.length, ...doc.frames.map((f) => f.palette?.length ?? 0)), pixels = validatePixels({
		width: c.width,
		height: c.height,
		pixels: c.pixels
	}, {
		...doc,
		palette: { length: capacity }
	}, "Tile image");
	if (ts.imageId && Number.isInteger(tile.asepriteTileId)) {
		const original = doc.images[ts.imageId];
		if (!original || original.tilemap) fail$8("Tileset atlas is missing");
		const columns = Math.floor(original.width / ts.tileWidth), x = index % columns * ts.tileWidth, y = Math.floor(index / columns) * ts.tileHeight;
		if (columns < 1 || y + ts.tileHeight > original.height) fail$8("Native tile index exceeds its atlas");
		const oldId = ts.imageId, shared = doc.tilesets.some((other) => other.id !== ts.id && (other.imageId === oldId || other.tiles?.some((t) => t.imageId === oldId))) || doc.frames.some((f) => Object.values(f.cels).some((c) => c.imageId === oldId));
		let imageId = oldId;
		if (shared) {
			reserve(doc, original.pixels.length);
			imageId = fresh(doc, "image");
			ts.imageId = imageId;
			for (const t of ts.tiles) if (t.imageId === oldId) t.imageId = imageId;
		}
		const atlas = {
			...original,
			pixels: [...original.pixels]
		};
		for (let yy = 0; yy < ts.tileHeight; yy++) for (let xx = 0; xx < ts.tileWidth; xx++) atlas.pixels[(y + yy) * atlas.width + x + xx] = pixels[yy * ts.tileWidth + xx];
		doc.images[imageId] = atlas;
		tile.imageId = imageId;
		tile.sourceRect = {
			x,
			y,
			width: ts.tileWidth,
			height: ts.tileHeight
		};
	} else {
		const shared = doc.tilesets.some((other) => other.tiles?.some((t) => t !== tile && t.imageId === tile.imageId)) || doc.frames.some((f) => Object.values(f.cels).some((c) => c.imageId === tile.imageId));
		const imageId = shared ? fresh(doc, "image") : tile.imageId;
		if (shared) reserve(doc, pixels.length);
		doc.images[imageId] = {
			width: ts.tileWidth,
			height: ts.tileHeight,
			pixels
		};
		tile.imageId = imageId;
		delete tile.sourceRect;
	}
}
function paintTilemap(doc, c) {
	const layer = layerFor(doc, c.layerId, true);
	if (layer.type !== "tilemap") fail$8("Tile painting requires a tilemap layer");
	const frame = frameFor(doc, c.frameId), ts = doc.tilesets.find((t) => t.id === (c.tilesetId ?? layer.tilemaps?.[frame.id]?.tilesetId ?? layer.tilesetId));
	if (!ts) fail$8("Tileset missing");
	const previous = layer.tilemaps?.[frame.id] ?? nativeMap(doc, layer, frame, ts), columns = integer$1(c.columns ?? previous?.columns ?? Math.ceil(doc.width / ts.tileWidth), "Tile columns", 1, 2048), rows = integer$1(c.rows ?? previous?.rows ?? Math.ceil(doc.height / ts.tileHeight), "Tile rows", 1, 2048);
	if (columns * rows > 1048576) fail$8("Tilemap too large");
	const cells = Array(columns * rows).fill(null);
	if (previous) for (let y = 0; y < Math.min(rows, previous.rows); y++) for (let x = 0; x < Math.min(columns, previous.columns); x++) cells[y * columns + x] = previous.cells[y * previous.columns + x];
	if (!Array.isArray(c.points) || c.points.length > 65536) fail$8("Invalid tile paint points");
	for (const p of c.points) {
		const x = integer$1(p.x, "Tile x", 0, columns - 1), y = integer$1(p.y, "Tile y", 0, rows - 1);
		cells[y * columns + x] = p.tileId == null ? null : {
			tileId: id(p.tileId),
			flipX: !!p.flipX,
			flipY: !!p.flipY,
			rotate: p.rotate ?? 0
		};
	}
	const map = {
		...previous ?? {},
		tilesetId: ts.id,
		columns,
		rows,
		cells
	};
	validateTilemap(doc, map);
	layer.tilemaps = {
		...layer.tilemaps ?? {},
		[frame.id]: map
	};
	layer.tilesetId = ts.id;
}
function stampImage(doc, c, changed) {
	const width = integer$1(c.width, "Stamp width", 1, LIMITS.imageEdge), height = integer$1(c.height, "Stamp height", 1, LIMITS.imageEdge);
	if (width * height > LIMITS.pixels || !Array.isArray(c.pixels) || c.pixels.length !== width * height) fail$8("Stamp pixels size mismatch");
	const x0 = integer$1(c.x ?? 0, "Stamp x", -65535, 65535), y0 = integer$1(c.y ?? 0, "Stamp y", -65535, 65535), opacity = finite(c.opacity ?? 1, "Stamp opacity", 0, 1), transparent = c.transparent ?? "skip";
	if (!["skip", "replace"].includes(transparent)) fail$8("Invalid transparent-pixel mode");
	const ctx = context(doc, c, changed), pixels = c.pixels.map((p) => encodeColor(ctx.doc, p));
	for (let y = Math.max(0, -y0); y < Math.min(height, doc.height - y0); y++) for (let x = Math.max(0, -x0); x < Math.min(width, doc.width - x0); x++) {
		const source = pixels[y * width + x];
		if (source === null) {
			if (transparent === "replace") ctx.put(x + x0, y + y0, null);
			continue;
		}
		if (c.blend === false && opacity === 1) ctx.put(x + x0, y + y0, source);
		else {
			const out = new Uint8ClampedArray(pixelRGBA(ctx.doc, ctx.get(x + x0, y + y0)));
			blendAt(out, 0, pixelRGBA(ctx.doc, source), opacity, "normal");
			ctx.put(x + x0, y + y0, encodeColor(ctx.doc, hex$1([...out])));
		}
	}
}
function removeUnusedTile(doc, tileset, tileId) {
	if (!tileId) return;
	const used = /* @__PURE__ */ new Set();
	for (const layer of doc.layers) if (layer.type === "tilemap") for (const frame of doc.frames) {
		const map = layer.tilemaps?.[frame.id] ?? (layer.tilesetId === tileset.id ? nativeMap(doc, layer, frame, tileset) : null);
		if (map?.tilesetId === tileset.id) {
			for (const cell of map.cells) if (cell) used.add(cell.tileId);
		}
	}
	if (used.has(tileId)) return;
	if (!tileset.tiles.find((tile) => tile.id === tileId)) return;
	if (!(!!tileset.imageId && Number.isInteger(tileset.asepriteId))) {
		tileset.tiles = tileset.tiles.filter((tile) => tile.id !== tileId);
		gcImages(doc);
		return;
	}
	for (const layer of doc.layers) if (layer.type === "tilemap" && layer.tilesetId === tileset.id) for (const frame of doc.frames) {
		if (layer.tilemaps?.[frame.id]) continue;
		const map = nativeMap(doc, layer, frame, tileset);
		if (map) layer.tilemaps = {
			...layer.tilemaps ?? {},
			[frame.id]: map
		};
	}
	const remaining = tileset.tiles.filter((tile) => tile.id !== tileId && !(tileset.flags & 4 && tile.asepriteTileId === 0 && !used.has(tile.id)));
	const plans = remaining.map((tile) => ({
		tile,
		pixels: getTile(doc, tileset.id, tile.id).pixels
	}));
	const tileUserData = tileset.tileUserData;
	tileset.tiles = [];
	delete tileset.imageId;
	delete tileset.tileCount;
	delete tileset.externalFileId;
	delete tileset.externalTilesetId;
	tileset.flags = ((tileset.flags ?? 0) | 6) & -2;
	if (tileUserData) tileset.tileUserData = [null, ...remaining.map((tile) => tileUserData[tile.asepriteTileId] ?? null)];
	gcImages(doc);
	for (const { tile, pixels } of plans) {
		reserve(doc, pixels.length);
		const imageId = fresh(doc, "image");
		doc.images[imageId] = {
			width: tileset.tileWidth,
			height: tileset.tileHeight,
			pixels
		};
		const copy = {
			...tile,
			imageId
		};
		delete copy.sourceRect;
		delete copy.asepriteTileId;
		tileset.tiles.push(copy);
	}
}
function editTilemap(doc, c) {
	const layer = layerFor(doc, c.layerId, true);
	if (layer.type !== "tilemap") fail$8("Tile editing requires a tilemap layer");
	const frame = frameFor(doc, c.frameId), ts = doc.tilesets.find((t) => t.id === (layer.tilemaps?.[frame.id]?.tilesetId ?? layer.tilesetId));
	if (!ts) fail$8("Tileset missing");
	const map = layer.tilemaps?.[frame.id] ?? nativeMap(doc, layer, frame, ts);
	if (!map) fail$8("Paint an initial tilemap cell before editing tiles");
	const x = integer$1(c.x, "Tile x", 0, map.columns - 1), y = integer$1(c.y, "Tile y", 0, map.rows - 1), mode = c.mode ?? "auto";
	if (![
		"manual",
		"auto",
		"stack"
	].includes(mode)) fail$8("Tile edit mode must be manual, auto, or stack");
	if (!Array.isArray(c.pixels) || c.pixels.length !== ts.tileWidth * ts.tileHeight) fail$8("Tile pixel dimensions mismatch");
	const working = colorContext(doc, frame.id, layer.id), pixels = c.pixels.map((p) => encodeColor(working, p)), previous = map.cells[y * map.columns + x];
	let tile;
	if (mode === "manual") {
		tile = ts.tiles.find((t) => t.id === previous?.tileId);
		if (!tile) fail$8("Manual editing requires a nonempty tile");
		const source = doc.images[tile.imageId];
		if (tile.sourceRect) {
			const r = tile.sourceRect, updated = [...source.pixels];
			for (let y = 0; y < r.height; y++) for (let x = 0; x < r.width; x++) updated[(r.y + y) * source.width + r.x + x] = pixels[Math.min(ts.tileHeight - 1, Math.floor(y * ts.tileHeight / r.height)) * ts.tileWidth + Math.min(ts.tileWidth - 1, Math.floor(x * ts.tileWidth / r.width))];
			doc.images[tile.imageId] = {
				...source,
				pixels: updated
			};
		} else {
			reserve(doc, pixels.length, tile.imageId);
			doc.images[tile.imageId] = {
				...source,
				width: ts.tileWidth,
				height: ts.tileHeight,
				pixels
			};
		}
		return;
	}
	if (!(mode === "auto" && pixels.every((pixel) => pixelRGBA(working, pixel)[3] === 0))) {
		if (mode === "auto") tile = ts.tiles.find((t) => getTile(doc, ts.id, t.id).pixels.every((p, i) => p === pixels[i]));
		if (!tile) {
			if (mode === "auto" && previous?.tileId) {
				const cleared = [...map.cells];
				cleared[y * map.columns + x] = null;
				layer.tilemaps = {
					...layer.tilemaps ?? {},
					[frame.id]: {
						...map,
						cells: cleared
					}
				};
				removeUnusedTile(doc, ts, previous.tileId);
			}
			if (ts.tiles.length >= 65536) fail$8("Tileset limit reached");
			reserve(doc, pixels.length);
			const imageId = fresh(doc, "image");
			doc.images[imageId] = {
				width: ts.tileWidth,
				height: ts.tileHeight,
				pixels
			};
			let n = 1;
			while (ts.tiles.some((t) => t.id === `tile-${n}`)) n++;
			tile = {
				id: `tile-${n}`,
				imageId
			};
			ts.tiles.push(tile);
		}
	}
	const cells = [...map.cells];
	cells[y * map.columns + x] = tile ? {
		tileId: tile.id,
		flipX: previous?.flipX ?? false,
		flipY: previous?.flipY ?? false,
		rotate: previous?.rotate ?? 0
	} : null;
	layer.tilemaps = {
		...layer.tilemaps ?? {},
		[frame.id]: {
			...map,
			cells
		}
	};
	if (mode === "auto" && previous?.tileId !== tile?.id) removeUnusedTile(doc, ts, previous?.tileId);
}
function duplicateLayer(doc, c) {
	const source = layerFor(doc, c.layerId), ids = new Set([source.id]);
	let again = true;
	while (again) {
		again = false;
		for (const l of doc.layers) if (ids.has(l.parentId) && !ids.has(l.id)) {
			ids.add(l.id);
			again = true;
		}
	}
	const originals = doc.layers.filter((l) => ids.has(l.id));
	if (doc.layers.length + originals.length > LIMITS.layers) fail$8("Layer limit reached");
	const copies = [], idMap = /* @__PURE__ */ new Map(), imageMap = /* @__PURE__ */ new Map();
	for (const l of originals) {
		const copy = {
			...jsonCopy(l),
			id: fresh(doc, "layer"),
			name: l.id === source.id ? name(c.name, `${l.name} copy`) : l.name
		};
		idMap.set(l.id, copy.id);
		doc.layers.push(copy);
		copies.push(copy);
	}
	for (const copy of copies) if (idMap.has(copy.parentId)) copy.parentId = idMap.get(copy.parentId);
	doc.layers = doc.layers.filter((l) => !copies.includes(l));
	const at = doc.layers.indexOf(originals.at(-1)) + 1;
	doc.layers.splice(at, 0, ...copies);
	for (const frame of doc.frames) for (const original of originals) {
		const cel = frame.cels[original.id];
		if (!cel) continue;
		let imageId = cel.imageId;
		if (!c.linked) if (imageMap.has(imageId)) imageId = imageMap.get(imageId);
		else {
			const image = doc.images[imageId], key = fresh(doc, "image");
			reserve(doc, image.width * image.height);
			doc.images[key] = {
				...image,
				pixels: [...image.pixels],
				...image.tilemap ? { tilemap: jsonCopy(image.tilemap) } : {}
			};
			imageMap.set(imageId, key);
			imageId = key;
		}
		frame.cels[idMap.get(original.id)] = {
			...cel,
			imageId
		};
	}
}
function descendantIds(doc, rootIds) {
	const ids = new Set(rootIds);
	let added = true;
	while (added) {
		added = false;
		for (const layer of doc.layers) if (ids.has(layer.parentId) && !ids.has(layer.id)) {
			ids.add(layer.id);
			added = true;
		}
	}
	return ids;
}
function rasterLayer(source, patch = {}) {
	const layer = {
		...source,
		...patch,
		type: "image"
	};
	delete layer.tilemaps;
	delete layer.tilesetId;
	delete layer.asepriteTilesetIndex;
	delete layer.reference;
	if (layer.asepriteFlags !== void 0) layer.asepriteFlags &= -65;
	return layer;
}
/** Bake selected whole layer subtrees, preserving off-canvas artwork and frame links.
* Root blend/opacity can stay on the replacement, or be baked against transparency.
* Non-normal blends that depend on unselected backdrop layers cannot be reproduced
* by an isolated normal layer; Merge Down matches that native editor convention. */
function bakeLayerTrees(doc, rootIds, replacement, { forceRootsVisible = false, preserveRootStyle = false } = {}) {
	const included = descendantIds(doc, rootIds), rootSet = new Set(rootIds), source = shallowDocument(doc);
	for (const layerId of included) layerFor(doc, layerId, true);
	const sourceLayers = source.layers.filter((layer) => included.has(layer.id));
	const renderLayers = sourceLayers.map((layer) => rootSet.has(layer.id) ? {
		...layer,
		parentId: null,
		visible: forceRootsVisible || layer.visible,
		...preserveRootStyle ? {
			opacity: 1,
			blendMode: "normal"
		} : {}
	} : layer);
	const byId = new Map(renderLayers.map((layer) => [layer.id, layer]));
	function visible(layer) {
		for (let item = layer; item; item = item.parentId ? byId.get(item.parentId) : null) if (!item.visible || item.opacity === 0) return false;
		return true;
	}
	const visibleLayers = renderLayers.filter(visible), cache = /* @__PURE__ */ new Map(), linkCache = /* @__PURE__ */ new Map();
	let work = 0;
	const insertion = source.layers.findIndex((layer) => layer.id === replacement.id);
	if (insertion < 0) fail$8("Flatten replacement layer is missing");
	doc.layers = source.layers.filter((layer) => !included.has(layer.id));
	doc.layers.splice(source.layers.slice(0, insertion).filter((layer) => !included.has(layer.id)).length, 0, replacement);
	for (const frame of doc.frames) for (const layerId of included) delete frame.cels[layerId];
	gcImages(doc);
	for (const frame of doc.frames) {
		const originalFrame = frameFor(source, frame.id), palette = getFramePalette(source, frame.id);
		const sourceLinks = sourceLayers.map((layer) => [
			layer.id,
			originalFrame.cels[layer.id] ?? null,
			layer.tilemaps?.[frame.id] ?? null
		]), linkSignature = JSON.stringify(sourceLinks);
		const signature = JSON.stringify([source.colorMode === "indexed" ? palette : null, sourceLinks]);
		if (cache.has(signature)) {
			const cel = cache.get(signature);
			if (cel) frame.cels[replacement.id] = { ...cel };
			continue;
		}
		let left = Infinity, top = Infinity, right = -Infinity, bottom = -Infinity;
		function addBounds(x, y, width, height) {
			if (width <= 0 || height <= 0) return;
			left = Math.min(left, Math.floor(x));
			top = Math.min(top, Math.floor(y));
			right = Math.max(right, Math.ceil(x + width));
			bottom = Math.max(bottom, Math.ceil(y + height));
		}
		for (const layer of visibleLayers) {
			if (layer.type === "group") continue;
			const cel = originalFrame.cels[layer.id], image = source.images[cel?.imageId];
			if (layer.type === "tilemap") {
				const map = layer.tilemaps?.[frame.id], tileset = source.tilesets.find((ts) => ts.id === (map?.tilesetId ?? layer.tilesetId));
				if (!tileset) fail$8("Cannot flatten a tilemap with a missing tileset");
				if (!tileset.tiles?.length && !tileset.imageId && tileset.externalFileId != null) fail$8("Embed external tileset pixels before flattening");
				if (map) addBounds(map.x ?? 0, map.y ?? 0, map.columns * tileset.tileWidth, map.rows * tileset.tileHeight);
				else if (image) addBounds(cel.x, cel.y, image.width * tileset.tileWidth, image.height * tileset.tileHeight);
			} else if (image) {
				const bounds = cel.preciseBounds;
				if (bounds?.flags & 1) addBounds(bounds.x, bounds.y, bounds.width, bounds.height);
				else addBounds(cel.x, cel.y, image.width, image.height);
			}
		}
		if (left === Infinity) {
			cache.set(signature, null);
			continue;
		}
		const width = right - left, height = bottom - top;
		integer$1(width, "Flattened image width", 1, LIMITS.imageEdge);
		integer$1(height, "Flattened image height", 1, LIMITS.imageEdge);
		if (width * height > LIMITS.pixels) fail$8("Flattened layer exceeds the pixel budget", "MEMORY_BUDGET");
		work += width * height * Math.max(1, visibleLayers.filter((layer) => layer.type !== "group").length);
		if (work > LIMITS.operations) fail$8("Flatten operation exceeds the work budget", "MEMORY_BUDGET");
		const cels = {};
		for (const layer of sourceLayers) {
			const cel = originalFrame.cels[layer.id];
			if (cel) cels[layer.id] = {
				...cel,
				x: cel.x - left,
				y: cel.y - top,
				...cel.preciseBounds ? { preciseBounds: {
					...cel.preciseBounds,
					x: cel.preciseBounds.x - left,
					y: cel.preciseBounds.y - top
				} } : {}
			};
		}
		const shiftedLayers = renderLayers.map((layer) => {
			const map = layer.tilemaps?.[frame.id];
			return map ? {
				...layer,
				tilemaps: { [frame.id]: {
					...map,
					x: (map.x ?? 0) - left,
					y: (map.y ?? 0) - top
				} }
			} : layer;
		});
		const rgbaPixels = renderFrame({
			...source,
			width,
			height,
			palette,
			layers: shiftedLayers,
			frames: [{
				...originalFrame,
				palette,
				cels
			}]
		}, frame.id);
		let minX = width, minY = height, maxX = -1, maxY = -1;
		for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) if (rgbaPixels[(y * width + x) * 4 + 3]) {
			minX = Math.min(minX, x);
			minY = Math.min(minY, y);
			maxX = Math.max(maxX, x);
			maxY = Math.max(maxY, y);
		}
		if (maxX < 0) {
			cache.set(signature, null);
			continue;
		}
		const outputWidth = maxX - minX + 1, outputHeight = maxY - minY + 1, pixels = Array(outputWidth * outputHeight), working = colorContext({
			...source,
			layers: source.layers.map((layer) => layer.id === replacement.id ? replacement : layer)
		}, frame.id, replacement.id);
		for (let y = 0; y < outputHeight; y++) for (let x = 0; x < outputWidth; x++) {
			const offset = ((y + minY) * width + x + minX) * 4;
			pixels[y * outputWidth + x] = rgbaPixels[offset + 3] ? encodeColor(working, hex$1([...rgbaPixels.subarray(offset, offset + 4)])) : null;
		}
		const x = integer$1(left + minX, "Flattened cel x", -65535, 65535), y = integer$1(top + minY, "Flattened cel y", -65535, 65535);
		const linked = linkCache.get(linkSignature) ?? [];
		let imageId = linked.find((candidate) => candidate.x === x && candidate.y === y && candidate.width === outputWidth && candidate.height === outputHeight && candidate.pixels.every((pixel, index) => pixel === pixels[index]))?.imageId;
		if (!imageId) {
			reserve(doc, pixels.length);
			imageId = fresh(doc, "image");
			doc.images[imageId] = {
				width: outputWidth,
				height: outputHeight,
				pixels
			};
			linked.push({
				imageId,
				x,
				y,
				width: outputWidth,
				height: outputHeight,
				pixels
			});
			linkCache.set(linkSignature, linked);
		}
		const previous = originalFrame.cels[replacement.id], cel = {
			...previous?.userData ? { userData: jsonCopy(previous.userData) } : {},
			imageId,
			x,
			y,
			opacity: 1
		};
		frame.cels[replacement.id] = cel;
		cache.set(signature, cel);
	}
}
function mergeDown(doc, c) {
	if (c.visibleOnly !== void 0 && typeof c.visibleOnly !== "boolean") fail$8("visibleOnly must be a boolean");
	const upper = layerFor(doc, c.layerId, true), at = doc.layers.indexOf(upper), lower = [...doc.layers.slice(0, at)].reverse().find((layer) => layer.parentId === upper.parentId);
	if (!lower) fail$8("No lower sibling layer to merge");
	const visibleOnly = c.visibleOnly === true, replacement = rasterLayer(lower, {
		name: name(c.name, lower.name),
		opacity: 1,
		blendMode: "normal",
		visible: visibleOnly ? lower.visible || upper.visible : lower.visible
	});
	bakeLayerTrees(doc, [lower.id, upper.id], replacement, { forceRootsVisible: !visibleOnly });
}
function flattenLayer(doc, c) {
	const layer = layerFor(doc, c.layerId, true), replacement = rasterLayer(layer, { name: name(c.name, layer.name) });
	bakeLayerTrees(doc, [layer.id], replacement, {
		forceRootsVisible: true,
		preserveRootStyle: true
	});
}
function flattenDocument(doc, c) {
	if (c.visibleOnly !== void 0 && typeof c.visibleOnly !== "boolean") fail$8("visibleOnly must be a boolean");
	const visibleOnly = c.visibleOnly !== false, roots = doc.layers.filter((layer) => layer.parentId === null && (!visibleOnly || layer.visible));
	if (!roots.length) return;
	const first = roots[0], replacement = rasterLayer(first, {
		name: name(c.name, "Flattened"),
		visible: true,
		opacity: 1,
		blendMode: "normal"
	});
	if (replacement.asepriteFlags !== void 0) replacement.asepriteFlags &= -9;
	bakeLayerTrees(doc, roots.map((layer) => layer.id), replacement);
}
/** A failed command never changes its input. Untouched image objects retain identity. */
function applyCommand(input, command) {
	if (!record$2(command) || typeof command.type !== "string") fail$8("Command type is missing", "INVALID_COMMAND");
	if (input?.format !== "pixelwall-document" || input.version !== 4) fail$8("Normalize the document before editing");
	const doc = shallowDocument(input), c = command, changed = /* @__PURE__ */ new Set();
	switch (c.type) {
		case "batch": {
			if (!Array.isArray(c.commands) || c.commands.length > 1024) fail$8("Invalid command batch");
			let result = input;
			for (const command of c.commands) result = applyCommand(result, command);
			return result;
		}
		case "object.userData": {
			let target;
			if (c.target === "sprite") target = doc;
			else if (c.target === "layer") target = layerFor(doc, c.layerId, true);
			else if (c.target === "cel") {
				const layer = layerFor(doc, c.layerId, true);
				target = frameFor(doc, c.frameId).cels[layer.id];
			} else if (c.target === "tileset" || c.target === "tile") {
				const ts = doc.tilesets.find((t) => t.id === c.tilesetId);
				if (!ts) fail$8("Tileset missing");
				assertTilesetEditable(doc, ts.id);
				if (c.target === "tileset") target = ts;
				else {
					const slots = tilesetSlots(doc, ts), index = integer$1(c.tileIndex, "Tile index", 0, slots.count - 1);
					ts.tileUserData = [...ts.tileUserData ?? []];
					const userData = validateAsepriteUserData(c.userData);
					ts.tileUserData[index] = userData;
					target = slots.entries.get(index);
					if (target) target.userData = userData;
					break;
				}
			} else if (c.target === "tag") target = doc.clips.find((v) => v.id === c.clipId);
			else if (c.target === "slice") target = doc.slices.find((v) => v.id === c.sliceId);
			else fail$8("Unsupported user-data target");
			if (!target) fail$8("User-data target missing");
			target.userData = validateAsepriteUserData(c.userData);
			break;
		}
		case "document.update":
			if (!record$2(c.patch)) fail$8("Document patch missing");
			for (const key of Object.keys(c.patch)) if (!["name", "metadata"].includes(key)) fail$8(`Document field ${key} cannot be patched`);
			if (c.patch.name !== void 0) doc.name = name(c.patch.name, "Untitled Sprite");
			if (c.patch.metadata !== void 0) doc.metadata = jsonCopy(c.patch.metadata);
			break;
		case "document.colorProfile":
			applyColorProfileCommand(doc, c);
			break;
		case "document.resize":
			resizeDocument(doc, c);
			break;
		case "document.colorMode": {
			const configured = [
				"paletteMode",
				"maxColors",
				"quantization",
				"withAlpha",
				"dithering",
				"ditherMatrix",
				"ditherStrength",
				"rgbmap",
				"fitCriteria"
			].some((key) => own$3(c, key));
			if (configured && c.colorMode !== "indexed") fail$8("Palette generation and dithering require indexed color mode");
			convertColorMode(doc, c.colorMode, configured ? { indexedOptions: indexedConversionOptions(c) } : {});
			break;
		}
		case "layer.add": {
			const v = c.layer ?? {};
			const layer = {
				id: v.id ?? fresh(doc, "layer"),
				name: v.name ?? `Layer ${doc.layers.length + 1}`,
				type: v.type ?? "image",
				parentId: v.parentId ?? null,
				visible: v.visible !== false,
				locked: !!v.locked,
				opacity: v.opacity ?? 1,
				blendMode: v.blendMode ?? "normal",
				...jsonCopy(v)
			};
			if (layer.parentId) layerFor(doc, layer.parentId, true);
			if (doc.layers.some((l) => l.id === layer.id)) fail$8("Layer id exists");
			const index = integer$1(c.index ?? doc.layers.length, "Layer index", 0, doc.layers.length);
			doc.layers.splice(index, 0, layer);
			break;
		}
		case "layer.update": {
			const layer = layerFor(doc, c.layerId);
			if (!record$2(c.patch)) fail$8("Layer patch missing");
			for (const key of Object.keys(c.patch)) if (![
				"name",
				"parentId",
				"visible",
				"locked",
				"opacity",
				"blendMode",
				"reference",
				"tilesetId"
			].includes(key)) fail$8(`Layer field ${key} cannot be patched`);
			Object.assign(layer, jsonCopy(c.patch));
			break;
		}
		case "layer.reorder": {
			const layer = layerFor(doc, c.layerId, true), index = integer$1(c.index, "Layer index", 0, doc.layers.length - 1);
			doc.layers.splice(doc.layers.indexOf(layer), 1);
			doc.layers.splice(index, 0, layer);
			break;
		}
		case "layer.duplicate":
			duplicateLayer(doc, c);
			break;
		case "layer.mergeDown":
			mergeDown(doc, c);
			break;
		case "layer.flatten":
			flattenLayer(doc, c);
			break;
		case "document.flatten":
			flattenDocument(doc, c);
			break;
		case "layer.remove": {
			const layer = layerFor(doc, c.layerId, true), remove = new Set([layer.id]);
			let again = true;
			while (again) {
				again = false;
				for (const l of doc.layers) if (remove.has(l.parentId) && !remove.has(l.id)) {
					remove.add(l.id);
					again = true;
				}
			}
			if (remove.size === doc.layers.length) fail$8("Document must retain a layer");
			doc.layers = doc.layers.filter((l) => !remove.has(l.id));
			for (const f of doc.frames) for (const key of remove) delete f.cels[key];
			break;
		}
		case "frame.add": {
			if (doc.frames.length >= LIMITS.frames) fail$8("Frame limit reached");
			const after = c.afterFrameId ? doc.frames.indexOf(frameFor(doc, c.afterFrameId)) : doc.frames.length - 1, newId = c.id ?? fresh(doc, "frame");
			if (doc.frames.some((f) => f.id === newId)) fail$8("Frame id exists");
			doc.frames.splice(after + 1, 0, {
				id: newId,
				durationMs: integer$1(c.durationMs ?? 125, "Duration", 1, 65535),
				cels: {}
			});
			if (c.clipId) {
				const clip = doc.clips.find((clip) => clip.id === c.clipId);
				if (!clip) fail$8("Clip missing");
				const pos = clip.frameIds.indexOf(c.afterFrameId);
				clip.frameIds.splice(pos < 0 ? clip.frameIds.length : pos + 1, 0, newId);
			}
			break;
		}
		case "frame.duplicate": {
			const frames = targetFrames(doc, c);
			if (doc.frames.length + frames.length > LIMITS.frames) fail$8("Frame limit reached");
			let at = c.afterFrameId ? doc.frames.indexOf(frameFor(doc, c.afterFrameId)) : doc.frames.indexOf(frames.at(-1));
			for (const f of frames) {
				const fid = fresh(doc, "frame"), cels = {};
				for (const [lid, cel] of Object.entries(f.cels)) if (c.linked) cels[lid] = { ...cel };
				else {
					const source = doc.images[cel.imageId];
					reserve(doc, source.width * source.height);
					const imageId = fresh(doc, "image");
					doc.images[imageId] = {
						...source,
						pixels: [...source.pixels],
						...source.tilemap ? { tilemap: jsonCopy(source.tilemap) } : {}
					};
					cels[lid] = {
						...cel,
						imageId
					};
				}
				doc.frames.splice(++at, 0, {
					...f,
					id: fid,
					cels
				});
				for (const layer of doc.layers) if (layer.tilemaps?.[f.id]) layer.tilemaps = {
					...layer.tilemaps,
					[fid]: jsonCopy(layer.tilemaps[f.id])
				};
				if (c.clipId) {
					const clip = doc.clips.find((v) => v.id === c.clipId);
					if (!clip) fail$8("Clip missing");
					clip.frameIds.push(fid);
				}
			}
			break;
		}
		case "frame.update":
			if (!record$2(c.patch) || Object.keys(c.patch).some((k) => ![
				"durationMs",
				"name",
				"pivot"
			].includes(k))) fail$8("Invalid frame patch");
			for (const f of targetFrames(doc, c)) Object.assign(f, jsonCopy(c.patch));
			break;
		case "frame.reorder": {
			const frames = targetFrames(doc, c), selected = new Set(frames.map((f) => f.id)), others = doc.frames.filter((f) => !selected.has(f.id)), index = integer$1(c.index, "Frame insertion index", 0, others.length);
			others.splice(index, 0, ...frames);
			doc.frames = others;
			break;
		}
		case "frame.reverse": {
			const frames = targetFrames(doc, c), ids = new Set(frames.map((f) => f.id)), reverse = [...frames].reverse();
			let i = 0;
			doc.frames = doc.frames.map((f) => ids.has(f.id) ? reverse[i++] : f);
			break;
		}
		case "frame.remove": {
			const ids = new Set(targetFrames(doc, c).map((f) => f.id));
			if (ids.size === doc.frames.length) fail$8("Document must retain a frame");
			doc.frames = doc.frames.filter((f) => !ids.has(f.id));
			doc.slices = doc.slices.map((s) => s.keys ? {
				...s,
				keys: s.keys.filter((k) => !ids.has(k.frameId))
			} : s);
			doc.clips = doc.clips.map((clip) => ({
				...clip,
				frameIds: clip.frameIds.filter((fid) => !ids.has(fid))
			})).filter((clip) => clip.frameIds.length);
			for (const layer of doc.layers) if (layer.tilemaps) {
				layer.tilemaps = { ...layer.tilemaps };
				for (const fid of ids) delete layer.tilemaps[fid];
			}
			break;
		}
		case "cel.set":
			setCel(doc, c);
			break;
		case "image.stamp":
			stampImage(doc, c, changed);
			break;
		case "cel.link": {
			const layer = layerFor(doc, c.layerId, true), source = frameFor(doc, c.sourceFrameId).cels[layer.id];
			if (!source) fail$8("Source cel is empty");
			for (const f of targetFrames(doc, c)) f.cels[layer.id] = { ...source };
			break;
		}
		case "cel.unlink": {
			const layer = layerFor(doc, c.layerId, true);
			for (const f of targetFrames(doc, c)) {
				const cel = f.cels[layer.id];
				if (!cel) continue;
				const source = doc.images[cel.imageId];
				reserve(doc, source.width * source.height);
				const key = fresh(doc, "image");
				doc.images[key] = {
					...source,
					pixels: [...source.pixels],
					...source.tilemap ? { tilemap: jsonCopy(source.tilemap) } : {}
				};
				cel.imageId = key;
			}
			break;
		}
		case "cel.move": {
			const layer = layerFor(doc, c.layerId, true);
			for (const f of targetFrames(doc, c)) {
				const cel = f.cels[layer.id];
				if (!cel) continue;
				cel.x = integer$1(c.x ?? cel.x, "Cel x", -65535, 65535);
				cel.y = integer$1(c.y ?? cel.y, "Cel y", -65535, 65535);
				if (c.opacity !== void 0) cel.opacity = finite(c.opacity, "Cel opacity", 0, 1);
				if (c.zIndex !== void 0) cel.zIndex = integer$1(c.zIndex, "Cel z-index", -2147483648, 2147483647);
			}
			break;
		}
		case "cel.clear": {
			const layer = layerFor(doc, c.layerId, true);
			for (const f of targetFrames(doc, c)) delete f.cels[layer.id];
			break;
		}
		case "draw.stroke":
			drawStroke(context(doc, c, changed), points(c.points), c);
			break;
		case "draw.line":
			drawStroke(context(doc, c, changed), [point(c.from), point(c.to)], c);
			break;
		case "draw.rect":
			drawShape(context(doc, c, changed), c, false);
			break;
		case "draw.ellipse":
			drawShape(context(doc, c, changed), c, true);
			break;
		case "draw.polygon":
			drawPolygon(context(doc, c, changed), c);
			break;
		case "draw.curve":
			drawCurve(context(doc, c, changed), c);
			break;
		case "draw.fill": {
			const ctx = context(doc, c, changed), mask = floodMask(ctx.doc, ctx.get, c), color = encodeColor(ctx.doc, c.color === void 0 ? ctx.doc.palette[0] : c.color);
			for (let i = 0; i < mask.length; i++) if (mask[i]) ctx.put(i % doc.width, Math.floor(i / doc.width), color);
			break;
		}
		case "draw.gradient":
			gradient(context(doc, c, changed), c);
			break;
		case "draw.text":
			drawText(context(doc, c, changed), c);
			break;
		case "selection.transform":
			selectionTransform(doc, c, changed);
			break;
		case "selection.clear": {
			const ctx = context(doc, c, changed);
			if (!ctx.mask) fail$8("Clear selection requires a selection mask");
			for (let y = 0; y < doc.height; y++) for (let x = 0; x < doc.width; x++) ctx.put(x, y, null);
			break;
		}
		case "palette.update":
			paletteEdit(doc, c, false);
			break;
		case "palette.remap":
			paletteEdit(doc, c, true);
			break;
		case "effect.apply":
			applyEffect(doc, c, changed);
			break;
		case "animation.tween":
			tween(doc, c);
			break;
		case "animation.particles":
			particles(doc, c, changed);
			break;
		case "tileset.add":
			addTileset(doc, c);
			break;
		case "tileset.create":
			createNativeTileset(doc, c, {
				fresh,
				reserve,
				limits: LIMITS
			});
			break;
		case "tileset.tileInsert":
		case "tileset.tileRemove":
			changeTilesetSlots(doc, c, {
				fresh,
				reserve,
				limits: LIMITS
			});
			break;
		case "layer.tileset":
			assignLayerTileset(doc, c, {
				fresh,
				reserve,
				limits: LIMITS,
				layerFor
			});
			break;
		case "tileset.tileImage":
			replaceTilesetImage(doc, c);
			break;
		case "tileset.update": {
			const ts = doc.tilesets.find((t) => t.id === c.tilesetId);
			if (!ts) fail$8("Tileset missing");
			assertTilesetEditable(doc, ts.id);
			if (c.patch?.baseIndex !== void 0) integer$1(c.patch.baseIndex, "Tileset base index", -32768, 32767);
			if (!record$2(c.patch) || Object.keys(c.patch).some((k) => ![
				"name",
				"tileWidth",
				"tileHeight",
				"tiles",
				"imageId",
				"baseIndex"
			].includes(k))) fail$8("Invalid tileset patch");
			Object.assign(ts, jsonCopy(c.patch));
			break;
		}
		case "tileset.remove":
			if (doc.layers.some((l) => l.tilesetId === c.tilesetId || Object.values(l.tilemaps ?? {}).some((m) => m.tilesetId === c.tilesetId))) fail$8("Cannot remove a tileset used by a layer");
			if (!doc.tilesets.some((t) => t.id === c.tilesetId)) fail$8("Tileset missing");
			doc.tilesets = doc.tilesets.filter((t) => t.id !== c.tilesetId);
			break;
		case "tilemap.paint":
			paintTilemap(doc, c);
			break;
		case "tilemap.edit":
			editTilemap(doc, c);
			break;
		case "clip.add": {
			const v = c.clip ?? {};
			doc.clips.push({
				id: v.id ?? fresh(doc, "clip"),
				name: v.name ?? "Animation",
				frameIds: v.frameIds ?? doc.frames.map((f) => f.id),
				direction: v.direction ?? "forward",
				loop: v.loop !== false
			});
			break;
		}
		case "clip.update": {
			const clip = doc.clips.find((v) => v.id === c.clipId);
			if (!clip) fail$8("Clip missing");
			if (!record$2(c.patch) || Object.keys(c.patch).some((k) => ![
				"name",
				"frameIds",
				"direction",
				"loop",
				"repeat",
				"color"
			].includes(k))) fail$8("Invalid clip patch");
			Object.assign(clip, jsonCopy(c.patch));
			break;
		}
		case "clip.remove":
			if (!doc.clips.some((v) => v.id === c.clipId)) fail$8("Clip missing");
			doc.clips = doc.clips.filter((v) => v.id !== c.clipId);
			break;
		case "slice.add": {
			const v = c.slice ?? {};
			doc.slices.push({
				...jsonCopy(v),
				id: v.id ?? fresh(doc, "slice"),
				name: v.name ?? "Slice"
			});
			break;
		}
		case "slice.update": {
			const s = doc.slices.find((v) => v.id === c.sliceId);
			if (!s) fail$8("Slice missing");
			if (!record$2(c.patch) || Object.keys(c.patch).some((k) => ![
				"name",
				"bounds",
				"pivot",
				"ninePatch",
				"keys"
			].includes(k))) fail$8("Invalid slice patch");
			Object.assign(s, jsonCopy(c.patch));
			if (c.patch.keys !== void 0) delete s.bounds;
			break;
		}
		case "slice.remove":
			if (!doc.slices.some((v) => v.id === c.sliceId)) fail$8("Slice missing");
			doc.slices = doc.slices.filter((v) => v.id !== c.sliceId);
			break;
		default: fail$8(`Unknown command: ${c.type}`, "UNKNOWN_COMMAND");
	}
	gcImages(doc);
	return normalizeDocument(doc, { shareImages: true });
}
const TARGET = {
	frameId: "Optional frame id; defaults to first frame.",
	layerId: "Optional raster layer id; defaults to first image layer."
};
const RANGE = { frameIds: "Nonempty list of unique frame ids; or pass frameId for one frame." };
const DRAW = {
	...TARGET,
	color: "Hex RGB/RGBA string, palette index, or null (transparent).",
	selection: "Optional canvas-size array of 0/1; restricts affected pixels."
};
const STROKE = {
	...DRAW,
	size: "Integer 1–256 (default 1).",
	brush: "square | circle",
	mask: "Optional {width,height,pixels:[0|1],colors?:[RGBA|null]}; maximum 256×256.",
	symmetry: "none | x | y | both",
	wrap: "none | x | y | both; true is both. Wraps brush pixels and line paths for seamless tiles.",
	pressure: "false ignores point pressures; true or omitted uses supplied point pressures.",
	pixelPerfect: "Boolean; removes 1px orthogonal corners along the sampled path.",
	erase: "Boolean; stamps transparency.",
	ink: "paint | lighten | darken | shading",
	amount: "Lighten/darken amount 0–1 (default .12).",
	ramp: "Shading ink: ordered palette-index or color array; defaults to the active frame palette.",
	shadeStep: "Shading ink: signed steps along ramp; default -1. Endpoints clamp; unlisted colors are unchanged."
};
/** Machine-readable public catalog. Every listed command is executable. */
const COMMANDS = Object.freeze([
	[
		"batch",
		"Apply an ordered command list atomically.",
		{ commands: "Array of up to 1024 command objects." }
	],
	[
		"object.userData",
		"Replace native user data on a sprite, layer, cel, tag, slice, tileset or tile.",
		{
			target: "sprite | layer | cel | tag | slice | tileset | tile",
			tilesetId: "Tileset/tile target ID",
			tileIndex: "Zero-based native tile index",
			layerId: "Layer target ID",
			frameId: "Cel frame ID",
			clipId: "Tag target ID",
			sliceId: "Slice target ID",
			userData: "{text?,color?:#rrggbbaa,propertiesBytes?:native property block}"
		}
	],
	[
		"document.update",
		"Rename the document or replace metadata.",
		{ patch: "{name?:string,metadata?:object}" }
	],
	[
		"document.colorProfile",
		"Assign a working profile or apply a bounded precomputed color conversion.",
		{
			profile: "{type:0|1|2,flags?:0|1,gamma?:number,icc?:byte[],name?:string}",
			replacements: "Optional validated images/palette/framePalettes; preserves dimensions, IDs, links, layers and color mode."
		}
	],
	[
		"document.resize",
		"Resize canvas or nearest-neighbor artwork.",
		{
			width: "Integer 1–65535; width × height ≤ 4194304",
			height: "Integer 1–65535; width × height ≤ 4194304",
			mode: "canvas | scale",
			anchor: "top-left | center (canvas mode)"
		}
	],
	[
		"document.colorMode",
		"Convert pixel storage between working color modes.",
		{
			colorMode: "rgba | indexed | grayscale",
			paletteMode: "existing (default) | generate; supplying indexed options enables explicit indexed remapping.",
			maxColors: "Generated palette limit 2–256, including transparent slot; default 256.",
			quantization: "median-cut (default, stored artwork) | octree | rgb5a3 (native algorithms sampling visible composited frames).",
			rgbmap: "pixelwall (legacy default) | octree | rgb5a3; native quantization/dithering defaults to octree.",
			fitCriteria: "default | rgb | linearizedRGB | ciexyz | cielab; non-default fitting requires a native RGB map.",
			withAlpha: "Generated palette retains partial alpha unless false; transparent pixels remain transparent.",
			dithering: "none | ordered | floyd-steinberg | aseprite-ordered | aseprite-old | aseprite-error-diffusion; legacy/native modes require matching RGB map.",
			ditherMatrix: "bayer2x2 | bayer4x4 (default) | bayer8x8",
			ditherStrength: "0–1, default 1; native ordered/old require 1; native diffusion uses integer percentage strength."
		}
	],
	[
		"layer.add",
		"Insert image, group, reference, or tilemap layer.",
		{
			layer: "{id?,name?,type?,parentId?,visible?,locked?,opacity?,blendMode?}",
			index: "Optional bottom-to-top insertion index."
		}
	],
	[
		"layer.update",
		"Update layer properties.",
		{
			layerId: "Layer id",
			patch: "{name?,parentId?,visible?,locked?,opacity?,blendMode?,reference?,tilesetId?}"
		}
	],
	[
		"layer.reorder",
		"Move a layer within bottom-to-top order.",
		{
			layerId: "Layer id",
			index: "Zero-based destination index."
		}
	],
	[
		"layer.duplicate",
		"Duplicate a layer or group hierarchy with independent image copies.",
		{
			layerId: "Layer id",
			name: "Optional duplicate name",
			linked: "True shares original image objects; false preserves linking only within the copied hierarchy."
		}
	],
	[
		"layer.mergeDown",
		"Bake two adjacent sibling subtrees into the lower raster layer across all frames.",
		{
			layerId: "Upper image/group/reference/tilemap layer id.",
			visibleOnly: "Default false includes both root layers regardless of visibility and retains lower visibility, matching native Merge Down. True uses current root visibility.",
			name: "Optional result name. Root blend modes/opacity bake against transparency, so blends depending on an outside backdrop may change appearance; use document.flatten for the whole visible composite."
		}
	],
	[
		"layer.flatten",
		"Rasterize one layer or group across all frames, retaining root visibility, opacity and blend mode.",
		{
			layerId: "Image/group/reference/tilemap root. Visible descendants are baked; hidden descendants are removed with the flattened subtree.",
			name: "Optional result name. Off-canvas pixels and equal-source frame links are retained within document budgets."
		}
	],
	[
		"document.flatten",
		"Bake the visible document composite into one normal raster layer across all frames.",
		{
			visibleOnly: "Default true retains hidden root layers separately. False removes hidden root layers as well, without adding their hidden pixels to the result.",
			name: "Optional result name; default Flattened."
		}
	],
	[
		"layer.remove",
		"Remove a layer and all descendants.",
		{ layerId: "Layer id; at least one layer must remain." }
	],
	[
		"frame.add",
		"Insert an empty animation frame.",
		{
			id: "Optional new id",
			afterFrameId: "Optional preceding frame id",
			durationMs: "1–65535; default125",
			clipId: "Optional clip receiving the frame."
		}
	],
	[
		"frame.duplicate",
		"Duplicate a frame range with independent or shared images.",
		{
			...RANGE,
			frameId: "Single frame id",
			afterFrameId: "Optional insertion anchor",
			linked: "Boolean; default false",
			clipId: "Optional clip to append duplicates to."
		}
	],
	[
		"frame.update",
		"Change duration or metadata for a frame range.",
		{
			...RANGE,
			frameId: "Single frame id",
			patch: "{durationMs?:1–65535,name?:string,pivot?:object}"
		}
	],
	[
		"frame.reorder",
		"Move a frame range to an insertion index.",
		{
			...RANGE,
			index: "Index among unselected frames."
		}
	],
	[
		"frame.reverse",
		"Reverse the selected animation frames.",
		RANGE
	],
	[
		"frame.remove",
		"Remove frames and repair clips/tilemaps.",
		RANGE
	],
	[
		"cel.set",
		"Import or replace a cel with decoded pixels.",
		{
			...TARGET,
			width: "Image width",
			height: "Image height",
			pixels: "Flat RGBA|null|palette-index array, width×height",
			x: "Optional integer offset",
			y: "Optional integer offset",
			opacity: "0–1",
			editLinked: "False by default; true replaces the shared image."
		}
	],
	[
		"image.stamp",
		"Paste image pixels into an existing cel.",
		{
			...DRAW,
			width: "Stamp width",
			height: "Stamp height",
			pixels: "Flat decoded RGBA|null|palette-index array.",
			x: "Destination left; default0",
			y: "Destination top; default0",
			transparent: "skip (default) | replace",
			blend: "true (default) composites source-over; false replaces pixels.",
			opacity: "0–1; default1"
		}
	],
	[
		"cel.link",
		"Reference one cel image from multiple frames.",
		{
			...RANGE,
			layerId: "Layer id",
			sourceFrameId: "Frame containing the source cel."
		}
	],
	[
		"cel.unlink",
		"Give selected cels independent images.",
		{
			...RANGE,
			layerId: "Layer id"
		}
	],
	[
		"cel.move",
		"Change cel offsets, opacity or drawing order across frames.",
		{
			...RANGE,
			layerId: "Layer id",
			x: "Integer -65535…65535",
			y: "Integer -65535…65535",
			opacity: "Optional 0–1",
			zIndex: "Optional signed 32-bit integer; portable sprite files require -32768…32767"
		}
	],
	[
		"cel.clear",
		"Remove cels from selected frames.",
		{
			...RANGE,
			layerId: "Layer id"
		}
	],
	[
		"draw.stroke",
		"Paint a pressure-aware freehand path with custom brush and symmetry.",
		{
			...STROKE,
			points: "Array of {x,y,pressure?:0–1}."
		}
	],
	[
		"draw.line",
		"Draw a straight pixel line.",
		{
			...STROKE,
			from: "{x,y}",
			to: "{x,y}"
		}
	],
	[
		"draw.rect",
		"Draw a rectangle.",
		{
			...DRAW,
			x: "Integer left",
			y: "Integer top",
			width: "Positive width",
			height: "Positive height",
			filled: "Boolean",
			size: "Outline thickness1–256"
		}
	],
	[
		"draw.ellipse",
		"Draw an ellipse.",
		{
			...DRAW,
			x: "Integer left",
			y: "Integer top",
			width: "Positive width",
			height: "Positive height",
			filled: "Boolean",
			size: "Outline thickness1–256"
		}
	],
	[
		"draw.polygon",
		"Draw a closed polygon or its filled interior.",
		{
			...STROKE,
			points: "2–4096 vertices {x,y}; at least3 for fill.",
			filled: "Boolean"
		}
	],
	[
		"draw.curve",
		"Rasterize quadratic or cubic Bézier curve.",
		{
			...STROKE,
			points: "[start,control,end] or [start,control1,control2,end]."
		}
	],
	[
		"draw.fill",
		"Flood fill matching connected pixels or all matching colors.",
		{
			...DRAW,
			x: "Seed x",
			y: "Seed y",
			tolerance: "Channel tolerance0–255",
			contiguous: "Boolean; default true"
		}
	],
	[
		"draw.gradient",
		"Paint an RGBA gradient or ordered two-color Bayer dither.",
		{
			...DRAW,
			from: "{x,y}",
			to: "{x,y}",
			endColor: "Ending color",
			dither: "Boolean; default false"
		}
	],
	[
		"draw.text",
		"Rasterize text with included 5×7 bitmap font or custom glyphs.",
		{
			...DRAW,
			x: "Text x",
			y: "Text y",
			text: "Up to4096 characters",
			scale: "Integer1–64",
			spacing: "Glyph spacing0–64",
			lineHeight: "Line advance1–128",
			font: "Optional {width,height,glyphs:{character:[0|1]}}."
		}
	],
	[
		"selection.transform",
		"Move, scale, rotate, flip, or copy a masked raster region.",
		{
			...TARGET,
			selection: "Canvas-size array of0/1; required.",
			operation: "move | scale | rotate | flipX | flipY",
			dx: "Translation pixels",
			dy: "Translation pixels",
			scaleX: "Scale .01–64",
			scaleY: "Scale .01–64",
			angle: "Clockwise degrees",
			method: "nearest (default; Fast rotation alias) | fast | rotsprite | pixel-safe (RotSprite alias). Fast/RotSprite are rotation-only; RotSprite uses the MIT native8× algorithm. Temporary owned buffers limited to64MiB. Corner coordinates are rounded to the pixel grid.",
			pivot: "Optional {x,y}; defaults to selection center.",
			copy: "False moves/cuts, true copies."
		}
	],
	[
		"selection.clear",
		"Erase pixels under a mask.",
		{
			...TARGET,
			selection: "Canvas-size array of0/1; required."
		}
	],
	[
		"palette.update",
		"Edit scoped palette entries; indexed pixels retain their indices.",
		{
			palette: "1–65536 RGBA hex colors. Cannot remove used indexed entries.",
			scope: "all (default with no selectors) | frame | range",
			frameId: "Frame for frame scope; defaults to the first frame. A frameId without scope infers frame.",
			frameIds: "Nonempty unique frame IDs for range scope. frameIds without scope infers range."
		}
	],
	[
		"palette.remap",
		"Replace scoped palettes and remap pixels in their effective color context.",
		{
			palette: "New RGBA palette.",
			mapping: "Optional old-index→new-index array; null clears that entry. Must cover every selected old palette. Omit to find nearest colors.",
			scope: "all (default with no selectors) | frame | range",
			frameId: "Frame for frame scope; defaults first. Inferred when provided without scope.",
			frameIds: "Nonempty unique frame IDs for range scope; inferred when provided without scope."
		}
	],
	[
		"effect.apply",
		"Apply destructive raster effect to selected unique images.",
		{
			...DRAW,
			...RANGE,
			effect: "replace | outline | brightness | contrast | hue | saturation | convolution | despeckle",
			fromColor: "Replace source color; omit to replace all opaque pixels.",
			toColor: "Replacement color.",
			amount: "Brightness/saturation -1…1; contrast -.99….99; hue degrees-360…360.",
			radius: "Outline radius1–64",
			diagonal: "Boolean, default true.",
			kernel: "Odd square numeric array, up to15×15.",
			divisor: "Optional nonzero convolution divisor.",
			bias: "Optional convolution RGB bias-255…255.",
			affectAlpha: "Convolve alpha as well."
		}
	],
	[
		"animation.tween",
		"Bake or link reusable deterministic 2D position/opacity tween.",
		{
			...RANGE,
			layerId: "Raster layer id",
			sourceFrameId: "Optional source cel frame.",
			from: "{x?,y?,opacity?}",
			to: "{x?,y?,opacity?}",
			easing: "linear | easeIn | easeOut | easeInOut | bounce",
			bake: "Default true creates independent images; false links images.",
			id: "Optional reusable preset key in metadata.motion."
		}
	],
	[
		"animation.particles",
		"Bake deterministic 2D particle simulation into cels.",
		{
			...RANGE,
			layerId: "Image layer id",
			seed: "Unsigned32-bit integer",
			count: "1–4096",
			x: "Emitter x",
			y: "Emitter y",
			speed: "Pixels/second0–4096",
			angle: "Emission direction degrees (default -90)",
			spread: "Cone width0–360 degrees",
			gravity: "Pixels/second²",
			lifetime: "Seconds.01–3600",
			emission: "Emission interval in seconds",
			color: "RGBA or palette index",
			size: "1–64",
			fade: "Boolean; default true",
			clear: "Replace target cels unless false.",
			id: "Optional reusable preset key in metadata.motion."
		}
	],
	[
		"tileset.add",
		"Create an independent tileset from images or tile pixels.",
		{
			frameId: "Optional frame palette used to encode tile colors.",
			layerId: "Optional layer for transparent-index semantics.",
			tileset: "{id?,name?,tileWidth,tileHeight,tiles:[{id?,imageId}|{id?,pixels}]}"
		}
	],
	[
		"tileset.create",
		"Create an embedded native tileset, optionally copying a same-document resource.",
		{
			tilesetId: "Optional ID",
			tileWidth: "Positive tile width",
			tileHeight: "Positive tile height",
			tileCount: "Count including tile zero; default 1",
			copyTilesetId: "Optional source tileset",
			gridOrigin: "Optional in-memory {x,y} origin"
		}
	],
	[
		"tileset.tileInsert",
		"Insert tile artwork at an index; native Lua leaves map numbers unchanged.",
		{
			tilesetId: "Tileset ID",
			tileIndex: "Index 1 through count; default append"
		}
	],
	[
		"tileset.tileRemove",
		"Delete tile artwork at an index; native Lua leaves map numbers unchanged.",
		{
			tilesetId: "Tileset ID",
			tileIndex: "Index 1 through count minus one"
		}
	],
	[
		"layer.tileset",
		"Assign a tileset to one layer, retaining map numbers, flags and positions.",
		{
			layerId: "Tilemap layer ID",
			tilesetId: "Destination tileset ID"
		}
	],
	[
		"tileset.tileImage",
		"Replace a tile image while retaining native tile IDs, placements and linked maps.",
		{
			tilesetId: "Tileset id",
			tileIndex: "Zero-based native tile index",
			width: "Exact tile grid width",
			height: "Exact tile grid height",
			pixels: "Exact native-mode raster pixels"
		}
	],
	[
		"tileset.update",
		"Update independent tileset properties and references.",
		{
			tilesetId: "Tileset id",
			patch: "{name?,tileWidth?,tileHeight?,tiles?,imageId?,baseIndex?}"
		}
	],
	[
		"tileset.remove",
		"Remove a tileset unused by layers.",
		{ tilesetId: "Tileset id" }
	],
	[
		"tilemap.paint",
		"Paint independently referenced tiles into a frame tilemap.",
		{
			...TARGET,
			tilesetId: "Tileset id; defaults to existing map.",
			columns: "Optional tile grid width",
			rows: "Optional tile grid height",
			points: "[{x,y,tileId:string|null,flipX?,flipY?,rotate?:0|90|180|270}]"
		}
	],
	[
		"tilemap.edit",
		"Edit intrinsic tile pixels in manual, automatic reuse, or stack mode.",
		{
			...TARGET,
			x: "Tile column",
			y: "Tile row",
			pixels: "Complete tileWidth×tileHeight decoded color array.",
			mode: "manual edits the shared tile; auto reuses/adds tiles and removes the replaced tile when no frame/layer uses it; stack retains prior tiles. Auto transparent pixels clear the cell. Cell transforms are preserved."
		}
	],
	[
		"clip.add",
		"Create an animation tag/clip.",
		{ clip: "{id?,name?,frameIds?,direction?:forward|reverse|pingpong|pingpong_reverse,loop?}" }
	],
	[
		"clip.update",
		"Update an animation tag/clip.",
		{
			clipId: "Clip id",
			patch: "{name?,frameIds?,direction?,loop?,repeat?:0–65535,color?}"
		}
	],
	[
		"clip.remove",
		"Remove an animation tag/clip.",
		{ clipId: "Clip id" }
	],
	[
		"slice.add",
		"Create an export slice with optional pivot and nine-patch.",
		{ slice: "{id?,name?,bounds:{x,y,width,height},pivot?,ninePatch?}" }
	],
	[
		"slice.update",
		"Update a slice.",
		{
			sliceId: "Slice id",
			patch: "{name?,bounds?,pivot?,ninePatch?,keys?}"
		}
	],
	[
		"slice.remove",
		"Remove a slice.",
		{ sliceId: "Slice id" }
	]
].map(([type, description, parameters]) => Object.freeze({
	type,
	description,
	parameters: Object.freeze(parameters)
})));
//#endregion
//#region app/color-management.mjs
/** ICC color transforms. Pixel data stays in the document's working profile;
* canvas/export callers explicitly request sRGB. LittleCMS owns the conversion. */
const MAX_PROFILE_BYTES = 4 * 1024 * 1024;
const SRGB = Object.freeze({
	type: 1,
	flags: 0,
	gamma: 0
});
const bytesOf = (value) => {
	if (!(value instanceof Uint8Array) && !Array.isArray(value)) throw Error("Choose an ICC profile file.");
	if (value.length < 132 || value.length > MAX_PROFILE_BYTES) throw Error("ICC profile must contain 132 bytes to 4 MB.");
	if (Array.isArray(value) && value.some((v) => !Number.isInteger(v) || v < 0 || v > 255)) throw Error("Invalid ICC profile bytes.");
	const bytes = Uint8Array.from(value), view = new DataView(bytes.buffer);
	if (String.fromCharCode(...bytes.subarray(36, 40)) !== "acsp" || view.getUint32(0) !== bytes.length) throw Error("Invalid ICC profile header or length.");
	const count = view.getUint32(128);
	if (count > 4096 || 132 + count * 12 > bytes.length) throw Error("Invalid ICC tag table.");
	for (let i = 0; i < count; i++) {
		const offset = view.getUint32(136 + i * 12), length = view.getUint32(140 + i * 12);
		if (offset < 128 || offset + length > bytes.length) throw Error("ICC tag extends beyond the profile.");
	}
	return bytes;
};
function documentProfile(doc) {
	return doc.metadata?.aseprite?.colorProfile ?? SRGB;
}
function isSRGB(profile) {
	return !profile || profile === "sRGB" || profile.type !== 2 && !(profile.flags & 1);
}
/** Matrix/TRC profile with sRGB primaries and a fixed transfer exponent.
* ICC v2 XYZ/curve tags, D50-adapted colorants; useful for Aseprite fixed gamma. */
function createGammaProfile(gamma = 1) {
	if (!Number.isFinite(gamma) || gamma < .1 || gamma > 10) throw Error("Gamma must be between 0.1 and 10.");
	const enc = new TextEncoder(), tags = [], tag = (sig, data) => tags.push({
		sig,
		data
	});
	const xyz = (values) => {
		const b = new Uint8Array(20), v = new DataView(b.buffer);
		b.set(enc.encode("XYZ "));
		values.forEach((n, i) => v.setInt32(8 + i * 4, Math.round(n * 65536)));
		return b;
	};
	const curve = new Uint8Array(16), cv = new DataView(curve.buffer);
	curve.set(enc.encode("curv"));
	cv.setUint32(8, 1);
	cv.setUint16(12, Math.round(gamma * 256));
	const label = enc.encode(`PixelWall sRGB primaries gamma ${gamma}\0`), description = new Uint8Array(12 + label.length + 78), dv = new DataView(description.buffer);
	description.set(enc.encode("desc"));
	dv.setUint32(8, label.length);
	description.set(label, 12);
	tag("desc", description);
	tag("wtpt", xyz([
		.9642,
		1,
		.8249
	]));
	tag("rXYZ", xyz([
		.4360747,
		.2225045,
		.0139322
	]));
	tag("gXYZ", xyz([
		.3850649,
		.7168786,
		.0971045
	]));
	tag("bXYZ", xyz([
		.1430804,
		.0606169,
		.7141733
	]));
	for (const sig of [
		"rTRC",
		"gTRC",
		"bTRC"
	]) tag(sig, curve);
	tag("cprt", enc.encode("text\0\0\0\0PixelWall generated profile. CC0.\0"));
	let offset = 132 + tags.length * 12;
	for (const t of tags) {
		t.offset = offset;
		offset += Math.ceil(t.data.length / 4) * 4;
	}
	const bytes = new Uint8Array(offset), view = new DataView(bytes.buffer);
	view.setUint32(0, offset);
	view.setUint32(8, 34603008);
	for (const [at, s] of [
		[12, "mntr"],
		[16, "RGB "],
		[20, "XYZ "],
		[36, "acsp"],
		[40, "APPL"],
		[80, "PWAL"]
	]) bytes.set(enc.encode(s), at);
	[
		2026,
		1,
		1,
		0,
		0,
		0
	].forEach((n, i) => view.setUint16(24 + i * 2, n));
	[
		.9642,
		1,
		.8249
	].forEach((n, i) => view.setInt32(68 + i * 4, Math.round(n * 65536)));
	view.setUint32(128, tags.length);
	tags.forEach((t, i) => {
		const at = 132 + i * 12;
		bytes.set(enc.encode(t.sig), at);
		view.setUint32(at + 4, t.offset);
		view.setUint32(at + 8, t.data.length);
		bytes.set(t.data, t.offset);
	});
	return bytes;
}
function createColorManager(lcms, constants) {
	const profiles = /* @__PURE__ */ new Map(), transforms = /* @__PURE__ */ new Map();
	let disposed = false, profileSequence = 0;
	function clearTransforms() {
		for (const handle of transforms.values()) lcms.cmsDeleteTransform(handle);
		transforms.clear();
	}
	function profileInfo(profile = SRGB) {
		if (disposed) throw Error("Color manager has been closed.");
		if (profile === "sRGB") profile = SRGB;
		let key = "sRGB", bytes;
		if (profile?.type === 2) {
			bytes = bytesOf(profile.icc);
			const chunks = [];
			for (let at = 0; at < bytes.length; at += 16384) chunks.push(String.fromCharCode(...bytes.subarray(at, at + 16384)));
			key = chunks.join("");
		} else if (profile?.flags & 1) {
			bytes = createGammaProfile(profile.gamma);
			key = `gamma:${profile.gamma}`;
		}
		if (profiles.has(key)) {
			const info = profiles.get(key);
			profiles.delete(key);
			profiles.set(key, info);
			return info;
		}
		const handle = bytes ? lcms.cmsOpenProfileFromMem(bytes, bytes.length) : lcms.cmsCreate_sRGBProfile();
		if (!handle) throw Error("LittleCMS could not read this ICC profile.");
		const space = lcms.cmsGetColorSpaceASCII(handle);
		if (!["RGB", "GRAY"].includes(space)) {
			lcms.cmsCloseProfile(handle);
			throw Error(`A ${space || "non-RGB"} profile cannot be used with this sprite.`);
		}
		const info = {
			key,
			token: ++profileSequence,
			handle,
			space,
			name: bytes ? lcms.cmsGetProfileInfoASCII(handle, constants.cmsInfoDescription, "en", "US") || "Embedded ICC profile" : "sRGB"
		};
		if (profiles.size >= 8) {
			clearTransforms();
			const oldest = profiles.keys().next().value;
			lcms.cmsCloseProfile(profiles.get(oldest).handle);
			profiles.delete(oldest);
		}
		profiles.set(key, info);
		return info;
	}
	function transformRGBA(input, source = SRGB, destination = SRGB, { intent = 1, blackPointCompensation = true } = {}) {
		if (!ArrayBuffer.isView(input) || input.length % 4) throw Error("Color conversion expects RGBA bytes.");
		if (!Number.isInteger(intent) || intent < 0 || intent > 3) throw Error("Choose a valid rendering intent.");
		const src = profileInfo(source), dst = profileInfo(destination);
		if (src.key === dst.key) return Uint8ClampedArray.from(input);
		const key = `${src.token}>${dst.token}:${intent}:${blackPointCompensation}`;
		let handle = transforms.get(key);
		if (!handle) {
			if (transforms.size >= 128) clearTransforms();
			handle = lcms.cmsCreateTransform(src.handle, src.space === "GRAY" ? constants.TYPE_GRAY_8 : constants.TYPE_RGB_8, dst.handle, dst.space === "GRAY" ? constants.TYPE_GRAY_8 : constants.TYPE_RGB_8, intent, blackPointCompensation ? constants.cmsFLAGS_BLACKPOINTCOMPENSATION : 0);
			if (!handle) throw Error("This ICC profile does not support the requested conversion.");
			transforms.set(key, handle);
		}
		const channels = src.space === "GRAY" ? 1 : 3, count = input.length / 4, packed = new Uint8Array(count * channels);
		for (let i = 0; i < count; i++) for (let c = 0; c < channels; c++) packed[i * channels + c] = input[i * 4 + c];
		const converted = lcms.cmsDoTransform(handle, packed, count), out = new Uint8ClampedArray(input.length), outChannels = dst.space === "GRAY" ? 1 : 3;
		for (let i = 0; i < count; i++) {
			for (let c = 0; c < 3; c++) out[i * 4 + c] = converted[i * outChannels + (outChannels === 1 ? 0 : c)];
			out[i * 4 + 3] = input[i * 4 + 3];
		}
		return out;
	}
	function transformColors(colors, source, destination, options) {
		const packed = new Uint8Array(colors.length * 4);
		colors.forEach((color, i) => {
			const s = normalizeColor(color);
			for (let c = 0; c < 4; c++) packed[i * 4 + c] = parseInt(s.slice(1 + c * 2, 3 + c * 2), 16);
		});
		const converted = transformRGBA(packed, source, destination, options);
		return colors.map((_, i) => "#" + Array.from(converted.subarray(i * 4, i * 4 + 4), (c) => c.toString(16).padStart(2, "0")).join(""));
	}
	function assignProfile(input, profile = SRGB) {
		const doc = normalizeDocument(input);
		if (profileInfo(profile).space === "GRAY" && doc.colorMode !== "grayscale") throw Error("A gray profile requires a grayscale document.");
		const cp = profile === "sRGB" ? SRGB : profile;
		doc.metadata.aseprite = {
			...doc.metadata.aseprite,
			colorProfile: structuredClone(cp)
		};
		return doc;
	}
	function convertDocument(input, profile = SRGB, options) {
		const source = documentProfile(input), destination = profileInfo(profile), doc = assignProfile(input, profile);
		if (destination.space === "RGB" && doc.colorMode === "grayscale" && !isSRGB(profile)) doc.colorMode = "rgba";
		doc.palette = transformColors(doc.palette, source, profile, options);
		for (const frame of doc.frames) if (frame.palette) frame.palette = transformColors(frame.palette, source, profile, options);
		if (doc.colorMode !== "indexed") {
			for (const image of Object.values(doc.images)) if (!image.tilemap) {
				const palette = [...new Set(image.pixels.filter((p) => p !== null))], converted = transformColors(palette, source, profile, options), lookup = new Map(palette.map((p, i) => [p, converted[i]]));
				image.pixels = image.pixels.map((p) => p === null ? null : lookup.get(p));
			}
		}
		if (doc.colorMode === "grayscale" && Object.values(doc.images).some((image) => !image.tilemap && image.pixels.some((p) => p !== null && (p.slice(1, 3) !== p.slice(3, 5) || p.slice(3, 5) !== p.slice(5, 7))))) doc.colorMode = "rgba";
		return normalizeDocument(doc);
	}
	return Object.freeze({
		profileInfo: (profile) => {
			const { space, name } = profileInfo(profile);
			return {
				space,
				name
			};
		},
		readProfile(bytes) {
			const profile = {
				type: 2,
				flags: 0,
				gamma: 0,
				icc: Array.from(bytesOf(bytes))
			};
			profileInfo(profile);
			return profile;
		},
		transformRGBA,
		transformColors,
		assignProfile,
		convertDocument,
		displayFrame: (doc, frameId) => transformRGBA(renderFrame(doc, frameId), documentProfile(doc)),
		displayColor: (doc, color) => transformColors([color], documentProfile(doc), SRGB)[0],
		workingColor: (doc, color) => transformColors([color], SRGB, documentProfile(doc))[0],
		close() {
			if (disposed) return;
			for (const handle of transforms.values()) lcms.cmsDeleteTransform(handle);
			for (const { handle } of profiles.values()) lcms.cmsCloseProfile(handle);
			transforms.clear();
			profiles.clear();
			disposed = true;
		}
	});
}
//#endregion
//#region app/color-runtime-node.mjs
let pending;
function loadNodeColorManager() {
	pending ??= (async () => {
		const distributed = new URL("./runtimes/lcms.wasm", import.meta.url);
		return createColorManager(await instantiate({ wasmBinary: await readFile(existsSync(distributed) ? distributed : new URL("../node_modules/lcms-wasm/dist/lcms.wasm", import.meta.url)) }), lcms_exports);
	})().catch((error) => {
		pending = void 0;
		throw error;
	});
	return pending;
}
function validateExportScale(value = 1) {
	const scale = Number(value);
	if (!Number.isFinite(scale) || scale <= 0 || scale > 64) throw Error("Scale must be a positive number up to 64.");
	return scale;
}
const dimension = (value, ratio) => Math.max(1, Math.trunc(value * ratio));
const position = (value, ratio) => Math.trunc(value * ratio) || 0;
/** Rectangles scale their endpoints; their sizes are not rounded independently. */
function scaleExportRectangle(rect, sx, sy) {
	const x = position(rect.x, sx), y = position(rect.y, sy);
	return {
		...rect,
		x,
		y,
		width: position(rect.x + rect.width, sx) - x,
		height: position(rect.y + rect.height, sy) - y
	};
}
function scaleSliceKey(key, sx, sy) {
	return {
		...scaleExportRectangle(key, sx, sy),
		...key.pivot ? { pivot: {
			x: position(key.pivot.x, sx),
			y: position(key.pivot.y, sy)
		} } : {},
		...key.center ? { center: scaleExportRectangle({
			...key.center,
			width: key.center.width ?? key.center.w,
			height: key.center.height ?? key.center.h
		}, sx, sy) } : {}
	};
}
function scaleExportSlices(slices, sx, sy) {
	return slices.map((slice) => slice.bounds ? {
		...slice,
		bounds: scaleExportRectangle(slice.bounds, sx, sy),
		...slice.pivot ? { pivot: {
			x: position(slice.pivot.x, sx),
			y: position(slice.pivot.y, sy)
		} } : {},
		...slice.ninePatch ? { ninePatch: scaleExportRectangle(slice.ninePatch, sx, sy) } : {}
	} : {
		...slice,
		keys: slice.keys.map((key) => scaleSliceKey(key, sx, sy))
	});
}
/** Pure temporary render document. The source, links and native export stay intact.
* Canvas ratios use the rounded destination size. Each cel/tile resamples locally.
* Reference bitmaps retain their resolution; their precise display bounds scale.
* This is not a persisted/normalized editor document: exports allow 64M pixels. */
function scaleExportDocument(source, value) {
	const scale = validateExportScale(value);
	const width = dimension(source.width, scale), height = dimension(source.height, scale);
	if (!Number.isSafeInteger(width * height) || width * height > 67108864) throw Error("Scaled output exceeds the pixel limit.");
	if (scale === 1 && !source.layers.some((layer) => layer.type === "tilemap")) return source;
	const sx = width / source.width, sy = height / source.height, images = { ...source.images };
	let allocated = 0, serial = 0;
	const reserve = (w, h) => {
		if (!Number.isSafeInteger(w * h) || w < 1 || h < 1 || (allocated += w * h) > 67108864) throw Error("Scaled cel and tile images exceed the export pixel limit.");
	};
	const key = () => {
		let result;
		do
			result = `export-scale-${serial++}`;
		while (Object.hasOwn(images, result));
		return result;
	};
	function resized(image, w, h) {
		reserve(w, h);
		const pixels = Array(w * h);
		for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) pixels[y * w + x] = image.pixels[Math.floor(y * image.height / h) * image.width + Math.floor(x * image.width / w)];
		return {
			...image,
			width: w,
			height: h,
			pixels
		};
	}
	const rasterCopies = /* @__PURE__ */ new Map(), layerById = new Map(source.layers.map((layer) => [layer.id, layer]));
	const frames = source.frames.map((frame) => ({
		...frame,
		cels: Object.fromEntries(Object.entries(frame.cels).map(([layerId, cel]) => {
			const layer = layerById.get(layerId), image = source.images[cel.imageId];
			let imageId = cel.imageId;
			const result = {
				...cel,
				x: position(cel.x, sx),
				y: position(cel.y, sy)
			};
			if (layer.type === "reference") {
				const b = cel.preciseBounds?.flags & 1 ? cel.preciseBounds : {
					flags: 1,
					x: cel.x,
					y: cel.y,
					width: image.width,
					height: image.height
				};
				result.preciseBounds = {
					...b,
					x: b.x * sx,
					y: b.y * sy,
					width: b.width * sx,
					height: b.height * sy
				};
			} else if (!image.tilemap) {
				if (!rasterCopies.has(imageId)) {
					const id = key();
					images[id] = resized(image, dimension(image.width, sx), dimension(image.height, sy));
					rasterCopies.set(imageId, id);
				}
				imageId = rasterCopies.get(imageId);
				if (result.preciseBounds?.flags & 1) delete result.preciseBounds;
			}
			return [layerId, {
				...result,
				imageId
			}];
		}))
	}));
	const tilesets = source.tilesets.map((ts) => ({
		...ts,
		tileWidth: dimension(ts.tileWidth, sx),
		tileHeight: dimension(ts.tileHeight, sy),
		tiles: []
	}));
	const sets = new Map(tilesets.map((ts, index) => [ts.id, {
		source: source.tilesets[index],
		output: ts,
		variants: /* @__PURE__ */ new Map()
	}]));
	function orientedTile(set, tileId, fx, fy, diagonal, canonical) {
		const cacheKey = JSON.stringify([
			tileId,
			fx,
			fy,
			diagonal,
			canonical
		]);
		if (set.variants.has(cacheKey)) return set.variants.get(cacheKey);
		const { source: ts, output } = set;
		let image, rect;
		if (canonical) {
			const tile = ts.tiles?.find((tile) => tile.id === tileId);
			image = source.images[tile?.imageId];
			if (!image) throw Error("Tile references a missing image.");
			rect = tile.sourceRect ?? {
				x: 0,
				y: 0,
				width: image.width,
				height: image.height
			};
		} else {
			image = source.images[ts.imageId];
			if (!image) throw Error("Tile references a missing atlas.");
			const columns = Math.floor(image.width / ts.tileWidth);
			rect = {
				x: tileId % columns * ts.tileWidth,
				y: Math.floor(tileId / columns) * ts.tileHeight,
				width: ts.tileWidth,
				height: ts.tileHeight
			};
		}
		const bitmapWidth = Math.max(1, Math.round(ts.tileWidth * sx)), bitmapHeight = Math.max(1, Math.round(ts.tileHeight * sy));
		const w = output.tileWidth, h = output.tileHeight;
		reserve(w, h);
		const pixels = Array(w * h);
		let clearMask;
		for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
			let ix = fx ? w - 1 - x : x, iy = fy ? h - 1 - y : y;
			if (diagonal) [ix, iy] = [iy, ix];
			if (ix >= bitmapWidth || iy >= bitmapHeight) {
				pixels[y * w + x] = null;
				clearMask ??= new Uint8Array(w * h);
				clearMask[y * w + x] = 1;
				continue;
			}
			ix = Math.floor(ix * ts.tileWidth / bitmapWidth);
			iy = Math.floor(iy * ts.tileHeight / bitmapHeight);
			if (canonical) {
				ix = Math.floor((ix + .5) * rect.width / ts.tileWidth);
				iy = Math.floor((iy + .5) * rect.height / ts.tileHeight);
			}
			ix += rect.x;
			iy += rect.y;
			pixels[y * w + x] = ix < 0 || iy < 0 || ix >= image.width || iy >= image.height ? null : image.pixels[iy * image.width + ix];
		}
		const imageId = key(), id = imageId;
		images[imageId] = {
			width: w,
			height: h,
			pixels,
			...clearMask ? { [TILE_BACKDROP_CLEAR]: clearMask } : {}
		};
		output.tiles.push({
			id,
			imageId
		});
		set.variants.set(cacheKey, id);
		return id;
	}
	const layers = source.layers.map((layer) => {
		if (layer.type !== "tilemap") return layer;
		const tilemaps = {};
		for (const frame of source.frames) {
			const map = layer.tilemaps?.[frame.id], cel = frame.cels[layer.id], rawImage = source.images[cel?.imageId], raw = rawImage?.tilemap;
			if (!map && !raw) continue;
			const set = sets.get(map?.tilesetId ?? layer.tilesetId);
			if (!set) throw Error("Tilemap references a missing tileset.");
			let cells;
			if (map) cells = map.cells.map((cell) => {
				if (!cell) return null;
				let fx = !!cell.flipX, fy = !!cell.flipY, diagonal = false;
				if (cell.rotate === 90) {
					diagonal = true;
					[fx, fy] = [!fy, fx];
				}
				if (cell.rotate === 180) {
					fx = !fx;
					fy = !fy;
				}
				if (cell.rotate === 270) {
					diagonal = true;
					[fx, fy] = [fy, !fx];
				}
				return { tileId: orientedTile(set, cell.tileId, fx, fy, diagonal, true) };
			});
			else cells = raw.tiles.map((value) => {
				value >>>= 0;
				const index = (value & (raw.idMask ?? 536870911)) >>> 0;
				if (set.source.flags & 4 ? index === 0 : value === 4294967295) return null;
				if (index >= set.source.tileCount) return null;
				return { tileId: orientedTile(set, index, !!(value & (raw.xFlipMask ?? 2147483648)), !!(value & (raw.yFlipMask ?? 1073741824)), !!(value & (raw.diagonalFlipMask ?? 536870912)), false) };
			});
			tilemaps[frame.id] = {
				...map ?? {},
				tilesetId: set.output.id,
				columns: map?.columns ?? rawImage.width,
				rows: map?.rows ?? rawImage.height,
				x: position(map?.x ?? cel?.x ?? 0, sx),
				y: position(map?.y ?? cel?.y ?? 0, sy),
				opacity: map?.opacity ?? cel?.opacity ?? 1,
				cells
			};
		}
		return {
			...layer,
			tilemaps
		};
	});
	const slices = scaleExportSlices(source.slices, sx, sy);
	return {
		...source,
		width,
		height,
		images,
		frames,
		layers,
		tilesets,
		slices
	};
}
//#endregion
//#region app/export-render.mjs
/** Rendered assets use sRGB. Composite layers in their working profile first;
* converting editable cels before compositing can change their appearance. */
/** Convert already-composited straight RGBA (or one standalone tile) to sRGB.
* Does not modify input bytes or the editable document. No runtime or I/O here. */
function toExportRGBA(input, document, { colorManager, intent = 1, blackPointCompensation = true } = {}) {
	if (!(input instanceof Uint8Array || input instanceof Uint8ClampedArray) || input.length % 4) throw Error("Rendered export expects RGBA bytes.");
	const source = documentProfile(document);
	if (isSRGB(source)) return Uint8ClampedArray.from(input);
	if (typeof colorManager?.transformRGBA !== "function") throw Error("Load the color manager before exporting a document with a custom color profile.");
	return colorManager.transformRGBA(input, source, "sRGB", {
		intent,
		blackPointCompensation
	});
}
/** Filter layers and apply fractional cel geometry before this call; crop and pack after it.
* Native editable exports must save the original document instead. */
function renderExportFrame(document, frameId, options) {
	return toExportRGBA(renderWorkingExportFrame(document, frameId), document, options);
}
/** Render bounded strips so export geometry does not enlarge the editor canvas limit. */
function renderWorkingExportFrame(document, frameId) {
	frameId ??= document.frames[0]?.id;
	if (!Number.isSafeInteger(document.width * document.height) || document.width * document.height > 67108864) throw Error("Rendered export exceeds the pixel limit.");
	if (document.width <= 65535 && document.height <= 65535 && document.width * document.height <= 4 * 1024 * 1024) return renderFrame(document, frameId);
	const result = new Uint8ClampedArray(document.width * document.height * 4);
	for (let y = 0; y < document.height; y += 2048) for (let x = 0; x < document.width; x += 2048) {
		const width = Math.min(2048, document.width - x), height = Math.min(2048, document.height - y);
		const frames = document.frames.map((frame) => frame.id !== frameId ? frame : {
			...frame,
			cels: Object.fromEntries(Object.entries(frame.cels).map(([id, cel]) => [id, {
				...cel,
				x: cel.x - x,
				y: cel.y - y,
				...cel.preciseBounds ? { preciseBounds: {
					...cel.preciseBounds,
					x: cel.preciseBounds.x - x,
					y: cel.preciseBounds.y - y
				} } : {}
			}]))
		});
		const layers = document.layers.map((layer) => layer.tilemaps?.[frameId] ? {
			...layer,
			tilemaps: {
				...layer.tilemaps,
				[frameId]: {
					...layer.tilemaps[frameId],
					x: (layer.tilemaps[frameId].x ?? 0) - x,
					y: (layer.tilemaps[frameId].y ?? 0) - y
				}
			}
		} : layer);
		const rgba = renderFrame({
			...document,
			width,
			height,
			frames,
			layers
		}, frameId);
		for (let row = 0; row < height; row++) result.set(rgba.subarray(row * width * 4, (row + 1) * width * 4), ((y + row) * document.width + x) * 4);
	}
	return result;
}
/** Integer magnification keeps existing pixel replication; fractions resize cels before compositing. */
function renderScaledExportFrame(document, frameId, value = 1, options) {
	const scale = validateExportScale(value);
	if (!Number.isInteger(scale)) {
		const scaled = scaleExportDocument(document, scale);
		return {
			width: scaled.width,
			height: scaled.height,
			rgba: renderExportFrame(scaled, frameId, options)
		};
	}
	const width = document.width * scale, height = document.height * scale;
	if (width * height > 67108864) throw Error("Scaled output exceeds the pixel limit.");
	const source = renderExportFrame(scaleExportDocument(document, 1), frameId, options);
	if (scale === 1) return {
		width,
		height,
		rgba: source
	};
	const rgba = new Uint8ClampedArray(width * height * 4);
	for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
		const at = (Math.floor(y / scale) * document.width + Math.floor(x / scale)) * 4;
		rgba.set(source.subarray(at, at + 4), (y * width + x) * 4);
	}
	return {
		width,
		height,
		rgba
	};
}
const WORK_PIXEL_LIMIT = 256 * 1024 * 1024;
const TOTAL_STEP_LIMIT = 1024;
const fail$7 = (message) => {
	throw Error(message);
};
function retainedImages(document) {
	const ids = new Set(document.frames.flatMap((frame) => Object.values(frame.cels).map((cel) => cel.imageId)));
	for (const tileset of document.tilesets) {
		if (tileset.imageId) ids.add(tileset.imageId);
		for (const tile of tileset.tiles ?? []) ids.add(tile.imageId);
	}
	return Object.fromEntries([...ids].filter((id) => document.images[id]).map((id) => [id, document.images[id]]));
}
/** Apply each resize separately; multiplying factors would lose intermediate
* dimension rounding and pixel sampling. Share one work budget across inputs. */
function applyOrderedExportScales(source, transforms = [], budget = {
	workPixels: 0,
	steps: 0
}) {
	if (!Array.isArray(transforms) || transforms.length > 32) fail$7(`Ordered exports allow at most 32 scale operations per input.`);
	const factors = transforms.map((transform) => {
		if (!transform || typeof transform !== "object" || Object.keys(transform).some((key) => !["type", "factor"].includes(key)) || transform.type !== "scale") fail$7("Unsupported ordered export transformation.");
		return validateExportScale(transform.factor);
	});
	if (factors.filter((factor) => factor !== 1).length > 1 && source.layers.some((layer) => layer.type === "tilemap")) fail$7("Tilemap inputs support one effective ordered scale. Multiple tilemap resizes require separate editable resize steps.");
	let document = source;
	const history = [];
	for (const factor of factors) {
		if (++budget.steps > TOTAL_STEP_LIMIT) fail$7("Ordered export exceeds the total scale-operation limit.");
		const before = {
			width: document.width,
			height: document.height
		};
		const width = Math.max(1, Math.trunc(document.width * factor)), height = Math.max(1, Math.trunc(document.height * factor));
		const sx = width / document.width, sy = height / document.height;
		let estimatedPixels = width * height;
		const seen = /* @__PURE__ */ new Set();
		for (const frame of document.frames) for (const [layerId, cel] of Object.entries(frame.cels)) {
			if (seen.has(cel.imageId) || document.layers.find((layer) => layer.id === layerId)?.type === "reference") continue;
			seen.add(cel.imageId);
			const image = document.images[cel.imageId];
			if (!image.tilemap) estimatedPixels += Math.max(1, Math.trunc(image.width * sx)) * Math.max(1, Math.trunc(image.height * sy));
		}
		if (!Number.isSafeInteger(estimatedPixels) || width * height > 67108864 || budget.workPixels + estimatedPixels > WORK_PIXEL_LIMIT) fail$7("Ordered scaling exceeds the pixel or cumulative work limit.");
		budget.workPixels += estimatedPixels;
		if (factor !== 1) {
			document = scaleExportDocument(document, factor);
			document = {
				...document,
				images: retainedImages(document)
			};
		}
		history.push({
			type: "scale",
			factor,
			before,
			after: {
				width: document.width,
				height: document.height
			}
		});
	}
	return {
		document,
		transforms: history
	};
}
/** Render a crop/window without clipping off-canvas cel pixels first. The result
* is temporary: profiles, palettes, pixel arrays and source geometry are retained. */
function exportRegionDocument(document, frameId, rectangle) {
	const { x, y, width, height } = rectangle;
	if (![
		x,
		y,
		width,
		height
	].every(Number.isSafeInteger) || width < 1 || height < 1 || width * height > 67108864) fail$7("Export region exceeds the pixel limit.");
	const frames = document.frames.map((frame) => frame.id !== frameId ? frame : {
		...frame,
		cels: Object.fromEntries(Object.entries(frame.cels).map(([id, cel]) => [id, {
			...cel,
			x: cel.x - x,
			y: cel.y - y,
			...cel.preciseBounds ? { preciseBounds: {
				...cel.preciseBounds,
				x: cel.preciseBounds.x - x,
				y: cel.preciseBounds.y - y
			} } : {}
		}]))
	});
	const layers = document.layers.map((layer) => layer.tilemaps?.[frameId] ? {
		...layer,
		tilemaps: {
			...layer.tilemaps,
			[frameId]: {
				...layer.tilemaps[frameId],
				x: (layer.tilemaps[frameId].x ?? 0) - x,
				y: (layer.tilemaps[frameId].y ?? 0) - y
			}
		}
	} : layer);
	return {
		...document,
		width,
		height,
		frames,
		layers
	};
}
//#endregion
//#region app/cli-arguments.mjs
/** CLI parsing preserves option/file order separately from output-wide options. */
const SCOPED = new Set([
	"layer",
	"ignore-layer",
	"all-layers",
	"split-layers",
	"split-tags",
	"play-subtags",
	"split-slices",
	"split-grid",
	"clip",
	"tag",
	"frame-tag",
	"frame-range",
	"frame",
	"slice",
	"grid"
]);
const BOOLEAN = new Set([
	"help",
	"include-reference-layers",
	"trim",
	"trim-sprite",
	"ignore-empty",
	"all-layers",
	"split-layers",
	"split-tags",
	"play-subtags",
	"split-slices",
	"split-grid",
	"power-of-two",
	"power-of-two-size",
	"ordered-inputs"
]);
const REPEAT = new Set(["layer", "ignore-layer"]);
const fail$6 = (message) => {
	throw Error(message);
};
/** Global behavior is unchanged unless --ordered-inputs is explicitly enabled.
* Ordered selectors persist for following inputs; scalar/boolean values replace,
* repeated layer selectors accumulate, and each input owns a defensive snapshot. */
function parseCliArguments(argv) {
	const args = { _: [] }, events = [];
	const positional = (value) => {
		args._.push(value);
		events.push({ filename: value });
	};
	for (let i = 0; i < argv.length; i++) {
		const value = argv[i];
		if (value === "--") {
			argv.slice(i + 1).forEach(positional);
			break;
		}
		if (!value.startsWith("--")) {
			positional(value);
			continue;
		}
		const eq = value.indexOf("="), rawKey = value.slice(2, eq < 0 ? void 0 : eq), key = rawKey === "import-layer" ? "layer" : rawKey;
		if (!key || [
			"__proto__",
			"prototype",
			"constructor",
			"_"
		].includes(key)) fail$6("Invalid option.");
		let parsed;
		if (BOOLEAN.has(key)) {
			const next = eq >= 0 ? value.slice(eq + 1) : ["true", "false"].includes(argv[i + 1]) ? argv[++i] : true;
			if (![
				true,
				"true",
				"false"
			].includes(next)) fail$6(`--${key} requires true or false.`);
			parsed = next === true || next === "true";
		} else if (eq >= 0) parsed = value.slice(eq + 1);
		else if (key === "extrude" && (!argv[i + 1] || !/^\d+$/.test(argv[i + 1]))) parsed = true;
		else if (argv[i + 1] && !argv[i + 1].startsWith("--")) parsed = argv[++i];
		else fail$6(`--${key} requires a value.`);
		if (REPEAT.has(key)) (args[key] ??= []).push(parsed);
		else args[key] = parsed;
		events.push({
			key,
			value: parsed
		});
	}
	const orderedInputs = args["ordered-inputs"] === true;
	if (orderedInputs && args._[0] !== "export" && args._[0] !== "help" && !args.help) fail$6("--ordered-inputs is available for export only.");
	if (!orderedInputs) return {
		args,
		orderedInputs: false,
		inputs: args._.slice(1).map((filename) => ({
			filename,
			options: {}
		}))
	};
	const state = {}, inputs = [];
	let commandSeen = false, orderedScaleCount = 0;
	for (const event of events) if (event.filename !== void 0) if (!commandSeen) commandSeen = true;
	else inputs.push({
		filename: event.filename,
		options: structuredClone(state),
		transforms: []
	});
	else if (event.key === "scale") {
		const factor = validateExportScale(event.value);
		if (++orderedScaleCount > 32) fail$6(`Ordered exports allow at most 32 scale operations.`);
		for (const input of inputs) input.transforms.push({
			type: "scale",
			factor
		});
	} else if (SCOPED.has(event.key)) {
		const key = ["clip", "frame-tag"].includes(event.key) ? "tag" : event.key;
		if (REPEAT.has(key)) (state[key] ??= []).push(event.value);
		else state[key] = event.value;
		if (key === "split-grid" && event.value === false) delete state.grid;
	}
	for (const key of SCOPED) delete args[key];
	delete args.scale;
	return {
		args,
		orderedInputs: true,
		inputs,
		orderedScaleCount
	};
}
//#endregion
//#region app/lua-plugin-schema.mjs
/** Data-only package command boundary. Host options enable it; Lua input cannot. */
const LUA_PLUGIN_LIMITS = Object.freeze({
	commands: 32,
	bytes: 65536,
	preferenceNodes: 4096,
	preferenceDepth: 12,
	stringBytes: 16384
});
const own$2 = (value, key) => Object.prototype.hasOwnProperty.call(value, key);
const record$1 = (value) => value && typeof value === "object" && !Array.isArray(value) && [Object.prototype, null].includes(Object.getPrototypeOf(value));
const unsafe = new Set([
	"__proto__",
	"constructor",
	"prototype"
]);
const fail$5 = (message) => {
	throw Error(`Lua package: ${message}`);
};
function object$1(value, label) {
	if (!record$1(value)) fail$5(`${label} must be a plain object.`);
	return value;
}
function keys$1(value, allowed, label) {
	for (const key of Object.keys(value)) if (!allowed.includes(key)) fail$5(`Unsupported ${label} property: ${key}.`);
}
function text$1(value, label, max = 512) {
	if (typeof value !== "string" || new TextEncoder().encode(value).length > max || value.includes("\0") || [...value].some((character) => {
		const point = character.codePointAt(0);
		return point >= 55296 && point <= 57343;
	})) fail$5(`${label} must be UTF-8 text of at most ${max} bytes.`);
	return value;
}
function size$1(value, label) {
	let json;
	try {
		json = JSON.stringify(value);
	} catch {
		fail$5(`${label} must be serializable.`);
	}
	if (!json || new TextEncoder().encode(json).length > LUA_PLUGIN_LIMITS.bytes) fail$5(`${label} exceeds 64 KiB.`);
}
/** Safe to use before reading saved preferences into a worker. Empty arrays normalize
* to empty Lua tables; null, sparse arrays, metatables/userdata and unsafe keys are unsupported. */
function validatePluginPreferences(input = {}) {
	object$1(input, "Preferences");
	let nodes = 0;
	const ancestors = /* @__PURE__ */ new Set();
	function copy(value, depth) {
		if (++nodes > LUA_PLUGIN_LIMITS.preferenceNodes || depth > LUA_PLUGIN_LIMITS.preferenceDepth) fail$5("Preferences exceed the depth or value-count limit.");
		if (typeof value === "boolean") return value;
		if (typeof value === "string") return text$1(value, "Preference string", LUA_PLUGIN_LIMITS.stringBytes);
		if (typeof value === "number") {
			if (!Number.isFinite(value) || Math.abs(value) > Number.MAX_SAFE_INTEGER) fail$5("Preference numbers must be finite and within the exact JavaScript range.");
			return value;
		}
		if (!value || typeof value !== "object" || !Array.isArray(value) && !record$1(value)) fail$5("Preferences support only plain Lua/JSON tables, strings, booleans and finite numbers.");
		if (ancestors.has(value)) fail$5("Preferences cannot be circular.");
		ancestors.add(value);
		let output;
		if (Array.isArray(value)) {
			if (value.length > LUA_PLUGIN_LIMITS.preferenceNodes || Reflect.ownKeys(value).length !== value.length + 1) fail$5("Preference arrays must be dense and bounded.");
			output = value.length ? Array.from({ length: value.length }, (_, index) => {
				const descriptor = Object.getOwnPropertyDescriptor(value, index);
				if (!descriptor || !own$2(descriptor, "value") || !descriptor.enumerable) fail$5("Preference arrays must have dense data values without accessors.");
				return copy(descriptor.value, depth + 1);
			}) : {};
		} else {
			output = {};
			const names = Reflect.ownKeys(value);
			if (names.some((key) => typeof key !== "string")) fail$5("Preference keys must be strings.");
			for (const key of names.sort()) {
				text$1(key, "Preference key", 128);
				if (unsafe.has(key)) fail$5("Unsafe preference key.");
				const descriptor = Object.getOwnPropertyDescriptor(value, key);
				if (!descriptor || !own$2(descriptor, "value") || !descriptor.enumerable) fail$5("Preference accessors and hidden properties are unsupported.");
				output[key] = copy(descriptor.value, depth + 1);
			}
		}
		ancestors.delete(value);
		return output;
	}
	const result = copy(input, 0);
	size$1(result, "Preferences");
	return result;
}
function validatePluginOptions(input) {
	object$1(input, "Plugin options");
	keys$1(input, [
		"name",
		"displayName",
		"version",
		"preferences"
	], "plugin option");
	const name = text$1(input.name, "Package name", 128);
	if (!/^[a-zA-Z0-9][a-zA-Z0-9._-]*$/.test(name) || unsafe.has(name)) fail$5("Package name is invalid.");
	const version = text$1(input.version, "Package version", 80);
	if (!version) fail$5("Package version is required.");
	return {
		name,
		displayName: text$1(input.displayName ?? name, "Package display name", 240),
		version,
		preferences: validatePluginPreferences(input.preferences)
	};
}
function validatePluginCatalog(input, expected) {
	object$1(input, "Command catalog");
	size$1(input, "Command catalog");
	keys$1(input, [
		"name",
		"displayName",
		"version",
		"commands"
	], "command catalog");
	if (!expected || input.name !== expected.name || input.displayName !== expected.displayName || input.version !== expected.version) fail$5("Command catalog package identity does not match the selected package.");
	if (!Array.isArray(input.commands) || !input.commands.length || input.commands.length > LUA_PLUGIN_LIMITS.commands) fail$5("A package session must register 1–32 commands.");
	const ids = /* @__PURE__ */ new Set();
	const commands = input.commands.map((raw) => {
		object$1(raw, "Command");
		keys$1(raw, [
			"id",
			"title",
			"group",
			"enabled",
			"checked"
		], "command");
		const id = text$1(raw.id, "Command ID", 128);
		if (!/^[a-zA-Z_][a-zA-Z0-9_.:-]*$/.test(id) || unsafe.has(id) || ids.has(id)) fail$5("Command IDs must be unique safe identifiers.");
		ids.add(id);
		const title = text$1(raw.title ?? id, "Command title", 512), group = text$1(raw.group ?? "", "Command group", 256);
		if (typeof raw.enabled !== "boolean" || own$2(raw, "checked") && typeof raw.checked !== "boolean") fail$5("Command enabled/checked states must be booleans.");
		return {
			id,
			title,
			group,
			enabled: raw.enabled,
			...own$2(raw, "checked") ? { checked: raw.checked } : {}
		};
	});
	return {
		name: expected.name,
		displayName: expected.displayName,
		version: expected.version,
		commands
	};
}
function validatePluginChoice(input, catalog) {
	object$1(input, "Command choice");
	keys$1(input, ["action", "commandId"], "command choice");
	if (input.action === "cancel") {
		if (own$2(input, "commandId")) fail$5("A cancelled choice cannot execute a command.");
		return { action: "cancel" };
	}
	if (input.action !== "run" || typeof input.commandId !== "string") fail$5("Choose one package command or cancel.");
	const command = catalog.commands.find((command) => command.id === input.commandId);
	if (!command?.enabled) fail$5("The chosen command is missing or disabled.");
	return {
		action: "run",
		commandId: command.id
	};
}
function validatePluginResult(input, expected, commandId) {
	object$1(input, "Plugin result");
	keys$1(input, [
		"name",
		"version",
		"commandId",
		"preferences",
		"preferencesChanged"
	], "plugin result");
	if (!expected || input.name !== expected.name || input.version !== expected.version || input.commandId !== commandId) fail$5("Plugin result does not match the chosen package command.");
	const preferences = validatePluginPreferences(input.preferences);
	return {
		name: expected.name,
		version: expected.version,
		commandId,
		preferences,
		preferencesChanged: JSON.stringify(preferences) !== JSON.stringify(validatePluginPreferences(expected.preferences))
	};
}
//#endregion
//#region app/lua-colors.mjs
/** UI colors cross the worker boundary as copied, unambiguous RGBA byte arrays. */
function validateLuaColor(value, label = "Lua color") {
	if (!Array.isArray(value) || value.length !== 4 || Array.from(value).some((channel) => !Number.isInteger(channel) || channel < 0 || channel > 255)) throw Error(`${label} must be an RGBA array of four integers from 0 to 255.`);
	return [...value];
}
Object.freeze({
	profile: Object.freeze({
		type: 0,
		flags: 0,
		gamma: 0
	}),
	name: ""
});
//#endregion
//#region app/lua-session.mjs
const LUA_LIMITS = Object.freeze({
	sourceBytes: 256 * 1024,
	pixels: 1048576,
	calls: 25e4,
	commands: 4096,
	outputBytes: 32 * 1024 * 1024,
	memoryBytes: 32 * 1024 * 1024,
	timeoutMs: 3e3,
	instructions: 1e8
});
const copy$1 = (value) => structuredClone(value);
/** Replays in the receiving thread; never trust a worker document without engine validation. */
function validateLuaResult(result, initialDocument) {
	if (!result || result.format !== "pixelwall-lua-result" || result.version !== 1 || !Array.isArray(result.transactions) || !Array.isArray(result.created) || !Array.isArray(result.documents) || result.created.length > 8) throw Error("Invalid Lua worker result.");
	if (JSON.stringify(result).length > LUA_LIMITS.outputBytes) throw Error("Lua output size limit exceeded.");
	const replay = /* @__PURE__ */ new Map();
	if (initialDocument) {
		const initial = normalizeDocument(copy$1(initialDocument));
		replay.set(initial.id, initial);
	}
	for (const seed of result.created) {
		const d = normalizeDocument(copy$1(seed));
		if (replay.has(d.id)) throw Error("Duplicate Lua sprite.");
		replay.set(d.id, d);
	}
	let commands = 0;
	for (const tx of result.transactions) {
		if (!Array.isArray(tx.commands) || !replay.has(tx.documentId) || typeof tx.label !== "string") throw Error("Invalid Lua transaction.");
		let d = replay.get(tx.documentId);
		for (const c of tx.commands) {
			if (++commands > LUA_LIMITS.commands) throw Error("Lua command budget exceeded.");
			d = applyCommand(d, c);
		}
		replay.set(tx.documentId, d);
	}
	if (result.documents.length !== replay.size) throw Error("Lua result sprite mismatch.");
	for (const document of result.documents) {
		const d = normalizeDocument(copy$1(document));
		if (JSON.stringify(d) !== JSON.stringify(replay.get(d.id))) throw Error("Lua output does not match its command transactions.");
	}
	const active = result.active?.documentId ? replay.get(result.active.documentId) : null;
	if (JSON.stringify(active) !== JSON.stringify(result.document)) throw Error("Lua active sprite mismatch.");
	if (result.selection != null && (!active || !Array.isArray(result.selection) || result.selection.length !== active.width * active.height || result.selection.some((value) => value !== 0 && value !== 1))) throw Error("Invalid Lua selection result.");
	if (result.range != null) {
		const r = result.range;
		if (!active || ![
			0,
			1,
			2,
			4
		].includes(r.type) || !Array.isArray(r.layerIds) || r.layerIds.some((id) => !active.layers.some((layer) => layer.id === id)) || !Array.isArray(r.frameIds) || r.frameIds.some((id) => !active.frames.some((frame) => frame.id === id)) || !Array.isArray(r.colors) || r.colors.some((index) => !Number.isInteger(index) || index < 0 || index >= active.palette.length) || !Array.isArray(r.sliceIds) || r.sliceIds.some((id) => !active.slices.some((slice) => slice.id === id))) throw Error("Invalid Lua range result.");
	}
	const fgColor = validateLuaColor(result.fgColor, "Lua foreground color result");
	const bgColor = validateLuaColor(result.bgColor, "Lua background color result");
	return {
		...result,
		fgColor,
		bgColor,
		document: active,
		documents: [...replay.values()]
	};
}
//#endregion
//#region app/lua-request.mjs
function luaRequest(input) {
	if (!input || typeof input.source !== "string" || new TextEncoder().encode(input.source).length > LUA_LIMITS.sourceBytes) throw Error("Lua source exceeds 256 KiB or is not text.");
	const timeoutMs = input.timeoutMs ?? LUA_LIMITS.timeoutMs, instructionLimit = input.instructionLimit ?? LUA_LIMITS.instructions;
	if (!Number.isSafeInteger(timeoutMs) || timeoutMs < 50 || timeoutMs > 1e4) throw Error("Lua timeout must be 50–10000 milliseconds.");
	if (!Number.isSafeInteger(instructionLimit) || instructionLimit < 1e3 || instructionLimit > 5e8) throw Error("Lua instruction limit must be 1000–500000000.");
	const params = input.params ?? {};
	if (!params || Array.isArray(params) || typeof params !== "object" || JSON.stringify(params).length > 16384) throw Error("Lua params must be an object below 16 KiB.");
	const document = input.document ? normalizeDocument(structuredClone(input.document)) : null;
	if (document && (document.width * document.height > LUA_LIMITS.pixels || Object.values(document.images).reduce((n, i) => n + i.width * i.height, 0) > LUA_LIMITS.pixels)) throw Error("Lua input exceeds the one-million-pixel budget.");
	const selection = input.selection == null ? null : structuredClone(input.selection), range = input.range == null ? null : structuredClone(input.range);
	if (selection && (!document || !Array.isArray(selection) || selection.length !== document.width * document.height || selection.some((value) => value !== 0 && value !== 1))) throw Error("Invalid initial Lua selection.");
	if (range && (!document || ![
		0,
		1,
		2,
		4
	].includes(range.type) || !Array.isArray(range.layerIds) || range.layerIds.some((id) => !document.layers.some((layer) => layer.id === id)) || !Array.isArray(range.frameIds) || range.frameIds.some((id) => !document.frames.some((frame) => frame.id === id)) || !Array.isArray(range.colors) || range.colors.some((index) => !Number.isInteger(index) || index < 0 || index >= document.palette.length) || !Array.isArray(range.sliceIds) || range.sliceIds.some((id) => !document.slices.some((slice) => slice.id === id)))) throw Error("Invalid initial Lua range.");
	const fgColor = validateLuaColor(input.fgColor === void 0 ? [
		0,
		0,
		0,
		255
	] : input.fgColor, "Initial Lua foreground color");
	const bgColor = validateLuaColor(input.bgColor === void 0 ? [
		255,
		255,
		255,
		255
	] : input.bgColor, "Initial Lua background color");
	return {
		source: input.source,
		document,
		selection,
		range,
		fgColor,
		bgColor,
		params: JSON.parse(JSON.stringify(params)),
		activeFrameId: input.activeFrameId,
		activeLayerId: input.activeLayerId,
		timeoutMs,
		instructionLimit
	};
}
//#endregion
//#region app/lua-dialog-schema.mjs
/** Data-only Dialog boundary. No Lua callbacks, DOM, or JavaScript objects cross it. */
const LUA_DIALOG_LIMITS = Object.freeze({
	controls: 64,
	bytes: 65536,
	requests: 32,
	waitMs: 12e4,
	totalWaitMs: 3e5
});
const own$1 = (object, key) => Object.prototype.hasOwnProperty.call(object, key);
const record = (value) => value && typeof value === "object" && !Array.isArray(value) && [Object.prototype, null].includes(Object.getPrototypeOf(value));
const fail$4 = (text) => {
	throw Error(`Lua Dialog: ${text}`);
};
function object(value, label) {
	if (!record(value)) fail$4(`${label} must be an object.`);
	return value;
}
function keys(value, allowed, label) {
	for (const key of Object.keys(value)) if (!allowed.includes(key)) fail$4(`Unsupported ${label} property: ${key}.`);
}
function text(value, label, max = 512) {
	if (typeof value !== "string" || new TextEncoder().encode(value).length > max || value.includes("\0")) fail$4(`${label} must be text of at most ${max} bytes.`);
	return value;
}
function bool(value, label, fallback = false) {
	if (value === void 0) return fallback;
	if (typeof value !== "boolean") fail$4(`${label} must be a boolean.`);
	return value;
}
function number$2(value, label, integer = false) {
	if (!Number.isFinite(value) || Math.abs(value) > 1e9 || integer && !Number.isInteger(value)) fail$4(`${label} must be ${integer ? "an integer" : "a finite number"} within ±1000000000.`);
	return value;
}
function color(value) {
	if (!Array.isArray(value) || value.length !== 4 || value.some((n) => !Number.isInteger(n) || n < 0 || n > 255)) fail$4("Color must contain four RGBA bytes.");
	return [...value];
}
function size(value) {
	let serialized;
	try {
		serialized = JSON.stringify(value);
	} catch {
		fail$4("Dialog data must be serializable.");
	}
	if (!serialized || new TextEncoder().encode(serialized).length > LUA_DIALOG_LIMITS.bytes) fail$4("Dialog data exceeds 64 KiB.");
}
const dataTypes = new Set([
	"entry",
	"number",
	"slider",
	"check",
	"combobox",
	"color",
	"button",
	"label"
]);
function validateDialogSchema(input) {
	object(input, "schema");
	size(input);
	keys(input, ["title", "controls"], "schema");
	const controls = Array.isArray(input.controls) ? input.controls : record(input.controls) && !Object.keys(input.controls).length ? [] : fail$4("Controls must be an array.");
	if (controls.length > LUA_DIALOG_LIMITS.controls) fail$4("A dialog supports at most 64 controls.");
	const seen = /* @__PURE__ */ new Set(), ids = /* @__PURE__ */ new Set();
	return {
		title: text(input.title ?? "", "title"),
		controls: controls.map((raw) => {
			object(raw, "control");
			keys(raw, [
				"key",
				"id",
				"type",
				"label",
				"text",
				"enabled",
				"visible",
				"focus",
				"hexpand",
				"vexpand",
				"value",
				"min",
				"max",
				"decimals",
				"options",
				"callback",
				"always"
			], "control");
			if (!dataTypes.has(raw.type) && !["separator", "newrow"].includes(raw.type)) fail$4(`Unsupported control: ${String(raw.type)}.`);
			const key = text(raw.key, "control key", 80);
			if (seen.has(key) || !/^w[1-9]\d*$/.test(key)) fail$4("Control keys must be unique internal widget identifiers.");
			seen.add(key);
			const control = {
				key,
				type: raw.type,
				label: text(raw.label ?? "", "label"),
				text: text(raw.text ?? "", "text", raw.type === "entry" ? 16384 : 512),
				enabled: bool(raw.enabled, "enabled", true),
				visible: bool(raw.visible, "visible", true),
				focus: bool(raw.focus, "focus"),
				hexpand: bool(raw.hexpand, "hexpand", true),
				vexpand: bool(raw.vexpand, "vexpand")
			};
			if (raw.id !== void 0) {
				const id = text(raw.id, "id", 128);
				if (!id || ids.has(id) || [
					"__proto__",
					"constructor",
					"prototype"
				].includes(id)) fail$4("Widget IDs must be unique nonempty safe strings.");
				ids.add(id);
				control.id = id;
			}
			if (raw.type === "entry") control.value = text(raw.value ?? "", "entry", 16384);
			if (raw.type === "label") control.value = text(raw.value ?? raw.text ?? "", "label text");
			if (raw.type === "number") {
				control.decimals = number$2(raw.decimals ?? 0, "decimals", true);
				if (control.decimals < 0 || control.decimals > 6) fail$4("Number fields support 0–6 decimal places.");
				const factor = 10 ** control.decimals;
				control.value = Math.round(number$2(raw.value ?? 0, "number") * factor) / factor;
			}
			if (raw.type === "slider") {
				control.min = number$2(raw.min ?? 0, "minimum", true);
				control.max = number$2(raw.max ?? 100, "maximum", true);
				if (control.min > control.max) fail$4("Slider minimum exceeds maximum.");
				control.value = number$2(raw.value ?? control.min, "slider", true);
				if (control.value < control.min || control.value > control.max) fail$4("Slider value is outside its range.");
			}
			if (["check", "button"].includes(raw.type)) control.value = bool(raw.value, "selected");
			if (raw.type === "button") control.callback = bool(raw.callback, "button callback");
			if (raw.type === "newrow") control.always = bool(raw.always, "always");
			if (raw.type === "color") control.value = color(raw.value ?? [
				0,
				0,
				0,
				255
			]);
			if (raw.type === "combobox") {
				if (!Array.isArray(raw.options) || !raw.options.length || raw.options.length > 128) fail$4("Combobox requires 1–128 options.");
				control.options = raw.options.map((option) => text(option, "option"));
				control.value = text(raw.value ?? control.options[0], "selected option");
				if (!control.options.includes(control.value)) fail$4("Combobox selection is not an available option.");
			}
			return control;
		})
	};
}
function validateDialogResponse(input, schema) {
	object(input, "response");
	size(input);
	keys(input, [
		"action",
		"button",
		"values"
	], "response");
	if (!["button", "close"].includes(input.action)) fail$4("Response action must be button or close.");
	const controls = new Map(schema.controls.map((control) => [control.key, control]));
	const button = input.action === "button" ? controls.get(input.button) : null;
	if (input.action === "button" && (!button || button.type !== "button" || !button.visible || !button.enabled)) fail$4("The response button is unavailable.");
	if (input.action === "close" && input.button !== void 0) fail$4("A close response cannot press a button.");
	const supplied = input.values ?? {};
	object(supplied, "values");
	for (const key of Object.keys(supplied)) if (!controls.has(key)) fail$4(`Unknown response control: ${key}.`);
	const values = {};
	for (const control of schema.controls) {
		let value = control.value;
		if (control.type === "button") value = control.key === button?.key;
		if (own$1(supplied, control.key)) {
			if ([
				"button",
				"label",
				"separator",
				"newrow"
			].includes(control.type) || !control.enabled || !control.visible) fail$4("The response cannot change a disabled, hidden or read-only control.");
			value = supplied[control.key];
			if (control.type === "entry") value = text(value, "entry", 16384);
			if (control.type === "number") {
				value = number$2(value, "number");
				const factor = 10 ** control.decimals;
				value = Math.round(value * factor) / factor;
			}
			if (control.type === "slider") {
				value = number$2(value, "slider", true);
				if (value < control.min || value > control.max) fail$4("Slider response is outside its range.");
			}
			if (control.type === "check") value = bool(value, "check");
			if (control.type === "combobox") {
				value = text(value, "option");
				if (!control.options.includes(value)) fail$4("Combobox response is not an available option.");
			}
			if (control.type === "color") value = color(value);
		}
		if (own$1(supplied, control.key)) values[control.key] = structuredClone(value);
	}
	return {
		action: input.action,
		...button ? { button: button.key } : {},
		values
	};
}
//#endregion
//#region app/lua-worker-controller.mjs
/** Host-side lifecycle shared by browser and Node. Results remain staged until
* completion; isCurrent additionally rejects stale editor context at every handoff. */
function createLuaWorkerController(request, { postMessage, terminate, signal, onDialog, onCommand, isCurrent, dialogWaitMs = LUA_DIALOG_LIMITS.waitMs } = {}) {
	if (!Number.isSafeInteger(dialogWaitMs) || dialogWaitMs < 50 || dialogWaitMs > LUA_DIALOG_LIMITS.totalWaitMs) throw Error("Lua dialog wait limit must be 50–300000 milliseconds.");
	const plugin = request.plugin == null ? null : validatePluginOptions(request.plugin);
	if (plugin && typeof onCommand !== "function") throw Error("Package commands require an explicit interactive host.");
	let packageRequested = false, chosenCommand;
	let settled = false, remaining = request.timeoutMs, activeStarted, timer, waitTimer, pending = null, serial = 0, waited = 0;
	let resolve, reject;
	const promise = new Promise((yes, no) => {
		resolve = yes;
		reject = no;
	});
	const now = () => globalThis.performance?.now() ?? Date.now();
	const current = () => {
		if (isCurrent && isCurrent() !== true) throw Error("The editor changed while Lua was running. No edits were committed.");
	};
	function finish(error, result) {
		if (settled) return;
		settled = true;
		clearTimeout(timer);
		clearTimeout(waitTimer);
		pending?.abort.abort();
		pending = null;
		signal?.removeEventListener("abort", abort);
		terminate();
		if (error) reject(error);
		else try {
			current();
			const validated = validateLuaResult(result, request.document);
			if (plugin) {
				if (!chosenCommand) throw Error("The package returned before a command was chosen.");
				validated.plugin = validatePluginResult(result.plugin, plugin, chosenCommand);
			} else if (result.plugin !== void 0) throw Error("Unsolicited package result from a standalone script.");
			resolve(validated);
		} catch (error) {
			reject(error);
		}
	}
	const abort = () => finish(Error("Lua script cancelled."));
	function arm() {
		activeStarted = now();
		timer = setTimeout(() => finish(Error("Lua execution time limit exceeded. No edits were committed.")), Math.max(0, remaining));
	}
	function show(message) {
		const packageChoice = message.type === "plugin-command-request";
		if (packageChoice) {
			if (!plugin || typeof onCommand !== "function") throw Error("Package commands require an explicit interactive host.");
			if (pending || packageRequested || message.id !== 1) throw Error("Invalid or out-of-order package command request.");
		} else {
			if (typeof onDialog !== "function") throw Error("Dialog requires an interactive UI host; it is unavailable in headless Lua execution.");
			if (pending || message.id !== serial + 1 || serial >= LUA_DIALOG_LIMITS.requests) throw Error("Invalid or out-of-order Lua dialog request.");
		}
		const schema = packageChoice ? validatePluginCatalog(message.catalog, plugin) : validateDialogSchema(message.dialog);
		current();
		remaining -= now() - activeStarted;
		clearTimeout(timer);
		if (remaining <= 0) throw Error("Lua execution time limit exceeded. No edits were committed.");
		const available = Math.min(dialogWaitMs, LUA_DIALOG_LIMITS.totalWaitMs - waited);
		if (available <= 0) throw Error("Lua dialog waiting limit exceeded. No edits were committed.");
		if (packageChoice) packageRequested = true;
		else serial = message.id;
		const waiting = {
			id: message.id,
			kind: packageChoice ? "package-command" : "dialog",
			started: now(),
			allowed: available,
			abort: new AbortController()
		};
		pending = waiting;
		waitTimer = setTimeout(() => finish(Error("Lua dialog waiting limit exceeded. No edits were committed.")), available);
		Promise.resolve().then(() => {
			if (settled || pending !== waiting) return;
			current();
			return (packageChoice ? onCommand : onDialog)(structuredClone(schema), {
				signal: waiting.abort.signal,
				requestId: waiting.id
			});
		}).then((response) => {
			if (settled || pending !== waiting) return;
			current();
			const data = packageChoice ? validatePluginChoice(response, schema) : validateDialogResponse(response, schema);
			if (packageChoice && data.action === "cancel") {
				finish(Error("Package command session cancelled. No edits were committed."));
				return;
			}
			if (now() - waiting.started >= waiting.allowed) throw Error("Lua dialog waiting limit exceeded. No edits were committed.");
			if (packageChoice) chosenCommand = data.commandId;
			waited += now() - waiting.started;
			clearTimeout(waitTimer);
			pending = null;
			waiting.abort.abort();
			arm();
			postMessage({
				type: packageChoice ? "plugin-command-response" : "dialog-response",
				id: waiting.id,
				response: data
			});
		}).catch((error) => finish(error instanceof Error ? error : Error(String(error))));
	}
	function message(value) {
		if (settled) return;
		try {
			if (value?.type === "dialog-request" || value?.type === "plugin-command-request") {
				show(value);
				return;
			}
			if (pending) throw Error("Lua worker returned output while a dialog or package response was pending.");
			if (value?.ok === true) {
				if (now() - activeStarted >= remaining) throw Error("Lua execution time limit exceeded. No edits were committed.");
				finish(null, value.result);
			} else finish(Error(value?.error || "Lua execution failed."));
		} catch (error) {
			finish(error);
		}
	}
	arm();
	signal?.addEventListener("abort", abort, { once: true });
	if (signal?.aborted) abort();
	return {
		promise,
		message,
		error: (error) => finish(error instanceof Error ? error : Error(String(error))),
		exit: (code) => finish(Error(`Lua worker exited before returning a result (${code}).`))
	};
}
//#endregion
//#region app/lua-runner-node.mjs
/** Real Lua 5.4, isolated from the editor. Without an explicit trusted onDialog
* host this remains headless. The CLI never supplies a dialog host. */
function runLuaScript(input, { wasmUri, workerUrl = new URL("./lua-node-worker.mjs", import.meta.url), onDialog, onCommand, plugin, isCurrent, dialogWaitMs } = {}) {
	const request = luaRequest(input), signal = input.signal;
	if (plugin !== void 0) {
		if (typeof onCommand !== "function") return Promise.reject(Error("Package commands require an explicit interactive host."));
		request.plugin = validatePluginOptions(plugin);
	}
	if (signal?.aborted) return Promise.reject(/* @__PURE__ */ new Error("Lua script cancelled."));
	const worker = new Worker(workerUrl, {
		workerData: {
			request,
			wasmUri,
			dialogs: typeof onDialog === "function"
		},
		execArgv: [],
		resourceLimits: {
			maxOldGenerationSizeMb: 128,
			maxYoungGenerationSizeMb: 16,
			stackSizeMb: 4
		}
	});
	let controller;
	try {
		controller = createLuaWorkerController(request, {
			signal,
			onDialog,
			onCommand,
			plugin,
			isCurrent,
			dialogWaitMs,
			postMessage: (message) => worker.postMessage(message),
			terminate: () => {
				worker.terminate();
			}
		});
	} catch (error) {
		worker.terminate();
		return Promise.reject(error);
	}
	worker.on("message", controller.message);
	worker.once("error", controller.error);
	worker.once("exit", controller.exit);
	return controller.promise;
}
//#endregion
//#region app/export-grid.mjs
/** Bounded sheet cell geometry. Original implementation from recorded CLI output. */
const PIXEL_LIMIT$1 = 64 * 1024 * 1024;
const CELL_LIMIT = 32768;
const fail$3 = (message) => {
	throw Error(message);
};
function parseExportGrid(value) {
	if (value == null) return null;
	const parts = typeof value === "string" ? value.split(",").map(Number) : Array.isArray(value) ? value : [
		value.x,
		value.y,
		value.width ?? value.w,
		value.height ?? value.h
	];
	if (parts.length !== 4 || !parts.every(Number.isSafeInteger) || Math.abs(parts[0]) > 2147483647 || Math.abs(parts[1]) > 2147483647 || parts[2] < 1 || parts[3] < 1 || parts[2] > 65535 || parts[3] > 65535 || parts[2] * parts[3] > PIXEL_LIMIT$1) fail$3("Grid requires x,y,width,height with integer origins and positive cell dimensions within the export limits.");
	return {
		x: parts[0],
		y: parts[1],
		width: parts[2],
		height: parts[3]
	};
}
/** Repeat the grid to the first cell containing canvas origin. Leading cells may
* extend outside the canvas; incomplete right/bottom cells are omitted. Grid
* dimensions are measured on the scaled sprite and do not scale themselves. */
function exportGridCells(width, height, value) {
	if (![width, height].every((n) => Number.isSafeInteger(n) && n > 0) || width * height > PIXEL_LIMIT$1) fail$3("Grid canvas exceeds the export pixel limit.");
	const grid = parseExportGrid(value) ?? {
		x: 0,
		y: 0,
		width: 16,
		height: 16
	};
	const origin = (position, size) => {
		const remainder = position % size;
		return remainder > 0 ? remainder - size : remainder || 0;
	};
	const x = origin(grid.x, grid.width), y = origin(grid.y, grid.height);
	const columns = Math.floor((width - x) / grid.width), rows = Math.floor((height - y) / grid.height), count = columns * rows;
	if (count > CELL_LIMIT || count * grid.width * grid.height > PIXEL_LIMIT$1) fail$3("Grid export exceeds the total pixel or cell limit; use larger cells or export smaller batches.");
	return Array.from({ length: count }, (_, index) => {
		const column = index % columns, row = Math.floor(index / columns);
		return {
			index,
			column,
			row,
			columns,
			rows,
			definition: { ...grid },
			bounds: {
				x: x + column * grid.width,
				y: y + row * grid.height,
				width: grid.width,
				height: grid.height
			}
		};
	});
}
/** Render the complete grid extent, including off-canvas cel pixels in leading
* cells. Translate just the selected frame so inherited palettes remain intact.
* This temporary view shares pixel arrays and never mutates source geometry. */
function exportGridCanvas(document, frameId, cells) {
	if (!cells.length) return null;
	const first = cells[0], { x, y, width: cellWidth, height: cellHeight } = first.bounds;
	const width = first.columns * cellWidth, height = first.rows * cellHeight;
	if (!Number.isSafeInteger(width * height) || width * height > PIXEL_LIMIT$1) fail$3("Grid render exceeds the export pixel limit.");
	return {
		x,
		y,
		document: exportRegionDocument(document, frameId, {
			x,
			y,
			width,
			height
		})
	};
}
//#endregion
//#region app/frame-traversal.mjs
/*!
* Modified JavaScript adaptation of Aseprite Document Library playback.cpp,
* playback.h and tag ordering from tags.cpp (v1.3.18.5).
* Copyright (c) 2021-2024 Igara Studio S.A.
* Copyright (c) 2001-2018 David Capello
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
* OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE. Full origin and modification notes: docs/playback-NOTICES.txt.
*/
const MODES = [
	"all",
	"loop",
	"without-tags",
	"once",
	"stopped"
];
const DIRECTIONS$1 = [
	"forward",
	"reverse",
	"pingpong",
	"pingpong_reverse"
];
const FRAME_LIMIT = 32768, TAG_LIMIT = 1024, WORK_LIMIT = 1048576;
const fail$2 = (message) => {
	throw new Error(message);
};
const integer = (value, min, max, label) => Number.isSafeInteger(value) && value >= min && value <= max ? value : fail$2(`${label} must be an integer from ${min} to ${max}.`);
const pingpong = (tag) => tag.direction === "pingpong" || tag.direction === "pingpong_reverse";
const contains = (tag, frame) => frame >= tag.from && frame <= tag.to;
/** Stateful, allocation-bounded native tag traversal; indices are zero-based.
* all = finite export, loop = editor loop, without-tags = timeline loop,
* once = one traversal (ignores subtags/repeat counts), stopped = no movement.
* An active tag in loop mode repeats indefinitely, as in native editor playback.
* next(delta) is bounded to 32768 steps per call. Snapshots are detached values.
*/
function createFramePlayback({ frameCount, tags = [], initialFrame = 0, mode = "loop", activeTagId = null, forward = 1 } = {}) {
	frameCount = integer(frameCount, 1, FRAME_LIMIT, "Frame count");
	initialFrame = integer(initialFrame, 0, frameCount - 1, "Initial frame");
	if (!MODES.includes(mode)) fail$2("Unknown playback mode.");
	if (forward !== 1 && forward !== -1) fail$2("Playback direction must be 1 or -1.");
	if (!Array.isArray(tags) || tags.length > TAG_LIMIT) fail$2(`Playback supports at most ${TAG_LIMIT} tags.`);
	const ids = /* @__PURE__ */ new Set();
	tags = tags.map((tag, i) => {
		const id = tag.id ?? String(i);
		if (typeof id !== "string" && !Number.isSafeInteger(id) || ids.has(id)) fail$2("Playback tag IDs must be unique strings or integers.");
		ids.add(id);
		const from = integer(tag.from, 0, frameCount - 1, "Tag first frame");
		const to = integer(tag.to, from, frameCount - 1, "Tag last frame");
		if (!DIRECTIONS$1.includes(tag.direction ?? "forward")) fail$2("Unknown tag direction.");
		return {
			id,
			from,
			to,
			direction: tag.direction ?? "forward",
			repeat: integer(tag.repeat ?? 0, 0, 65535, "Tag repeat")
		};
	}).sort((a, b) => a.from - b.from || b.to - a.to);
	const active = activeTagId == null ? null : tags.find((tag) => tag.id === activeTagId);
	if (activeTagId != null && !active) fail$2("Unknown active playback tag.");
	let frame = initialFrame, playMode = mode, work = 0;
	const playing = [], played = /* @__PURE__ */ new Set();
	function tick() {
		if (++work > WORK_LIMIT) fail$2("Tag traversal exceeds the per-step work limit.");
	}
	const current = () => playing.at(-1);
	const tag = () => current()?.tag;
	const parentForward = () => current()?.forward ?? forward;
	const first = (t) => current().forward < 0 ? t.to : t.from;
	const last = (t) => current().forward > 0 ? t.to : t.from;
	function stop() {
		if (playMode === "all" || playMode === "once") frame = initialFrame;
		playMode = "stopped";
	}
	function add(t, rewind, direction) {
		tick();
		if (playing.length >= TAG_LIMIT) fail$2("Tag traversal stack exceeds its limit.");
		const item = {
			tag: t,
			forward: direction * (t.direction === "forward" || t.direction === "pingpong" ? 1 : -1),
			repeat: t.repeat > 0 ? t.repeat : pingpong(t) ? 2 : 1,
			rewind,
			delayedDelete: null,
			removeThese: []
		};
		if (rewind) {
			let delayed = current();
			while (delayed.delayedDelete) {
				tick();
				delayed = delayed.delayedDelete;
			}
			delayed.delayedDelete = item;
			item.removeThese.push(...delayed.removeThese, delayed.tag);
			delayed.removeThese.length = 0;
			let at = playing.length - 1;
			while (at > 0 && playing[at].tag !== delayed.tag) {
				tick();
				--at;
			}
			playing.splice(at, 0, item);
		} else playing.push(item);
		played.add(t);
	}
	function enter(delta, firstTime, depth = 0) {
		tick();
		if (depth > 128) fail$2("Tag traversal nesting exceeds 128 levels.");
		if (playMode !== "all" && playMode !== "loop") return;
		const active = tag(), enteringFrame = frame, direction = parentForward();
		for (const t of tags) {
			tick();
			if (!contains(t, enteringFrame) || played.has(t)) continue;
			if (active && (active.to < t.to || active.from > t.from)) add(t, true, 1);
			else {
				add(t, false, direction);
				if (!firstTime) {
					frame = first(t);
					if (enteringFrame !== frame) enter(delta, false, depth + 1);
				}
			}
		}
	}
	function decrement(delta) {
		while (true) {
			tick();
			const t = tag(), item = current();
			if (!item) fail$2("Invalid tag traversal state.");
			if (item.repeat > 1) {
				--item.repeat;
				frame = first(t);
				return t.to > t.from;
			}
			if (!item.delayedDelete) {
				for (const other of item.removeThese) played.delete(other);
				played.delete(t);
			}
			playing.pop();
			const direction = parentForward();
			let next = current()?.rewind ? first(tag()) : delta * direction < 0 ? t.from - 1 : t.to + 1;
			if (next < 0 || next >= frameCount) {
				if (playMode === "all") {
					stop();
					return false;
				}
				if (next < 0) if (!current()) next = frameCount - 1;
				else if (current().repeat > 1) {
					if (tag().direction === "pingpong_reverse") current().forward *= -1;
					--current().repeat;
					next = t.to + 1;
				} else continue;
				else {
					if (!current() && t.direction === "pingpong_reverse" && t.from === 0 && t.to === frameCount - 1) {
						frame = frameCount - 1;
						enter(delta, false);
						if (playing.length > 1) {
							current().forward *= -1;
							frame = first(tag());
						}
						return false;
					}
					if (current() && t.to === tag().to) {
						if (current().repeat <= 1) continue;
						if (pingpong(tag())) {
							current().forward *= -1;
							next = t.from - 1;
						} else if (tag().direction === "forward") {
							--current().repeat;
							next = tag().from;
						} else next = 0;
					} else next = 0;
				}
			}
			frame = next;
			if (tag()) {
				if (contains(tag(), frame)) return false;
			} else {
				if (playMode === "loop" && pingpong(t) && t.from === 0 && t.to === frameCount - 1) add(t, false, parentForward());
				return false;
			}
		}
	}
	function exit(delta) {
		tick();
		if (playMode === "all" || playMode === "loop") {
			const t = tag();
			if (t && contains(t, frame)) {
				if (!pingpong(t) && delta > 0 && frame === last(t)) {
					decrement(delta);
					return false;
				}
				if (pingpong(t) && frame === last(t)) {
					current().forward *= -1;
					return decrement(delta);
				}
				if (playMode === "loop") {
					if (delta < 0 && frame === first(t)) {
						frame = last(t);
						return false;
					}
					return true;
				}
				return true;
			}
			if (delta > 0 && (frame === frameCount - 1 && forward > 0 || frame === 0 && forward < 0)) {
				if (playMode === "loop") frame = forward > 0 ? 0 : frameCount - 1;
				else stop();
				return false;
			}
			if (delta < 0 && (frame === 0 && forward > 0 || frame === frameCount - 1 && forward < 0)) {
				if (playMode === "loop") frame = forward > 0 ? frameCount - 1 : 0;
				else stop();
				return false;
			}
		} else if (playMode === "once") {
			const t = tag(), direction = parentForward();
			if (t) {
				if (t.direction === "forward" && frame === t.to || t.direction === "reverse" && frame === t.from || t.direction === "pingpong" && frame === t.from && direction < 0 || t.direction === "pingpong_reverse" && frame === t.to && direction > 0) {
					stop();
					return false;
				}
				if (t.direction === "pingpong" && frame === t.to && direction > 0 || t.direction === "pingpong_reverse" && frame === t.from && direction < 0) current().forward *= -1;
			} else if (delta > 0 && frame === frameCount - 1 || delta < 0 && frame === 0) {
				stop();
				return false;
			}
		}
		return true;
	}
	function snapshot() {
		return {
			frame,
			stopped: playMode === "stopped",
			tagId: tag()?.id ?? null
		};
	}
	if (mode === "once") if (active) {
		frame = active.direction === "reverse" || active.direction === "pingpong_reverse" ? active.to : active.from;
		add(active, false, 1);
	} else frame = 0;
	else if (mode === "loop" && active) {
		add(active, false, 1);
		current().repeat = Infinity;
	}
	enter(initialFrame, true);
	return Object.freeze({
		snapshot,
		stop() {
			stop();
			return snapshot();
		},
		next(delta = 1) {
			integer(delta, -FRAME_LIMIT, FRAME_LIMIT, "Playback step");
			work = 0;
			const step = delta > 0 ? 1 : -1;
			while (delta !== 0 && playMode !== "stopped") {
				if (exit(step)) {
					if (playMode === "without-tags") frame = (frame + step + frameCount) % frameCount;
					else if (playMode !== "stopped") frame += step * parentForward();
				}
				enter(step, false);
				delta -= step;
			}
			return snapshot();
		}
	});
}
/** Convert contiguous timeline tags; old discontiguous PixelWall clips have no native range. */
function documentPlaybackTags(document) {
	const byId = new Map(document.frames.map((frame, i) => [frame.id, i]));
	return (document.clips ?? []).flatMap((clip) => {
		const indices = clip.frameIds.map((id) => byId.get(id));
		if (!indices.length || indices.some((index, i) => !Number.isInteger(index) || i > 0 && index !== indices[i - 1] + 1)) return [];
		return [{
			id: clip.id,
			from: indices[0],
			to: indices.at(-1),
			direction: clip.direction ?? "forward",
			repeat: clip.repeat ?? (clip.loop === false ? 1 : 0)
		}];
	});
}
/** Legacy clips keep their explicit frame list and previous endpoint convention. */
function legacyClipFrames(document, clip) {
	const byId = new Map(document.frames.map((frame, index) => [frame.id, index]));
	let indices = clip.frameIds.map((id) => byId.get(id));
	if (indices.some((index) => !Number.isInteger(index))) fail$2("Clip references an unknown frame.");
	if (clip.direction === "reverse" || clip.direction === "pingpong_reverse") indices.reverse();
	if (pingpong(clip)) indices = [...indices, ...indices.slice(1, -1).reverse()];
	return indices;
}
/** Finite native --play-subtags traversal. With false, selection order is unchanged.
* An explicit selected range bypasses this helper in the CLI, matching native.
* clipScope:'contained' is a deliberate UI policy: traverse only tags fully inside
* the selected clip. The default rejects cross-boundary scopes whose native CLI
* output is not a clean traversal of the selected frames.
*/
function exportFrameTraversal(document, { clip = null, playSubtags = false, maxFrames = FRAME_LIMIT, clipScope = "strict", legacyDirection = true } = {}) {
	integer(maxFrames, 1, FRAME_LIMIT, "Maximum output frames");
	if (!["strict", "contained"].includes(clipScope)) fail$2("Unknown clip traversal scope.");
	const tags = documentPlaybackTags(document), selected = clip && tags.find((tag) => tag.id === clip.id);
	if (clip && !selected) {
		const indices = legacyDirection ? legacyClipFrames(document, clip) : clip.frameIds.map((id) => document.frames.findIndex((frame) => frame.id === id));
		if (indices.length > maxFrames) fail$2("Animation traversal exceeds the maximum output frame count.");
		return indices;
	}
	const from = selected?.from ?? 0, to = selected?.to ?? document.frames.length - 1;
	if (!playSubtags) return Array.from({ length: to - from + 1 }, (_, i) => from + i);
	let relevant = tags.filter((tag) => tag.to >= from && tag.from <= to);
	if (selected && relevant.some((tag) => tag.from < from || tag.to > to)) {
		if (clipScope === "strict") fail$2("Subtag export cannot scope tags crossing the selected tag boundary. Select the full timeline, use an explicit frame range, or disable --play-subtags.");
		relevant = relevant.filter((tag) => tag.from >= from && tag.to <= to);
	}
	const playback = createFramePlayback({
		frameCount: to - from + 2,
		initialFrame: 0,
		mode: "all",
		tags: relevant.map((tag) => ({
			...tag,
			from: tag.from - from + 1,
			to: tag.to - from + 1
		}))
	});
	const frames = [];
	for (let state = playback.next(); !state.stopped; state = playback.next()) {
		if (state.frame < 1 || state.frame > to - from + 1) fail$2("Native traversal leaves the selected frame range.");
		if (frames.length >= maxFrames) fail$2("Animation traversal exceeds the maximum output frame count.");
		frames.push(state.frame);
	}
	return frames.map((frame) => from + frame - 1);
}
//#endregion
//#region app/cli-export-plan.mjs
/** Pure export planning. The caller supplies a color manager for custom profiles and owns licensing/I/O. */
const PIXEL_LIMIT = 64 * 1024 * 1024;
const ENTRY_LIMIT = 32768;
const own = (object, key) => Object.prototype.hasOwnProperty.call(object, key);
const copy = (value) => structuredClone(value);
const fail$1 = (message) => {
	throw new Error(message);
};
const list = (value) => value == null ? [] : Array.isArray(value) ? value : [value];
function option(options, ...keys) {
	for (const key of keys) if (own(options, key)) return options[key];
}
function boolean(value, fallback = false) {
	if (value == null) return fallback;
	if (value === true || value === "true" || value === 1) return true;
	if (value === false || value === "false" || value === 0) return false;
	fail$1(`Expected a boolean option, received ${String(value)}.`);
}
function number$1(value, fallback, label, min = 0, max = 16384, integer = true) {
	if (value == null) return fallback;
	const n = Number(value);
	if (!Number.isFinite(n) || integer && !Number.isInteger(n) || n < min || n > max) fail$1(`${label} must be ${integer ? "an integer" : "a number"} from ${min} to ${max}.`);
	return n;
}
function rectangle(value, label) {
	if (value == null) return null;
	const parts = typeof value === "string" ? value.split(",").map(Number) : Array.isArray(value) ? value : [
		value.x,
		value.y,
		value.width ?? value.w,
		value.height ?? value.h
	];
	if (parts.length !== 4 || !parts.every(Number.isSafeInteger) || parts[2] < 1 || parts[3] < 1 || parts[2] * parts[3] > PIXEL_LIMIT) fail$1(`${label} requires x,y,width,height with positive dimensions within the export pixel limit.`);
	return {
		x: parts[0],
		y: parts[1],
		width: parts[2],
		height: parts[3]
	};
}
/** Accepts CLI hyphenated keys and corresponding camelCase keys. Unknown CLI keys are ignored. */
function normalizeExportOptions(options = {}) {
	const mode = options.mode ?? "atlas";
	if (![
		"atlas",
		"sequence",
		"animation"
	].includes(mode)) fail$1("Export mode must be atlas, sequence, or animation.");
	const sheetType = option(options, "sheet-type", "sheetType", "layout") ?? "packed";
	if (![
		"packed",
		"horizontal",
		"vertical",
		"rows",
		"columns",
		"grid"
	].includes(sheetType)) fail$1("Unknown sheet layout.");
	const metadataFormat = option(options, "metadata-format", "metadataFormat", "data-format") ?? (["json-array", "json-hash"].includes(options.format) ? options.format : "json-hash");
	if (!["json-array", "json-hash"].includes(metadataFormat)) fail$1("Metadata format must be json-array or json-hash.");
	const trim = boolean(options.trim), splitGrid = boolean(option(options, "split-grid", "splitGrid"));
	const grid = parseExportGrid(options.grid), orderedInputs = boolean(option(options, "ordered-inputs", "orderedInputs"));
	if (orderedInputs && options.scale != null) fail$1("Ordered scale operations must be associated with their input command sequence.");
	if (orderedInputs && options.crop != null && mode === "atlas") fail$1("Ordered crop is available for PNG, BMP, TGA and GIF exports only.");
	if (grid && !splitGrid) fail$1("--grid requires --split-grid.");
	if (splitGrid && mode !== "atlas") fail$1("--split-grid is available for sheet, atlas and ZIP exports only.");
	if (splitGrid && (options.crop != null || options.slice != null || boolean(option(options, "split-slices", "splitSlices")) || boolean(option(options, "trim-sprite", "trimSprite")))) fail$1("--split-grid cannot be combined with crop, slice, split-slices or trim-sprite selections.");
	return {
		mode,
		metadataFormat,
		sheetType,
		splitGrid,
		grid,
		orderedInputs,
		layer: list(option(options, "layer", "layers", "import-layer")).map(String),
		ignoreLayer: list(option(options, "ignore-layer", "ignoreLayer")).map(String),
		allLayers: boolean(option(options, "all-layers", "allLayers")),
		includeReferences: boolean(option(options, "include-reference-layers", "includeReferences")),
		splitLayers: boolean(option(options, "split-layers", "splitLayers")),
		tag: option(options, "clip", "tag", "frame-tag"),
		splitTags: boolean(option(options, "split-tags", "splitTags")),
		playSubtags: boolean(option(options, "play-subtags", "playSubtags")),
		slice: options.slice,
		splitSlices: boolean(option(options, "split-slices", "splitSlices")),
		frame: options.frame,
		frameRange: option(options, "frame-range", "frameRange"),
		ignoreEmpty: boolean(option(options, "ignore-empty", "ignoreEmpty")),
		filenameFormat: option(options, "filename-format", "filenameFormat"),
		tagnameFormat: option(options, "tagname-format", "tagnameFormat"),
		crop: rectangle(options.crop, "Crop"),
		trim: mode === "atlas" && trim && !splitGrid,
		trimSprite: boolean(option(options, "trim-sprite", "trimSprite")) || mode !== "atlas" && trim,
		scale: validateExportScale(options.scale),
		padding: number$1(option(options, "shape-padding", "shapePadding", "padding"), 0, "Shape padding"),
		border: number$1(option(options, "border-padding", "borderPadding", "border"), 0, "Border padding"),
		innerPadding: number$1(option(options, "inner-padding", "innerPadding"), 0, "Inner padding"),
		extrude: options.extrude === true ? 1 : number$1(options.extrude, 0, "Extrude"),
		powerOfTwo: boolean(option(options, "power-of-two", "power-of-two-size", "powerOfTwo")),
		maxSize: number$1(option(options, "max-size", "maxSize"), 8192, "Maximum atlas size", 1),
		columns: number$1(option(options, "sheet-columns", "columns"), void 0, "Sheet columns", 1, ENTRY_LIMIT),
		rows: number$1(option(options, "sheet-rows", "rows"), void 0, "Sheet rows", 1, ENTRY_LIMIT),
		width: number$1(option(options, "sheet-width", "width"), void 0, "Sheet width", 1),
		height: number$1(option(options, "sheet-height", "height"), void 0, "Sheet height", 1),
		imageName: option(options, "imageName", "image-name") ?? "atlas.png"
	};
}
function fileParts(filename) {
	const fullname = String(filename).replaceAll("\\", "/"), at = fullname.lastIndexOf("/");
	const name = fullname.slice(at + 1), dot = name.lastIndexOf(".");
	return {
		fullname,
		path: at < 0 ? "" : fullname.slice(0, at),
		name,
		title: dot <= 0 ? name : name.slice(0, dot),
		extension: dot <= 0 ? "" : name.slice(dot + 1)
	};
}
/** Numeric suffixes specify both offset and width: frame001 starts at one, padded to three digits. */
function formatExportFilename(template, context) {
	if (typeof template !== "string" || !template.length || template.length > 4096) fail$1("Filename format must be a nonempty string of at most 4096 characters.");
	return template.replace(/\{([^{}]+)\}/g, (token, key) => {
		const match = /^(tagframe|frame|cell|column|row)(\d*)$/.exec(key);
		if (match) {
			if ([
				"cell",
				"column",
				"row"
			].includes(match[1]) && !own(context, match[1])) fail$1(`Unknown filename placeholder ${token}. Grid placeholders require --split-grid.`);
			const base = Number(context[match[1]] ?? 0), suffix = match[2];
			const offset = suffix ? Number(suffix) : 0;
			if (!Number.isSafeInteger(offset)) fail$1("Frame placeholder offset is too large.");
			return String(base + offset).padStart(suffix.length, "0");
		}
		if (!own(context, key)) fail$1(`Unknown filename placeholder ${token}.`);
		return String(context[key] ?? "");
	});
}
function layerContext(document) {
	const byId = new Map(document.layers.map((layer) => [layer.id, layer]));
	const path = (layer) => layer.parentId ? `${path(byId.get(layer.parentId))}/${layer.name}` : layer.name;
	const paths = new Map(document.layers.map((layer) => [layer.id, path(layer)]));
	const ancestors = (layer) => {
		const result = [];
		while (layer?.parentId) {
			layer = byId.get(layer.parentId);
			result.push(layer);
		}
		return result;
	};
	const descendants = (root) => document.layers.filter((layer) => layer.id === root.id || ancestors(layer).some((parent) => parent.id === root.id));
	const resolve = (value) => {
		const layer = byId.get(value) ?? document.layers.find((layer) => paths.get(layer.id) === value) ?? document.layers.find((layer) => layer.name === value);
		if (!layer) fail$1(`Unknown layer: ${value}.`);
		return layer;
	};
	return {
		paths,
		ancestors,
		descendants,
		resolve
	};
}
/** Visibility-only document scopes retain all source frames, preserving inherited frame palettes and slice timing. */
function layerJobs(document, options) {
	const context = layerContext(document), included = options.layer.map(context.resolve), excluded = new Set(options.ignoreLayer.flatMap((value) => context.descendants(context.resolve(value)).map((layer) => layer.id)));
	const chosen = included.length ? new Set(included.flatMap((layer) => context.descendants(layer).map((child) => child.id))) : null;
	const explicitAncestors = new Set(included.flatMap((layer) => [layer, ...context.ancestors(layer)]).map((layer) => layer.id));
	const visible = (layer) => !excluded.has(layer.id) && (options.allLayers || explicitAncestors.has(layer.id) || layer.visible && context.ancestors(layer).every((parent) => parent.visible || explicitAncestors.has(parent.id)));
	const leaves = document.layers.filter((layer) => layer.type !== "group" && (layer.type !== "reference" || options.includeReferences) && (!chosen || chosen.has(layer.id)) && visible(layer));
	return (options.splitLayers ? leaves.map((layer) => ({
		layer,
		leaves: [layer]
	})) : [{
		layer: included.length === 1 ? included[0] : null,
		leaves
	}]).map(({ layer, leaves }) => {
		const ids = new Set(leaves.flatMap((item) => [item, ...context.ancestors(item)]).map((item) => item.id));
		return {
			layer,
			layerPath: layer ? context.paths.get(layer.id) : "",
			document: {
				...document,
				layers: document.layers.map((item) => ({
					...item,
					visible: ids.has(item.id)
				}))
			},
			layerIds: leaves.map((item) => item.id)
		};
	});
}
function frameIndices(document, options, tag) {
	let indices = document.frames.map((_, index) => index);
	if (tag) indices = indices.filter((index) => tag.frameIds.includes(document.frames[index].id));
	if (options.frameRange != null) {
		const range = typeof options.frameRange === "string" ? options.frameRange.split(",").map(Number) : options.frameRange;
		if (!Array.isArray(range) || range.length !== 2 || !range.every(Number.isInteger) || range[0] < 0 || range[1] < range[0] || range[1] >= document.frames.length) fail$1("Frame range must be inclusive zero-based from,to indices inside the document.");
		indices = indices.filter((index) => index >= range[0] && index <= range[1]);
	}
	if (options.frame != null) {
		const byId = document.frames.findIndex((frame) => frame.id === String(options.frame));
		const index = byId >= 0 ? byId : Number(options.frame);
		if (!Number.isInteger(index) || index < 0 || index >= document.frames.length) fail$1(`Unknown frame: ${options.frame}.`);
		indices = indices.filter((value) => value === index);
	}
	if (options.mode !== "atlas" && options.frameRange == null && options.frame == null) indices = exportFrameTraversal(document, {
		clip: tag,
		playSubtags: options.playSubtags,
		legacyDirection: options.mode === "animation",
		maxFrames: ENTRY_LIMIT
	});
	return indices;
}
/** Slice keys persist until their next key; a zero-size key hides the slice until it reappears. */
function sliceBoundsAt(document, slice, frameIndex) {
	if (slice.bounds) return {
		...slice.bounds,
		...slice.pivot ? { pivot: copy(slice.pivot) } : {}
	};
	let current = null, at = -1;
	for (const key of slice.keys ?? []) {
		const index = key.frameId ? document.frames.findIndex((frame) => frame.id === key.frameId) : key.frame ?? 0;
		if (index >= 0 && index <= frameIndex && index >= at) {
			current = key;
			at = index;
		}
	}
	return current && current.width > 0 && current.height > 0 ? copy(current) : null;
}
function cropPixels(entry, rect) {
	if (rect.width * rect.height > PIXEL_LIMIT) fail$1("Cropped output exceeds the pixel limit.");
	const rgba = new Uint8Array(rect.width * rect.height * 4);
	const left = Math.max(0, rect.x), right = Math.min(entry.width, rect.x + rect.width);
	if (right > left) for (let y = Math.max(0, rect.y); y < Math.min(entry.height, rect.y + rect.height); y++) rgba.set(entry.rgba.subarray((y * entry.width + left) * 4, (y * entry.width + right) * 4), ((y - rect.y) * rect.width + left - rect.x) * 4);
	return {
		...entry,
		width: rect.width,
		height: rect.height,
		rgba
	};
}
function scalePixels(entry, scale) {
	if (scale === 1) return entry;
	const width = Math.max(1, Math.floor(entry.width * scale)), height = Math.max(1, Math.floor(entry.height * scale));
	if (width * height > PIXEL_LIMIT) fail$1("Scaled output exceeds the pixel limit.");
	const rgba = new Uint8Array(width * height * 4);
	for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
		const source = (Math.floor(y * entry.height / height) * entry.width + Math.floor(x * entry.width / width)) * 4;
		rgba.set(entry.rgba.subarray(source, source + 4), (y * width + x) * 4);
	}
	return {
		...entry,
		width,
		height,
		rgba
	};
}
function opaqueBounds(entry) {
	let left = entry.width, top = entry.height, right = -1, bottom = -1;
	for (let y = 0; y < entry.height; y++) for (let x = 0; x < entry.width; x++) if (entry.rgba[(y * entry.width + x) * 4 + 3]) {
		left = Math.min(left, x);
		right = Math.max(right, x);
		top = Math.min(top, y);
		bottom = Math.max(bottom, y);
	}
	return right < 0 ? null : {
		x: left,
		y: top,
		width: right - left + 1,
		height: bottom - top + 1
	};
}
function unionBounds(bounds) {
	const nonempty = bounds.filter(Boolean);
	if (!nonempty.length) return {
		x: 0,
		y: 0,
		width: 1,
		height: 1
	};
	const x = Math.min(...nonempty.map((value) => value.x)), y = Math.min(...nonempty.map((value) => value.y));
	return {
		x,
		y,
		width: Math.max(...nonempty.map((value) => value.x + value.width)) - x,
		height: Math.max(...nonempty.map((value) => value.y + value.height)) - y
	};
}
function resolveNamed(values, name, kind) {
	const result = values.find((value) => value.id === name || value.name === name);
	if (!result) fail$1(`Unknown ${kind}: ${String(name)}.`);
	return result;
}
function filenameContext(document, filename, entry, job, ordinal) {
	const tags = document.clips.filter((tag) => tag.frameIds.includes(entry.sourceFrameId)).sort((a, b) => a.frameIds.length - b.frameIds.length);
	const tag = job.tag ?? tags[0];
	const selectedIndices = tag?.frameIds.map((id) => document.frames.findIndex((frame) => frame.id === id)).sort((a, b) => a - b);
	return {
		...fileParts(filename),
		layer: job.layer?.name ?? "",
		layerpath: job.layerPath,
		tag: tag?.name ?? "",
		innertag: tags[0]?.name ?? "",
		outertag: tags.at(-1)?.name ?? "",
		slice: job.slice?.name ?? "",
		frame: ordinal,
		sourceframe: entry.frameIndex,
		tagframe: tag ? selectedIndices.indexOf(entry.frameIndex) : entry.frameIndex,
		duration: entry.durationMs,
		...entry.grid ? {
			cell: entry.grid.index,
			column: entry.grid.column,
			row: entry.grid.row
		} : {}
	};
}
/**
* Build one ordered atlas entry list and separate output jobs from one or more inputs.
* Input options override global options. File names are labels only; this function performs no I/O.
* Atlas frames stay in timeline order. Animation/sequence traversal requires playSubtags; discontiguous animation clips retain legacy direction.
* Trimming and inner padding are already baked; pass atlasOptions.trim=false to the packer.
*/
function planExport(inputs, globalOptions = {}, rendering = {}) {
	if (!Array.isArray(inputs) || !inputs.length || inputs.length > 1024) fail$1("Export requires 1–1024 document inputs.");
	const options = normalizeExportOptions(globalOptions), entries = [], jobs = [], sources = [], usedNames = /* @__PURE__ */ new Set();
	let totalPixels = 0, packedPixels = 0;
	const transformBudget = {
		workPixels: 0,
		steps: 0
	};
	for (let inputIndex = 0; inputIndex < inputs.length; inputIndex++) {
		const input = inputs[inputIndex], sourceDocument = normalizeDocument(input.document), settings = normalizeExportOptions({
			...globalOptions,
			...input.options
		});
		if (input.transforms?.length && !settings.orderedInputs) fail$1("Input scale operations require --ordered-inputs.");
		const prepared = applyOrderedExportScales(sourceDocument, input.transforms, transformBudget);
		const fractional = !Number.isInteger(settings.scale), document = scaleExportDocument(prepared.document, fractional || settings.splitGrid ? settings.scale : 1);
		const gridCells = settings.splitGrid ? exportGridCells(document.width, document.height, settings.grid ?? sourceDocument.metadata?.aseprite?.grid) : [null];
		const sx = document.width / sourceDocument.width, sy = document.height / sourceDocument.height;
		for (const key of [
			"padding",
			"border",
			"extrude",
			"powerOfTwo",
			"maxSize",
			"columns",
			"rows",
			"width",
			"height",
			"sheetType",
			"metadataFormat"
		]) if (settings[key] !== options[key]) fail$1(`${key} must be specified globally for a multi-input atlas.`);
		const filename = String(input.filename ?? `${document.name}.pixelwall`);
		sources.push({
			inputIndex,
			filename,
			document: sourceDocument,
			transforms: prepared.transforms
		});
		const tags = settings.tag != null ? [resolveNamed(document.clips, settings.tag, "tag")] : settings.splitTags && document.clips.length ? document.clips : [null];
		const slices = settings.slice != null ? [resolveNamed(document.slices, settings.slice, "slice")] : settings.splitSlices && document.slices.length ? document.slices : [null];
		for (const layerJob of layerJobs(document, settings)) for (const tag of tags) for (const slice of slices) {
			const job = {
				id: `input-${inputIndex}/job-${jobs.length}`,
				inputIndex,
				filename,
				document: layerJob.document,
				layer: layerJob.layer,
				layerPath: layerJob.layerPath,
				layerIds: layerJob.layerIds,
				tag,
				slice,
				options: settings,
				entries: []
			};
			const indices = frameIndices(document, settings, tag);
			if (settings.splitGrid && (entries.length + indices.length * gridCells.length > ENTRY_LIMIT || totalPixels + indices.length * gridCells.length * (gridCells[0]?.bounds.width ?? 0) * (gridCells[0]?.bounds.height ?? 0) > PIXEL_LIMIT)) fail$1("Grid export exceeds the total pixel or frame limit; export smaller batches.");
			for (const [ordinal, frameIndex] of indices.entries()) {
				const frame = document.frames[frameIndex], sliceBounds = slice ? sliceBoundsAt(document, slice, frameIndex) : null;
				if (slice && !sliceBounds || !gridCells.length) continue;
				const gridCanvas = settings.splitGrid ? exportGridCanvas(layerJob.document, frame.id, gridCells) : null;
				const orderedCrop = settings.orderedInputs && settings.crop ? sliceBounds ?? settings.crop : null;
				const rasterDocument = gridCanvas?.document ?? (orderedCrop ? exportRegionDocument(layerJob.document, frame.id, orderedCrop) : layerJob.document);
				const rgba = renderExportFrame(rasterDocument, frame.id, rendering);
				for (const grid of gridCells) {
					let entry = {
						id: `${job.id}/frame-${ordinal}${grid ? `/cell-${grid.index}` : ""}`,
						inputIndex,
						jobId: job.id,
						sourceFrameId: frame.id,
						frameIndex,
						layerId: layerJob.layer?.id ?? null,
						tagId: tag?.id ?? null,
						sliceId: slice?.id ?? null,
						width: rasterDocument.width,
						height: rasterDocument.height,
						rgba,
						durationMs: frame.durationMs,
						...grid ? { grid } : {}
					};
					const sourceSlice = slice ? sourceDocument.slices.find((value) => value.id === slice.id) : null;
					const sourceRect = prepared.transforms.length && settings.crop ? {
						x: 0,
						y: 0,
						width: sourceDocument.width,
						height: sourceDocument.height
					} : grid && settings.scale === 1 && !prepared.transforms.length ? grid.bounds : (sourceSlice ? sliceBoundsAt(sourceDocument, sourceSlice, frameIndex) : null) ?? settings.crop ?? {
						x: 0,
						y: 0,
						width: sourceDocument.width,
						height: sourceDocument.height
					};
					const rect = grid?.bounds ?? sliceBounds ?? (fractional && settings.crop ? scaleExportRectangle(settings.crop, sx, sy) : settings.crop) ?? {
						x: 0,
						y: 0,
						width: document.width,
						height: document.height
					};
					if (rect.width < 1 || rect.height < 1) continue;
					const rasterRect = grid ? {
						...rect,
						x: rect.x - gridCanvas.x,
						y: rect.y - gridCanvas.y
					} : orderedCrop ? {
						...rect,
						x: 0,
						y: 0
					} : rect;
					entry = scalePixels(cropPixels(entry, rasterRect), fractional || grid ? 1 : settings.scale);
					entry.crop = {
						x: sourceRect.x,
						y: sourceRect.y,
						width: sourceRect.width,
						height: sourceRect.height
					};
					if (fractional || grid || prepared.transforms.length || orderedCrop) entry.scaledCrop = {
						x: rect.x,
						y: rect.y,
						width: rect.width,
						height: rect.height
					};
					entry.scale = settings.scale;
					entry.empty = !opaqueBounds(entry);
					if (settings.ignoreEmpty && entry.empty) continue;
					if (sliceBounds?.pivot) entry.pivot = {
						x: sliceBounds.pivot.x / rect.width,
						y: sliceBounds.pivot.y / rect.height
					};
					entry.filenameContext = filenameContext(document, filename, entry, job, ordinal);
					const defaultName = `${fileParts(filename).title}${layerJob.layer ? ` (${layerJob.layerPath})` : ""}${tag && settings.splitTags ? ` (${tag.name})` : ""}${slice ? ` (${slice.name})` : ""}${indices.length > 1 ? ` ${ordinal}` : ""}${grid ? ` (cell ${grid.index})` : ""}.${fileParts(filename).extension || "pixelwall"}`;
					entry.name = settings.filenameFormat ? formatExportFilename(settings.filenameFormat, entry.filenameContext) : defaultName;
					if (usedNames.has(entry.name)) fail$1(`Duplicate export filename "${entry.name}". Use distinct input names or include {layerpath}, {tag}, {slice}, {frame}, and {cell} for grid exports in --filename-format.`);
					usedNames.add(entry.name);
					totalPixels += entry.width * entry.height;
					if (totalPixels > PIXEL_LIMIT || entries.length + job.entries.length >= ENTRY_LIMIT) fail$1("Export exceeds the total pixel or frame limit; export smaller batches.");
					job.entries.push(entry);
				}
			}
			if (settings.trimSprite && job.entries.length) {
				const bounds = unionBounds(job.entries.map(opaqueBounds));
				job.entries = job.entries.map((entry) => ({
					...cropPixels(entry, bounds),
					spriteCrop: bounds
				}));
			}
			if (settings.mode === "animation" && job.entries.length) {
				const width = Math.max(...job.entries.map((entry) => entry.width)), height = Math.max(...job.entries.map((entry) => entry.height));
				job.entries = job.entries.map((entry) => cropPixels(entry, {
					x: 0,
					y: 0,
					width,
					height
				}));
			}
			job.entries = job.entries.map((entry) => {
				const sourceSize = {
					w: entry.width,
					h: entry.height
				}, bounds = settings.trim ? opaqueBounds(entry) ?? {
					x: 0,
					y: 0,
					width: 1,
					height: 1
				} : {
					x: 0,
					y: 0,
					width: entry.width,
					height: entry.height
				};
				let raster = cropPixels(entry, bounds);
				if (settings.innerPadding) raster = cropPixels(raster, {
					x: -settings.innerPadding,
					y: -settings.innerPadding,
					width: raster.width + settings.innerPadding * 2,
					height: raster.height + settings.innerPadding * 2
				});
				return {
					...raster,
					sourceSize,
					spriteSourceSize: {
						x: bounds.x,
						y: bounds.y,
						w: bounds.width,
						h: bounds.height
					},
					trimmed: bounds.x !== 0 || bounds.y !== 0 || bounds.width !== sourceSize.w || bounds.height !== sourceSize.h,
					innerPadding: settings.innerPadding
				};
			});
			const addedPixels = job.entries.reduce((sum, entry) => sum + entry.width * entry.height, 0);
			packedPixels += addedPixels;
			if (packedPixels > PIXEL_LIMIT) fail$1("Padded export exceeds the total pixel limit.");
			job.frameIds = job.entries.map((entry) => entry.sourceFrameId);
			job.entryIds = job.entries.map((entry) => entry.id);
			entries.push(...job.entries);
			jobs.push(job);
		}
	}
	const layout = ["rows", "columns"].includes(options.sheetType) ? "grid" : options.sheetType;
	const columns = options.sheetType === "columns" && options.rows ? Math.ceil(entries.length / options.rows) : options.columns;
	return {
		entries,
		jobs,
		sources,
		options,
		atlasOptions: {
			trim: false,
			padding: options.padding,
			border: options.border,
			extrude: options.extrude,
			powerOfTwo: options.powerOfTwo,
			maxSize: options.maxSize,
			layout,
			...columns ? { columns } : {},
			...options.width ? { width: options.width } : {},
			...options.height ? { height: options.height } : {},
			scale: options.scale,
			imageName: options.imageName
		},
		metadataFormat: options.metadataFormat
	};
}
/** Rebuild metadata after packing so cropping, padding, source IDs and per-input tags remain unambiguous. */
function buildExportMetadata(result, plan, format = plan.metadataFormat) {
	if (!["json-array", "json-hash"].includes(format)) fail$1("Metadata format must be json-array or json-hash.");
	if (!Array.isArray(result.frames) || result.frames.length !== plan.entries.length) fail$1("Packed metadata frame count does not match the export plan.");
	const byId = new Map(result.frames.filter((frame) => frame.id).map((frame) => [frame.id, frame]));
	const frames = plan.entries.map((entry, index) => {
		const packed = byId.get(entry.id) ?? result.frames[index];
		if (packed.filename !== entry.name) fail$1("Packed metadata frame order or filenames do not match the export plan.");
		return {
			...packed,
			filename: entry.name,
			id: entry.id,
			duration: entry.durationMs,
			sourceSize: copy(entry.sourceSize),
			spriteSourceSize: copy(entry.spriteSourceSize),
			trimmed: entry.trimmed,
			empty: entry.empty,
			source: {
				inputIndex: entry.inputIndex,
				filename: plan.sources[entry.inputIndex].filename,
				frameId: entry.sourceFrameId,
				frame: entry.frameIndex,
				layerId: entry.layerId,
				tagId: entry.tagId,
				sliceId: entry.sliceId,
				crop: copy(entry.crop),
				scale: entry.scale,
				...entry.grid ? { grid: copy(entry.grid) } : {},
				...entry.scaledCrop ? { scaledCrop: copy(entry.scaledCrop) } : {},
				...entry.spriteCrop ? { spriteCrop: copy(entry.spriteCrop) } : {}
			},
			...entry.innerPadding ? { innerPadding: entry.innerPadding } : {}
		};
	});
	const frameTags = [];
	for (const job of plan.jobs) for (const tag of job.tag ? [job.tag] : plan.sources[job.inputIndex].document.clips) {
		const indices = plan.entries.flatMap((entry, index) => entry.jobId === job.id && tag.frameIds.includes(entry.sourceFrameId) ? [index] : []);
		if (!indices.length) continue;
		const context = {
			...fileParts(job.filename),
			tag: tag.name,
			layer: job.layer?.name ?? "",
			layerpath: job.layerPath,
			slice: job.slice?.name ?? ""
		};
		frameTags.push({
			name: job.options.tagnameFormat ? formatExportFilename(job.options.tagnameFormat, context) : tag.name,
			from: indices[0],
			to: indices.at(-1),
			direction: tag.direction,
			repeat: String(tag.repeat ?? 0),
			inputIndex: job.inputIndex,
			jobId: job.id,
			sourceTagId: tag.id,
			frameIndices: indices,
			partial: tag.frameIds.some((id) => !job.frameIds.includes(id))
		});
	}
	const layers = plan.jobs.flatMap((job) => job.document.layers.filter((layer) => layer.visible).map((layer) => ({
		inputIndex: job.inputIndex,
		jobId: job.id,
		id: layer.id,
		name: layer.name,
		parentId: layer.parentId,
		opacity: Math.round(layer.opacity * 255),
		blendMode: layer.blendMode,
		type: layer.type
	})));
	const slices = plan.jobs.flatMap((job) => (job.slice ? [job.slice] : job.document.slices).map((slice) => ({
		name: slice.name,
		id: slice.id,
		inputIndex: job.inputIndex,
		jobId: job.id,
		keys: plan.entries.flatMap((entry, index) => {
			if (entry.jobId !== job.id) return [];
			const key = sliceBoundsAt(job.document, slice, entry.frameIndex);
			if (!key) return [{
				frame: index,
				bounds: {
					x: 0,
					y: 0,
					w: 0,
					h: 0
				}
			}];
			const scale = entry.scaledCrop ? 1 : entry.scale, crop = entry.scaledCrop ?? entry.crop;
			return [{
				frame: index,
				bounds: {
					x: (key.x - crop.x) * scale - (entry.spriteCrop?.x ?? 0),
					y: (key.y - crop.y) * scale - (entry.spriteCrop?.y ?? 0),
					w: key.width * scale,
					h: key.height * scale
				},
				...key.pivot ? { pivot: {
					x: key.pivot.x * scale,
					y: key.pivot.y * scale
				} } : {},
				...key.center ? { center: {
					x: key.center.x * scale,
					y: key.center.y * scale,
					w: (key.center.width ?? key.center.w) * scale,
					h: (key.center.height ?? key.center.h) * scale
				} } : {}
			}];
		})
	})));
	const sourceSlices = plan.sources.flatMap((source) => source.document.slices.map((slice) => ({
		...copy(slice),
		inputIndex: source.inputIndex
	})));
	const meta = {
		...result.meta,
		frameTags,
		layers,
		slices,
		sourceSlices,
		sources: plan.sources.map((source) => ({
			inputIndex: source.inputIndex,
			filename: source.filename,
			documentId: source.document.id,
			...source.transforms.length ? { transforms: copy(source.transforms) } : {}
		}))
	};
	return {
		frames: format === "json-array" ? frames : Object.fromEntries(frames.map((frame) => {
			const { filename, ...value } = frame;
			return [filename, value];
		})),
		meta
	};
}
//#endregion
//#region node_modules/fflate/esm/index.mjs
var require = createRequire("/");
var _a;
try {
	_a = require("worker_threads"), _a.Worker, _a.isMarkedAsUntransferable;
} catch (e) {}
var u8 = Uint8Array, u16 = Uint16Array, i32 = Int32Array;
var fleb = new u8([
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1,
	1,
	1,
	1,
	2,
	2,
	2,
	2,
	3,
	3,
	3,
	3,
	4,
	4,
	4,
	4,
	5,
	5,
	5,
	5,
	0,
	0,
	0,
	0
]);
var fdeb = new u8([
	0,
	0,
	0,
	0,
	1,
	1,
	2,
	2,
	3,
	3,
	4,
	4,
	5,
	5,
	6,
	6,
	7,
	7,
	8,
	8,
	9,
	9,
	10,
	10,
	11,
	11,
	12,
	12,
	13,
	13,
	0,
	0
]);
var clim = new u8([
	16,
	17,
	18,
	0,
	8,
	7,
	9,
	6,
	10,
	5,
	11,
	4,
	12,
	3,
	13,
	2,
	14,
	1,
	15
]);
var freb = function(eb, start) {
	var b = new u16(31);
	for (var i = 0; i < 31; ++i) b[i] = start += 1 << eb[i - 1];
	var r = new i32(b[30]);
	for (var i = 1; i < 30; ++i) for (var j = b[i]; j < b[i + 1]; ++j) r[j] = j - b[i] << 5 | i;
	return {
		b,
		r
	};
};
var _a = freb(fleb, 2), fl = _a.b, revfl = _a.r;
fl[28] = 258, revfl[258] = 28;
var _b = freb(fdeb, 0), fd = _b.b, revfd = _b.r;
var rev = new u16(32768);
for (var i = 0; i < 32768; ++i) {
	var x = (i & 43690) >> 1 | (i & 21845) << 1;
	x = (x & 52428) >> 2 | (x & 13107) << 2;
	x = (x & 61680) >> 4 | (x & 3855) << 4;
	rev[i] = ((x & 65280) >> 8 | (x & 255) << 8) >> 1;
}
var hMap = (function(cd, mb, r) {
	var s = cd.length;
	var i = 0;
	var l = new u16(mb);
	for (; i < s; ++i) if (cd[i]) ++l[cd[i] - 1];
	var le = new u16(mb);
	for (i = 1; i < mb; ++i) le[i] = le[i - 1] + l[i - 1] << 1;
	var co;
	if (r) {
		co = new u16(1 << mb);
		var rvb = 15 - mb;
		for (i = 0; i < s; ++i) if (cd[i]) {
			var sv = i << 4 | cd[i];
			var r_1 = mb - cd[i];
			var v = le[cd[i] - 1]++ << r_1;
			for (var m = v | (1 << r_1) - 1; v <= m; ++v) co[rev[v] >> rvb] = sv;
		}
	} else {
		co = new u16(s);
		for (i = 0; i < s; ++i) if (cd[i]) co[i] = rev[le[cd[i] - 1]++] >> 15 - cd[i];
	}
	return co;
});
var flt = new u8(288);
for (var i = 0; i < 144; ++i) flt[i] = 8;
for (var i = 144; i < 256; ++i) flt[i] = 9;
for (var i = 256; i < 280; ++i) flt[i] = 7;
for (var i = 280; i < 288; ++i) flt[i] = 8;
var fdt = new u8(32);
for (var i = 0; i < 32; ++i) fdt[i] = 5;
var flm = /* @__PURE__ */ hMap(flt, 9, 0), flrm = /* @__PURE__ */ hMap(flt, 9, 1);
var fdm = /* @__PURE__ */ hMap(fdt, 5, 0), fdrm = /* @__PURE__ */ hMap(fdt, 5, 1);
var max = function(a) {
	var m = a[0];
	for (var i = 1; i < a.length; ++i) if (a[i] > m) m = a[i];
	return m;
};
var bits = function(d, p, m) {
	var o = p / 8 | 0;
	return (d[o] | d[o + 1] << 8) >> (p & 7) & m;
};
var bits16 = function(d, p) {
	var o = p / 8 | 0;
	return (d[o] | d[o + 1] << 8 | d[o + 2] << 16) >> (p & 7);
};
var shft = function(p) {
	return (p + 7) / 8 | 0;
};
var slc = function(v, s, e) {
	if (s == null || s < 0) s = 0;
	if (e == null || e > v.length) e = v.length;
	return new u8(v.subarray(s, e));
};
var ec = [
	"unexpected EOF",
	"invalid block type",
	"invalid length/literal",
	"invalid distance",
	"stream finished",
	"no stream handler",
	,
	"no callback",
	"invalid UTF-8 data",
	"extra field too long",
	"date not in range 1980-2099",
	"filename too long",
	"stream finishing",
	"invalid zip data"
];
var err = function(ind, msg, nt) {
	var e = new Error(msg || ec[ind]);
	e.code = ind;
	if (Error.captureStackTrace) Error.captureStackTrace(e, err);
	if (!nt) throw e;
	return e;
};
var inflt = function(dat, st, buf, dict) {
	var sl = dat.length, dl = dict ? dict.length : 0;
	if (!sl || st.f && !st.l) return buf || new u8(0);
	var noBuf = !buf;
	var resize = noBuf || st.i != 2;
	var noSt = st.i;
	if (noBuf) buf = new u8(sl * 3);
	var cbuf = function(l) {
		var bl = buf.length;
		if (l > bl) {
			var nbuf = new u8(Math.max(bl * 2, l));
			nbuf.set(buf);
			buf = nbuf;
		}
	};
	var final = st.f || 0, pos = st.p || 0, bt = st.b || 0, lm = st.l, dm = st.d, lbt = st.m, dbt = st.n;
	var tbts = sl * 8;
	do {
		if (!lm) {
			final = bits(dat, pos, 1);
			var type = bits(dat, pos + 1, 3);
			pos += 3;
			if (!type) {
				var s = shft(pos) + 4, l = dat[s - 4] | dat[s - 3] << 8, t = s + l;
				if (t > sl) {
					if (noSt) err(0);
					break;
				}
				if (resize) cbuf(bt + l);
				buf.set(dat.subarray(s, t), bt);
				st.b = bt += l, st.p = pos = t * 8, st.f = final;
				continue;
			} else if (type == 1) lm = flrm, dm = fdrm, lbt = 9, dbt = 5;
			else if (type == 2) {
				var hLit = bits(dat, pos, 31) + 257, hcLen = bits(dat, pos + 10, 15) + 4;
				var tl = hLit + bits(dat, pos + 5, 31) + 1;
				pos += 14;
				var ldt = new u8(tl);
				var clt = new u8(19);
				for (var i = 0; i < hcLen; ++i) clt[clim[i]] = bits(dat, pos + i * 3, 7);
				pos += hcLen * 3;
				var clb = max(clt), clbmsk = (1 << clb) - 1;
				var clm = hMap(clt, clb, 1);
				for (var i = 0; i < tl;) {
					var r = clm[bits(dat, pos, clbmsk)];
					pos += r & 15;
					var s = r >> 4;
					if (s < 16) ldt[i++] = s;
					else {
						var c = 0, n = 0;
						if (s == 16) n = 3 + bits(dat, pos, 3), pos += 2, c = ldt[i - 1];
						else if (s == 17) n = 3 + bits(dat, pos, 7), pos += 3;
						else if (s == 18) n = 11 + bits(dat, pos, 127), pos += 7;
						while (n--) ldt[i++] = c;
					}
				}
				var lt = ldt.subarray(0, hLit), dt = ldt.subarray(hLit);
				lbt = max(lt);
				dbt = max(dt);
				lm = hMap(lt, lbt, 1);
				dm = hMap(dt, dbt, 1);
			} else err(1);
			if (pos > tbts) {
				if (noSt) err(0);
				break;
			}
		}
		if (resize) cbuf(bt + 131072);
		var lms = (1 << lbt) - 1, dms = (1 << dbt) - 1;
		var lpos = pos;
		for (;; lpos = pos) {
			var c = lm[bits16(dat, pos) & lms], sym = c >> 4;
			pos += c & 15;
			if (pos > tbts) {
				if (noSt) err(0);
				break;
			}
			if (!c) err(2);
			if (sym < 256) buf[bt++] = sym;
			else if (sym == 256) {
				lpos = pos, lm = null;
				break;
			} else {
				var add = sym - 254;
				if (sym > 264) {
					var i = sym - 257, b = fleb[i];
					add = bits(dat, pos, (1 << b) - 1) + fl[i];
					pos += b;
				}
				var d = dm[bits16(dat, pos) & dms], dsym = d >> 4;
				if (!d) err(3);
				pos += d & 15;
				var dt = fd[dsym];
				if (dsym > 3) {
					var b = fdeb[dsym];
					dt += bits16(dat, pos) & (1 << b) - 1, pos += b;
				}
				if (pos > tbts) {
					if (noSt) err(0);
					break;
				}
				if (resize) cbuf(bt + 131072);
				var end = bt + add;
				if (bt < dt) {
					var shift = dl - dt, dend = Math.min(dt, end);
					if (shift + bt < 0) err(3);
					for (; bt < dend; ++bt) buf[bt] = dict[shift + bt];
				}
				for (; bt < end; ++bt) buf[bt] = buf[bt - dt];
			}
		}
		st.l = lm, st.p = lpos, st.b = bt, st.f = final;
		if (lm) final = 1, st.m = lbt, st.d = dm, st.n = dbt;
	} while (!final);
	return bt != buf.length && noBuf ? slc(buf, 0, bt) : buf.subarray(0, bt);
};
var wbits = function(d, p, v) {
	v <<= p & 7;
	var o = p / 8 | 0;
	d[o] |= v;
	d[o + 1] |= v >> 8;
};
var wbits16 = function(d, p, v) {
	v <<= p & 7;
	var o = p / 8 | 0;
	d[o] |= v;
	d[o + 1] |= v >> 8;
	d[o + 2] |= v >> 16;
};
var hTree = function(d, mb) {
	var t = [];
	for (var i = 0; i < d.length; ++i) if (d[i]) t.push({
		s: i,
		f: d[i]
	});
	var s = t.length;
	var t2 = t.slice();
	if (!s) return {
		t: et,
		l: 0
	};
	if (s == 1) {
		var v = new u8(t[0].s + 1);
		v[t[0].s] = 1;
		return {
			t: v,
			l: 1
		};
	}
	t.sort(function(a, b) {
		return a.f - b.f;
	});
	t.push({
		s: -1,
		f: 25001
	});
	var l = t[0], r = t[1], i0 = 0, i1 = 1, i2 = 2;
	t[0] = {
		s: -1,
		f: l.f + r.f,
		l,
		r
	};
	while (i1 != s - 1) {
		l = t[t[i0].f < t[i2].f ? i0++ : i2++];
		r = t[i0 != i1 && t[i0].f < t[i2].f ? i0++ : i2++];
		t[i1++] = {
			s: -1,
			f: l.f + r.f,
			l,
			r
		};
	}
	var maxSym = t2[0].s;
	for (var i = 1; i < s; ++i) if (t2[i].s > maxSym) maxSym = t2[i].s;
	var tr = new u16(maxSym + 1);
	var mbt = ln(t[i1 - 1], tr, 0);
	if (mbt > mb) {
		var i = 0, dt = 0;
		var lft = mbt - mb, cst = 1 << lft;
		t2.sort(function(a, b) {
			return tr[b.s] - tr[a.s] || a.f - b.f;
		});
		for (; i < s; ++i) {
			var i2_1 = t2[i].s;
			if (tr[i2_1] > mb) {
				dt += cst - (1 << mbt - tr[i2_1]);
				tr[i2_1] = mb;
			} else break;
		}
		dt >>= lft;
		while (dt > 0) {
			var i2_2 = t2[i].s;
			if (tr[i2_2] < mb) dt -= 1 << mb - tr[i2_2]++ - 1;
			else ++i;
		}
		for (; i >= 0 && dt; --i) {
			var i2_3 = t2[i].s;
			if (tr[i2_3] == mb) {
				--tr[i2_3];
				++dt;
			}
		}
		mbt = mb;
	}
	return {
		t: new u8(tr),
		l: mbt
	};
};
var ln = function(n, l, d) {
	return n.s == -1 ? Math.max(ln(n.l, l, d + 1), ln(n.r, l, d + 1)) : l[n.s] = d;
};
var lc = function(c) {
	var s = c.length;
	while (s && !c[--s]);
	var cl = new u16(++s);
	var cli = 0, cln = c[0], cls = 1;
	var w = function(v) {
		cl[cli++] = v;
	};
	for (var i = 1; i <= s; ++i) if (c[i] == cln && i != s) ++cls;
	else {
		if (!cln && cls > 2) {
			for (; cls > 138; cls -= 138) w(32754);
			if (cls > 2) {
				w(cls > 10 ? cls - 11 << 5 | 28690 : cls - 3 << 5 | 12305);
				cls = 0;
			}
		} else if (cls > 3) {
			w(cln), --cls;
			for (; cls > 6; cls -= 6) w(8304);
			if (cls > 2) w(cls - 3 << 5 | 8208), cls = 0;
		}
		while (cls--) w(cln);
		cls = 1;
		cln = c[i];
	}
	return {
		c: cl.subarray(0, cli),
		n: s
	};
};
var clen = function(cf, cl) {
	var l = 0;
	for (var i = 0; i < cl.length; ++i) l += cf[i] * cl[i];
	return l;
};
var wfblk = function(out, pos, dat) {
	var s = dat.length;
	var o = shft(pos + 2);
	out[o] = s & 255;
	out[o + 1] = s >> 8;
	out[o + 2] = out[o] ^ 255;
	out[o + 3] = out[o + 1] ^ 255;
	for (var i = 0; i < s; ++i) out[o + i + 4] = dat[i];
	return (o + 4 + s) * 8;
};
var wblk = function(dat, out, final, syms, lf, df, eb, li, bs, bl, p) {
	wbits(out, p++, final);
	++lf[256];
	var _a = hTree(lf, 15), dlt = _a.t, mlb = _a.l;
	var _b = hTree(df, 15), ddt = _b.t, mdb = _b.l;
	var _c = lc(dlt), lclt = _c.c, nlc = _c.n;
	var _d = lc(ddt), lcdt = _d.c, ndc = _d.n;
	var lcfreq = new u16(19);
	for (var i = 0; i < lclt.length; ++i) ++lcfreq[lclt[i] & 31];
	for (var i = 0; i < lcdt.length; ++i) ++lcfreq[lcdt[i] & 31];
	var _e = hTree(lcfreq, 7), lct = _e.t, mlcb = _e.l;
	var nlcc = 19;
	for (; nlcc > 4 && !lct[clim[nlcc - 1]]; --nlcc);
	var flen = bl + 5 << 3;
	var ftlen = clen(lf, flt) + clen(df, fdt) + eb;
	var dtlen = clen(lf, dlt) + clen(df, ddt) + eb + 14 + 3 * nlcc + clen(lcfreq, lct) + 2 * lcfreq[16] + 3 * lcfreq[17] + 7 * lcfreq[18];
	if (bs >= 0 && flen <= ftlen && flen <= dtlen) return wfblk(out, p, dat.subarray(bs, bs + bl));
	var lm, ll, dm, dl;
	wbits(out, p, 1 + (dtlen < ftlen)), p += 2;
	if (dtlen < ftlen) {
		lm = hMap(dlt, mlb, 0), ll = dlt, dm = hMap(ddt, mdb, 0), dl = ddt;
		var llm = hMap(lct, mlcb, 0);
		wbits(out, p, nlc - 257);
		wbits(out, p + 5, ndc - 1);
		wbits(out, p + 10, nlcc - 4);
		p += 14;
		for (var i = 0; i < nlcc; ++i) wbits(out, p + 3 * i, lct[clim[i]]);
		p += 3 * nlcc;
		var lcts = [lclt, lcdt];
		for (var it = 0; it < 2; ++it) {
			var clct = lcts[it];
			for (var i = 0; i < clct.length; ++i) {
				var len = clct[i] & 31;
				wbits(out, p, llm[len]), p += lct[len];
				if (len > 15) wbits(out, p, clct[i] >> 5 & 127), p += clct[i] >> 12;
			}
		}
	} else lm = flm, ll = flt, dm = fdm, dl = fdt;
	for (var i = 0; i < li; ++i) {
		var sym = syms[i];
		if (sym > 255) {
			var len = sym >> 18 & 31;
			wbits16(out, p, lm[len + 257]), p += ll[len + 257];
			if (len > 7) wbits(out, p, sym >> 23 & 31), p += fleb[len];
			var dst = sym & 31;
			wbits16(out, p, dm[dst]), p += dl[dst];
			if (dst > 3) wbits16(out, p, sym >> 5 & 8191), p += fdeb[dst];
		} else wbits16(out, p, lm[sym]), p += ll[sym];
	}
	wbits16(out, p, lm[256]);
	return p + ll[256];
};
var deo = /* @__PURE__ */ new i32([
	65540,
	131080,
	131088,
	131104,
	262176,
	1048704,
	1048832,
	2114560,
	2117632
]);
var et = /* @__PURE__ */ new u8(0);
var dflt = function(dat, lvl, plvl, pre, post, st) {
	var s = st.z || dat.length;
	var o = new u8(pre + s + 5 * (1 + Math.ceil(s / 7e3)) + post);
	var w = o.subarray(pre, o.length - post);
	var lst = st.l;
	var pos = (st.r || 0) & 7;
	if (lvl) {
		if (pos) w[0] = st.r >> 3;
		var opt = deo[lvl - 1];
		var n = opt >> 13, c = opt & 8191;
		var msk_1 = (1 << plvl) - 1;
		var prev = st.p || new u16(32768), head = st.h || new u16(msk_1 + 1);
		var bs1_1 = Math.ceil(plvl / 3), bs2_1 = 2 * bs1_1;
		var hsh = function(i) {
			return (dat[i] ^ dat[i + 1] << bs1_1 ^ dat[i + 2] << bs2_1) & msk_1;
		};
		var syms = new i32(25e3);
		var lf = new u16(288), df = new u16(32);
		var lc_1 = 0, eb = 0, i = st.i || 0, li = 0, wi = st.w || 0, bs = 0;
		for (; i + 2 < s; ++i) {
			var hv = hsh(i);
			var imod = i & 32767, pimod = head[hv];
			prev[imod] = pimod;
			head[hv] = imod;
			if (wi <= i) {
				var rem = s - i;
				if ((lc_1 > 7e3 || li > 24576) && (rem > 423 || !lst)) {
					pos = wblk(dat, w, 0, syms, lf, df, eb, li, bs, i - bs, pos);
					li = lc_1 = eb = 0, bs = i;
					for (var j = 0; j < 286; ++j) lf[j] = 0;
					for (var j = 0; j < 30; ++j) df[j] = 0;
				}
				var l = 2, d = 0, ch_1 = c, dif = imod - pimod & 32767;
				if (rem > 2 && hv == hsh(i - dif)) {
					var maxn = Math.min(n, rem) - 1;
					var maxd = Math.min(32767, i);
					var ml = Math.min(258, rem);
					while (dif <= maxd && --ch_1 && imod != pimod) {
						if (dat[i + l] == dat[i + l - dif]) {
							var nl = 0;
							for (; nl < ml && dat[i + nl] == dat[i + nl - dif]; ++nl);
							if (nl > l) {
								l = nl, d = dif;
								if (nl > maxn) break;
								var mmd = Math.min(dif, nl - 2);
								var md = 0;
								for (var j = 0; j < mmd; ++j) {
									var ti = i - dif + j & 32767;
									var cd = ti - prev[ti] & 32767;
									if (cd > md) md = cd, pimod = ti;
								}
							}
						}
						imod = pimod, pimod = prev[imod];
						dif += imod - pimod & 32767;
					}
				}
				if (d) {
					syms[li++] = 268435456 | revfl[l] << 18 | revfd[d];
					var lin = revfl[l] & 31, din = revfd[d] & 31;
					eb += fleb[lin] + fdeb[din];
					++lf[257 + lin];
					++df[din];
					wi = i + l;
					++lc_1;
				} else {
					syms[li++] = dat[i];
					++lf[dat[i]];
				}
			}
		}
		for (i = Math.max(i, wi); i < s; ++i) {
			syms[li++] = dat[i];
			++lf[dat[i]];
		}
		pos = wblk(dat, w, lst, syms, lf, df, eb, li, bs, i - bs, pos);
		if (!lst) {
			st.r = pos & 7 | w[pos / 8 | 0] << 3;
			pos -= 7;
			st.h = head, st.p = prev, st.i = i, st.w = wi;
		}
	} else {
		for (var i = st.w || 0; i < s + lst; i += 65535) {
			var e = i + 65535;
			if (e >= s) {
				w[pos / 8 | 0] = lst;
				e = s;
			}
			pos = wfblk(w, pos + 1, dat.subarray(i, e));
		}
		st.i = s;
	}
	return slc(o, 0, pre + shft(pos) + post);
};
var crct = /* @__PURE__ */ (function() {
	var t = new Int32Array(256);
	for (var i = 0; i < 256; ++i) {
		var c = i, k = 9;
		while (--k) c = (c & 1 && -306674912) ^ c >>> 1;
		t[i] = c;
	}
	return t;
})();
var crc = function() {
	var c = -1;
	return {
		p: function(d) {
			var cr = c;
			for (var i = 0; i < d.length; ++i) cr = crct[cr & 255 ^ d[i]] ^ cr >>> 8;
			c = cr;
		},
		d: function() {
			return ~c;
		}
	};
};
var adler = function() {
	var a = 1, b = 0;
	return {
		p: function(d) {
			var n = a, m = b;
			var l = d.length | 0;
			for (var i = 0; i != l;) {
				var e = Math.min(i + 2655, l);
				for (; i < e; ++i) m += n += d[i];
				n = (n & 65535) + 15 * (n >> 16), m = (m & 65535) + 15 * (m >> 16);
			}
			a = n, b = m;
		},
		d: function() {
			a %= 65521, b %= 65521;
			return (a & 255) << 24 | (a & 65280) << 8 | (b & 255) << 8 | b >> 8;
		}
	};
};
var dopt = function(dat, opt, pre, post, st) {
	if (!st) {
		st = { l: 1 };
		if (opt.dictionary) {
			var dict = opt.dictionary.subarray(-32768);
			var newDat = new u8(dict.length + dat.length);
			newDat.set(dict);
			newDat.set(dat, dict.length);
			dat = newDat;
			st.w = dict.length;
		}
	}
	return dflt(dat, opt.level == null ? 6 : opt.level, opt.mem == null ? st.l ? Math.ceil(Math.max(8, Math.min(13, Math.log(dat.length))) * 1.5) : 20 : 12 + opt.mem, pre, post, st);
};
var mrg = function(a, b) {
	var o = {};
	for (var k in a) o[k] = a[k];
	for (var k in b) o[k] = b[k];
	return o;
};
var b2 = function(d, b) {
	return d[b] | d[b + 1] << 8;
};
var b4 = function(d, b) {
	return (d[b] | d[b + 1] << 8 | d[b + 2] << 16 | d[b + 3] << 24) >>> 0;
};
var b8 = function(d, b) {
	return b4(d, b) + b4(d, b + 4) * 4294967296;
};
var wbytes = function(d, b, v) {
	for (; v; ++b) d[b] = v, v >>>= 8;
};
var zlh = function(c, o) {
	var lv = o.level, fl = lv == 0 ? 0 : lv < 6 ? 1 : lv == 9 ? 3 : 2;
	c[0] = 120, c[1] = fl << 6 | (o.dictionary && 32);
	c[1] |= 31 - (c[0] << 8 | c[1]) % 31;
	if (o.dictionary) {
		var h = adler();
		h.p(o.dictionary);
		wbytes(c, 2, h.d());
	}
};
var zls = function(d, dict) {
	if ((d[0] & 15) != 8 || d[0] >> 4 > 7 || (d[0] << 8 | d[1]) % 31) err(6, "invalid zlib data");
	if ((d[1] >> 5 & 1) == +!dict) err(6, "invalid zlib data: " + (d[1] & 32 ? "need" : "unexpected") + " dictionary");
	return (d[1] >> 3 & 4) + 2;
};
/**
* Compresses data with DEFLATE without any wrapper
* @param data The data to compress
* @param opts The compression options
* @returns The deflated version of the data
*/
function deflateSync(data, opts) {
	return dopt(data, opts || {}, 0, 0);
}
function inflateSync(data, opts) {
	return inflt(data, { i: 2 }, opts && opts.out, opts && opts.dictionary);
}
/**
* Compress data with Zlib
* @param data The data to compress
* @param opts The compression options
* @returns The zlib-compressed version of the data
*/
function zlibSync(data, opts) {
	if (!opts) opts = {};
	var a = adler();
	a.p(data);
	var d = dopt(data, opts, opts.dictionary ? 6 : 2, 4);
	return zlh(d, opts), wbytes(d, d.length - 4, a.d()), d;
}
function unzlibSync(data, opts) {
	return inflt(data.subarray(zls(data, opts && opts.dictionary), -4), { i: 2 }, opts && opts.out, opts && opts.dictionary);
}
var fltn = function(d, p, t, o) {
	for (var k in d) {
		var val = d[k], n = p + k, op = o;
		if (Array.isArray(val)) op = mrg(o, val[1]), val = val[0];
		if (ArrayBuffer.isView(val)) t[n] = [val, op];
		else {
			t[n += "/"] = [new u8(0), op];
			fltn(val, n, t, o);
		}
	}
};
var te = typeof TextEncoder != "undefined" && /* @__PURE__ */ new TextEncoder();
var td = typeof TextDecoder != "undefined" && /* @__PURE__ */ new TextDecoder();
try {
	td.decode(et, { stream: true });
} catch (e) {}
var dutf8 = function(d) {
	for (var r = "", i = 0;;) {
		var c = d[i++];
		var eb = (c > 127) + (c > 223) + (c > 239);
		if (i + eb > d.length) return {
			s: r,
			r: slc(d, i - 1)
		};
		if (!eb) r += String.fromCharCode(c);
		else if (eb == 3) c = ((c & 15) << 18 | (d[i++] & 63) << 12 | (d[i++] & 63) << 6 | d[i++] & 63) - 65536, r += String.fromCharCode(55296 | c >> 10, 56320 | c & 1023);
		else if (eb & 1) r += String.fromCharCode((c & 31) << 6 | d[i++] & 63);
		else r += String.fromCharCode((c & 15) << 12 | (d[i++] & 63) << 6 | d[i++] & 63);
	}
};
/**
* Converts a string into a Uint8Array for use with compression/decompression methods
* @param str The string to encode
* @param latin1 Whether or not to interpret the data as Latin-1. This should
*               not need to be true unless decoding a binary string.
* @returns The string encoded in UTF-8/Latin-1 binary
*/
function strToU8(str, latin1) {
	if (latin1) {
		var ar_1 = new u8(str.length);
		for (var i = 0; i < str.length; ++i) ar_1[i] = str.charCodeAt(i);
		return ar_1;
	}
	if (te) return te.encode(str);
	var l = str.length;
	var ar = new u8(str.length + (str.length >> 1));
	var ai = 0;
	var w = function(v) {
		ar[ai++] = v;
	};
	for (var i = 0; i < l; ++i) {
		if (ai + 5 > ar.length) {
			var n = new u8(ai + 8 + (l - i << 1));
			n.set(ar);
			ar = n;
		}
		var c = str.charCodeAt(i);
		if (c < 128 || latin1) w(c);
		else if (c < 2048) w(192 | c >> 6), w(128 | c & 63);
		else if (c > 55295 && c < 57344) c = 65536 + (c & 1047552) | str.charCodeAt(++i) & 1023, w(240 | c >> 18), w(128 | c >> 12 & 63), w(128 | c >> 6 & 63), w(128 | c & 63);
		else w(224 | c >> 12), w(128 | c >> 6 & 63), w(128 | c & 63);
	}
	return slc(ar, 0, ai);
}
/**
* Converts a Uint8Array to a string
* @param dat The data to decode to string
* @param latin1 Whether or not to interpret the data as Latin-1. This should
*               not need to be true unless encoding to binary string.
* @returns The original UTF-8/Latin-1 string
*/
function strFromU8(dat, latin1) {
	if (latin1) {
		var r = "";
		for (var i = 0; i < dat.length; i += 16384) r += String.fromCharCode.apply(null, dat.subarray(i, i + 16384));
		return r;
	} else if (td) return td.decode(dat);
	else {
		var _a = dutf8(dat), s = _a.s, r = _a.r;
		if (r.length) err(8);
		return s;
	}
}
var slzh = function(d, b) {
	return b + 30 + b2(d, b + 26) + b2(d, b + 28);
};
var zh = function(d, b, z) {
	var fnl = b2(d, b + 28), efl = b2(d, b + 30), fn = strFromU8(d.subarray(b + 46, b + 46 + fnl), !(b2(d, b + 8) & 2048)), es = b + 46 + fnl;
	var _a = z64hs(d, es, efl, z, b4(d, b + 20), b4(d, b + 24), b4(d, b + 42)), sc = _a[0], su = _a[1], off = _a[2];
	return [
		b2(d, b + 10),
		sc,
		su,
		fn,
		es + efl + b2(d, b + 32),
		off
	];
};
var z64hs = function(d, b, l, z, sc, su, off) {
	var nsc = sc == 4294967295, nsu = su == 4294967295, noff = off == 4294967295, e = b + l;
	var nf = nsc + nsu + noff;
	if (z && nf) {
		for (; b + 4 < e; b += 4 + b2(d, b + 2)) if (b2(d, b) == 1) return [
			nsc ? b8(d, b + 4 + 8 * nsu) : sc,
			nsu ? b8(d, b + 4) : su,
			noff ? b8(d, b + 4 + 8 * (nsu + nsc)) : off,
			1
		];
		if (z < 2) err(13);
	}
	return [
		sc,
		su,
		off,
		0
	];
};
var exfl = function(ex) {
	var le = 0;
	if (ex) for (var k in ex) {
		var l = ex[k].length;
		if (l > 65535) err(9);
		le += l + 4;
	}
	return le;
};
var wzh = function(d, b, f, fn, u, c, ce, co) {
	var fl = fn.length, ex = f.extra, col = co && co.length;
	var exl = exfl(ex);
	wbytes(d, b, ce != null ? 33639248 : 67324752), b += 4;
	if (ce != null) d[b++] = 20, d[b++] = f.os;
	d[b] = 20, b += 2;
	d[b++] = f.flag << 1 | (c < 0 && 8), d[b++] = u && 8;
	d[b++] = f.compression & 255, d[b++] = f.compression >> 8;
	var dt = new Date(f.mtime == null ? Date.now() : f.mtime), y = dt.getFullYear() - 1980;
	if (y < 0 || y > 119) err(10);
	wbytes(d, b, y << 25 | dt.getMonth() + 1 << 21 | dt.getDate() << 16 | dt.getHours() << 11 | dt.getMinutes() << 5 | dt.getSeconds() >> 1), b += 4;
	if (c != -1) {
		wbytes(d, b, f.crc);
		wbytes(d, b + 4, c < 0 ? -c - 2 : c);
		wbytes(d, b + 8, f.size);
	}
	wbytes(d, b + 12, fl);
	wbytes(d, b + 14, exl), b += 16;
	if (ce != null) {
		wbytes(d, b, col);
		wbytes(d, b + 6, f.attrs);
		wbytes(d, b + 10, ce), b += 14;
	}
	d.set(fn, b);
	b += fl;
	if (exl) for (var k in ex) {
		var exf = ex[k], l = exf.length;
		wbytes(d, b, +k);
		wbytes(d, b + 2, l);
		d.set(exf, b + 4), b += 4 + l;
	}
	if (col) d.set(co, b), b += col;
	return b;
};
var wzf = function(o, b, c, d, e) {
	wbytes(o, b, 101010256);
	wbytes(o, b + 8, c);
	wbytes(o, b + 10, c);
	wbytes(o, b + 12, d);
	wbytes(o, b + 16, e);
};
/**
* Synchronously creates a ZIP file. Prefer using `zip` for better performance
* with more than one file.
* @param data The directory structure for the ZIP archive
* @param opts The main options, merged with per-file options
* @returns The generated ZIP archive
*/
function zipSync(data, opts) {
	if (!opts) opts = {};
	var r = {};
	var files = [];
	fltn(data, "", r, opts);
	var o = 0;
	var tot = 0;
	for (var fn in r) {
		var _a = r[fn], file = _a[0], p = _a[1];
		var compression = p.level == 0 ? 0 : 8;
		var f = strToU8(fn), s = f.length;
		var com = p.comment, m = com && strToU8(com), ms = m && m.length;
		var exl = exfl(p.extra);
		if (s > 65535) err(11);
		var d = compression ? deflateSync(file, p) : file, l = d.length;
		var c = crc();
		c.p(file);
		files.push(mrg(p, {
			size: file.length,
			crc: c.d(),
			c: d,
			f,
			m,
			u: s != fn.length || m && com.length != ms,
			o,
			compression
		}));
		o += 30 + s + exl + l;
		tot += 76 + 2 * (s + exl) + (ms || 0) + l;
	}
	var out = new u8(tot + 22), oe = o, cdl = tot - o;
	for (var i = 0; i < files.length; ++i) {
		var f = files[i];
		wzh(out, f.o, f, f.f, f.u, f.c.length);
		var badd = 30 + f.f.length + exfl(f.extra);
		out.set(f.c, f.o + badd);
		wzh(out, o, f, f.f, f.u, f.c.length, f.o, f.m), o += 16 + badd + (f.m ? f.m.length : 0);
	}
	wzf(out, o, files.length, cdl, oe);
	return out;
}
/**
* Synchronously decompresses a ZIP archive. Prefer using `unzip` for better
* performance with more than one file.
* @param data The raw compressed ZIP file
* @param opts The ZIP extraction options
* @returns The decompressed files
*/
function unzipSync(data, opts) {
	var files = {};
	var e = data.length - 22;
	for (; b4(data, e) != 101010256; --e) if (!e || data.length - e > 65558) err(13);
	var c = b2(data, e + 8);
	if (!c) return {};
	var o = b4(data, e + 16);
	var z = b4(data, e - 20) == 117853008;
	if (z) {
		var ze = b4(data, e - 12);
		z = b4(data, ze) == 101075792;
		if (z) {
			c = b4(data, ze + 32);
			o = b4(data, ze + 48);
		}
	}
	var fltr = opts && opts.filter;
	for (var i = 0; i < c; ++i) {
		var _a = zh(data, o, z), c_2 = _a[0], sc = _a[1], su = _a[2], fn = _a[3], no = _a[4], off = _a[5], b = slzh(data, off);
		o = no;
		if (!fltr || fltr({
			name: fn,
			size: sc,
			originalSize: su,
			compression: c_2
		})) if (!c_2) files[fn] = slc(data, b, b + sc);
		else if (c_2 == 8) files[fn] = inflateSync(data.subarray(b, b + sc), { out: new u8(su) });
		else err(14, "unknown compression type " + c_2);
	}
	return files;
}
const { GifReader, GifWriter } = (/* @__PURE__ */ __toESM((/* @__PURE__ */ __commonJSMin(((exports) => {
	function GifWriter(buf, width, height, gopts) {
		var p = 0;
		var gopts = gopts === void 0 ? {} : gopts;
		var loop_count = gopts.loop === void 0 ? null : gopts.loop;
		var global_palette = gopts.palette === void 0 ? null : gopts.palette;
		if (width <= 0 || height <= 0 || width > 65535 || height > 65535) throw new Error("Width/Height invalid.");
		function check_palette_and_num_colors(palette) {
			var num_colors = palette.length;
			if (num_colors < 2 || num_colors > 256 || num_colors & num_colors - 1) throw new Error("Invalid code/color length, must be power of 2 and 2 .. 256.");
			return num_colors;
		}
		buf[p++] = 71;
		buf[p++] = 73;
		buf[p++] = 70;
		buf[p++] = 56;
		buf[p++] = 57;
		buf[p++] = 97;
		var gp_num_colors_pow2 = 0;
		var background = 0;
		if (global_palette !== null) {
			var gp_num_colors = check_palette_and_num_colors(global_palette);
			while (gp_num_colors >>= 1) ++gp_num_colors_pow2;
			gp_num_colors = 1 << gp_num_colors_pow2;
			--gp_num_colors_pow2;
			if (gopts.background !== void 0) {
				background = gopts.background;
				if (background >= gp_num_colors) throw new Error("Background index out of range.");
				if (background === 0) throw new Error("Background index explicitly passed as 0.");
			}
		}
		buf[p++] = width & 255;
		buf[p++] = width >> 8 & 255;
		buf[p++] = height & 255;
		buf[p++] = height >> 8 & 255;
		buf[p++] = (global_palette !== null ? 128 : 0) | gp_num_colors_pow2;
		buf[p++] = background;
		buf[p++] = 0;
		if (global_palette !== null) for (var i = 0, il = global_palette.length; i < il; ++i) {
			var rgb = global_palette[i];
			buf[p++] = rgb >> 16 & 255;
			buf[p++] = rgb >> 8 & 255;
			buf[p++] = rgb & 255;
		}
		if (loop_count !== null) {
			if (loop_count < 0 || loop_count > 65535) throw new Error("Loop count invalid.");
			buf[p++] = 33;
			buf[p++] = 255;
			buf[p++] = 11;
			buf[p++] = 78;
			buf[p++] = 69;
			buf[p++] = 84;
			buf[p++] = 83;
			buf[p++] = 67;
			buf[p++] = 65;
			buf[p++] = 80;
			buf[p++] = 69;
			buf[p++] = 50;
			buf[p++] = 46;
			buf[p++] = 48;
			buf[p++] = 3;
			buf[p++] = 1;
			buf[p++] = loop_count & 255;
			buf[p++] = loop_count >> 8 & 255;
			buf[p++] = 0;
		}
		var ended = false;
		this.addFrame = function(x, y, w, h, indexed_pixels, opts) {
			if (ended === true) {
				--p;
				ended = false;
			}
			opts = opts === void 0 ? {} : opts;
			if (x < 0 || y < 0 || x > 65535 || y > 65535) throw new Error("x/y invalid.");
			if (w <= 0 || h <= 0 || w > 65535 || h > 65535) throw new Error("Width/Height invalid.");
			if (indexed_pixels.length < w * h) throw new Error("Not enough pixels for the frame size.");
			var using_local_palette = true;
			var palette = opts.palette;
			if (palette === void 0 || palette === null) {
				using_local_palette = false;
				palette = global_palette;
			}
			if (palette === void 0 || palette === null) throw new Error("Must supply either a local or global palette.");
			var num_colors = check_palette_and_num_colors(palette);
			var min_code_size = 0;
			while (num_colors >>= 1) ++min_code_size;
			num_colors = 1 << min_code_size;
			var delay = opts.delay === void 0 ? 0 : opts.delay;
			var disposal = opts.disposal === void 0 ? 0 : opts.disposal;
			if (disposal < 0 || disposal > 3) throw new Error("Disposal out of range.");
			var use_transparency = false;
			var transparent_index = 0;
			if (opts.transparent !== void 0 && opts.transparent !== null) {
				use_transparency = true;
				transparent_index = opts.transparent;
				if (transparent_index < 0 || transparent_index >= num_colors) throw new Error("Transparent color index.");
			}
			if (disposal !== 0 || use_transparency || delay !== 0) {
				buf[p++] = 33;
				buf[p++] = 249;
				buf[p++] = 4;
				buf[p++] = disposal << 2 | (use_transparency === true ? 1 : 0);
				buf[p++] = delay & 255;
				buf[p++] = delay >> 8 & 255;
				buf[p++] = transparent_index;
				buf[p++] = 0;
			}
			buf[p++] = 44;
			buf[p++] = x & 255;
			buf[p++] = x >> 8 & 255;
			buf[p++] = y & 255;
			buf[p++] = y >> 8 & 255;
			buf[p++] = w & 255;
			buf[p++] = w >> 8 & 255;
			buf[p++] = h & 255;
			buf[p++] = h >> 8 & 255;
			buf[p++] = using_local_palette === true ? 128 | min_code_size - 1 : 0;
			if (using_local_palette === true) for (var i = 0, il = palette.length; i < il; ++i) {
				var rgb = palette[i];
				buf[p++] = rgb >> 16 & 255;
				buf[p++] = rgb >> 8 & 255;
				buf[p++] = rgb & 255;
			}
			p = GifWriterOutputLZWCodeStream(buf, p, min_code_size < 2 ? 2 : min_code_size, indexed_pixels);
			return p;
		};
		this.end = function() {
			if (ended === false) {
				buf[p++] = 59;
				ended = true;
			}
			return p;
		};
		this.getOutputBuffer = function() {
			return buf;
		};
		this.setOutputBuffer = function(v) {
			buf = v;
		};
		this.getOutputBufferPosition = function() {
			return p;
		};
		this.setOutputBufferPosition = function(v) {
			p = v;
		};
	}
	function GifWriterOutputLZWCodeStream(buf, p, min_code_size, index_stream) {
		buf[p++] = min_code_size;
		var cur_subblock = p++;
		var clear_code = 1 << min_code_size;
		var code_mask = clear_code - 1;
		var eoi_code = clear_code + 1;
		var next_code = eoi_code + 1;
		var cur_code_size = min_code_size + 1;
		var cur_shift = 0;
		var cur = 0;
		function emit_bytes_to_buffer(bit_block_size) {
			while (cur_shift >= bit_block_size) {
				buf[p++] = cur & 255;
				cur >>= 8;
				cur_shift -= 8;
				if (p === cur_subblock + 256) {
					buf[cur_subblock] = 255;
					cur_subblock = p++;
				}
			}
		}
		function emit_code(c) {
			cur |= c << cur_shift;
			cur_shift += cur_code_size;
			emit_bytes_to_buffer(8);
		}
		var ib_code = index_stream[0] & code_mask;
		var code_table = {};
		emit_code(clear_code);
		for (var i = 1, il = index_stream.length; i < il; ++i) {
			var k = index_stream[i] & code_mask;
			var cur_key = ib_code << 8 | k;
			var cur_code = code_table[cur_key];
			if (cur_code === void 0) {
				cur |= ib_code << cur_shift;
				cur_shift += cur_code_size;
				while (cur_shift >= 8) {
					buf[p++] = cur & 255;
					cur >>= 8;
					cur_shift -= 8;
					if (p === cur_subblock + 256) {
						buf[cur_subblock] = 255;
						cur_subblock = p++;
					}
				}
				if (next_code === 4096) {
					emit_code(clear_code);
					next_code = eoi_code + 1;
					cur_code_size = min_code_size + 1;
					code_table = {};
				} else {
					if (next_code >= 1 << cur_code_size) ++cur_code_size;
					code_table[cur_key] = next_code++;
				}
				ib_code = k;
			} else ib_code = cur_code;
		}
		emit_code(ib_code);
		emit_code(eoi_code);
		emit_bytes_to_buffer(1);
		if (cur_subblock + 1 === p) buf[cur_subblock] = 0;
		else {
			buf[cur_subblock] = p - cur_subblock - 1;
			buf[p++] = 0;
		}
		return p;
	}
	function GifReader(buf) {
		var p = 0;
		if (buf[p++] !== 71 || buf[p++] !== 73 || buf[p++] !== 70 || buf[p++] !== 56 || (buf[p++] + 1 & 253) !== 56 || buf[p++] !== 97) throw new Error("Invalid GIF 87a/89a header.");
		var width = buf[p++] | buf[p++] << 8;
		var height = buf[p++] | buf[p++] << 8;
		var pf0 = buf[p++];
		var global_palette_flag = pf0 >> 7;
		var num_global_colors = 1 << (pf0 & 7) + 1;
		buf[p++];
		buf[p++];
		var global_palette_offset = null;
		var global_palette_size = null;
		if (global_palette_flag) {
			global_palette_offset = p;
			global_palette_size = num_global_colors;
			p += num_global_colors * 3;
		}
		var no_eof = true;
		var frames = [];
		var delay = 0;
		var transparent_index = null;
		var disposal = 0;
		var loop_count = null;
		this.width = width;
		this.height = height;
		while (no_eof && p < buf.length) switch (buf[p++]) {
			case 33:
				switch (buf[p++]) {
					case 255:
						if (buf[p] !== 11 || buf[p + 1] == 78 && buf[p + 2] == 69 && buf[p + 3] == 84 && buf[p + 4] == 83 && buf[p + 5] == 67 && buf[p + 6] == 65 && buf[p + 7] == 80 && buf[p + 8] == 69 && buf[p + 9] == 50 && buf[p + 10] == 46 && buf[p + 11] == 48 && buf[p + 12] == 3 && buf[p + 13] == 1 && buf[p + 16] == 0) {
							p += 14;
							loop_count = buf[p++] | buf[p++] << 8;
							p++;
						} else {
							p += 12;
							while (true) {
								var block_size = buf[p++];
								if (!(block_size >= 0)) throw Error("Invalid block size");
								if (block_size === 0) break;
								p += block_size;
							}
						}
						break;
					case 249:
						if (buf[p++] !== 4 || buf[p + 4] !== 0) throw new Error("Invalid graphics extension block.");
						var pf1 = buf[p++];
						delay = buf[p++] | buf[p++] << 8;
						transparent_index = buf[p++];
						if ((pf1 & 1) === 0) transparent_index = null;
						disposal = pf1 >> 2 & 7;
						p++;
						break;
					case 254:
						while (true) {
							var block_size = buf[p++];
							if (!(block_size >= 0)) throw Error("Invalid block size");
							if (block_size === 0) break;
							p += block_size;
						}
						break;
					default: throw new Error("Unknown graphic control label: 0x" + buf[p - 1].toString(16));
				}
				break;
			case 44:
				var x = buf[p++] | buf[p++] << 8;
				var y = buf[p++] | buf[p++] << 8;
				var w = buf[p++] | buf[p++] << 8;
				var h = buf[p++] | buf[p++] << 8;
				var pf2 = buf[p++];
				var local_palette_flag = pf2 >> 7;
				var interlace_flag = pf2 >> 6 & 1;
				var num_local_colors = 1 << (pf2 & 7) + 1;
				var palette_offset = global_palette_offset;
				var palette_size = global_palette_size;
				var has_local_palette = false;
				if (local_palette_flag) {
					var has_local_palette = true;
					palette_offset = p;
					palette_size = num_local_colors;
					p += num_local_colors * 3;
				}
				var data_offset = p;
				p++;
				while (true) {
					var block_size = buf[p++];
					if (!(block_size >= 0)) throw Error("Invalid block size");
					if (block_size === 0) break;
					p += block_size;
				}
				frames.push({
					x,
					y,
					width: w,
					height: h,
					has_local_palette,
					palette_offset,
					palette_size,
					data_offset,
					data_length: p - data_offset,
					transparent_index,
					interlaced: !!interlace_flag,
					delay,
					disposal
				});
				break;
			case 59:
				no_eof = false;
				break;
			default: throw new Error("Unknown gif block: 0x" + buf[p - 1].toString(16));
		}
		this.numFrames = function() {
			return frames.length;
		};
		this.loopCount = function() {
			return loop_count;
		};
		this.frameInfo = function(frame_num) {
			if (frame_num < 0 || frame_num >= frames.length) throw new Error("Frame index out of range.");
			return frames[frame_num];
		};
		this.decodeAndBlitFrameBGRA = function(frame_num, pixels) {
			var frame = this.frameInfo(frame_num);
			var num_pixels = frame.width * frame.height;
			var index_stream = new Uint8Array(num_pixels);
			GifReaderLZWOutputIndexStream(buf, frame.data_offset, index_stream, num_pixels);
			var palette_offset = frame.palette_offset;
			var trans = frame.transparent_index;
			if (trans === null) trans = 256;
			var framewidth = frame.width;
			var framestride = width - framewidth;
			var xleft = framewidth;
			var opbeg = (frame.y * width + frame.x) * 4;
			var opend = ((frame.y + frame.height) * width + frame.x) * 4;
			var op = opbeg;
			var scanstride = framestride * 4;
			if (frame.interlaced === true) scanstride += width * 4 * 7;
			var interlaceskip = 8;
			for (var i = 0, il = index_stream.length; i < il; ++i) {
				var index = index_stream[i];
				if (xleft === 0) {
					op += scanstride;
					xleft = framewidth;
					if (op >= opend) {
						scanstride = framestride * 4 + width * 4 * (interlaceskip - 1);
						op = opbeg + (framewidth + framestride) * (interlaceskip << 1);
						interlaceskip >>= 1;
					}
				}
				if (index === trans) op += 4;
				else {
					var r = buf[palette_offset + index * 3];
					var g = buf[palette_offset + index * 3 + 1];
					var b = buf[palette_offset + index * 3 + 2];
					pixels[op++] = b;
					pixels[op++] = g;
					pixels[op++] = r;
					pixels[op++] = 255;
				}
				--xleft;
			}
		};
		this.decodeAndBlitFrameRGBA = function(frame_num, pixels) {
			var frame = this.frameInfo(frame_num);
			var num_pixels = frame.width * frame.height;
			var index_stream = new Uint8Array(num_pixels);
			GifReaderLZWOutputIndexStream(buf, frame.data_offset, index_stream, num_pixels);
			var palette_offset = frame.palette_offset;
			var trans = frame.transparent_index;
			if (trans === null) trans = 256;
			var framewidth = frame.width;
			var framestride = width - framewidth;
			var xleft = framewidth;
			var opbeg = (frame.y * width + frame.x) * 4;
			var opend = ((frame.y + frame.height) * width + frame.x) * 4;
			var op = opbeg;
			var scanstride = framestride * 4;
			if (frame.interlaced === true) scanstride += width * 4 * 7;
			var interlaceskip = 8;
			for (var i = 0, il = index_stream.length; i < il; ++i) {
				var index = index_stream[i];
				if (xleft === 0) {
					op += scanstride;
					xleft = framewidth;
					if (op >= opend) {
						scanstride = framestride * 4 + width * 4 * (interlaceskip - 1);
						op = opbeg + (framewidth + framestride) * (interlaceskip << 1);
						interlaceskip >>= 1;
					}
				}
				if (index === trans) op += 4;
				else {
					var r = buf[palette_offset + index * 3];
					var g = buf[palette_offset + index * 3 + 1];
					var b = buf[palette_offset + index * 3 + 2];
					pixels[op++] = r;
					pixels[op++] = g;
					pixels[op++] = b;
					pixels[op++] = 255;
				}
				--xleft;
			}
		};
	}
	function GifReaderLZWOutputIndexStream(code_stream, p, output, output_length) {
		var min_code_size = code_stream[p++];
		var clear_code = 1 << min_code_size;
		var eoi_code = clear_code + 1;
		var next_code = eoi_code + 1;
		var cur_code_size = min_code_size + 1;
		var code_mask = (1 << cur_code_size) - 1;
		var cur_shift = 0;
		var cur = 0;
		var op = 0;
		var subblock_size = code_stream[p++];
		var code_table = new Int32Array(4096);
		var prev_code = null;
		while (true) {
			while (cur_shift < 16) {
				if (subblock_size === 0) break;
				cur |= code_stream[p++] << cur_shift;
				cur_shift += 8;
				if (subblock_size === 1) subblock_size = code_stream[p++];
				else --subblock_size;
			}
			if (cur_shift < cur_code_size) break;
			var code = cur & code_mask;
			cur >>= cur_code_size;
			cur_shift -= cur_code_size;
			if (code === clear_code) {
				next_code = eoi_code + 1;
				cur_code_size = min_code_size + 1;
				code_mask = (1 << cur_code_size) - 1;
				prev_code = null;
				continue;
			} else if (code === eoi_code) break;
			var chase_code = code < next_code ? code : prev_code;
			var chase_length = 0;
			var chase = chase_code;
			while (chase > clear_code) {
				chase = code_table[chase] >> 8;
				++chase_length;
			}
			var k = chase;
			if (op + chase_length + (chase_code !== code ? 1 : 0) > output_length) {
				console.log("Warning, gif stream longer than expected.");
				return;
			}
			output[op++] = k;
			op += chase_length;
			var b = op;
			if (chase_code !== code) output[op++] = k;
			chase = chase_code;
			while (chase_length--) {
				chase = code_table[chase];
				output[--b] = chase & 255;
				chase >>= 8;
			}
			if (prev_code !== null && next_code < 4096) {
				code_table[next_code++] = prev_code << 8 | k;
				if (next_code >= code_mask + 1 && cur_code_size < 12) {
					++cur_code_size;
					code_mask = code_mask << 1 | 1;
				}
			}
			prev_code = code;
		}
		if (op !== output_length) console.log("Warning, gif stream shorter than expected.");
		return output;
	}
	try {
		exports.GifWriter = GifWriter;
		exports.GifReader = GifReader;
	} catch (e) {}
})))(), 1)).default;
const encoder$1 = new TextEncoder(), decoder = new TextDecoder();
const ASEPRITE_BLEND_MODES = [
	"normal",
	"multiply",
	"screen",
	"overlay",
	"darken",
	"lighten",
	"color-dodge",
	"color-burn",
	"hard-light",
	"soft-light",
	"difference",
	"exclusion",
	"hue",
	"saturation",
	"color",
	"luminosity",
	"addition",
	"subtract",
	"divide"
];
const DIRECTIONS = [
	"forward",
	"reverse",
	"pingpong",
	"pingpong_reverse"
];
const MAX_PIXELS = 64 * 1024 * 1024;
function assert(value, message) {
	if (!value) throw new Error(message);
}
function bytes(value) {
	return value instanceof Uint8Array ? value : new Uint8Array(value);
}
function dimensions(w, h) {
	assert(Number.isInteger(w) && Number.isInteger(h) && w > 0 && h > 0 && w * h <= MAX_PIXELS, "Invalid or excessive image dimensions.");
}
function hex(r, g, b, a = 255) {
	return "#" + [
		r,
		g,
		b,
		a
	].map((v) => v.toString(16).padStart(2, "0")).join("");
}
function colorRgba(value, palette = []) {
	if (typeof value === "number") value = palette[value];
	if (value == null) return [
		0,
		0,
		0,
		0
	];
	assert(typeof value === "string" && /^#[0-9a-f]{6}([0-9a-f]{2})?$/i.test(value), `Invalid pixel color ${value}.`);
	return [
		parseInt(value.slice(1, 3), 16),
		parseInt(value.slice(3, 5), 16),
		parseInt(value.slice(5, 7), 16),
		value.length === 9 ? parseInt(value.slice(7, 9), 16) : 255
	];
}
function pixelsToRgba(pixels, palette = []) {
	const out = new Uint8Array(pixels.length * 4);
	pixels.forEach((p, i) => out.set(colorRgba(p, palette), i * 4));
	return out;
}
function rgbaToPixels(rgba) {
	const out = [];
	for (let i = 0; i < rgba.length; i += 4) out.push(rgba[i + 3] ? hex(...rgba.subarray(i, i + 4)) : null);
	return out;
}
var Reader = class {
	constructor(data) {
		this.b = bytes(data);
		this.v = new DataView(this.b.buffer, this.b.byteOffset, this.b.byteLength);
		this.p = 0;
	}
	need(n) {
		assert(Number.isSafeInteger(n) && n >= 0 && this.p + n <= this.b.length, "Truncated or malformed binary file.");
	}
	u8() {
		this.need(1);
		return this.v.getUint8(this.p++);
	}
	u16() {
		this.need(2);
		const v = this.v.getUint16(this.p, true);
		this.p += 2;
		return v;
	}
	i16() {
		this.need(2);
		const v = this.v.getInt16(this.p, true);
		this.p += 2;
		return v;
	}
	u32() {
		this.need(4);
		const v = this.v.getUint32(this.p, true);
		this.p += 4;
		return v;
	}
	i32() {
		this.need(4);
		const v = this.v.getInt32(this.p, true);
		this.p += 4;
		return v;
	}
	skip(n) {
		this.need(n);
		this.p += n;
		return this;
	}
	take(n) {
		this.need(n);
		const v = this.b.slice(this.p, this.p + n);
		this.p += n;
		return v;
	}
	str() {
		return decoder.decode(this.take(this.u16()));
	}
	remaining() {
		return this.take(this.b.length - this.p);
	}
};
var Writer = class {
	constructor() {
		this.b = [];
	}
	u8(v) {
		this.b.push(v & 255);
		return this;
	}
	u16(v) {
		return this.u8(v).u8(v >>> 8);
	}
	i16(v) {
		return this.u16(v);
	}
	u32(v) {
		return this.u16(v).u16(v >>> 16);
	}
	i32(v) {
		return this.u32(v);
	}
	raw(v) {
		for (const x of v) this.b.push(x);
		return this;
	}
	zero(n) {
		for (let i = 0; i < n; i++) this.b.push(0);
		return this;
	}
	str(v) {
		const b = encoder$1.encode(v || "");
		assert(b.length <= 65535, "Sprite name exceeds 65535 UTF-8 bytes.");
		return this.u16(b.length).raw(b);
	}
	done() {
		return Uint8Array.from(this.b);
	}
};
function concat(parts) {
	const out = new Uint8Array(parts.reduce((n, p) => n + p.length, 0));
	let p = 0;
	for (const v of parts) {
		out.set(v, p);
		p += v.length;
	}
	return out;
}
function inflateExact(compressed, length) {
	assert(length <= MAX_PIXELS * 4, "Decompressed image exceeds safety limit.");
	const out = unzlibSync(compressed, { out: new Uint8Array(length + 1) });
	assert(out.length === length, "Image data length does not match its dimensions.");
	let a = 1, b = 0;
	for (const byte of out) {
		a = (a + byte) % 65521;
		b = (b + a) % 65521;
	}
	const p = compressed.length - 4, checksum = (compressed[p] << 24 | compressed[p + 1] << 16 | compressed[p + 2] << 8 | compressed[p + 3]) >>> 0;
	assert((b << 16 | a) >>> 0 === checksum, "Compressed image checksum mismatch.");
	return out;
}
function decodePixels(data, w, h, depth) {
	dimensions(w, h);
	const channels = depth / 8;
	assert(data.length === w * h * channels, "Sprite cel data has incorrect length.");
	const out = new Array(w * h);
	for (let i = 0; i < out.length; i++) {
		const p = i * channels;
		out[i] = depth === 8 ? data[p] : depth === 16 ? hex(data[p], data[p], data[p], data[p + 1]) : hex(data[p], data[p + 1], data[p + 2], data[p + 3]);
	}
	return out;
}
function encodePixels(image, depth, palette, transparentIndex = 0) {
	dimensions(image.width, image.height);
	assert(image.pixels?.length === image.width * image.height, "Image pixel count does not match dimensions.");
	const out = new Uint8Array(image.pixels.length * depth / 8);
	image.pixels.forEach((v, i) => {
		if (depth === 8) {
			const index = v == null ? transparentIndex : typeof v === "number" ? v : palette.findIndex((p) => p.toLowerCase() === v.toLowerCase());
			assert(Number.isInteger(index) && index >= 0 && index < Math.min(palette.length, 256), `Pixel ${i} is not in the indexed palette.`);
			out[i] = index;
		} else {
			const [r, g, b, a] = colorRgba(v, palette);
			if (depth === 16) {
				assert(r === g && g === b, "Grayscale sprite export contains a non-grayscale pixel. Convert color mode first.");
				out.set([r, a], i * 2);
			} else out.set([
				r,
				g,
				b,
				a
			], i * 4);
		}
	});
	return out;
}
function baseDocument(w, h, name = "Imported sprite") {
	dimensions(w, h);
	return {
		format: "pixelwall-document",
		version: 4,
		id: "document-import",
		name,
		width: w,
		height: h,
		colorMode: "rgba",
		palette: [
			"#00000000",
			"#000000ff",
			"#ffffffff"
		],
		colorProfile: "sRGB",
		layers: [],
		frames: [],
		images: {},
		clips: [],
		slices: [],
		tilesets: [],
		metadata: {}
	};
}
function imageDocument(entries, options = {}) {
	assert(entries.length > 0, "No images to import.");
	const doc = baseDocument(options.width || Math.max(...entries.map((e) => e.width)), options.height || Math.max(...entries.map((e) => e.height)), options.name);
	doc.layers = [{
		id: "layer-1",
		name: "Artwork",
		type: "image",
		parentId: null,
		visible: true,
		locked: false,
		opacity: 1,
		blendMode: "normal"
	}];
	for (const [i, e] of entries.entries()) {
		dimensions(e.width, e.height);
		assert(e.rgba.length === e.width * e.height * 4, "RGBA data length is invalid.");
		const id = `image-${i + 1}`;
		doc.images[id] = {
			width: e.width,
			height: e.height,
			pixels: rgbaToPixels(e.rgba)
		};
		doc.frames.push({
			id: `frame-${i + 1}`,
			durationMs: e.durationMs || options.durationMs || 100,
			cels: { "layer-1": {
				imageId: id,
				x: e.x || 0,
				y: e.y || 0,
				opacity: 1
			} }
		});
	}
	return doc;
}
function importSequence(entries, options = {}) {
	return imageDocument(entries, options);
}
function readAseprite(input) {
	const data = bytes(input), r = new Reader(data);
	assert(data.length >= 128, "Sprite header is truncated.");
	assert(r.u32() === data.length, "Sprite file size does not match header.");
	assert(r.u16() === 42464, "Not a supported sprite file.");
	const count = r.u16(), width = r.u16(), height = r.u16(), depth = r.u16();
	assert([
		8,
		16,
		32
	].includes(depth), "Unsupported sprite color depth.");
	assert(count > 0, "Sprite has no frames.");
	const flags = r.u32(), speed = r.u16();
	r.skip(8);
	const transparentIndex = r.u8();
	r.skip(3);
	const colors = r.u16() || 256, pixelWidth = r.u8() || 1, pixelHeight = r.u8() || 1, grid = {
		x: r.i16(),
		y: r.i16(),
		width: r.u16(),
		height: r.u16()
	};
	r.p = 128;
	const doc = baseDocument(width, height), warnings = [], meta = {
		transparentIndex,
		pixelRatio: {
			width: pixelWidth,
			height: pixelHeight
		},
		grid,
		flags,
		paletteNames: {},
		externalFiles: [],
		opaqueChunks: []
	};
	doc.colorMode = {
		8: "indexed",
		16: "grayscale",
		32: "rgba"
	}[depth];
	doc.metadata.aseprite = meta;
	let palette = Array.from({ length: colors }, () => "#000000ff"), paletteSeen = false, anyPalette = false, parents = [], lastObject = doc, pendingUserObjects = [], pendingTile = null;
	const links = [];
	for (let fi = 0; fi < count; fi++) {
		const start = r.p, frameSize = r.u32();
		assert(frameSize >= 16 && start + frameSize <= data.length, "Invalid sprite frame size.");
		assert(r.u16() === 61946, "Invalid sprite frame magic.");
		const oldCount = r.u16(), duration = r.u16();
		r.skip(2);
		const chunkCount = r.u32() || oldCount;
		const frame = {
			id: `frame-${fi + 1}`,
			durationMs: duration || speed || 100,
			cels: {}
		};
		doc.frames.push(frame);
		let paletteChanged = false;
		for (let ci = 0; ci < chunkCount; ci++) {
			const cs = r.p, chunkSize = r.u32(), type = r.u16();
			assert(chunkSize >= 6 && cs + chunkSize <= start + frameSize, "Invalid sprite chunk size.");
			const raw = r.take(chunkSize - 6), c = new Reader(raw);
			if (type !== 8224) {
				pendingUserObjects = [];
				pendingTile = null;
			}
			if (type === 8196) {
				assert(fi === 0, "Per-frame layer definitions are not supported.");
				const layerFlags = c.u16(), layerType = c.u16(), level = c.u16();
				c.skip(4);
				const blend = c.u16(), opacity = c.u8();
				c.skip(3);
				const name = c.str();
				assert(layerType <= 2, "Unsupported sprite layer type.");
				assert(blend < ASEPRITE_BLEND_MODES.length, "Unsupported sprite blend mode.");
				assert(level === 0 || parents[level - 1], "Invalid sprite layer hierarchy.");
				const layer = {
					id: `layer-${doc.layers.length + 1}`,
					name,
					type: layerType === 1 ? "group" : layerType === 2 ? "tilemap" : layerFlags & 64 ? "reference" : "image",
					parentId: level ? parents[level - 1].id : null,
					visible: !!(layerFlags & 1),
					locked: !(layerFlags & 2),
					opacity: layerType === 1 ? flags & 2 ? opacity / 255 : 1 : flags & 1 ? opacity / 255 : 1,
					blendMode: layerType === 1 && !(flags & 2) ? "normal" : ASEPRITE_BLEND_MODES[blend],
					asepriteFlags: layerFlags
				};
				if (layerType === 2) layer.asepriteTilesetIndex = c.u32();
				if (flags & 4) layer.uuid = Array.from(c.take(16));
				doc.layers.push(layer);
				parents.length = level;
				parents[level] = layer;
				lastObject = layer;
			} else if (type === 8197) {
				const li = c.u16(), x = c.i16(), y = c.i16(), opacity = c.u8() / 255, celType = c.u16(), zIndex = c.i16();
				c.skip(5);
				const layer = doc.layers[li];
				assert(layer, "Sprite cel references a missing layer.");
				assert(!frame.cels[layer.id], "Duplicate cel for one layer/frame is unsupported.");
				const cel = {
					imageId: "",
					x,
					y,
					opacity,
					zIndex
				};
				frame.cels[layer.id] = cel;
				lastObject = cel;
				if (celType === 1) links.push({
					cel,
					fi,
					li,
					target: c.u16()
				});
				else if (celType === 0 || celType === 2) {
					const w = c.u16(), h = c.u16();
					dimensions(w, h);
					const payload = celType === 0 ? c.remaining() : inflateExact(c.remaining(), w * h * depth / 8);
					cel.imageId = `image-${fi + 1}-${li + 1}`;
					doc.images[cel.imageId] = {
						width: w,
						height: h,
						pixels: decodePixels(payload, w, h, depth)
					};
				} else if (celType === 3) {
					const w = c.u16(), h = c.u16(), bitsPerTile = c.u16();
					dimensions(w, h);
					assert([
						8,
						16,
						32
					].includes(bitsPerTile), "Unsupported sprite tile bit depth.");
					const tilemap = {
						bitsPerTile,
						idMask: c.u32(),
						xFlipMask: c.u32(),
						yFlipMask: c.u32(),
						diagonalFlipMask: c.u32()
					};
					c.skip(10);
					const tr = new Reader(inflateExact(c.remaining(), w * h * bitsPerTile / 8));
					tilemap.tiles = Array.from({ length: w * h }, () => bitsPerTile === 32 ? tr.u32() : bitsPerTile === 16 ? tr.u16() : tr.u8());
					cel.imageId = `image-${fi + 1}-${li + 1}`;
					doc.images[cel.imageId] = {
						width: w,
						height: h,
						pixels: [],
						tilemap
					};
				} else throw new Error(`Unsupported sprite cel type ${celType}.`);
			} else if (type === 8198) {
				assert(lastObject && "imageId" in lastObject, "Cel extra has no preceding cel.");
				const extraFlags = c.u32();
				lastObject.preciseBounds = {
					flags: extraFlags,
					x: c.i32() / 65536,
					y: c.i32() / 65536,
					width: c.i32() / 65536,
					height: c.i32() / 65536
				};
				c.skip(16);
			} else if (type === 8199) {
				const profile = {
					type: c.u16(),
					flags: c.u16(),
					gamma: c.i32() / 65536
				};
				c.skip(8);
				if (profile.type === 2) profile.icc = Array.from(c.take(c.u32()));
				meta.colorProfile = profile;
				if (profile.type === 2 || profile.flags & 1) warnings.push("Embedded ICC / fixed-gamma profile retained for color-managed preview and export.");
			} else if (type === 8200) {
				const n = c.u32();
				c.skip(8);
				for (let i = 0; i < n; i++) {
					const entry = {
						id: c.u32(),
						type: c.u8()
					};
					c.skip(7);
					entry.name = c.str();
					meta.externalFiles.push(entry);
				}
			} else if (type === 8217) {
				const n = c.u32(), first = c.u32(), last = c.u32();
				assert(n > 0 && n <= 65536 && first <= last && last < n, "Invalid sprite palette.");
				c.skip(8);
				palette.length = n;
				for (let i = first; i <= last; i++) {
					const f = c.u16();
					palette[i] = hex(c.u8(), c.u8(), c.u8(), c.u8());
					if (f & 1) meta.paletteNames[i] = c.str();
				}
				palette = Array.from(palette, (p) => p || "#000000ff");
				paletteSeen = true;
				anyPalette = true;
				paletteChanged = true;
				lastObject = doc;
			} else if (type === 4 || type === 17) {
				anyPalette = true;
				if (!paletteSeen) {
					const n = c.u16();
					let index = 0;
					for (let i = 0; i < n; i++) {
						index += c.u8();
						const ct = c.u8() || 256;
						for (let j = 0; j < ct; j++) {
							const rgb = [
								c.u8(),
								c.u8(),
								c.u8()
							].map((v) => type === 17 ? Math.round(v * 255 / 63) : v);
							palette[index++] = hex(...rgb);
						}
					}
					paletteChanged = true;
				}
			} else if (type === 8216) {
				const n = c.u16();
				c.skip(8);
				for (let i = 0; i < n; i++) {
					const from = c.u16(), to = c.u16(), direction = c.u8(), repeat = c.u16();
					assert(from <= to && to < count && direction <= 3, "Invalid sprite animation tag.");
					c.skip(6);
					const color = hex(c.u8(), c.u8(), c.u8());
					c.skip(1);
					const clip = {
						id: `clip-${doc.clips.length + 1}`,
						name: c.str(),
						frameIds: Array.from({ length: to - from + 1 }, (_, j) => `frame-${from + j + 1}`),
						direction: DIRECTIONS[direction],
						loop: repeat === 0,
						repeat,
						color
					};
					doc.clips.push(clip);
					pendingUserObjects.push(clip);
				}
				lastObject = doc;
			} else if (type === 8226) {
				const n = c.u32(), sliceFlags = c.u32();
				c.skip(4);
				const slice = {
					id: `slice-${doc.slices.length + 1}`,
					name: c.str(),
					keys: []
				};
				for (let i = 0; i < n; i++) {
					const frameIndex = c.u32();
					assert(frameIndex < count, "Slice refers to an unknown frame.");
					const key = {
						frameId: `frame-${frameIndex + 1}`,
						x: c.i32(),
						y: c.i32(),
						width: c.u32(),
						height: c.u32()
					};
					if (sliceFlags & 1) key.center = {
						x: c.i32(),
						y: c.i32(),
						width: c.u32(),
						height: c.u32()
					};
					if (sliceFlags & 2) key.pivot = {
						x: c.i32(),
						y: c.i32()
					};
					slice.keys.push(key);
				}
				doc.slices.push(slice);
				lastObject = slice;
			} else if (type === 8227) {
				const numericId = c.u32(), tileFlags = c.u32(), tileCount = c.u32(), tileWidth = c.u16(), tileHeight = c.u16(), baseIndex = c.i16();
				c.skip(14);
				const tileset = {
					id: `tileset-${numericId}`,
					asepriteId: numericId,
					name: c.str(),
					flags: tileFlags,
					tileCount,
					tileWidth,
					tileHeight,
					baseIndex
				};
				dimensions(tileWidth, tileHeight * Math.max(1, tileCount));
				if (tileFlags & 1) {
					tileset.externalFileId = c.u32();
					tileset.externalTilesetId = c.u32();
					warnings.push(`Tileset “${tileset.name}” links an external file; external content is not loaded automatically.`);
				}
				if (tileFlags & 2) {
					const compressed = c.take(c.u32()), h = tileHeight * tileCount;
					tileset.imageId = `tileset-image-${numericId}`;
					doc.images[tileset.imageId] = {
						width: tileWidth,
						height: h,
						pixels: decodePixels(inflateExact(compressed, tileWidth * h * depth / 8), tileWidth, h, depth)
					};
				}
				doc.tilesets.push(tileset);
				lastObject = tileset;
				pendingTile = {
					tileset,
					index: -1
				};
			} else if (type === 8224) {
				const uflags = c.u32(), userData = {};
				if (uflags & 1) userData.text = c.str();
				if (uflags & 2) userData.color = hex(c.u8(), c.u8(), c.u8(), c.u8());
				if (uflags & 4) {
					const len = c.u32();
					assert(len >= 8, "Invalid sprite property block.");
					const prop = new Writer().u32(len).raw(c.take(len - 4));
					userData.propertiesBytes = Array.from(prop.done());
					warnings.push("Sprite extension properties are preserved as opaque data.");
				}
				assert(!(uflags & -8), "Unsupported sprite user-data flags.");
				if (pendingUserObjects.length) pendingUserObjects.shift().userData = userData;
				else if (pendingTile) {
					if (pendingTile.index < 0) pendingTile.tileset.userData = userData;
					else {
						pendingTile.tileset.tileUserData ||= [];
						pendingTile.tileset.tileUserData[pendingTile.index] = userData;
					}
					pendingTile.index++;
				} else lastObject.userData = userData;
			} else {
				meta.opaqueChunks.push({
					frameIndex: fi,
					type,
					data: Array.from(raw)
				});
				warnings.push(`Unsupported sprite chunk 0x${type.toString(16)} preserved in the project; native re-export is blocked to prevent data loss.`);
			}
		}
		assert(r.p === start + frameSize, "Frame size/chunk count mismatch.");
		if (paletteChanged || fi === 0) frame.palette = [...palette];
	}
	assert(r.p === data.length, "Unexpected bytes after sprite frames.");
	const resolve = (link, seen = /* @__PURE__ */ new Set()) => {
		assert(link.target < count, "Linked cel references an unknown frame.");
		assert(!seen.has(link), "Cyclic linked sprite cels.");
		seen.add(link);
		const target = doc.frames[link.target].cels[doc.layers[link.li].id];
		assert(target, "Linked cel references an empty cel.");
		if (!target.imageId) {
			const other = links.find((l) => l.cel === target);
			assert(other, "Missing linked cel target.");
			resolve(other, seen);
		}
		link.cel.imageId = target.imageId;
	};
	links.forEach((l) => resolve(l));
	for (const layer of doc.layers) if (layer.type === "tilemap") {
		const ts = doc.tilesets[layer.asepriteTilesetIndex];
		assert(ts, "Tilemap references an unknown tileset.");
		layer.tilesetId = ts.id;
	}
	doc.palette = [...doc.frames[0].palette || palette];
	if (doc.colorMode === "indexed" && !anyPalette) warnings.push("Indexed file has no explicit palette.");
	meta.warnings = [...new Set(warnings)];
	return {
		document: doc,
		warnings: meta.warnings
	};
}
function aseChunk(type, w) {
	const b = w instanceof Writer ? w.done() : w;
	return new Writer().u32(b.length + 6).u16(type).raw(b).done();
}
function userChunk(obj) {
	if (!obj?.userData) return [];
	const u = obj.userData, w = new Writer().u32((u.text != null ? 1 : 0) | (u.color ? 2 : 0) | (u.propertiesBytes ? 4 : 0));
	if (u.text != null) w.str(u.text);
	if (u.color) w.raw(colorRgba(u.color));
	if (u.propertiesBytes) w.raw(u.propertiesBytes);
	return [aseChunk(8224, w)];
}
function paletteChunk(palette, names = {}) {
	assert(palette.length > 0, "Indexed export requires a palette.");
	const w = new Writer().u32(palette.length).u32(0).u32(palette.length - 1).zero(8);
	palette.forEach((p, i) => {
		w.u16(names[i] ? 1 : 0).raw(colorRgba(p));
		if (names[i]) w.str(names[i]);
	});
	return aseChunk(8217, w);
}
function tileImage(doc, tile) {
	const image = doc.images[tile.imageId];
	assert(image && !image.tilemap, "Tile raster image is missing.");
	if (!tile.sourceRect) return image;
	const { x, y, width, height } = tile.sourceRect;
	assert([
		x,
		y,
		width,
		height
	].every(Number.isInteger) && x >= 0 && y >= 0 && width > 0 && height > 0 && x + width <= image.width && y + height <= image.height, "Tile source rectangle exceeds its atlas.");
	const pixels = [];
	for (let yy = 0; yy < height; yy++) for (let xx = 0; xx < width; xx++) pixels.push(image.pixels[(y + yy) * image.width + x + xx]);
	return {
		width,
		height,
		pixels
	};
}
function prepareNativeTiles(input) {
	if (!input.layers.some((l) => l.tilemaps && Object.keys(l.tilemaps).length) && !input.tilesets?.some((t) => t.tiles?.length)) return input;
	const doc = structuredClone(input), indices = /* @__PURE__ */ new Map();
	for (const ts of doc.tilesets) {
		if (!Array.isArray(ts.tiles)) continue;
		const ids = /* @__PURE__ */ new Map(), native = Number.isInteger(ts.asepriteId) && ts.imageId && doc.images[ts.imageId], original = native ? doc.images[ts.imageId] : null, transparent = doc.colorMode === "indexed" ? doc.metadata?.aseprite?.transparentIndex ?? 0 : null;
		let nextIndex = native ? ts.tileCount : 1;
		const assignments = [];
		for (const tile of ts.tiles) {
			const raw = native && Number.isInteger(tile.asepriteTileId) ? tile.asepriteTileId : nextIndex++;
			assert(raw >= 0 && raw < 536870911, "Tile ID exceeds the native range.");
			nextIndex = Math.max(nextIndex, raw + 1);
			ids.set(tile.id, raw);
			assignments.push({
				tile,
				index: raw
			});
		}
		const pixels = new Array(ts.tileWidth * ts.tileHeight * nextIndex).fill(transparent);
		if (original) {
			assert(original.width === ts.tileWidth && original.height === ts.tileHeight * ts.tileCount, "Native tileset atlas shape is invalid.");
			for (let i = 0; i < original.pixels.length; i++) pixels[i] = original.pixels[i];
		}
		for (const { tile, index } of assignments) {
			if (tile.userData !== void 0) {
				ts.tileUserData ??= [];
				ts.tileUserData[index] = structuredClone(tile.userData);
			}
			const image = tileImage(doc, tile);
			assert(image.width === ts.tileWidth && image.height === ts.tileHeight, "Tile dimensions do not match their tileset.");
			const offset = index * ts.tileWidth * ts.tileHeight;
			for (let i = 0; i < image.pixels.length; i++) pixels[offset + i] = image.pixels[i];
		}
		indices.set(ts.id, ids);
		ts.imageId = `ase-tileset-${ts.id}`;
		ts.tileCount = nextIndex;
		ts.flags = native ? ts.flags | 2 : (ts.flags || 0) | 6;
		doc.images[ts.imageId] = {
			width: ts.tileWidth,
			height: ts.tileHeight * ts.tileCount,
			pixels
		};
	}
	const links = /* @__PURE__ */ new Map();
	for (const layer of doc.layers) {
		if (!layer.tilemaps) continue;
		for (const [frameId, map] of Object.entries(layer.tilemaps)) {
			const frame = doc.frames.find((f) => f.id === frameId);
			assert(frame, "Tilemap references a missing frame.");
			assert(!layer.tilesetId || layer.tilesetId === map.tilesetId, "Sprite tilemap layer cannot switch tilesets between frames.");
			layer.tilesetId = map.tilesetId;
			const ids = indices.get(map.tilesetId), ts = doc.tilesets.find((t) => t.id === map.tilesetId);
			assert(ids && ts, "Tilemap requires an embedded tileset.");
			const columns = map.columns, rows = map.rows;
			dimensions(columns, rows);
			assert(map.cells.length === columns * rows, "Tilemap cell count does not match dimensions.");
			const tilemap = {
				bitsPerTile: 32,
				idMask: 536870911,
				xFlipMask: 2147483648,
				yFlipMask: 1073741824,
				diagonalFlipMask: 536870912,
				tiles: map.cells.map((cell) => {
					if (cell == null) return ts.flags & 4 ? 0 : 4294967295;
					const id = ids.get(cell.tileId);
					assert(id != null, "Tilemap references an unknown tile.");
					let fx = !!cell.flipX, fy = !!cell.flipY, d = false;
					const rotation = ((cell.rotate || 0) % 360 + 360) % 360;
					assert([
						0,
						90,
						180,
						270
					].includes(rotation), "Sprite tiles require quarter-turn rotations.");
					if (rotation === 90) {
						d = true;
						[fx, fy] = [!fy, fx];
					}
					if (rotation === 180) {
						fx = !fx;
						fy = !fy;
					}
					if (rotation === 270) {
						d = true;
						[fx, fy] = [fy, !fx];
					}
					return (id | (fx ? 2147483648 : 0) | (fy ? 1073741824 : 0) | (d ? 536870912 : 0)) >>> 0;
				})
			};
			const previous = frame.cels[layer.id], sourceId = map.sourceImageId || previous?.imageId, old = doc.images[sourceId], unchanged = old?.tilemap && old.width === columns && old.height === rows && JSON.stringify(old.tilemap) === JSON.stringify(tilemap), key = sourceId ? `${layer.id}:${sourceId}:${JSON.stringify(tilemap)}` : null;
			let imageId = unchanged ? sourceId : key && links.get(key);
			if (!imageId) {
				imageId = `ase-map-${layer.id}-${frameId}`;
				doc.images[imageId] = {
					width: columns,
					height: rows,
					pixels: [],
					tilemap
				};
				if (key) links.set(key, imageId);
			}
			frame.cels[layer.id] = {
				...previous || {
					x: map.x || 0,
					y: map.y || 0,
					opacity: 1
				},
				imageId
			};
		}
	}
	return doc;
}
function prepareIndexedTransparency(input) {
	if (input.colorMode !== "indexed" || Number.isInteger(input.metadata?.aseprite?.transparentIndex)) return input;
	const doc = structuredClone(input), palettes = [doc.palette, ...doc.frames.filter((f) => f.palette).map((f) => f.palette)], length = Math.max(...palettes.map((p) => p.length)), used = /* @__PURE__ */ new Set();
	for (const image of Object.values(doc.images)) if (!image.tilemap) {
		for (const pixel of image.pixels) if (pixel != null) used.add(typeof pixel === "number" ? pixel : doc.palette.findIndex((p) => p.toLowerCase() === pixel.toLowerCase()));
	}
	let index = doc.palette.findIndex((p, i) => colorRgba(p)[3] === 0 && palettes.every((palette) => !palette[i] || colorRgba(palette[i])[3] === 0));
	if (index < 0) if (length < 256) index = length;
	else index = Array.from({ length: 256 }, (_, i) => i).find((i) => !used.has(i));
	assert(Number.isInteger(index), "Indexed sprite needs a reserved transparent palette entry. Free a palette slot or convert the document to RGBA before export.");
	for (const palette of palettes) {
		while (palette.length <= index) palette.push("#000000ff");
		palette[index] = "#00000000";
	}
	doc.metadata ||= {};
	doc.metadata.aseprite = {
		...doc.metadata.aseprite || {},
		transparentIndex: index
	};
	return doc;
}
function writeAseprite(input) {
	const doc = prepareNativeTiles(prepareIndexedTransparency(input));
	dimensions(doc.width, doc.height);
	assert(doc.width <= 65535 && doc.height <= 65535, "Sprite dimensions exceed 65535.");
	assert(doc.frames.length > 0 && doc.frames.length <= 65535, "Sprite supports 1–65535 frames.");
	const meta = doc.metadata?.aseprite || {};
	assert(!meta.opaqueChunks?.length, "Native export blocked: unsupported sprite chunks are retained in this project. Save the PixelWall project to preserve them.");
	const depth = {
		rgba: 32,
		indexed: 8,
		grayscale: 16
	}[doc.colorMode];
	assert(depth, "Unsupported color mode.");
	assert(depth !== 8 || doc.palette.length > 0 && doc.palette.length <= 256, "Indexed sprite requires a palette of 1–256 colors.");
	const layers = [], walk = (parent, ancestors = []) => {
		for (const l of doc.layers.filter((l) => (l.parentId || null) === parent)) {
			assert(!ancestors.includes(l.id), "Cyclic layer hierarchy.");
			layers.push(l);
			walk(l.id, [...ancestors, l.id]);
		}
	};
	walk(null);
	assert(layers.length === doc.layers.length, "Layer hierarchy contains a missing parent or cycle.");
	assert(layers.length <= 65535, "Too many sprite layers.");
	const frames = [], seenImages = /* @__PURE__ */ new Map(), hasUuid = layers.some((l) => l.uuid);
	for (let fi = 0; fi < doc.frames.length; fi++) {
		const frame = doc.frames[fi], chunks = [];
		assert(Number.isInteger(frame.durationMs) && frame.durationMs > 0 && frame.durationMs <= 65535, "Sprite frame duration must be 1–65535 ms.");
		if (fi === 0) {
			const cp = meta.colorProfile || {
				type: 1,
				flags: 0,
				gamma: 0
			}, cw = new Writer().u16(cp.type).u16(cp.flags).i32(Math.round(cp.gamma * 65536)).zero(8);
			if (cp.type === 2) {
				assert(cp.icc?.length, "Missing embedded color profile.");
				cw.u32(cp.icc.length).raw(cp.icc);
			}
			chunks.push(aseChunk(8199, cw));
			if (meta.externalFiles?.length) {
				const w = new Writer().u32(meta.externalFiles.length).zero(8);
				for (const e of meta.externalFiles) w.u32(e.id).u8(e.type).zero(7).str(e.name);
				chunks.push(aseChunk(8200, w));
			}
			const initialPalette = frame.palette || doc.palette;
			if (initialPalette?.length) chunks.push(paletteChunk(initialPalette, meta.paletteNames), ...userChunk(doc));
			for (const [ti, ts] of (doc.tilesets || []).entries()) {
				assert(!ts.tiles?.length || ts.imageId, "Native tileset export requires a stacked atlas image.");
				const flags = (ts.flags ?? 4) | (ts.imageId ? 2 : 0) | (ts.externalFileId != null ? 1 : 0), w = new Writer().u32(ts.asepriteId ?? ti).u32(flags).u32(ts.tileCount).u16(ts.tileWidth).u16(ts.tileHeight).i16(ts.baseIndex ?? 1).zero(14).str(ts.name);
				if (flags & 1) w.u32(ts.externalFileId).u32(ts.externalTilesetId);
				if (flags & 2) {
					const image = doc.images[ts.imageId];
					assert(image && image.width === ts.tileWidth && image.height === ts.tileHeight * ts.tileCount, "Invalid embedded tileset atlas.");
					const compressed = zlibSync(encodePixels(image, depth, doc.palette, meta.transparentIndex || 0));
					w.u32(compressed.length).raw(compressed);
				}
				chunks.push(aseChunk(8227, w), ...userChunk(ts));
				if (ts.tileUserData?.length) {
					if (!ts.userData) chunks.push(aseChunk(8224, new Writer().u32(0)));
					for (const ud of ts.tileUserData) chunks.push(...userChunk({ userData: ud || {} }));
				}
			}
			for (const l of layers) {
				const type = l.type === "group" ? 1 : l.type === "tilemap" ? 2 : 0;
				assert([
					"group",
					"tilemap",
					"reference",
					"image"
				].includes(l.type), "Unsupported layer type.");
				const blend = ASEPRITE_BLEND_MODES.indexOf(l.blendMode || "normal");
				assert(blend >= 0, `Unsupported blend mode ${l.blendMode}.`);
				let level = 0, p = l.parentId;
				while (p) {
					level++;
					p = layers.find((x) => x.id === p)?.parentId;
				}
				let lf = (l.asepriteFlags || 0) & -68;
				if (l.visible !== false) lf |= 1;
				if (!l.locked) lf |= 2;
				if (l.type === "reference") lf |= 64;
				const w = new Writer().u16(lf).u16(type).u16(level).u16(0).u16(0).u16(blend).u8(Math.round((l.opacity ?? 1) * 255)).zero(3).str(l.name);
				if (type === 2) {
					const index = doc.tilesets.findIndex((t) => t.id === l.tilesetId);
					assert(index >= 0, "Tilemap layer has no tileset.");
					w.u32(index);
				}
				if (hasUuid) w.raw(l.uuid || new Uint8Array(16));
				chunks.push(aseChunk(8196, w), ...userChunk(l));
			}
		}
		const pal = frame.palette;
		if (fi > 0 && pal?.length) chunks.push(paletteChunk(pal, meta.paletteNames));
		if (fi === 0) {
			if (doc.clips?.length) {
				const w = new Writer().u16(doc.clips.length).zero(8);
				for (const clip of doc.clips) {
					const indices = clip.frameIds.map((id) => doc.frames.findIndex((f) => f.id === id));
					assert(indices.length && indices.every((n, i) => n >= 0 && (i === 0 || n === indices[i - 1] + 1)), "Sprite tags require a contiguous forward frame range.");
					const direction = DIRECTIONS.indexOf(clip.direction || "forward");
					assert(direction >= 0, "Unsupported clip direction.");
					w.u16(indices[0]).u16(indices.at(-1)).u8(direction).u16(clip.repeat ?? (clip.loop ? 0 : 1)).zero(6).raw(colorRgba(clip.color || "#000000").slice(0, 3)).u8(0).str(clip.name);
				}
				chunks.push(aseChunk(8216, w));
				if (doc.clips.some((c) => c.userData)) for (const clip of doc.clips) chunks.push(...userChunk({ userData: clip.userData || {} }));
			}
			for (const rawSlice of doc.slices || []) {
				const slice = rawSlice.keys ? rawSlice : {
					...rawSlice,
					keys: [{
						frameId: doc.frames[0].id,
						...rawSlice.bounds,
						...rawSlice.pivot ? { pivot: rawSlice.pivot } : {},
						...rawSlice.ninePatch ? { center: rawSlice.ninePatch } : {}
					}]
				};
				const hasCenter = slice.keys.some((k) => k.center), hasPivot = slice.keys.some((k) => k.pivot), w = new Writer().u32(slice.keys.length).u32((hasCenter ? 1 : 0) | (hasPivot ? 2 : 0)).u32(0).str(slice.name);
				for (const key of slice.keys) {
					const index = doc.frames.findIndex((f) => f.id === key.frameId);
					assert(index >= 0, "Slice refers to a missing frame.");
					w.u32(index).i32(key.x).i32(key.y).u32(key.width).u32(key.height);
					if (hasCenter) {
						assert(key.center, "All sprite slice keys must share nine-patch fields.");
						const c = key.center;
						w.i32(c.x).i32(c.y).u32(c.width).u32(c.height);
					}
					if (hasPivot) {
						assert(key.pivot, "All sprite slice keys must share pivot fields.");
						w.i32(key.pivot.x).i32(key.pivot.y);
					}
				}
				chunks.push(aseChunk(8226, w), ...userChunk(slice));
			}
		}
		for (const [li, layer] of layers.entries()) {
			const cel = frame.cels[layer.id];
			if (!cel) continue;
			assert(layer.type !== "group", "Sprite group cannot contain a cel.");
			assert([
				cel.x,
				cel.y,
				cel.zIndex || 0
			].every((v) => Number.isInteger(v) && v >= -32768 && v <= 32767), "Sprite cel positions and z-index must be signed 16-bit integers.");
			const image = doc.images[cel.imageId];
			assert(image, "Cel references a missing image.");
			assert(image.width <= 65535 && image.height <= 65535, "Sprite cel dimensions exceed limit.");
			const key = `${layer.id}\0${cel.imageId}`, linked = seenImages.get(key), type = linked != null ? 1 : image.tilemap ? 3 : 2, w = new Writer().u16(li).i16(cel.x).i16(cel.y).u8(Math.round((cel.opacity ?? 1) * 255)).u16(type).i16(cel.zIndex || 0).zero(5);
			if (type === 1) w.u16(linked);
			else {
				seenImages.set(key, fi);
				w.u16(image.width).u16(image.height);
				if (type === 3) {
					const t = image.tilemap;
					assert([
						8,
						16,
						32
					].includes(t.bitsPerTile), "Invalid tile bits.");
					assert(t.tiles.length === image.width * image.height, "Tilemap cell count mismatch.");
					w.u16(t.bitsPerTile).u32(t.idMask).u32(t.xFlipMask).u32(t.yFlipMask).u32(t.diagonalFlipMask).zero(10);
					const tw = new Writer();
					for (const value of t.tiles) if (t.bitsPerTile === 32) tw.u32(value);
					else if (t.bitsPerTile === 16) tw.u16(value);
					else tw.u8(value);
					w.raw(zlibSync(tw.done()));
				} else w.raw(zlibSync(encodePixels(image, depth, frame.palette || doc.palette, meta.transparentIndex || 0)));
			}
			chunks.push(aseChunk(8197, w));
			if (cel.preciseBounds) {
				const b = cel.preciseBounds;
				chunks.push(aseChunk(8198, new Writer().u32(b.flags ?? 1).i32(Math.round(b.x * 65536)).i32(Math.round(b.y * 65536)).i32(Math.round(b.width * 65536)).i32(Math.round(b.height * 65536)).zero(16)));
			}
			chunks.push(...userChunk(cel));
		}
		const body = concat(chunks), fw = new Writer().u32(body.length + 16).u16(61946).u16(Math.min(chunks.length, 65535)).u16(frame.durationMs).zero(2).u32(chunks.length).raw(body);
		frames.push(fw.done());
	}
	const body = concat(frames);
	return concat([new Writer().u32(body.length + 128).u16(42464).u16(doc.frames.length).u16(doc.width).u16(doc.height).u16(depth).u32(3 | (hasUuid ? 4 : 0)).u16(doc.frames[0].durationMs).zero(8).u8(meta.transparentIndex || 0).zero(3).u16(doc.palette?.length || 0).u8(meta.pixelRatio?.width || 1).u8(meta.pixelRatio?.height || 1).i16(meta.grid?.x || 0).i16(meta.grid?.y || 0).u16(meta.grid?.width || 0).u16(meta.grid?.height || 0).zero(84).done(), body]);
}
const crcTable = Uint32Array.from({ length: 256 }, (_, n) => {
	for (let k = 0; k < 8; k++) n = n & 1 ? 3988292384 ^ n >>> 1 : n >>> 1;
	return n >>> 0;
});
function crc32(data) {
	let c = 4294967295;
	for (const b of data) c = crcTable[(c ^ b) & 255] ^ c >>> 8;
	return (c ^ 4294967295) >>> 0;
}
function be32(n) {
	return Uint8Array.of(n >>> 24, n >>> 16, n >>> 8, n);
}
function pngChunk(name, payload) {
	const body = concat([encoder$1.encode(name), payload]);
	return concat([
		be32(payload.length),
		body,
		be32(crc32(body))
	]);
}
function writePng(width, height, rgba, options = {}) {
	dimensions(width, height);
	assert(rgba.length === width * height * 4, "PNG RGBA data length mismatch.");
	const head = concat([
		be32(width),
		be32(height),
		Uint8Array.of(8, 6, 0, 0, 0)
	]), scan = new Uint8Array(height * (width * 4 + 1));
	for (let y = 0; y < height; y++) scan.set(rgba.subarray(y * width * 4, (y + 1) * width * 4), y * (width * 4 + 1) + 1);
	return concat([
		Uint8Array.of(137, 80, 78, 71, 13, 10, 26, 10),
		pngChunk("IHDR", head),
		...options.colorProfile?.type === 2 ? [pngChunk("iCCP", concat([
			encoder$1.encode("PixelWall ICC"),
			Uint8Array.of(0, 0),
			zlibSync(Uint8Array.from(options.colorProfile.icc))
		]))] : [pngChunk("sRGB", Uint8Array.of(0))],
		pngChunk("IDAT", zlibSync(scan)),
		pngChunk("IEND", new Uint8Array())
	]);
}
function paeth(a, b, c) {
	const p = a + b - c, pa = Math.abs(p - a), pb = Math.abs(p - b), pc = Math.abs(p - c);
	return pa <= pb && pa <= pc ? a : pb <= pc ? b : c;
}
function readPng(input) {
	const data = bytes(input);
	assert(data.length >= 33 && [
		137,
		80,
		78,
		71,
		13,
		10,
		26,
		10
	].every((b, i) => data[i] === b), "Not a PNG image.");
	const v = new DataView(data.buffer, data.byteOffset, data.byteLength), idat = [], warnings = [];
	let p = 8, width, height, bitDepth, colorType, interlace, palette = null, transparency = null, ended = false, header = false, colorProfile = null, pngGamma = null, explicitSRGB = false;
	while (p < data.length) {
		assert(p + 12 <= data.length, "Truncated PNG chunk.");
		const len = v.getUint32(p), type = decoder.decode(data.subarray(p + 4, p + 8));
		assert(p + len + 12 <= data.length, "Truncated PNG payload.");
		const body = data.subarray(p + 8, p + 8 + len);
		assert(crc32(data.subarray(p + 4, p + 8 + len)) === v.getUint32(p + 8 + len), `PNG ${type} checksum mismatch.`);
		if (type === "IHDR") {
			assert(!header && p === 8 && len === 13, "Invalid PNG header.");
			header = true;
			width = v.getUint32(p + 8);
			height = v.getUint32(p + 12);
			dimensions(width, height);
			bitDepth = body[8];
			colorType = body[9];
			assert(body[10] === 0 && body[11] === 0 && body[12] <= 1, "Unsupported PNG compression, filter or interlace.");
			interlace = body[12];
			assert({
				0: [
					1,
					2,
					4,
					8,
					16
				],
				2: [8, 16],
				3: [
					1,
					2,
					4,
					8
				],
				4: [8, 16],
				6: [8, 16]
			}[colorType]?.includes(bitDepth), "Unsupported PNG color type/bit depth.");
		} else if (type === "PLTE") {
			assert(len % 3 === 0 && len > 0 && len <= 768, "Invalid PNG palette.");
			palette = body;
		} else if (type === "tRNS") transparency = body;
		else if (type === "IDAT") idat.push(body);
		else if (type === "IEND") {
			ended = true;
			p += 12;
			break;
		} else if (type === "acTL") throw new Error("Animated PNG is not supported; import PNG frames or a GIF instead.");
		else if (type === "sRGB") {
			assert(len === 1 && body[0] <= 3, "Invalid PNG rendering intent.");
			explicitSRGB = true;
		} else if (type === "gAMA") {
			assert(len === 4, "Invalid PNG gamma.");
			const value = new DataView(body.buffer, body.byteOffset, body.byteLength).getUint32(0);
			assert(value > 0, "Invalid PNG gamma.");
			pngGamma = 1e5 / value;
		} else if (type === "iCCP") {
			const end = body.indexOf(0);
			assert(end > 0 && end <= 79 && body[end + 1] === 0, "Invalid PNG ICC profile.");
			const compressed = body.subarray(end + 2), icc = unzlibSync(compressed, { out: new Uint8Array(4194305) });
			assert(icc.length >= 132 && icc.length <= 4 * 1024 * 1024, "PNG ICC profile exceeds 4 MB or is truncated.");
			inflateExact(compressed, icc.length);
			colorProfile = {
				type: 2,
				flags: 0,
				gamma: 0,
				icc: Array.from(icc)
			};
		} else if (type[0] === type[0].toUpperCase()) throw new Error(`Unsupported critical PNG chunk ${type}.`);
		p += len + 12;
	}
	assert(header && ended && idat.length, "Incomplete PNG file.");
	assert(p === data.length, "Unexpected bytes after PNG end.");
	if (colorType === 3) assert(palette, "Indexed PNG is missing its palette.");
	if (bitDepth === 16) warnings.push("16-bit PNG channels are reduced to 8 bits for pixel editing.");
	const channels = {
		0: 1,
		2: 3,
		3: 1,
		4: 2,
		6: 4
	}[colorType], passes = interlace ? [
		[
			0,
			0,
			8,
			8
		],
		[
			4,
			0,
			8,
			8
		],
		[
			0,
			4,
			4,
			8
		],
		[
			2,
			0,
			4,
			4
		],
		[
			0,
			2,
			2,
			4
		],
		[
			1,
			0,
			2,
			2
		],
		[
			0,
			1,
			1,
			2
		]
	] : [[
		0,
		0,
		1,
		1
	]], scanLen = passes.reduce((n, [x, y, dx, dy]) => {
		const w = Math.ceil((width - x) / dx), h = Math.ceil((height - y) / dy);
		return n + (w > 0 && h > 0 ? (1 + Math.ceil(w * channels * bitDepth / 8)) * h : 0);
	}, 0), raw = inflateExact(concat(idat), scanLen), rgba = new Uint8Array(width * height * 4);
	let offset = 0;
	for (const [x0, y0, dx, dy] of passes) {
		const w = Math.ceil((width - x0) / dx), h = Math.ceil((height - y0) / dy);
		if (w <= 0 || h <= 0) continue;
		const rowBytes = Math.ceil(w * channels * bitDepth / 8), bpp = Math.max(1, Math.ceil(channels * bitDepth / 8));
		let prev = new Uint8Array(rowBytes);
		for (let y = 0; y < h; y++) {
			const filter = raw[offset++];
			assert(filter <= 4, "Invalid PNG filter.");
			const row = raw.slice(offset, offset + rowBytes);
			offset += rowBytes;
			for (let i = 0; i < rowBytes; i++) {
				const a = i >= bpp ? row[i - bpp] : 0, b = prev[i], c = i >= bpp ? prev[i - bpp] : 0;
				row[i] = row[i] + (filter === 1 ? a : filter === 2 ? b : filter === 3 ? Math.floor((a + b) / 2) : filter === 4 ? paeth(a, b, c) : 0) & 255;
			}
			const sample = (i) => bitDepth === 16 ? row[i * 2] << 8 | row[i * 2 + 1] : bitDepth === 8 ? row[i] : row[Math.floor(i * bitDepth / 8)] >>> 8 - bitDepth - i * bitDepth % 8 & (1 << bitDepth) - 1, to8 = (n) => Math.round(n * 255 / (bitDepth === 16 ? 65535 : (1 << bitDepth) - 1));
			for (let x = 0; x < w; x++) {
				const q = x * channels, out = ((y0 + y * dy) * width + x0 + x * dx) * 4;
				let r, g, b, a = 255;
				if (colorType === 3) {
					const index = sample(q);
					assert(index * 3 + 2 < palette.length, "PNG pixel references a missing palette color.");
					r = palette[index * 3];
					g = palette[index * 3 + 1];
					b = palette[index * 3 + 2];
					a = transparency?.[index] ?? 255;
				} else if (colorType === 0 || colorType === 4) {
					const gray = sample(q);
					r = g = b = to8(gray);
					a = colorType === 4 ? to8(sample(q + 1)) : transparency && gray === (transparency[0] << 8 | transparency[1]) ? 0 : 255;
				} else {
					const rv = sample(q), gv = sample(q + 1), bv = sample(q + 2);
					r = to8(rv);
					g = to8(gv);
					b = to8(bv);
					a = colorType === 6 ? to8(sample(q + 3)) : transparency && rv === (transparency[0] << 8 | transparency[1]) && gv === (transparency[2] << 8 | transparency[3]) && bv === (transparency[4] << 8 | transparency[5]) ? 0 : 255;
				}
				rgba.set([
					r,
					g,
					b,
					a
				], out);
			}
			prev = row;
		}
	}
	return {
		width,
		height,
		rgba,
		warnings: [...new Set(warnings)],
		...colorProfile ? { colorProfile } : !explicitSRGB && pngGamma ? { colorProfile: {
			type: 1,
			flags: 1,
			gamma: pngGamma
		} } : {}
	};
}
function importGif(input, options = {}) {
	const data = bytes(input);
	assert(data.length >= 13 && /^GIF8[79]a$/.test(decoder.decode(data.subarray(0, 6))), "Not a GIF image.");
	const reader = new GifReader(data), { width, height } = reader;
	dimensions(width, height);
	const entries = [], canvas = new Uint8Array(width * height * 4), warnings = ["GIF imports use its indexed colors and frame timing; GIF has binary transparency."];
	assert(reader.numFrames() > 0, "GIF has no frames.");
	assert(width * height * reader.numFrames() <= MAX_PIXELS, "GIF animation exceeds the import pixel limit.");
	let previous = null, restore = null;
	const hasGlobalPalette = !!(data[10] & 128), bgOffset = 13 + data[11] * 3;
	const bg = hasGlobalPalette && bgOffset + 2 < data.length ? [
		data[bgOffset],
		data[bgOffset + 1],
		data[bgOffset + 2],
		255
	] : [
		0,
		0,
		0,
		0
	];
	for (let i = 0; i < reader.numFrames(); i++) {
		const info = reader.frameInfo(i);
		if (previous?.disposal === 2) {
			const fill = previous.transparent_index != null ? [
				0,
				0,
				0,
				0
			] : bg;
			for (let y = previous.y; y < previous.y + previous.height; y++) for (let x = previous.x; x < previous.x + previous.width; x++) canvas.set(fill, (y * width + x) * 4);
		} else if (previous?.disposal === 3 && restore) canvas.set(restore);
		if (i === 0 && info.transparent_index == null) for (let p = 0; p < canvas.length; p += 4) canvas.set(bg, p);
		restore = info.disposal === 3 ? canvas.slice() : null;
		const decoded = new Uint8Array(canvas.length);
		reader.decodeAndBlitFrameRGBA(i, decoded);
		for (let p = 0; p < decoded.length; p += 4) if (decoded[p + 3]) canvas.set(decoded.subarray(p, p + 4), p);
		entries.push({
			width,
			height,
			rgba: canvas.slice(),
			durationMs: info.delay ? info.delay * 10 : 100
		});
		previous = info;
	}
	const document = imageDocument(entries, {
		...options,
		name: options.name || "Imported GIF"
	});
	document.metadata.gif = { loopCount: reader.loopCount() };
	return {
		document,
		warnings
	};
}
function importSheet(image, options = {}) {
	const { width, height, rgba } = image;
	dimensions(width, height);
	assert(rgba.length === width * height * 4, "Sprite sheet pixels mismatch.");
	const cellWidth = Number(options.frameWidth || options.cellWidth), cellHeight = Number(options.frameHeight || options.cellHeight), margin = Number(options.margin ?? options.padding ?? 0), spacing = Number(options.spacing || 0);
	dimensions(cellWidth, cellHeight);
	assert([margin, spacing].every((n) => Number.isInteger(n) && n >= 0), "Sheet margin and spacing must be nonnegative integers.");
	const availableColumns = Math.floor((width - margin * 2 + spacing) / (cellWidth + spacing)), columns = options.columns || availableColumns, rows = Math.floor((height - margin * 2 + spacing) / (cellHeight + spacing));
	assert(Number.isInteger(columns) && columns > 0 && columns <= availableColumns && rows > 0, "Frame dimensions do not fit the sheet.");
	const count = options.count ?? columns * rows;
	assert(Number.isInteger(count) && count > 0 && count <= columns * rows, "Requested sheet frame count exceeds available cells.");
	const entries = [];
	for (let i = 0; i < count; i++) {
		const col = options.order === "column" ? Math.floor(i / rows) : i % columns, row = options.order === "column" ? i % rows : Math.floor(i / columns), x = margin + col * (cellWidth + spacing), y = margin + row * (cellHeight + spacing), out = new Uint8Array(cellWidth * cellHeight * 4);
		for (let yy = 0; yy < cellHeight; yy++) out.set(rgba.subarray(((y + yy) * width + x) * 4, ((y + yy) * width + x + cellWidth) * 4), yy * cellWidth * 4);
		entries.push({
			width: cellWidth,
			height: cellHeight,
			rgba: out
		});
	}
	return imageDocument(entries, options);
}
function frameBounds(entry, trim) {
	let x = 0, y = 0, w = entry.width, h = entry.height;
	if (trim) {
		let x1 = w, y1 = h, x2 = -1, y2 = -1;
		for (let py = 0; py < h; py++) for (let px = 0; px < w; px++) if (entry.rgba[(py * w + px) * 4 + 3]) {
			x1 = Math.min(x1, px);
			y1 = Math.min(y1, py);
			x2 = Math.max(x2, px);
			y2 = Math.max(y2, py);
		}
		if (x2 < 0) return {
			x: 0,
			y: 0,
			w: 1,
			h: 1,
			empty: true
		};
		x = x1;
		y = y1;
		w = x2 - x1 + 1;
		h = y2 - y1 + 1;
	}
	return {
		x,
		y,
		w,
		h,
		empty: false
	};
}
const pow2 = (n) => 2 ** Math.ceil(Math.log2(Math.max(1, n)));
function intersects(a, b) {
	return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
}
function maxRects(items, width, height) {
	let free = [{
		x: 0,
		y: 0,
		w: width,
		h: height
	}];
	const placed = [];
	for (const item of items) {
		let best = null;
		for (const f of free) if (item.w <= f.w && item.h <= f.h) {
			const score = [
				Math.min(f.w - item.w, f.h - item.h),
				Math.max(f.w - item.w, f.h - item.h),
				f.y,
				f.x
			];
			if (!best || score.some((v, i) => v < best.score[i] && score.slice(0, i).every((n, j) => n === best.score[j]))) best = {
				x: f.x,
				y: f.y,
				w: item.w,
				h: item.h,
				score
			};
		}
		if (!best) return null;
		const next = [];
		for (const f of free) {
			if (!intersects(f, best)) {
				next.push(f);
				continue;
			}
			if (best.x > f.x) next.push({
				x: f.x,
				y: f.y,
				w: best.x - f.x,
				h: f.h
			});
			if (best.x + best.w < f.x + f.w) next.push({
				x: best.x + best.w,
				y: f.y,
				w: f.x + f.w - best.x - best.w,
				h: f.h
			});
			if (best.y > f.y) next.push({
				x: f.x,
				y: f.y,
				w: f.w,
				h: best.y - f.y
			});
			if (best.y + best.h < f.y + f.h) next.push({
				x: f.x,
				y: best.y + best.h,
				w: f.w,
				h: f.y + f.h - best.y - best.h
			});
		}
		free = next.filter((a, i) => !next.some((b, j) => i !== j && a.x >= b.x && a.y >= b.y && a.x + a.w <= b.x + b.w && a.y + a.h <= b.y + b.h && (a.w !== b.w || a.h !== b.h || i > j)));
		placed.push({
			...item,
			x: best.x,
			y: best.y
		});
	}
	return placed;
}
function blitTrim(atlas, atlasWidth, entry, bounds, x, y, extrude) {
	for (let py = -extrude; py < bounds.h + extrude; py++) for (let px = -extrude; px < bounds.w + extrude; px++) {
		const sx = bounds.x + Math.min(bounds.w - 1, Math.max(0, px)), source = ((bounds.y + Math.min(bounds.h - 1, Math.max(0, py))) * entry.width + sx) * 4, dest = ((y + py) * atlasWidth + x + px) * 4;
		if (!bounds.empty) atlas.set(entry.rgba.subarray(source, source + 4), dest);
	}
}
function packAtlas(entries, options = {}) {
	assert(entries.length > 0, "No frames to pack.");
	const padding = options.padding ?? 1, extrude = options.extrude ?? 0, maxSize = options.maxSize ?? 8192, border = options.border ?? padding;
	assert([
		padding,
		extrude,
		border
	].every((n) => Number.isInteger(n) && n >= 0), "Atlas spacing must be nonnegative integers.");
	assert(Number.isInteger(maxSize) && maxSize > 0 && maxSize <= 16384, "Atlas maxSize must be 1–16384.");
	const names = /* @__PURE__ */ new Set(), items = entries.map((entry, index) => {
		dimensions(entry.width, entry.height);
		assert(entry.rgba.length === entry.width * entry.height * 4, "Atlas frame pixels mismatch.");
		const name = entry.name || entry.id || `frame-${index + 1}`;
		assert(!names.has(name), "Atlas frame names must be unique.");
		names.add(name);
		const bounds = frameBounds(entry, options.trim !== false);
		return {
			index,
			name,
			entry,
			bounds,
			w: bounds.w + extrude * 2 + padding,
			h: bounds.h + extrude * 2 + padding
		};
	}).sort((a, b) => Math.max(b.w, b.h) - Math.max(a.w, a.h) || b.w * b.h - a.w * a.h || a.index - b.index);
	const layout = options.layout || "packed";
	assert([
		"packed",
		"horizontal",
		"vertical",
		"grid"
	].includes(layout), "Unknown atlas layout.");
	let placed, width, height;
	if (layout !== "packed") {
		const ordered = [...items].sort((a, b) => a.index - b.index), columns = layout === "horizontal" ? items.length : layout === "vertical" ? 1 : options.columns || Math.ceil(Math.sqrt(items.length));
		assert(Number.isInteger(columns) && columns > 0, "Atlas columns must be positive.");
		const cw = Math.max(...items.map((i) => i.w)), ch = Math.max(...items.map((i) => i.h));
		placed = ordered.map((item, index) => ({
			...item,
			x: index % columns * cw,
			y: Math.floor(index / columns) * ch
		}));
		width = columns * cw + border * 2;
		height = Math.ceil(items.length / columns) * ch + border * 2;
		if (options.powerOfTwo) {
			width = pow2(width);
			height = pow2(height);
		}
		assert(width <= maxSize && height <= maxSize, "Layout exceeds the maximum atlas size.");
	} else {
		const minW = Math.max(...items.map((i) => i.w)) + border * 2, minH = Math.max(...items.map((i) => i.h)) + border * 2, area = items.reduce((n, i) => n + i.w * i.h, 0), candidates = [];
		assert(!!options.width === !!options.height, "Specify both atlas width and height.");
		if (options.width && options.height) candidates.push([options.width, options.height]);
		else {
			const ws = [], hs = [];
			for (let w = pow2(minW); w <= maxSize; w *= 2) ws.push(w);
			for (let h = pow2(minH); h <= maxSize; h *= 2) hs.push(h);
			if (!options.powerOfTwo) {
				if (!ws.includes(maxSize)) ws.push(maxSize);
				if (!hs.includes(maxSize)) hs.push(maxSize);
			}
			for (const w of ws) for (const h of hs) if ((w - border * 2) * (h - border * 2) >= area) candidates.push([w, h]);
		}
		candidates.sort((a, b) => a[0] * a[1] - b[0] * b[1] || Math.abs(a[0] - a[1]) - Math.abs(b[0] - b[1]));
		for (const [w, h] of candidates) {
			if (w > maxSize || h > maxSize || w <= border * 2 || h <= border * 2) continue;
			const result = maxRects(items, w - border * 2, h - border * 2);
			if (result) {
				placed = result;
				width = w;
				height = h;
				break;
			}
		}
		assert(placed, "Frames do not fit the maximum atlas size; increase maxSize or export fewer frames.");
		if (!options.powerOfTwo && !options.width && !options.height) {
			width = Math.max(...placed.map((i) => i.x + i.w)) + border * 2;
			height = Math.max(...placed.map((i) => i.y + i.h)) + border * 2;
		}
	}
	dimensions(width, height);
	const rgba = new Uint8Array(width * height * 4), frames = [];
	for (const item of placed) {
		const x = item.x + border + extrude, y = item.y + border + extrude;
		blitTrim(rgba, width, item.entry, item.bounds, x, y, extrude);
		frames.push({
			filename: item.name,
			id: item.entry.id || item.name,
			frame: {
				x,
				y,
				w: item.bounds.w,
				h: item.bounds.h
			},
			rotated: false,
			trimmed: item.bounds.w !== item.entry.width || item.bounds.h !== item.entry.height || item.bounds.x !== 0 || item.bounds.y !== 0,
			spriteSourceSize: {
				x: item.bounds.x,
				y: item.bounds.y,
				w: item.bounds.w,
				h: item.bounds.h
			},
			sourceSize: {
				w: item.entry.width,
				h: item.entry.height
			},
			duration: item.entry.durationMs || 100,
			empty: item.bounds.empty,
			pivot: item.entry.pivot || {
				x: .5,
				y: .5
			},
			index: item.index
		});
	}
	frames.sort((a, b) => a.index - b.index);
	const scale = options.scale ?? 1;
	assert(Number.isFinite(Number(scale)) && Number(scale) > 0, "Atlas metadata scale must be positive.");
	const scaleBounds = (value) => value ? Object.fromEntries(Object.entries(value).map(([key, v]) => [key, [
		"x",
		"y",
		"width",
		"height"
	].includes(key) && typeof v === "number" ? v * Number(scale) : v])) : value;
	const slices = (options.slices || []).map((slice) => ({
		...slice,
		...slice.bounds ? { bounds: scaleBounds(slice.bounds) } : {},
		...slice.pivot ? { pivot: scaleBounds(slice.pivot) } : {},
		...slice.ninePatch ? { ninePatch: scaleBounds(slice.ninePatch) } : {},
		...slice.keys ? { keys: slice.keys.map((key) => ({
			...scaleBounds(key),
			...key.pivot ? { pivot: scaleBounds(key.pivot) } : {},
			...key.center ? { center: scaleBounds(key.center) } : {}
		})) } : {}
	}));
	const frameTags = (options.clips || []).flatMap((clip) => {
		const indices = entries.map((entry, index) => clip.frameIds?.includes(entry.id) ? index : -1).filter((index) => index >= 0);
		return indices.length ? [{
			...clip,
			from: indices[0],
			to: indices.at(-1),
			frameIndices: indices,
			sourceFrameIds: clip.frameIds,
			frameIds: indices.map((i) => entries[i].id),
			partial: clip.frameIds.some((id) => !entries.some((e) => e.id === id))
		}] : [];
	});
	return {
		width,
		height,
		rgba,
		frames,
		meta: {
			app: "PixelWall",
			version: "4",
			image: options.imageName || "atlas.png",
			format: "RGBA8888",
			size: {
				w: width,
				h: height
			},
			scale: String(scale),
			padding,
			extrude,
			border,
			layout,
			powerOfTwo: !!options.powerOfTwo,
			frameTags,
			sourceClips: options.clips || [],
			slices,
			sourceSlices: options.slices || []
		}
	};
}
function encodeGif(entries, options = {}) {
	assert(entries.length > 0, "No GIF frames.");
	const { width, height } = entries[0];
	dimensions(width, height);
	assert(width <= 65535 && height <= 65535, "GIF dimensions exceed limit.");
	assert(entries.every((e) => e.width === width && e.height === height), "GIF frames must share dimensions.");
	const buffer = new Uint8Array(Math.max(4096, width * height * entries.length * 2 + entries.length * 1024)), writer = new GifWriter(buffer, width, height, options.loop === -1 ? {} : { loop: options.loop ?? 0 });
	for (const entry of entries) {
		const exact = /* @__PURE__ */ new Map(), pixels = entry.rgba;
		assert(pixels.length === width * height * 4, "GIF pixel count mismatch.");
		for (let p = 0; p < pixels.length; p += 4) if (pixels[p + 3] >= 128) {
			const value = pixels[p] * 65536 + pixels[p + 1] * 256 + pixels[p + 2];
			if (!exact.has(value)) exact.set(value, exact.size + 1);
			if (exact.size > 255) break;
		}
		let palette = [0], indices = new Uint8Array(width * height);
		if (exact.size <= 255) {
			palette.push(...exact.keys());
			for (let i = 0; i < indices.length; i++) {
				const p = i * 4;
				indices[i] = pixels[p + 3] >= 128 ? exact.get(pixels[p] * 65536 + pixels[p + 1] * 256 + pixels[p + 2]) : 0;
			}
		} else {
			for (let r = 0; r < 6; r++) for (let g = 0; g < 6; g++) for (let b = 0; b < 6; b++) palette.push(r * 51 * 65536 + g * 51 * 256 + b * 51);
			for (let i = 0; i < indices.length; i++) {
				const p = i * 4;
				indices[i] = pixels[p + 3] >= 128 ? 1 + Math.round(pixels[p] / 51) * 36 + Math.round(pixels[p + 1] / 51) * 6 + Math.round(pixels[p + 2] / 51) : 0;
			}
		}
		while (palette.length < pow2(palette.length)) palette.push(0);
		if (palette.length < 2) palette.push(0);
		writer.addFrame(0, 0, width, height, indices, {
			palette,
			transparent: 0,
			disposal: 2,
			delay: Math.max(1, Math.min(65535, Math.round((entry.durationMs || 100) / 10)))
		});
	}
	return buffer.slice(0, writer.end());
}
/** Windows BMP: RGB, indexed, bitfields and RLE4/RLE8. */
function readBmp(input) {
	const data = bytes(input), r = new Reader(data);
	assert(data.length >= 26 && r.u16() === 19778, "Not a BMP image.");
	const fileSize = r.u32();
	r.skip(4);
	const pixelOffset = r.u32(), headerSize = r.u32();
	assert(fileSize === 0 || fileSize <= data.length, "Truncated BMP file.");
	assert(headerSize === 12 || [
		40,
		52,
		56,
		108,
		124
	].includes(headerSize), "Unsupported BMP header version.");
	assert(14 + headerSize <= data.length && pixelOffset >= 14 + headerSize && pixelOffset <= data.length, "Invalid BMP pixel offset.");
	let width, height, topDown = false, bits, compression = 0, colorCount = 0;
	const warnings = [];
	let maskR = 0, maskG = 0, maskB = 0, maskA = 0;
	if (headerSize === 12) {
		width = r.u16();
		height = r.u16();
		assert(r.u16() === 1, "Invalid BMP planes.");
		bits = r.u16();
	} else {
		width = r.i32();
		const signedHeight = r.i32();
		topDown = signedHeight < 0;
		height = Math.abs(signedHeight);
		assert(r.u16() === 1, "Invalid BMP planes.");
		bits = r.u16();
		compression = r.u32();
		r.skip(12);
		colorCount = r.u32();
		r.skip(4);
		if (headerSize >= 52) {
			maskR = r.u32();
			maskG = r.u32();
			maskB = r.u32();
			if (headerSize >= 56) maskA = r.u32();
		}
		if (headerSize >= 108) {
			r.p = 70;
			const space = r.u32();
			if (![1934772034, 1466527264].includes(space)) warnings.push("BMP calibrated or embedded color profile is not converted; imported pixels use sRGB.");
		}
	}
	dimensions(width, height);
	assert([
		1,
		4,
		8,
		16,
		24,
		32
	].includes(bits), "Unsupported BMP bit depth.");
	assert([
		0,
		1,
		2,
		3,
		6
	].includes(compression), "Unsupported BMP compression (JPEG/PNG-embedded BMP is not supported).");
	assert(compression !== 1 || bits === 8, "BMP RLE8 requires 8-bit pixels.");
	assert(compression !== 2 || bits === 4, "BMP RLE4 requires 4-bit pixels.");
	assert(![3, 6].includes(compression) || [16, 32].includes(bits), "BMP bitfields require 16 or 32 bits.");
	assert(!topDown || [
		0,
		3,
		6
	].includes(compression), "Top-down RLE BMP is invalid.");
	r.p = 14 + headerSize;
	if ([3, 6].includes(compression) && headerSize === 40) {
		maskR = r.u32();
		maskG = r.u32();
		maskB = r.u32();
		if (compression === 6) maskA = r.u32();
	}
	if (![3, 6].includes(compression)) {
		if (bits === 16) {
			maskR = 31744;
			maskG = 992;
			maskB = 31;
			maskA = 0;
		} else if (bits === 32) {
			maskR = 16711680;
			maskG = 65280;
			maskB = 255;
			maskA = 0;
		}
	}
	function channel(value, mask, defaultValue = 0) {
		if (!mask) return defaultValue;
		mask >>>= 0;
		let shift = 0;
		while ((mask >>> shift & 1) === 0 && shift < 32) shift++;
		const max = mask >>> shift;
		assert((max & max + 1) === 0, "Noncontiguous BMP channel mask.");
		return Math.round(((value & mask) >>> 0) / 2 ** shift * 255 / max);
	}
	if ([16, 32].includes(bits)) assert(maskR && maskG && maskB && !(maskR & maskG) && !(maskR & maskB) && !(maskG & maskB) && !(maskA & (maskR | maskG | maskB)), "Invalid overlapping BMP bit masks.");
	const palette = [];
	if (bits <= 8) {
		const count = colorCount || 2 ** bits;
		assert(count <= 2 ** bits, "BMP palette exceeds bit depth.");
		for (let i = 0; i < count; i++) {
			const b = r.u8(), g = r.u8(), red = r.u8();
			if (headerSize !== 12) r.skip(1);
			palette.push([
				red,
				g,
				b,
				255
			]);
		}
		assert(r.p <= pixelOffset, "BMP palette overlaps pixels.");
	}
	const rgba = new Uint8Array(width * height * 4), put = (x, y, index) => {
		assert(x >= 0 && x < width && y >= 0 && y < height, "BMP RLE coordinates exceed the image.");
		assert(palette[index], "BMP index refers to a missing palette color.");
		rgba.set(palette[index], ((topDown ? y : height - 1 - y) * width + x) * 4);
	};
	r.p = pixelOffset;
	if (compression === 1 || compression === 2) {
		for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) put(x, y, 0);
		let x = 0, y = 0, ended = false;
		while (r.p < data.length && !ended) {
			const count = r.u8(), value = r.u8();
			if (count) for (let i = 0; i < count; i++) put(x++, y, compression === 1 ? value : i % 2 ? value & 15 : value >>> 4);
			else if (value === 0) {
				x = 0;
				y++;
			} else if (value === 1) ended = true;
			else if (value === 2) {
				x += r.u8();
				y += r.u8();
				assert(x <= width && y < height, "BMP RLE delta exceeds image.");
			} else {
				const n = value, byteCount = compression === 1 ? n : Math.ceil(n / 2), packet = r.take(byteCount);
				for (let i = 0; i < n; i++) put(x++, y, compression === 1 ? packet[i] : i % 2 ? packet[i >> 1] & 15 : packet[i >> 1] >>> 4);
				if (byteCount % 2) r.skip(1);
			}
		}
		assert(ended, "BMP RLE has no end-of-bitmap marker.");
	} else {
		const stride = Math.ceil(width * bits / 32) * 4;
		assert(pixelOffset + stride * height <= data.length, "Truncated BMP raster.");
		for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
			const p = pixelOffset + y * stride + Math.floor(x * bits / 8), out = ((topDown ? y : height - 1 - y) * width + x) * 4;
			let color;
			if (bits <= 8) {
				const index = bits === 8 ? data[p] : bits === 4 ? x % 2 ? data[p] & 15 : data[p] >>> 4 : data[p] >>> 7 - x % 8 & 1;
				assert(palette[index], "BMP index refers to a missing palette color.");
				color = palette[index];
			} else if (bits === 24) color = [
				data[p + 2],
				data[p + 1],
				data[p],
				255
			];
			else {
				const value = bits === 16 ? data[p] | data[p + 1] << 8 : (data[p] | data[p + 1] << 8 | data[p + 2] << 16 | data[p + 3] << 24) >>> 0;
				color = [
					channel(value, maskR),
					channel(value, maskG),
					channel(value, maskB),
					channel(value, maskA, 255)
				];
			}
			rgba.set(color, out);
		}
	}
	return {
		width,
		height,
		rgba,
		warnings
	};
}
/** Emits a BITMAPV5HEADER with explicit RGBA masks and sRGB color space. */
function writeBmp(width, height, rgba) {
	dimensions(width, height);
	assert(rgba.length === width * height * 4, "BMP pixel data length mismatch.");
	const offset = 138, header = new Writer().u16(19778).u32(offset + rgba.length).zero(4).u32(offset).u32(124).i32(width).i32(-height).u16(1).u16(32).u32(3).u32(rgba.length).i32(2835).i32(2835).u32(0).u32(0).u32(16711680).u32(65280).u32(255).u32(4278190080).u32(1934772034).zero(36).zero(12).u32(4).zero(12);
	const raster = new Uint8Array(rgba.length);
	for (let i = 0; i < rgba.length; i += 4) raster.set([
		rgba[i + 2],
		rgba[i + 1],
		rgba[i],
		rgba[i + 3]
	], i);
	return concat([header.done(), raster]);
}
/** Truevision TGA v1/v2: indexed, truecolor and gray, raw or RLE. */
function readTga(input) {
	const data = bytes(input), r = new Reader(data);
	assert(data.length >= 18, "TGA header is truncated.");
	const idLength = r.u8(), colorMapType = r.u8(), type = r.u8(), mapFirst = r.u16(), mapLength = r.u16(), mapBits = r.u8(), xOrigin = r.u16(), yOrigin = r.u16(), width = r.u16(), height = r.u16(), bits = r.u8(), descriptor = r.u8();
	dimensions(width, height);
	assert([
		1,
		2,
		3,
		9,
		10,
		11
	].includes(type) && colorMapType <= 1, "Unsupported TGA image type.");
	assert((descriptor & 192) === 0, "Interleaved TGA images are unsupported.");
	const indexed = type === 1 || type === 9, gray = type === 3 || type === 11, rle = type >= 9;
	assert(!indexed || colorMapType === 1, "Indexed TGA requires a color map.");
	assert(indexed ? [8, 16].includes(bits) : gray ? [8, 16].includes(bits) : [
		15,
		16,
		24,
		32
	].includes(bits), "Unsupported TGA pixel depth.");
	r.skip(idLength);
	const warnings = [];
	let attributeType = null, footerStart = data.length;
	if (data.length >= 26 && decoder.decode(data.subarray(data.length - 18, data.length - 1)) === "TRUEVISION-XFILE.") {
		footerStart = data.length - 26;
		const footer = new Reader(data.subarray(footerStart)), extensionOffset = footer.u32(), developerOffset = footer.u32();
		if (extensionOffset) {
			assert(extensionOffset + 495 <= footerStart, "Truncated TGA extension.");
			attributeType = data[extensionOffset + 494];
			if (data[extensionOffset + 478] || data[extensionOffset + 479] || data[extensionOffset + 480] || data[extensionOffset + 481]) warnings.push("TGA gamma metadata is not converted; imported pixels use sRGB.");
			if (data.subarray(extensionOffset + 2, extensionOffset + 494).some((v) => v !== 0)) warnings.push("TGA extension metadata is not retained in the raster project.");
		}
		if (developerOffset) warnings.push("TGA developer metadata is not retained in the raster project.");
	}
	const alphaBits = descriptor & 15;
	function readColor(depth, isGray = false, fromPalette = false) {
		if (isGray) {
			const v = r.u8();
			return [
				v,
				v,
				v,
				depth === 16 ? r.u8() : 255
			];
		}
		if (depth === 15 || depth === 16) {
			const v = r.u16();
			return [
				Math.round((v >> 10 & 31) * 255 / 31),
				Math.round((v >> 5 & 31) * 255 / 31),
				Math.round((v & 31) * 255 / 31),
				depth === 16 && (alphaBits || fromPalette) ? v & 32768 ? 255 : 0 : 255
			];
		}
		const b = r.u8(), g = r.u8(), red = r.u8(), a = depth === 32 ? r.u8() : 255;
		return [
			red,
			g,
			b,
			depth === 32 && (fromPalette || alphaBits > 0 || attributeType === 3 || attributeType === 4) ? a : 255
		];
	}
	const palette = [];
	if (colorMapType === 1) {
		assert([
			15,
			16,
			24,
			32
		].includes(mapBits), "Unsupported TGA palette entry depth.");
		for (let i = 0; i < mapLength; i++) palette[mapFirst + i] = readColor(mapBits, false, true);
	}
	const readPixel = () => {
		if (indexed) {
			const index = bits === 8 ? r.u8() : r.u16();
			assert(palette[index], "TGA pixel references a missing palette color.");
			return palette[index];
		}
		return readColor(bits, gray);
	}, rgba = new Uint8Array(width * height * 4);
	let written = 0;
	const put = (color) => {
		assert(written < width * height, "TGA RLE packet exceeds image size.");
		let x = written % width, y = Math.floor(written / width);
		if (descriptor & 16) x = width - 1 - x;
		if (!(descriptor & 32)) y = height - 1 - y;
		let [red, g, b, a] = color;
		if (attributeType === 0 || attributeType === 1) a = 255;
		else if (attributeType === 4 && a > 0) {
			red = Math.min(255, Math.round(red * 255 / a));
			g = Math.min(255, Math.round(g * 255 / a));
			b = Math.min(255, Math.round(b * 255 / a));
		}
		rgba.set([
			red,
			g,
			b,
			a
		], (y * width + x) * 4);
		written++;
	};
	while (written < width * height) {
		if (!rle) {
			put(readPixel());
			continue;
		}
		const packet = r.u8(), count = (packet & 127) + 1;
		assert(written + count <= width * height, "TGA RLE packet exceeds dimensions.");
		if (packet & 128) {
			const color = readPixel();
			for (let i = 0; i < count; i++) put(color);
		} else for (let i = 0; i < count; i++) put(readPixel());
	}
	assert(r.p <= footerStart, "TGA pixels overlap its footer.");
	if (xOrigin || yOrigin) warnings.push(`TGA origin (${xOrigin}, ${yOrigin}) is not applied to the raster canvas.`);
	return {
		width,
		height,
		rgba,
		warnings: [...new Set(warnings)]
	};
}
/** Top-left BGRA TGA v2 with straight alpha. */
function writeTga(width, height, rgba, options = {}) {
	dimensions(width, height);
	assert(width <= 65535 && height <= 65535 && rgba.length === width * height * 4, "TGA dimensions or pixels are invalid.");
	const useRle = options.rle !== false, w = new Writer().u8(0).u8(0).u8(useRle ? 10 : 2).zero(9).u16(width).u16(height).u8(32).u8(40), put = (i) => w.raw([
		rgba[i * 4 + 2],
		rgba[i * 4 + 1],
		rgba[i * 4],
		rgba[i * 4 + 3]
	]), equal = (a, b) => rgba[a * 4] === rgba[b * 4] && rgba[a * 4 + 1] === rgba[b * 4 + 1] && rgba[a * 4 + 2] === rgba[b * 4 + 2] && rgba[a * 4 + 3] === rgba[b * 4 + 3];
	if (!useRle) for (let i = 0; i < width * height; i++) put(i);
	else for (let y = 0; y < height; y++) {
		let i = y * width, end = i + width;
		while (i < end) {
			let run = 1;
			while (i + run < end && run < 128 && equal(i, i + run)) run++;
			if (run > 1) {
				w.u8(128 | run - 1);
				put(i);
				i += run;
			} else {
				const start = i++;
				while (i < end && i - start < 128 && !(i + 1 < end && equal(i, i + 1))) i++;
				w.u8(i - start - 1);
				for (let j = start; j < i; j++) put(j);
			}
		}
	}
	const body = w.done();
	return concat([
		body,
		new Writer().u16(495).zero(492).u8(3).done(),
		new Writer().u32(body.length).u32(0).raw(encoder$1.encode("TRUEVISION-XFILE.")).u8(0).done()
	]);
}
/** Game-ready PNG assets, metadata, native project and per-frame Tiled maps.
* The caller MUST authorize Pro before invoking this function. Pass colorManager
* for custom profiles. Supplied entries/atlas must already contain sRGB pixels.
* Pass projectDocument when doc is a visibility-filtered rendering scope, so
* the embedded native project preserves the complete original artwork. */
function makeGamePackage(doc, options = {}) {
	const projectDocument = options.projectDocument ?? doc;
	const safe = (value) => String(value || "asset").replace(/[^a-z0-9_.-]/gi, "_"), json = (value) => strToU8(JSON.stringify(value, null, 2)), entries = options.entries || doc.frames.map((f, i) => ({
		id: f.id,
		name: `${safe(doc.name)}-${String(i + 1).padStart(4, "0")}`,
		width: doc.width,
		height: doc.height,
		rgba: renderExportFrame(doc, f.id, options),
		durationMs: f.durationMs
	}));
	const atlas = options.atlas || packAtlas(entries, {
		...options,
		clips: doc.clips,
		slices: doc.slices,
		imageName: "sprites.png"
	}), files = {
		"sprites.png": writePng(atlas.width, atlas.height, atlas.rgba),
		"sprites.json": json({
			frames: atlas.frames,
			meta: {
				...atlas.meta,
				image: "sprites.png",
				clips: doc.clips,
				slices: atlas.meta.slices || doc.slices,
				sourceSlices: doc.slices
			}
		}),
		[`${safe(projectDocument.name)}.pixelwall`]: json(projectDocument)
	}, manifest = {
		format: "pixelwall-game-package",
		version: 1,
		frameScale: atlas.meta.scale || "1",
		tilemapScale: "1",
		project: `${safe(projectDocument.name)}.pixelwall`,
		atlas: {
			image: "sprites.png",
			metadata: "sprites.json"
		},
		frames: [],
		tilesets: [],
		maps: [],
		clips: doc.clips,
		slices: doc.slices,
		warnings: []
	};
	for (const [index, entry] of entries.entries()) {
		const path = `frames/${String(index + 1).padStart(4, "0")}-${safe(entry.name || entry.id)}.png`;
		files[path] = writePng(entry.width, entry.height, entry.rgba);
		manifest.frames.push({
			frameId: entry.id || doc.frames[index]?.id,
			image: path,
			width: entry.width,
			height: entry.height,
			durationMs: entry.durationMs || entry.duration || 100
		});
	}
	const palettes = [], framePalettes = /* @__PURE__ */ new Map();
	let currentPalette = doc.palette;
	for (const frame of doc.frames) {
		if (frame.palette) currentPalette = frame.palette;
		const key = doc.colorMode === "indexed" ? JSON.stringify(currentPalette) : "rgba";
		let index = palettes.findIndex((v) => v.key === key);
		if (index < 0) {
			index = palettes.length;
			palettes.push({
				key,
				palette: currentPalette
			});
		}
		framePalettes.set(frame.id, index);
	}
	const sets = /* @__PURE__ */ new Map();
	let firstgid = 1;
	for (const [tsi, ts] of (doc.tilesets || []).entries()) {
		const tiles = [];
		if (ts.tiles?.length) for (const tile of ts.tiles) {
			const image = tileImage(doc, tile);
			tiles.push({
				sourceId: tile.id,
				asepriteTileId: tile.asepriteTileId,
				image,
				width: image.width,
				height: image.height
			});
		}
		else if (ts.imageId) {
			const image = doc.images[ts.imageId];
			assert(image && !image.tilemap, "Embedded tileset image is missing.");
			const columns = Math.floor(image.width / ts.tileWidth), count = ts.tileCount ?? columns * Math.floor(image.height / ts.tileHeight);
			for (let index = 0; index < count; index++) {
				const sx = index % columns * ts.tileWidth, sy = Math.floor(index / columns) * ts.tileHeight, pixels = [];
				assert(sx + ts.tileWidth <= image.width && sy + ts.tileHeight <= image.height, "Tileset dimensions exceed its atlas.");
				for (let y = 0; y < ts.tileHeight; y++) for (let x = 0; x < ts.tileWidth; x++) pixels.push(image.pixels[(sy + y) * image.width + sx + x]);
				tiles.push({
					sourceId: index,
					image: {
						width: ts.tileWidth,
						height: ts.tileHeight,
						pixels
					},
					width: ts.tileWidth,
					height: ts.tileHeight
				});
			}
		} else throw new Error(`Tileset “${ts.name}” has no embedded pixel data. Load its external source before exporting a game package.`);
		const localIds = /* @__PURE__ */ new Map();
		tiles.forEach((tile, i) => {
			localIds.set(tile.sourceId, i);
			if (Number.isInteger(tile.asepriteTileId)) localIds.set(tile.asepriteTileId, i);
		});
		const info = {
			firstgid,
			tiles,
			localIds,
			variants: []
		};
		firstgid += tiles.length;
		assert(firstgid < 268435456, "Tiled global tile IDs exceed their supported range.");
		sets.set(ts.id, info);
		for (const [pi, variant] of palettes.entries()) {
			const folder = `tilesets/${tsi + 1}-${safe(ts.name)}${palettes.length > 1 ? `-palette-${pi + 1}` : ""}`, path = `${folder}/tileset.tsj`, tileDefs = [];
			for (const [index, tile] of tiles.entries()) {
				let palette = variant.palette;
				if (doc.colorMode === "indexed" && Number.isInteger(doc.metadata?.aseprite?.transparentIndex)) {
					palette = [...palette];
					palette[doc.metadata.aseprite.transparentIndex] = "#00000000";
				}
				const imagePath = `tile-${String(index).padStart(4, "0")}.png`;
				files[`${folder}/${imagePath}`] = writePng(tile.width, tile.height, toExportRGBA(pixelsToRgba(tile.image.pixels, palette), doc, options));
				tileDefs.push({
					id: index,
					image: imagePath,
					imagewidth: tile.width,
					imageheight: tile.height,
					properties: [{
						name: "pixelwallTileId",
						type: "string",
						value: String(tile.sourceId)
					}]
				});
			}
			files[path] = json({
				type: "tileset",
				version: "1.10",
				name: ts.name,
				tilewidth: ts.tileWidth,
				tileheight: ts.tileHeight,
				tilecount: tiles.length,
				columns: 0,
				margin: 0,
				spacing: 0,
				tiles: tileDefs,
				transformations: {
					hflip: true,
					vflip: true,
					rotate: true,
					preferuntransformed: true
				}
			});
			files[`${folder}/pixelwall-tileset.json`] = json({
				...ts,
				exportedTiles: tileDefs.map((t) => ({
					id: tiles[t.id].sourceId,
					image: `${folder}/${t.image}`
				}))
			});
			info.variants.push(path);
			manifest.tilesets.push({
				id: ts.id,
				name: ts.name,
				firstgid: info.firstgid,
				paletteIndex: pi,
				source: path,
				tileWidth: ts.tileWidth,
				tileHeight: ts.tileHeight,
				count: tiles.length
			});
		}
	}
	function transformGid(gid, cell) {
		let fx = !!cell.flipX, fy = !!cell.flipY, diagonal = false;
		const rotation = ((cell.rotate || 0) % 360 + 360) % 360;
		assert([
			0,
			90,
			180,
			270
		].includes(rotation), "Tiled tiles require quarter-turn rotations.");
		if (rotation === 90) {
			diagonal = true;
			[fx, fy] = [!fy, fx];
		}
		if (rotation === 180) {
			fx = !fx;
			fy = !fy;
		}
		if (rotation === 270) {
			diagonal = true;
			[fx, fy] = [fy, !fx];
		}
		return (gid | (fx ? 2147483648 : 0) | (fy ? 1073741824 : 0) | (diagonal ? 536870912 : 0)) >>> 0;
	}
	const selectedFrameIds = new Set(entries.map((entry) => entry.id).filter(Boolean));
	for (const [fi, frame] of doc.frames.entries()) {
		if (selectedFrameIds.size && !selectedFrameIds.has(frame.id)) continue;
		const groups = /* @__PURE__ */ new Map();
		for (const layer of doc.layers) {
			if (layer.type !== "tilemap") continue;
			const native = layer.tilemaps?.[frame.id], cel = frame.cels[layer.id], image = doc.images[cel?.imageId], ase = image?.tilemap, tilesetId = native?.tilesetId || layer.tilesetId;
			if (!native && !ase) continue;
			const ts = doc.tilesets.find((t) => t.id === tilesetId), info = sets.get(tilesetId);
			assert(ts && info, "Tilemap has no exported tileset.");
			const columns = native?.columns || image.width, rows = native?.rows || image.height, key = `${ts.tileWidth}x${ts.tileHeight}`;
			if (!groups.has(key)) groups.set(key, {
				tilewidth: ts.tileWidth,
				tileheight: ts.tileHeight,
				layers: [],
				sets: /* @__PURE__ */ new Set()
			});
			const group = groups.get(key), data = native ? native.cells.map((cell) => {
				if (cell == null) return 0;
				const id = info.localIds.get(cell.tileId);
				assert(id != null, "Tilemap refers to a missing tile.");
				return transformGid(info.firstgid + id, cell);
			}) : ase.tiles.map((value) => {
				const raw = value >>> 0, index = (raw & ase.idMask) >>> 0;
				if (ts.flags & 4 ? index === 0 : raw === 4294967295) return 0;
				const localId = info.localIds.get(index);
				assert(localId != null, "Sprite tilemap refers to a missing tile.");
				let fx = !!(raw & ase.xFlipMask), fy = !!(raw & ase.yFlipMask);
				const diagonal = !!(raw & ase.diagonalFlipMask);
				return (info.firstgid + localId | (fx ? 2147483648 : 0) | (fy ? 1073741824 : 0) | (diagonal ? 536870912 : 0)) >>> 0;
			});
			let opacity = (layer.opacity ?? 1) * (native ? native.opacity ?? 1 : cel.opacity ?? 1), visible = layer.visible !== false, parent = layer.parentId;
			while (parent) {
				const ancestor = doc.layers.find((l) => l.id === parent);
				assert(ancestor, "Tilemap group parent is missing.");
				opacity *= ancestor.opacity ?? 1;
				visible &&= ancestor.visible !== false;
				parent = ancestor.parentId;
			}
			if (ts.tileWidth !== ts.tileHeight && data.some((gid) => gid & 536870912)) manifest.warnings.push("Some rotated rectangular tiles erase artwork beneath their empty areas. Tiled maps cannot preserve this effect. Use the included rendered frames or atlas for the exact appearance.");
			const mode = layer.blendMode === "addition" ? "add" : layer.blendMode || "normal";
			if (![
				"normal",
				"add",
				"multiply",
				"screen",
				"overlay",
				"darken",
				"lighten",
				"color-dodge",
				"color-burn",
				"hard-light",
				"soft-light",
				"difference",
				"exclusion"
			].includes(mode)) manifest.warnings.push(`Tiled does not support the ${mode} blend mode on “${layer.name}”; the original setting is retained as a property and in the project.`);
			group.layers.push({
				type: "tilelayer",
				id: group.layers.length + 1,
				name: layer.name,
				width: columns,
				height: rows,
				x: 0,
				y: 0,
				offsetx: native ? native.x || 0 : cel.x,
				offsety: native ? native.y || 0 : cel.y,
				opacity,
				visible,
				locked: !!layer.locked,
				mode: [
					"normal",
					"add",
					"multiply",
					"screen",
					"overlay",
					"darken",
					"lighten",
					"color-dodge",
					"color-burn",
					"hard-light",
					"soft-light",
					"difference",
					"exclusion"
				].includes(mode) ? mode : "normal",
				data,
				properties: [
					{
						name: "pixelwallLayerId",
						type: "string",
						value: layer.id
					},
					{
						name: "pixelwallParentId",
						type: "string",
						value: layer.parentId || ""
					},
					{
						name: "pixelwallBlendMode",
						type: "string",
						value: layer.blendMode || "normal"
					}
				]
			});
			group.sets.add(tilesetId);
		}
		for (const [grid, group] of groups) {
			const width = Math.max(Math.ceil(doc.width / group.tilewidth), ...group.layers.map((l) => l.width)), height = Math.max(Math.ceil(doc.height / group.tileheight), ...group.layers.map((l) => l.height));
			for (const layer of group.layers) if (layer.width !== width || layer.height !== height) {
				const data = new Array(width * height).fill(0);
				for (let y = 0; y < layer.height; y++) for (let x = 0; x < layer.width; x++) data[y * width + x] = layer.data[y * layer.width + x];
				layer.width = width;
				layer.height = height;
				layer.data = data;
			}
			const path = `maps/frame-${String(fi + 1).padStart(4, "0")}-${grid}.tmj`;
			files[path] = json({
				type: "map",
				version: "1.10",
				orientation: "orthogonal",
				renderorder: "right-down",
				infinite: false,
				width,
				height,
				tilewidth: group.tilewidth,
				tileheight: group.tileheight,
				nextlayerid: group.layers.length + 1,
				nextobjectid: 1,
				layers: group.layers,
				tilesets: [...sets.keys()].map((id) => {
					const info = sets.get(id);
					return {
						firstgid: info.firstgid,
						source: `../${info.variants[framePalettes.get(frame.id)]}`
					};
				}),
				properties: [{
					name: "pixelwallFrameId",
					type: "string",
					value: frame.id
				}, {
					name: "durationMs",
					type: "int",
					value: frame.durationMs
				}]
			});
			manifest.maps.push({
				frameId: frame.id,
				durationMs: frame.durationMs,
				grid,
				source: path
			});
		}
	}
	if (manifest.maps.length && !isSRGB(documentProfile(doc))) manifest.warnings.push("Tile images are converted to sRGB. A Tiled renderer composites them in its own color space, so overlapping translucent tiles or blend modes can differ from the original profile. Use the rendered frames or atlas for the exact composite.");
	if (manifest.maps.length && doc.layers.some((l) => l.type !== "tilemap")) manifest.warnings.push("Tiled maps contain the tilemap layers. Rendered frame PNGs and the native project retain all raster and group artwork.");
	manifest.warnings = [...new Set(manifest.warnings)];
	files["manifest.json"] = json(manifest);
	return zipSync(files);
}
const encoder = new TextEncoder();
function fromBase64url(value) {
	if (!/^[A-Za-z0-9_-]+$/.test(value)) throw new Error("Invalid license encoding");
	const raw = atob(value.replace(/-/g, "+").replace(/_/g, "/").padEnd(Math.ceil(value.length / 4) * 4, "="));
	return Uint8Array.from(raw, (char) => char.charCodeAt(0));
}
function parsePublicKeys(value) {
	if (typeof value === "string") try {
		value = JSON.parse(value);
	} catch {
		return {};
	}
	if (!value || typeof value !== "object" || Array.isArray(value)) return {};
	return Object.fromEntries(Object.entries(value).filter(([id, key]) => /^[A-Za-z0-9_-]{1,64}$/.test(id) && key?.kty === "EC" && key.crv === "P-256" && typeof key.x === "string" && typeof key.y === "string" && !key.d));
}
/** Returns verified claims or null. A disconnected clock never expires a purchase.
* @param {string} token
* @param {{publicKeys?: Record<string, JsonWebKey> | string, mode?: string, crypto?: Crypto}} [options]
*/
async function verifyOfflineLicense(token, { publicKeys, mode = "live", crypto = globalThis.crypto } = {}) {
	try {
		if (typeof token !== "string" || token.length > 4096 || !crypto?.subtle) return null;
		const parts = token.trim().split(".");
		if (parts.length !== 3 || parts[0] !== "PW2") return null;
		const payloadBytes = fromBase64url(parts[1]);
		const signature = fromBase64url(parts[2]);
		if (signature.length !== 64 || payloadBytes.length > 2e3) return null;
		const claims = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(payloadBytes));
		if (claims.version !== 2 || claims.product !== "pixelwall-pro" || claims.mode !== mode || !["live", "test"].includes(claims.mode) || !/^cs_(test|live)_[a-zA-Z0-9]{8,200}$/.test(claims.purchaseId) || !claims.purchaseId.startsWith(`cs_${mode}_`) || !Number.isSafeInteger(claims.issuedAt) || claims.issuedAt <= 0 || claims.perpetual !== true || Object.hasOwn(claims, "expiresAt")) return null;
		const jwk = parsePublicKeys(publicKeys)[claims.keyId];
		if (!jwk) return null;
		const key = await crypto.subtle.importKey("jwk", jwk, {
			name: "ECDSA",
			namedCurve: "P-256"
		}, false, ["verify"]);
		return await crypto.subtle.verify({
			name: "ECDSA",
			hash: "SHA-256"
		}, key, signature, encoder.encode(`PW2.${parts[1]}`)) ? claims : null;
	} catch {
		return null;
	}
}
//#endregion
//#region app/license-public-keys.mjs
const PINNED_PUBLIC_KEYS = Object.freeze({ "ownership-2026": {
	"key_ops": ["verify"],
	"ext": true,
	"kty": "EC",
	"x": "eNHqIYzyVtEgBb7Y1tUoZ72No3eBuUcFRBOb1hFSVjs",
	"y": "nMCEYZoKTe590TpkPVWcObIuStngIdFYVVb6V2BEa-I",
	"crv": "P-256"
} });
//#endregion
//#region app/cli.mjs
/** Standalone trusted-user CLI; no app server or AI service is required. */
const HELP = `PixelWall CLI — local sprite editing and export

  pixelwall new --width 32 --height 32 --name Hero --out hero.pixelwall
  pixelwall inspect hero.pixelwall
  pixelwall commands
  pixelwall apply hero.pixelwall --commands edits.json --out hero.pixelwall
  pixelwall script hero.pixelwall --script ./draw.mjs --out hero.pixelwall
  pixelwall script hero.pixelwall --script ./draw.lua --params '{"shade":"red"}' --out hero.pixelwall
  pixelwall profile hero.pixelwall --convert sRGB --out converted.pixelwall
  pixelwall profile hero.pixelwall --assign ./working.icc --out assigned.pixelwall
  pixelwall import art.ase --out hero.pixelwall
  pixelwall import sheet.png --frame-width 32 --frame-height 32 --out hero.pixelwall
  pixelwall import-sequence frame1.png frame2.png --duration 100 --out hero.pixelwall
  pixelwall render hero.pixelwall --frame 0 --scale 4 --out hero.png
  pixelwall export hero.pixelwall --format ase --out hero.ase
  pixelwall export hero.pixelwall --format gif --out hero.gif --license license.txt
  pixelwall export hero.pixelwall --format sheet --columns 4 --out hero.png --license license.txt
  pixelwall export hero.pixelwall --format atlas --trim --padding 2 --extrude 1 --power-of-two --out atlas.png --license license.txt
  pixelwall export hero.pixelwall --format zip --out frames.zip --license license.txt
  pixelwall export hero.pixelwall --format png --out-dir frames --split-layers
  pixelwall export hero.pixelwall enemy.ase --format atlas --out sprites.png --license license.txt
  pixelwall export --ordered-inputs --tag idle hero.ase --tag run enemy.ase --format atlas --out sprites.png --license license.txt
  pixelwall export tiles.png --split-grid --grid 0,0,16,16 --format sheet --out tiles-sheet.png --license license.txt
  pixelwall export hero.pixelwall --format gif --play-subtags --split-tags --out-dir animations --license license.txt

Frames are zero-based indices or frame IDs. --clip selects a clip by name or ID.
PNG/BMP/TGA and editable projects are free; GIF, sheet, atlas and ZIP require Pro.
A signed perpetual license can also be supplied with PIXELWALL_PRO_LICENSE.
Lua scripts run in a bounded Lua 5.4 worker with supported sprite editing APIs.
Use --out-dir for scripts that edit several projects and image sequences or split GIF jobs.
Directory exports refuse existing or colliding output filenames. --out and --out-dir are exclusive.
Export flags apply to every input by default, preserving existing commands.
Add --ordered-inputs for selectors before each input: they affect that file and later files.
Repeated --layer/--import-layer/--ignore-layer accumulate; --tag/--clip and ranges replace.
Layer/split visibility flags, --frame, --slice and --grid are also captured per input.
With ordered inputs, --split-grid=false also clears the preceding grid override.
Each --scale resizes inputs already listed; leading scales do not affect later files.
Repeated scales keep intermediate rounding. Tilemaps allow one effective scale.
The last --crop selects the final scaled canvas region for PNG/BMP/TGA/GIF output;
ordered crop cannot be combined with sheet/atlas/ZIP. Editable exports retain originals.
Packing, filenames, crop, trim, scale, license and output paths remain global.
Export accepts --frame-range from,to, --tag, --slice, --crop x,y,w,h, --trim-sprite,
--split-layers/--split-tags/--split-slices, --ignore-empty, and positive --scale up to 64 (including fractions such as 0.5 or 1.5).
GIF/PNG/BMP/TGA tags export timeline order by default. --play-subtags applies tag directions,
finite repeats and nested tags; --frame-range/--frame suppress traversal. Sheets remain timeline order.
Reference layers are omitted from rendered exports; --include-reference-layers opts in.
Atlas/sheet support --sheet-type, --shape-padding, --inner-padding, --border-padding,
--metadata-format json-hash|json-array and --filename-format using source-file placeholders.
Filename templates name files within --out-dir; path separators become underscores.
PNG/BMP/TGA --out exports frame 0 by default; explicit multi-frame selections require --out-dir.
ZIP retains original projects and source packages alongside the combined atlas and source metadata.
Grid extraction: --split-grid supports sheet, atlas and ZIP. --grid x,y,w,h overrides
the saved sprite grid (default 0,0,16,16); it requires --split-grid. Scale applies to
the sprite first; cell dimensions stay fixed. Cells keep their size under --trim.
Incomplete right/bottom cells are omitted; --ignore-empty removes empty cells.
Grid cannot combine with crop, slice, split-slices or trim-sprite. Names include a
cell number; templates can use {cell}, {column}, {row} (zero-based, e.g. {cell001}).
Metadata source.grid records each cell rectangle, index and grid definition.
Atlas coordinates follow the selected PixelWall packing settings.
--timeout allows up to 10000 ms for Lua scripts.
JavaScript modules are explicitly trusted local scripts with normal Node access.
Export default async ({document,apply}) => { apply({type:...}); } from your script.
All edits use the same document commands as the editor. No embedded AI is used.
`;
function fail(message) {
	throw new Error(message);
}
function number(args, key, fallback) {
	if (args[key] == null) return fallback;
	const n = Number(args[key]);
	if (!Number.isFinite(n)) fail(`--${key} must be a number.`);
	return n;
}
function required(args, key) {
	const value = args[key];
	if (typeof value !== "string" || !value) fail(`--${key} is required.`);
	return value;
}
function warn(warnings) {
	for (const warning of warnings || []) process.stderr.write(`Warning: ${warning}\n`);
}
async function readManagedPng(bytes) {
	const image = readPng(bytes);
	if (!image.colorProfile) return image;
	return {
		...image,
		rgba: (await loadNodeColorManager()).transformRGBA(image.rgba, image.colorProfile),
		colorProfile: void 0
	};
}
async function readDocument(path) {
	if (!path) fail("Input file is required.");
	const input = new Uint8Array(await readFile(resolve(path))), extension = extname(path).toLowerCase();
	if ([".ase", ".aseprite"].includes(extension)) {
		const result = readAseprite(input);
		warn(result.warnings);
		return normalizeDocument(result.document);
	}
	if ([
		".png",
		".bmp",
		".tga"
	].includes(extension)) {
		const image = extension === ".bmp" ? readBmp(input) : extension === ".tga" ? readTga(input) : await readManagedPng(input);
		warn(image.warnings);
		return normalizeDocument(importSequence([image], { name: path.split(/[\\/]/).at(-1) }));
	}
	if (extension === ".gif") {
		const result = importGif(input);
		warn(result.warnings);
		return normalizeDocument(result.document);
	}
	return normalizeDocument(JSON.parse(new TextDecoder().decode(input)));
}
async function atomicWrite(path, data) {
	const target = resolve(path);
	await mkdir(dirname(target), { recursive: true });
	const temp = `${target}.${process.pid}.${Date.now()}.tmp`;
	try {
		await writeFile(temp, data);
		await rename(temp, target);
	} catch (error) {
		await unlink(temp).catch(() => {});
		throw error;
	}
}
async function saveDocument(path, document) {
	await atomicWrite(path, JSON.stringify(normalizeDocument(document), null, 2) + "\n");
}
function outputName(value, extension) {
	let name = String(value || "sprite").replace(/\.(ase|aseprite|pixelwall|json|png|bmp|tga|gif|zip)$/i, "").replace(/[<>:"/\\|?*]/g, "_").split("").map((char) => char.charCodeAt(0) < 32 ? "_" : char).join("").replace(/^[. ]+|[. ]+$/g, "").slice(0, 180) || "sprite";
	if (/^(con|prn|aux|nul|com[1-9]|lpt[1-9])$/i.test(name)) name = "_" + name;
	return `${name}.${extension}`;
}
async function writeOutputs(outputs, { exclusive = false } = {}) {
	const seen = /* @__PURE__ */ new Set();
	for (const output of outputs) {
		const target = resolve(output.path), key = target.toLowerCase();
		if (seen.has(key)) fail(`Output filenames collide: ${output.path}. Choose distinct names.`);
		seen.add(key);
		if (exclusive) try {
			await lstat(target);
			fail(`Output already exists: ${output.path}. Choose an empty --out-dir.`);
		} catch (error) {
			if (error.code !== "ENOENT") throw error;
		}
	}
	if (!exclusive) {
		for (const output of outputs) await atomicWrite(output.path, output.data);
		return;
	}
	const staged = [], installed = [];
	try {
		for (const output of outputs) {
			const target = resolve(output.path);
			await mkdir(dirname(target), { recursive: true });
			const temporary = join(dirname(target), `.pixelwall-${randomUUID()}.tmp`);
			const handle = await open(temporary, "wx");
			staged.push({
				target,
				temporary
			});
			try {
				await handle.writeFile(output.data);
			} finally {
				await handle.close();
			}
		}
		for (const item of staged) {
			await link(item.temporary, item.target);
			installed.push({
				...item,
				identity: await stat(item.temporary, { bigint: true })
			});
		}
	} catch (error) {
		for (const item of installed) {
			const current = await lstat(item.target, { bigint: true }).catch(() => null);
			if (current && current.dev === item.identity.dev && current.ino === item.identity.ino && current.mtimeNs === item.identity.mtimeNs) await unlink(item.target).catch(() => {});
		}
		throw error;
	} finally {
		for (const item of staged) await unlink(item.temporary).catch(() => {});
	}
}
const jsonBytes = (value) => strToU8(JSON.stringify(value, null, 2) + "\n");
const selectionKeys = [
	"play-subtags",
	"clip",
	"tag",
	"frame-tag",
	"frame-range",
	"split-tags",
	"split-layers",
	"split-slices",
	"split-grid",
	"grid"
];
/** Pure output construction, like the format codecs. The CLI checks Pro before calling this for paid formats. */
function buildCliExportOutputs(inputs, args, rendering = {}) {
	const format = String(args.format).toLowerCase(), raster = [
		"png",
		"bmp",
		"tga"
	].includes(format), imageName = format === "zip" ? "sprites.png" : basename(args.out || "sprites.png");
	if (![
		"png",
		"bmp",
		"tga",
		"gif",
		"atlas",
		"sheet",
		"zip"
	].includes(format)) fail(`Unknown planned export format ${format}.`);
	const options = {
		...args,
		mode: raster ? "sequence" : format === "gif" ? "animation" : "atlas",
		imageName
	};
	const singleSelection = {
		...args,
		...inputs[0]?.options
	};
	if (raster && !args["out-dir"] && inputs.length === 1 && singleSelection.frame == null && !selectionKeys.some((key) => singleSelection[key])) options.frame = "0";
	if (["atlas", "zip"].includes(format)) {
		options.trim = args.trim ?? true;
		options.padding = args["shape-padding"] ?? args.padding ?? 1;
		options.border = args["border-padding"] ?? args.border ?? options.padding;
	}
	if (format === "sheet") {
		options["sheet-type"] = args["sheet-type"] ?? args.layout ?? "rows";
		options.padding = args["shape-padding"] ?? args.padding ?? 0;
		options.border = args["border-padding"] ?? args.border ?? 0;
	}
	const plan = planExport(inputs, options, rendering);
	if (!plan.entries.length) fail("No frames matched the export selection. No output was written.");
	let outputs;
	if (raster) {
		const encoder = format === "bmp" ? writeBmp : format === "tga" ? writeTga : writePng;
		outputs = plan.entries.map((entry) => ({
			name: outputName(entry.name, format),
			data: encoder(entry.width, entry.height, entry.rgba),
			entryId: entry.id
		}));
	} else if (format === "gif") outputs = plan.jobs.filter((job) => job.entries.length).map((job) => {
		return {
			name: outputName(args["filename-format"] ? job.entries[0].name : `${basename(job.filename, extname(job.filename))}${job.layer ? ` (${job.layerPath})` : ""}${job.tag ? ` (${job.tag.name})` : ""}${job.slice ? ` (${job.slice.name})` : ""}`, "gif"),
			data: encodeGif(job.entries, { loop: number(args, "loop", 0) }),
			jobId: job.id
		};
	});
	else {
		if (format === "sheet" && !plan.atlasOptions.columns && !plan.options.rows && ["rows", "grid"].includes(plan.options.sheetType)) plan.atlasOptions.columns = plan.entries.length;
		const atlas = packAtlas(plan.entries, plan.atlasOptions), metadata = buildExportMetadata(atlas, plan);
		if (format === "sheet" && plan.atlasOptions.layout === "grid") {
			metadata.meta.columns = plan.atlasOptions.columns || Math.ceil(Math.sqrt(plan.entries.length));
			metadata.meta.rows = Math.ceil(plan.entries.length / metadata.meta.columns);
		}
		if (format === "zip") {
			const files = {
				"sprites.png": writePng(atlas.width, atlas.height, atlas.rgba),
				"sprites.json": jsonBytes(metadata)
			}, sources = [];
			for (const [index, source] of plan.sources.entries()) {
				const original = normalizeDocument(inputs[index].originalDocument || inputs[index].document), project = `projects/${outputName(`${String(index + 1).padStart(3, "0")}-${basename(source.filename)}`, "pixelwall")}`;
				files[project] = jsonBytes(original);
				const entries = plan.entries.filter((entry) => entry.inputIndex === index).map((entry) => ({
					...entry,
					entryId: entry.id,
					id: entry.sourceFrameId
				}));
				let gamePackage = null;
				if (entries.length) {
					const sourceFiles = unzipSync(makeGamePackage(source.document, {
						...rendering,
						entries,
						trim: false,
						scale: plan.options.scale,
						padding: plan.options.padding,
						extrude: plan.options.extrude,
						powerOfTwo: plan.options.powerOfTwo
					})), prefix = plan.sources.length === 1 ? "" : `packages/${String(index + 1).padStart(3, "0")}-${outputName(basename(source.filename), "source")}/`;
					const manifest = JSON.parse(new TextDecoder().decode(sourceFiles["manifest.json"]));
					if (source.transforms.length) {
						manifest.sourceTransforms = source.transforms;
						sourceFiles["manifest.json"] = jsonBytes(manifest);
					}
					if (entries.some((entry) => entry.grid)) {
						manifest.frames = manifest.frames.map((frame, index) => ({
							...frame,
							entryId: entries[index].entryId,
							...entries[index].grid ? { grid: entries[index].grid } : {}
						}));
						sourceFiles["manifest.json"] = jsonBytes(manifest);
					}
					sourceFiles[manifest.project] = jsonBytes(original);
					for (const [name, data] of Object.entries(sourceFiles)) if (prefix || !["sprites.png", "sprites.json"].includes(name)) files[prefix + name] = data;
					gamePackage = prefix + "manifest.json";
				}
				sources.push({
					inputIndex: index,
					filename: source.filename,
					documentId: original.id,
					...source.transforms.length ? { transforms: source.transforms } : {},
					project,
					gamePackage,
					entryIds: plan.entries.filter((entry) => entry.inputIndex === index).map((entry) => entry.id),
					jobIds: plan.jobs.filter((job) => job.inputIndex === index).map((job) => job.id)
				});
			}
			const sourceMetadata = {
				format: "pixelwall-export-sources",
				version: 1,
				atlas: {
					image: "sprites.png",
					metadata: "sprites.json"
				},
				sources,
				jobs: plan.jobs.map((job) => ({
					id: job.id,
					inputIndex: job.inputIndex,
					layerIds: job.layerIds,
					tagId: job.tag?.id ?? null,
					sliceId: job.slice?.id ?? null,
					sourceFrameIds: job.frameIds,
					entryIds: job.entryIds
				}))
			};
			files["sources.json"] = jsonBytes(sourceMetadata);
			if (plan.sources.length > 1) files["manifest.json"] = jsonBytes({
				format: "pixelwall-game-package",
				version: 2,
				atlas: sourceMetadata.atlas,
				sources: "sources.json",
				projects: sources.map((source) => source.project),
				packages: sources.map((source) => source.gamePackage).filter(Boolean)
			});
			outputs = [{
				name: "sprites.zip",
				data: zipSync(files)
			}];
		} else outputs = [{
			name: imageName,
			data: writePng(atlas.width, atlas.height, atlas.rgba),
			kind: "image"
		}, {
			name: outputName(imageName, "json"),
			data: jsonBytes(metadata),
			kind: "metadata"
		}];
	}
	const names = /* @__PURE__ */ new Set();
	for (const output of outputs) {
		const name = output.name.toLowerCase();
		if (names.has(name)) fail(`Output filenames collide after filename sanitizing: ${output.name}. Use a distinct --filename-format.`);
		names.add(name);
	}
	return {
		plan,
		outputs
	};
}
function extractLicenseToken(text) {
	if (Buffer.byteLength(text, "utf8") > 65536) fail("Ownership license file exceeds 64 KiB.");
	const candidates = text.split(/\s+/).filter((word) => word.startsWith("PW2."));
	if (candidates.length !== 1) fail(candidates.length ? "Ownership license file contains multiple PW2 codes; keep exactly one code in the file." : "Ownership license file does not contain a PW2 code.");
	const token = candidates[0];
	if (!/^PW2\.[A-Za-z0-9_-]{1,2667}\.[A-Za-z0-9_-]{86}$/.test(token)) fail("Ownership license file contains a malformed PW2 code.");
	return token;
}
async function requirePro(args) {
	let token = process.env.PIXELWALL_PRO_LICENSE || "";
	if (args.license) {
		const value = required(args, "license");
		if (value.startsWith("PW2.")) token = value;
		else {
			const path = resolve(value);
			if ((await stat(path)).size > 65536) fail("Ownership license file exceeds 64 KiB.");
			token = extractLicenseToken(await readFile(path, "utf8"));
		}
	}
	const claims = await verifyOfflineLicense(token, {
		publicKeys: PINNED_PUBLIC_KEYS,
		mode: "live"
	});
	if (!claims) fail("A valid PixelWall Pro license is required for this export. Supply --license license.txt or PIXELWALL_PRO_LICENSE.");
	return claims;
}
function framesFor(doc, args, rendering = {}) {
	if (args["include-reference-layers"] !== true) doc = {
		...doc,
		layers: doc.layers.map((layer) => layer.type === "reference" ? {
			...layer,
			visible: false
		} : layer)
	};
	let frames = doc.frames;
	if (args.clip) {
		const clip = doc.clips.find((c) => c.id === args.clip || c.name === args.clip);
		if (!clip) fail("Unknown clip.");
		frames = clip.frameIds.map((id) => doc.frames.find((f) => f.id === id));
		if (clip.direction === "reverse" || clip.direction === "pingpong_reverse") frames.reverse();
		if (clip.direction === "pingpong" || clip.direction === "pingpong_reverse") frames = [...frames, ...frames.slice(1, -1).reverse()];
	}
	if (args.frame != null) {
		const frame = doc.frames.find((f) => f.id === args.frame) || doc.frames[Number(args.frame)];
		if (!frame) fail("Unknown frame.");
		frames = [frame];
	}
	const scale = number(args, "scale", 1);
	return frames.map((frame, index) => ({
		id: frame.id,
		name: `${doc.name.replace(/[^a-z0-9_-]/gi, "_")}-${String(index + 1).padStart(4, "0")}`,
		...renderScaledExportFrame(doc, frame.id, scale, rendering),
		durationMs: frame.durationMs
	}));
}
async function main(argv = process.argv.slice(2)) {
	const { args, inputs: inputScopes, orderedScaleCount } = parseCliArguments(argv), [command, input, ...rest] = args._;
	if (!command || command === "help" || args.help) {
		process.stdout.write(HELP);
		return;
	}
	if (command === "commands") {
		process.stdout.write(JSON.stringify(COMMANDS, null, 2) + "\n");
		return;
	}
	if (command === "new") {
		const doc = createDocument({
			width: number(args, "width", 32),
			height: number(args, "height", number(args, "width", 32)),
			name: args.name || "Untitled Sprite",
			colorMode: args["color-mode"] || "rgba",
			durationMs: number(args, "duration", 100)
		});
		await saveDocument(required(args, "out"), doc);
		return;
	}
	if (command === "import-sequence") {
		const paths = [input, ...rest].filter(Boolean);
		if (!paths.length) fail("Provide one or more PNG filenames.");
		const entries = [];
		for (const path of paths) {
			const result = await readManagedPng(new Uint8Array(await readFile(resolve(path))));
			warn(result.warnings);
			entries.push(result);
		}
		await saveDocument(required(args, "out"), importSequence(entries, {
			name: args.name || "Imported sequence",
			durationMs: number(args, "duration", 100)
		}));
		return;
	}
	let doc = await readDocument(input);
	if (command === "inspect") {
		process.stdout.write(JSON.stringify({
			...describeDocument(doc),
			layerDetails: doc.layers,
			frameDetails: doc.frames.map((f) => ({
				id: f.id,
				durationMs: f.durationMs,
				cels: Object.keys(f.cels)
			})),
			clips: doc.clips,
			slices: doc.slices,
			metadata: doc.metadata
		}, null, 2) + "\n");
		return;
	}
	if (command === "import") {
		if (args["frame-width"] || args["frame-height"]) {
			if (extname(input).toLowerCase() !== ".png") fail("Sheet import requires a PNG image.");
			doc = importSheet(await readManagedPng(new Uint8Array(await readFile(resolve(input)))), {
				frameWidth: number(args, "frame-width"),
				frameHeight: number(args, "frame-height"),
				margin: number(args, "margin", 0),
				spacing: number(args, "spacing", 0),
				count: number(args, "count"),
				durationMs: number(args, "duration", 100),
				order: args.order || "row",
				name: args.name || "Imported sheet"
			});
		}
		await saveDocument(required(args, "out"), doc);
		return;
	}
	if (command === "apply") {
		const data = JSON.parse(await readFile(resolve(required(args, "commands")), "utf8")), commands = Array.isArray(data) ? data : data.commands;
		if (!Array.isArray(commands)) fail("Command file must be a JSON array or {commands:[...]}.");
		for (const cmd of commands) doc = applyCommand(doc, cmd);
		await saveDocument(required(args, "out"), doc);
		return;
	}
	if (command === "script") {
		const scriptPath = resolve(required(args, "script"));
		if (extname(scriptPath).toLowerCase() === ".lua") {
			const wasm = new URL("./runtimes/lua.wasm", import.meta.url), result = await runLuaScript({
				source: await readFile(scriptPath, "utf8"),
				document: doc,
				params: args.params ? JSON.parse(required(args, "params")) : {},
				timeoutMs: number(args, "timeout", 3e3)
			}, { wasmUri: existsSync(wasm) ? wasm.href : void 0 });
			const changedIds = new Set(result.transactions.map((item) => item.documentId));
			if (args["out-dir"]) {
				let index = 0;
				const outputs = [];
				for (const output of result.documents) if (changedIds.has(output.id) || result.created.some((created) => created.id === output.id)) {
					const name = output.name.replace(/[^a-z0-9_-]/gi, "_") || "sprite";
					outputs.push({
						path: join(required(args, "out-dir"), `${String(++index).padStart(3, "0")}-${name}.pixelwall`),
						data: jsonBytes(normalizeDocument(output))
					});
				}
				await writeOutputs(outputs, { exclusive: true });
			} else {
				if ([...changedIds].some((id) => id !== result.document?.id)) fail("The script edited multiple projects. Supply --out-dir to save every result.");
				if (!result.document) fail("The Lua script returned no active sprite.");
				await saveDocument(required(args, "out"), result.document);
			}
			for (const line of result.prints) process.stderr.write(line + "\n");
			return;
		}
		const scriptModule = await import(pathToFileURL(scriptPath).href);
		if (typeof scriptModule.default !== "function") fail("Script must export a default function.");
		const context = {
			get document() {
				return structuredClone(doc);
			},
			apply(command) {
				doc = applyCommand(doc, command);
				return structuredClone(doc);
			},
			commands: COMMANDS
		};
		const result = await scriptModule.default(context);
		if (result != null) doc = normalizeDocument(result);
		await saveDocument(required(args, "out"), doc);
		return;
	}
	if (command === "profile") {
		if (args.assign && args.convert) fail("Choose either --assign or --convert.");
		const manager = await loadNodeColorManager(), file = args.assign || args.convert;
		if (!file || file === true) fail("Supply --assign or --convert with sRGB or an ICC filename.");
		const target = file === "sRGB" ? "sRGB" : manager.readProfile(new Uint8Array(await readFile(resolve(file))));
		doc = args.assign ? manager.assignProfile(doc, target) : manager.convertDocument(doc, target, { intent: number(args, "intent", 1) });
		await saveDocument(required(args, "out"), doc);
		return;
	}
	if (command === "render") {
		const colorManager = isSRGB(documentProfile(doc)) ? void 0 : await loadNodeColorManager();
		const [entry] = framesFor(doc, {
			...args,
			frame: args.frame ?? "0"
		}, {
			colorManager,
			intent: number(args, "intent", 1)
		});
		await atomicWrite(required(args, "out"), writePng(entry.width, entry.height, entry.rgba));
		return;
	}
	if (command === "export") {
		const format = required(args, "format").toLowerCase(), paths = [input, ...rest], outDir = args["out-dir"] ? required(args, "out-dir") : null;
		if (![
			"ase",
			"aseprite",
			"pixelwall",
			"json",
			"png",
			"bmp",
			"tga",
			"gif",
			"sheet",
			"atlas",
			"zip"
		].includes(format)) fail(`Unknown export format ${format}.`);
		if (outDir && args.out) fail("Choose --out or --out-dir, not both.");
		const out = outDir ? null : required(args, "out");
		if (outDir && [
			"sheet",
			"atlas",
			"zip"
		].includes(format)) fail(`Combined ${format} export requires --out; --out-dir is for separate files.`);
		if ([
			"gif",
			"sheet",
			"atlas",
			"zip"
		].includes(format)) await requirePro(args);
		const inputs = [];
		for (const [index, path] of paths.entries()) {
			const originalDocument = index === 0 ? doc : await readDocument(path);
			inputs.push({
				filename: path,
				document: originalDocument,
				originalDocument,
				options: inputScopes[index]?.options,
				transforms: inputScopes[index]?.transforms
			});
		}
		if ([
			"ase",
			"aseprite",
			"pixelwall",
			"json"
		].includes(format)) {
			if (orderedScaleCount) fail("Ordered scale operations are available for rendered exports only. Editable exports preserve the original project.");
			if (inputs.some((source) => (source.options?.["split-grid"] ?? args["split-grid"]) || (source.options?.grid ?? args.grid) != null)) fail("--split-grid and --grid are available for sheet, atlas and ZIP exports only.");
			if (inputs.length > 1 && !outDir) fail("Multiple editable projects require --out-dir so every input is saved.");
			if (inputs.some((source) => [
				...selectionKeys,
				"layer",
				"ignore-layer",
				"slice",
				"crop",
				"frame",
				"all-layers",
				"trim-sprite"
			].some((key) => {
				const value = source.options?.[key] ?? args[key];
				return value != null && value !== false;
			}))) fail("Native editable exports preserve the complete project. Use raster exports for layer, frame, tag, slice or crop selections.");
			const extension = ["ase", "aseprite"].includes(format) ? "aseprite" : "pixelwall";
			await writeOutputs(inputs.map((source) => ({
				path: outDir ? join(outDir, outputName(basename(source.filename), extension)) : out,
				data: extension === "aseprite" ? writeAseprite(source.document) : jsonBytes(source.document)
			})), { exclusive: !!outDir });
			return;
		}
		const colorManager = inputs.some((source) => !isSRGB(documentProfile(source.document))) ? await loadNodeColorManager() : void 0;
		const { plan, outputs } = buildCliExportOutputs(inputs, {
			...args,
			format
		}, {
			colorManager,
			intent: number(args, "intent", 1)
		});
		if ([
			"png",
			"bmp",
			"tga",
			"gif"
		].includes(format)) {
			if (!outDir && (outputs.length > 1 || format === "gif" && (inputs.some((source) => [
				"split-layers",
				"split-tags",
				"split-slices"
			].some((key) => source.options?.[key] ?? args[key])) || inputs.length > 1))) fail("Multiple frames or split animation jobs require --out-dir; no output was written.");
			if (format === "gif") warn(["GIF reduces alpha to binary transparency and quantizes images that exceed 255 opaque colors."]);
			await writeOutputs(outputs.map((output) => ({
				path: outDir ? join(outDir, output.name) : out,
				data: output.data
			})), { exclusive: !!outDir });
			return;
		}
		const files = outputs.map((output) => ({
			path: output.kind === "metadata" ? args.metadata ? required(args, "metadata") : join(dirname(out), basename(out, extname(out)) + ".json") : out,
			data: output.data
		}));
		if (plan.entries.length) await writeOutputs(files);
		return;
	}
	fail(`Unknown command ${command}. Run pixelwall help.`);
}
if (process.argv[1] && import.meta.url === pathToFileURL(realpathSync(resolve(process.argv[1]))).href) main().catch((error) => {
	process.stderr.write(`PixelWall: ${error.message}\n`);
	process.exitCode = 1;
});
//#endregion
export { buildCliExportOutputs, extractLicenseToken, main };
