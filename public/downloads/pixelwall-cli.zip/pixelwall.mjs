#!/usr/bin/env node
import { mkdir, readFile, rename, stat, unlink, writeFile } from "node:fs/promises";
import { dirname, extname, resolve } from "node:path";
import { realpathSync } from "node:fs";
import { pathToFileURL } from "node:url";
import { createRequire } from "module";
//#region \0rolldown/runtime.js
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJSMin = (cb, mod) => () => (mod || (cb((mod = { exports: {} }).exports, mod), cb = null), mod.exports);
var __copyProps = (to, from, except, desc) => {
	if (from && typeof from === "object" || typeof from === "function") for (var keys = __getOwnPropNames(from), i = 0, n = keys.length, key; i < n; i++) {
		key = keys[i];
		if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
			get: ((k) => from[k]).bind(null, key),
			enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
		});
	}
	return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", {
	value: mod,
	enumerable: true
}) : target, mod));
//#endregion
//#region app/editor-core.mjs
/** PixelWall v4: a portable, transactional 2D document and raster engine. No DOM. */
const LIMITS = Object.freeze({
	edge: 2048,
	imageEdge: 65535,
	pixels: 16777216,
	layers: 256,
	frames: 2048,
	palette: 65536,
	operations: 67108864
});
const BLEND_MODES = Object.freeze([
	"normal",
	"multiply",
	"screen",
	"overlay",
	"darken",
	"lighten",
	"color-dodge",
	"color-burn",
	"hard-light",
	"soft-light",
	"difference",
	"exclusion",
	"addition",
	"subtract",
	"divide",
	"hue",
	"saturation",
	"color",
	"luminosity"
]);
const DEFAULT_PALETTE = [
	"#16152bff",
	"#3c315fff",
	"#7059c7ff",
	"#ff6b57ff",
	"#ffb34bff",
	"#ffe66dff",
	"#70d6b2ff",
	"#218c89ff",
	"#f8f0dfff"
];
const DIRECTIONS$1 = [
	"forward",
	"reverse",
	"pingpong",
	"pingpong_reverse"
];
const validatedImages = /* @__PURE__ */ new WeakMap();
const clamp = (v, lo = 0, hi = 1) => Math.max(lo, Math.min(hi, v));
const own = (o, k) => Object.prototype.hasOwnProperty.call(o, k);
const record = (o) => o !== null && typeof o === "object" && !Array.isArray(o);
var EditorError = class extends Error {
	constructor(message, code = "INVALID_DOCUMENT") {
		super(message);
		this.name = "EditorError";
		this.code = code;
	}
};
function fail$1(message, code) {
	throw new EditorError(message, code);
}
function integer(v, label, min = 0, max = Number.MAX_SAFE_INTEGER) {
	if (!Number.isSafeInteger(v) || v < min || v > max) fail$1(`${label} must be an integer from ${min} to ${max}`);
	return v;
}
function finite(v, label, min = -1e6, max = 1e6) {
	if (typeof v !== "number" || !Number.isFinite(v) || v < min || v > max) fail$1(`${label} is outside ${min}…${max}`);
	return v;
}
function id(v, label = "Id") {
	if (typeof v !== "string" || !/^[a-zA-Z0-9][a-zA-Z0-9_.:-]{0,127}$/.test(v) || [
		"constructor",
		"prototype",
		"__proto__"
	].includes(v)) fail$1(`${label} is invalid`);
	return v;
}
function name(v, fallback) {
	const n = typeof v === "string" && v.trim() ? v.trim() : fallback;
	if (n.length > 240) fail$1("Name is too long");
	return n;
}
function jsonCopy(v) {
	if (v === void 0) return void 0;
	try {
		const s = JSON.stringify(v);
		if (s.length > 64 * 1024 * 1024) fail$1("Metadata is too large");
		return JSON.parse(s);
	} catch (e) {
		if (e instanceof EditorError) throw e;
		fail$1("Value must be serializable");
	}
}
function unique(items, label) {
	const s = /* @__PURE__ */ new Set();
	for (const item of items) {
		id(item.id, label);
		if (s.has(item.id)) fail$1(`Duplicate ${label}: ${item.id}`);
		s.add(item.id);
	}
	return s;
}
function rgba(value) {
	if (value === null || value === void 0) return [
		0,
		0,
		0,
		0
	];
	if (typeof value !== "string") fail$1("Color must be a hex string");
	let s = value.trim().toLowerCase();
	if (/^#[0-9a-f]{3,4}$/.test(s)) s = "#" + [...s.slice(1)].map((c) => c + c).join("");
	if (/^#[0-9a-f]{6}$/.test(s)) s += "ff";
	if (!/^#[0-9a-f]{8}$/.test(s)) fail$1(`Invalid RGBA color: ${String(value).slice(0, 30)}`);
	return [
		1,
		3,
		5,
		7
	].map((i) => parseInt(s.slice(i, i + 2), 16));
}
const hex$1 = (c) => "#" + c.map((v) => Math.round(clamp(v, 0, 255)).toString(16).padStart(2, "0")).join("");
const normalizeColor = (value) => hex$1(rgba(value));
function pixelRGBA(doc, pixel) {
	return rgba(typeof pixel === "number" ? doc.palette[pixel] : pixel);
}
function nearest(palette, c) {
	let result = 0, d = Infinity;
	for (let i = 0; i < palette.length; i++) {
		const p = rgba(palette[i]);
		const q = (p[0] - c[0]) ** 2 + (p[1] - c[1]) ** 2 + (p[2] - c[2]) ** 2 + 2 * (p[3] - c[3]) ** 2;
		if (q < d) {
			result = i;
			d = q;
		}
	}
	return result;
}
function encodeColor(doc, color) {
	if (color === null || color === void 0) return null;
	if (typeof color === "number") {
		integer(color, "Palette index", 0, doc.palette.length - 1);
		return doc.colorMode === "indexed" ? color : encodeColor(doc, doc.palette[color]);
	}
	const c = rgba(color);
	if (c[3] === 0) return null;
	if (doc.colorMode === "indexed") return nearest(doc.palette, c);
	if (doc.colorMode === "grayscale") c[0] = c[1] = c[2] = Math.round(.2126 * c[0] + .7152 * c[1] + .0722 * c[2]);
	return hex$1(c);
}
function validatePixels(image, doc, label, copy = true) {
	integer(image.width, `${label} width`, 1, LIMITS.imageEdge);
	integer(image.height, `${label} height`, 1, LIMITS.imageEdge);
	const count = image.width * image.height;
	if (count > LIMITS.pixels) fail$1("Image exceeds pixel budget");
	if (image.tilemap) {
		if (!Array.isArray(image.tilemap.tiles) || image.tilemap.tiles.length !== count) fail$1("Tilemap image size mismatch");
		for (const value of image.tilemap.tiles) integer(value, "Tile data", 0, 4294967295);
		if (!Array.isArray(image.pixels) || image.pixels.length !== 0 && image.pixels.length !== count) fail$1("Tilemap pixels are invalid");
		return copy ? [...image.pixels] : image.pixels;
	}
	if (!Array.isArray(image.pixels) || image.pixels.length !== count) fail$1(`${label} pixel count does not match dimensions`);
	const convert = (p) => {
		if (p === null) return null;
		if (doc.colorMode === "indexed") return integer(p, "Indexed pixel", 0, doc.palette.length - 1);
		if (typeof p !== "string") fail$1("RGBA pixels must be strings or null");
		const c = rgba(p);
		if (doc.colorMode === "grayscale" && (c[0] !== c[1] || c[1] !== c[2])) fail$1("Grayscale pixels must have equal RGB channels");
		return c[3] === 0 ? null : hex$1(c);
	};
	if (copy) return image.pixels.map(convert);
	for (const p of image.pixels) convert(p);
	return image.pixels;
}
function createDocument(options = {}) {
	const width = integer(options.width ?? options.size ?? 32, "Width", 1, LIMITS.edge), height = integer(options.height ?? options.size ?? width, "Height", 1, LIMITS.edge);
	return normalizeDocument({
		format: "pixelwall-document",
		version: 4,
		id: options.id ?? globalThis.crypto?.randomUUID?.() ?? `document-${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`,
		name: options.name ?? "Untitled Sprite",
		width,
		height,
		colorMode: options.colorMode ?? "rgba",
		colorProfile: "sRGB",
		palette: options.palette ?? DEFAULT_PALETTE,
		layers: [{
			id: "layer-1",
			name: "Layer 1",
			type: "image",
			parentId: null,
			visible: true,
			locked: false,
			opacity: 1,
			blendMode: "normal"
		}],
		frames: [{
			id: "frame-1",
			durationMs: options.durationMs ?? 125,
			cels: {}
		}],
		images: {},
		clips: [{
			id: "clip-1",
			name: "default",
			frameIds: ["frame-1"],
			direction: "forward",
			loop: true
		}],
		slices: [],
		tilesets: [],
		metadata: {}
	});
}
function normalizeDocument(input, options = {}) {
	if (typeof input === "string") try {
		input = JSON.parse(input);
	} catch {
		fail$1("Invalid document JSON");
	}
	if (!record(input)) fail$1("Document must be an object");
	if (input.format !== "pixelwall-document" || input.version !== 4) return migrateLegacy(input);
	const width = integer(input.width, "Width", 1, LIMITS.edge), height = integer(input.height, "Height", 1, LIMITS.edge);
	if (![
		"rgba",
		"indexed",
		"grayscale"
	].includes(input.colorMode)) fail$1("Unsupported color mode");
	if (input.colorProfile && input.colorProfile !== "sRGB") fail$1("Only the sRGB working profile is supported");
	if (!Array.isArray(input.palette) || input.palette.length < 1 || input.palette.length > LIMITS.palette) fail$1("Palette must have 1–65536 colors");
	const doc = {
		...input,
		id: id(input.id ?? "document-1"),
		name: name(input.name, "Untitled Sprite"),
		width,
		height,
		colorMode: input.colorMode,
		colorProfile: "sRGB",
		palette: input.palette.map(normalizeColor)
	};
	if (!Array.isArray(input.layers) || input.layers.length < 1 || input.layers.length > LIMITS.layers) fail$1("Document must have 1–256 layers");
	doc.layers = input.layers.map((layer, i) => {
		if (!record(layer)) fail$1("Invalid layer");
		const type = layer.type ?? "image";
		if (![
			"image",
			"group",
			"reference",
			"tilemap"
		].includes(type)) fail$1("Unsupported layer type");
		const blendMode = layer.blendMode ?? "normal";
		if (!BLEND_MODES.includes(blendMode)) fail$1(`Unsupported blend mode: ${blendMode}`);
		return {
			...jsonCopy(layer),
			id: id(layer.id),
			name: name(layer.name, `Layer ${i + 1}`),
			type,
			parentId: layer.parentId == null ? null : id(layer.parentId),
			visible: layer.visible !== false,
			locked: !!layer.locked,
			opacity: finite(layer.opacity ?? 1, "Layer opacity", 0, 1),
			blendMode
		};
	});
	const layerIds = unique(doc.layers, "layer id");
	const layerMap = new Map(doc.layers.map((l) => [l.id, l]));
	for (const layer of doc.layers) {
		let current = layer;
		const seen = /* @__PURE__ */ new Set();
		while (current.parentId !== null) {
			if (seen.has(current.id)) fail$1("Layer groups cannot contain cycles");
			seen.add(current.id);
			const p = layerMap.get(current.parentId);
			if (!p || p.type !== "group") fail$1("Layer parent must be an existing group");
			current = p;
		}
	}
	if (!record(input.images)) fail$1("Images must be an object");
	if (Object.keys(input.images).length > 131072) fail$1("Too many stored images");
	doc.images = {};
	let pixels = 0;
	const validationKey = doc.colorMode === "indexed" ? `indexed:${doc.palette.length}` : doc.colorMode;
	for (const [key, image] of Object.entries(input.images)) {
		id(key, "Image id");
		if (!record(image)) fail$1("Invalid image");
		pixels += image.width * image.height;
		if (pixels > LIMITS.pixels) fail$1("Document exceeds the 16,777,216 stored pixel budget");
		if (options.shareImages) {
			if (validatedImages.get(image) !== validationKey) validatePixels(image, doc, `Image ${key}`, false);
			doc.images[key] = image;
		} else doc.images[key] = {
			...image,
			...image.tilemap ? { tilemap: jsonCopy(image.tilemap) } : {},
			pixels: validatePixels(image, doc, `Image ${key}`)
		};
		validatedImages.set(doc.images[key], validationKey);
	}
	if (!Array.isArray(input.frames) || input.frames.length < 1 || input.frames.length > LIMITS.frames) fail$1("Document must have 1–2048 frames");
	let celCount = 0;
	doc.frames = input.frames.map((frame) => {
		if (!record(frame) || !record(frame.cels)) fail$1("Invalid frame");
		const cels = {};
		for (const [layerId, cel] of Object.entries(frame.cels)) {
			if (!layerIds.has(layerId) || layerMap.get(layerId).type === "group") fail$1("Cel references missing or group layer");
			if (!record(cel) || !own(doc.images, cel.imageId)) fail$1("Cel references missing image");
			if (++celCount > 131072) fail$1("Too many cels");
			cels[layerId] = {
				...jsonCopy(cel),
				imageId: id(cel.imageId),
				x: integer(cel.x ?? 0, "Cel x", -65535, 65535),
				y: integer(cel.y ?? 0, "Cel y", -65535, 65535),
				opacity: finite(cel.opacity ?? 1, "Cel opacity", 0, 1)
			};
		}
		return {
			...jsonCopy({
				...frame,
				cels: void 0
			}),
			id: id(frame.id),
			durationMs: integer(frame.durationMs ?? 125, "Frame duration", 1, 65535),
			cels
		};
	});
	const frameIds = unique(doc.frames, "frame id");
	doc.clips = (input.clips ?? []).map((clip, i) => {
		if (!record(clip) || !Array.isArray(clip.frameIds) || !clip.frameIds.length) fail$1("Invalid clip");
		for (const f of clip.frameIds) if (!frameIds.has(f)) fail$1("Clip references missing frame");
		if (!DIRECTIONS$1.includes(clip.direction ?? "forward")) fail$1("Invalid clip direction");
		return {
			...jsonCopy(clip),
			id: id(clip.id),
			name: name(clip.name, `Clip ${i + 1}`),
			direction: clip.direction ?? "forward",
			loop: clip.loop !== false
		};
	});
	unique(doc.clips, "clip id");
	if (doc.clips.length > 512) fail$1("Too many clips");
	doc.slices = jsonCopy(input.slices ?? []);
	if (!Array.isArray(doc.slices) || doc.slices.length > 1024) fail$1("Too many slices");
	for (const slice of doc.slices) {
		id(slice.id);
		const b = slice.bounds;
		if (record(b)) {
			integer(b.x, "Slice x", 0, width - 1);
			integer(b.y, "Slice y", 0, height - 1);
			integer(b.width, "Slice width", 1, width - b.x);
			integer(b.height, "Slice height", 1, height - b.y);
		} else if (Array.isArray(slice.keys)) for (const key of slice.keys) {
			if (key.frameId && !frameIds.has(key.frameId)) fail$1("Slice key references missing frame");
			integer(key.x, "Slice key x", -2147483648, 2147483647);
			integer(key.y, "Slice key y", -2147483648, 2147483647);
			integer(key.width, "Slice key width", 0, 65535);
			integer(key.height, "Slice key height", 0, 65535);
		}
		else fail$1("Invalid slice");
	}
	unique(doc.slices, "slice id");
	doc.tilesets = jsonCopy(input.tilesets ?? []);
	if (!Array.isArray(doc.tilesets) || doc.tilesets.length > 256) fail$1("Too many tilesets");
	unique(doc.tilesets, "Tileset id");
	if (doc.tilesets.reduce((s, t) => s + (t.tiles?.length ?? t.tileCount ?? 0), 0) > 131072) fail$1("Too many tile definitions");
	for (const ts of doc.tilesets) {
		integer(ts.tileWidth, "Tile width", 1, LIMITS.edge);
		integer(ts.tileHeight, "Tile height", 1, LIMITS.edge);
		if (ts.imageId && !own(doc.images, ts.imageId)) fail$1("Tileset atlas image is missing");
		if (!ts.tiles && ts.imageId) {
			const atlas = doc.images[ts.imageId], columns = Math.floor(atlas.width / ts.tileWidth), count = ts.tileCount ?? columns * Math.floor(atlas.height / ts.tileHeight);
			integer(count, "Native tile count", 0, 65536);
			if (columns < 1 || count > columns * Math.floor(atlas.height / ts.tileHeight)) fail$1("Native atlas dimensions mismatch");
			ts.tiles = Array.from({ length: count }, (_, i) => ({
				id: `ase-tile-${i}`,
				imageId: ts.imageId,
				asepriteTileId: i,
				sourceRect: {
					x: i % columns * ts.tileWidth,
					y: Math.floor(i / columns) * ts.tileHeight,
					width: ts.tileWidth,
					height: ts.tileHeight
				}
			}));
		}
		if (ts.tiles) {
			if (!Array.isArray(ts.tiles) || ts.tiles.length > 65536) fail$1("Invalid tileset");
			unique(ts.tiles, "tile id");
			for (const t of ts.tiles) {
				if (!own(doc.images, t.imageId)) fail$1("Tile image missing");
				if (t.sourceRect) {
					const image = doc.images[t.imageId], r = t.sourceRect;
					integer(r.x, "Tile source x", 0, image.width - 1);
					integer(r.y, "Tile source y", 0, image.height - 1);
					integer(r.width, "Tile source width", 1, image.width - r.x);
					integer(r.height, "Tile source height", 1, image.height - r.y);
				}
			}
		}
	}
	for (const layer of doc.layers) {
		if (layer.tilesetId && !doc.tilesets.some((t) => t.id === layer.tilesetId)) fail$1("Layer tileset missing");
		for (const [fid, map] of Object.entries(layer.tilemaps ?? {})) {
			if (!frameIds.has(fid)) fail$1("Tilemap frame missing");
			validateTilemap(doc, map);
		}
	}
	doc.metadata = jsonCopy(input.metadata ?? {});
	if (!record(doc.metadata)) fail$1("Metadata must be an object");
	return doc;
}
function decodeLegacyPixels(data, bpi, colors, total) {
	if (typeof data !== "string" || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(data)) fail$1("Invalid legacy pixel encoding");
	if (bpi !== 1 && bpi !== 2) fail$1("Invalid legacy color index size");
	let bytes;
	if (typeof atob === "function") bytes = Uint8Array.from(atob(data), (c) => c.charCodeAt(0));
	else if (globalThis.Buffer) bytes = new Uint8Array(globalThis.Buffer.from(data, "base64"));
	else fail$1("Base64 decoding unavailable");
	if (bytes.length !== total * bpi) fail$1("Legacy pixel size mismatch");
	return Array.from({ length: total }, (_, i) => {
		const n = bytes[i * bpi] + (bpi === 2 ? bytes[i * bpi + 1] * 256 : 0);
		if (n > colors.length) fail$1("Legacy palette index missing");
		return n ? normalizeColor(colors[n - 1]) : null;
	});
}
function migrateLegacy(input) {
	if (typeof input === "string") try {
		input = JSON.parse(input);
	} catch {
		fail$1("Invalid document JSON");
	}
	const p = input?.project ?? input;
	if (!record(p) || !Array.isArray(p.frames) || !p.frames.length) fail$1("Unsupported document");
	if (p.version !== void 0 && ![
		1,
		2,
		3
	].includes(p.version)) fail$1("Unsupported document version");
	const width = integer(p.size ?? p.width, "Legacy width", 1, LIMITS.edge), height = integer(p.height ?? width, "Legacy height", 1, LIMITS.edge), total = width * height;
	const doc = createDocument({
		width,
		height,
		name: p.name,
		palette: p.palette?.length ? p.palette : DEFAULT_PALETTE
	});
	doc.layers = (p.layers?.length ? p.layers : [{
		id: 1,
		name: "Layer 1"
	}]).map((l, i) => ({
		...l,
		id: `layer-${l.id ?? i + 1}`,
		name: l.name ?? `Layer ${i + 1}`,
		type: "image",
		parentId: null,
		visible: l.visible !== false,
		locked: !!l.locked,
		opacity: (l.opacity ?? 100) / 100,
		blendMode: "normal"
	}));
	doc.images = {};
	const used = /* @__PURE__ */ new Set();
	doc.frames = p.frames.map((f, i) => {
		let fid = `frame-${f.id ?? i + 1}`;
		if (used.has(fid)) fid = `frame-migrated-${i}`;
		used.add(fid);
		const cels = {};
		const source = Array.isArray(f.cels) ? f.cels : [{
			layerId: p.layers?.[0]?.id ?? 1,
			pixels: f.pixels,
			data: f.data
		}];
		for (const [j, c] of source.entries()) {
			let pix;
			if (Array.isArray(c.pixels)) pix = c.pixels.map((v) => v == null ? null : normalizeColor(v));
			else if (c.data !== void 0) pix = decodeLegacyPixels(c.data, c.bytesPerIndex ?? f.bytesPerIndex ?? p.bytesPerIndex, p.colors ?? [], total);
			else continue;
			if (pix.length !== total) fail$1("Legacy pixel count mismatch");
			const imageId = `image-migrated-${i}-${j}`;
			doc.images[imageId] = {
				width,
				height,
				pixels: pix
			};
			cels[`layer-${c.layerId ?? 1}`] = {
				imageId,
				x: 0,
				y: 0,
				opacity: 1
			};
		}
		return {
			id: fid,
			durationMs: f.durationMs ?? 125,
			cels
		};
	});
	const oldFrameMap = new Map(p.frames.map((f, i) => [String(f.id ?? i + 1), doc.frames[i].id]));
	doc.clips = p.clips?.length ? p.clips.map((c, i) => ({
		id: `clip-${c.id ?? i + 1}`,
		name: c.name ?? `Clip ${i + 1}`,
		frameIds: c.frameIds.map((fid) => oldFrameMap.get(String(fid))),
		direction: c.direction ?? "forward",
		loop: c.loop !== false
	})) : [{
		id: "clip-1",
		name: "default",
		frameIds: doc.frames.map((f) => f.id),
		direction: "forward",
		loop: true
	}];
	doc.slices = (p.slices ?? []).map((s, i) => ({
		...s,
		id: `slice-${s.id ?? i + 1}`
	}));
	doc.metadata = {
		migratedFrom: p.version ?? "runtime",
		legacy: {
			pivot: jsonCopy(p.pivot),
			tile: jsonCopy(p.tile),
			tilemap: jsonCopy(p.tilemap),
			projector: jsonCopy(p.projector),
			editor: jsonCopy(input.editor ?? p.editor)
		}
	};
	return normalizeDocument(doc);
}
function describeDocument(doc) {
	return {
		id: doc.id,
		name: doc.name,
		width: doc.width,
		height: doc.height,
		colorMode: doc.colorMode,
		layers: doc.layers.length,
		frames: doc.frames.length,
		images: Object.keys(doc.images).length,
		storedPixels: Object.values(doc.images).reduce((s, i) => s + i.width * i.height, 0),
		durationMs: doc.frames.reduce((s, f) => s + f.durationMs, 0),
		linkedCels: doc.frames.reduce((s, f) => s + Object.keys(f.cels).length, 0) - new Set(doc.frames.flatMap((f) => Object.values(f.cels).map((c) => c.imageId))).size,
		tilesets: doc.tilesets.length,
		layerList: doc.layers.map(({ id, name, type, parentId, visible, locked, opacity, blendMode, tilesetId }) => ({
			id,
			name,
			type,
			parentId,
			visible,
			locked,
			opacity,
			blendMode,
			...tilesetId ? { tilesetId } : {}
		})),
		frameList: doc.frames.map((f) => ({
			id: f.id,
			durationMs: f.durationMs,
			cels: Object.fromEntries(Object.entries(f.cels).map(([lid, c]) => [lid, {
				imageId: c.imageId,
				x: c.x,
				y: c.y,
				opacity: c.opacity
			}]))
		})),
		clipList: doc.clips.map((c) => ({
			...c,
			frameIds: [...c.frameIds]
		})),
		sliceList: doc.slices.map((s) => ({
			id: s.id,
			name: s.name,
			...s.bounds ? { bounds: { ...s.bounds } } : {},
			...s.keys ? { keyFrames: s.keys.map((k) => k.frameId) } : {}
		})),
		tilesetList: doc.tilesets.map((t) => ({
			id: t.id,
			name: t.name,
			tileWidth: t.tileWidth,
			tileHeight: t.tileHeight,
			tileCount: t.tiles?.length ?? t.tileCount ?? 0,
			tileIds: t.tiles?.map((t) => t.id) ?? []
		}))
	};
}
function validateTilemap(doc, map) {
	const ts = doc.tilesets.find((t) => t.id === map.tilesetId);
	if (!ts) fail$1("Tilemap tileset missing");
	integer(map.columns, "Tilemap columns", 1, 2048);
	integer(map.rows, "Tilemap rows", 1, 2048);
	integer(map.x ?? 0, "Tilemap x", -65535, 65535);
	integer(map.y ?? 0, "Tilemap y", -65535, 65535);
	finite(map.opacity ?? 1, "Tilemap opacity", 0, 1);
	if (map.columns * map.rows > 1048576 || !Array.isArray(map.cells) || map.cells.length !== map.columns * map.rows) fail$1("Invalid tilemap dimensions");
	const ids = new Set((ts.tiles ?? []).map((t) => t.id));
	for (const c of map.cells) if (c !== null && (!record(c) || !ids.has(c.tileId) || ![
		0,
		90,
		180,
		270
	].includes(c.rotate ?? 0))) fail$1("Tilemap tile is invalid");
}
function rgbHsl(rgb) {
	const r = rgb[0] / 255, g = rgb[1] / 255, b = rgb[2] / 255, max = Math.max(r, g, b), min = Math.min(r, g, b), d = max - min, l = (max + min) / 2;
	let h = 0, s = 0;
	if (d) {
		s = d / (1 - Math.abs(2 * l - 1));
		h = max === r ? (g - b) / d % 6 : max === g ? (b - r) / d + 2 : (r - g) / d + 4;
		h = (h / 6 % 1 + 1) % 1;
	}
	return [
		h,
		s,
		l
	];
}
function hslRgb([h, s, l]) {
	h = (h % 1 + 1) % 1;
	s = clamp(s);
	l = clamp(l);
	const a = s * Math.min(l, 1 - l);
	return [
		0,
		8,
		4
	].map((n) => {
		const k = (n + h * 12) % 12;
		return 255 * (l - a * Math.max(-1, Math.min(k - 3, 9 - k, 1)));
	});
}
function blendChannel(b, s, mode) {
	switch (mode) {
		case "multiply": return b * s;
		case "screen": return b + s - b * s;
		case "overlay": return b < .5 ? 2 * b * s : 1 - 2 * (1 - b) * (1 - s);
		case "darken": return Math.min(b, s);
		case "lighten": return Math.max(b, s);
		case "color-dodge": return s >= 1 ? 1 : Math.min(1, b / (1 - s));
		case "color-burn": return s <= 0 ? 0 : 1 - Math.min(1, (1 - b) / s);
		case "hard-light": return s < .5 ? 2 * b * s : 1 - 2 * (1 - b) * (1 - s);
		case "soft-light": return s <= .5 ? b - (1 - 2 * s) * b * (1 - b) : b + (2 * s - 1) * ((b <= .25 ? ((16 * b - 12) * b + 4) * b : Math.sqrt(b)) - b);
		case "difference": return Math.abs(b - s);
		case "exclusion": return b + s - 2 * b * s;
		case "addition": return Math.min(1, b + s);
		case "subtract": return Math.max(0, b - s);
		case "divide": return s === 0 ? 1 : Math.min(1, b / s);
		default: return s;
	}
}
const luminosity = (c) => .3 * c[0] + .59 * c[1] + .11 * c[2], saturation = (c) => Math.max(...c) - Math.min(...c);
function setLuminosity(c, l) {
	let result = c.map((v) => v + l - luminosity(c));
	const mid = luminosity(result), min = Math.min(...result), max = Math.max(...result);
	if (min < 0) result = result.map((v) => mid + (v - mid) * mid / (mid - min));
	if (max > 1) result = result.map((v) => mid + (v - mid) * (1 - mid) / (max - mid));
	return result;
}
function setSaturation(c, s) {
	const order = [
		0,
		1,
		2
	].sort((a, b) => c[a] - c[b]), result = [
		0,
		0,
		0
	], [lo, mid, hi] = order;
	if (c[hi] > c[lo]) {
		result[mid] = (c[mid] - c[lo]) * s / (c[hi] - c[lo]);
		result[hi] = s;
	}
	return result;
}
function blendAt(out, index, source, opacity = 1, mode = "normal") {
	const sa = source[3] / 255 * opacity;
	if (sa <= 0) return;
	const ba = out[index + 3] / 255, oa = sa + ba * (1 - sa);
	let color;
	if ([
		"hue",
		"saturation",
		"color",
		"luminosity"
	].includes(mode)) {
		const b = [
			out[index] / 255,
			out[index + 1] / 255,
			out[index + 2] / 255
		], s = source.slice(0, 3).map((v) => v / 255);
		color = mode === "hue" ? setLuminosity(setSaturation(s, saturation(b)), luminosity(b)) : mode === "saturation" ? setLuminosity(setSaturation(b, saturation(s)), luminosity(b)) : mode === "color" ? setLuminosity(s, luminosity(b)) : setLuminosity(b, luminosity(s));
	}
	for (let k = 0; k < 3; k++) {
		const b = out[index + k] / 255, s = source[k] / 255, blended = color ? color[k] : blendChannel(b, s, mode);
		out[index + k] = Math.round(255 * ((1 - sa) * ba * b + (1 - ba) * sa * s + ba * sa * blended) / oa);
	}
	out[index + 3] = Math.round(255 * oa);
}
function renderImage(doc, out, image, cel, opacity, mode) {
	if (!image || image.tilemap) return;
	if (cel.preciseBounds?.flags & 1) {
		const b = cel.preciseBounds;
		if (![
			b.x,
			b.y,
			b.width,
			b.height
		].every(Number.isFinite) || b.width <= 0 || b.height <= 0) return;
		for (let y = Math.max(0, Math.ceil(b.y - .5)); y < Math.min(doc.height, Math.ceil(b.y + b.height - .5)); y++) for (let x = Math.max(0, Math.ceil(b.x - .5)); x < Math.min(doc.width, Math.ceil(b.x + b.width - .5)); x++) {
			const ix = clamp(Math.floor((x + .5 - b.x) / b.width * image.width), 0, image.width - 1), iy = clamp(Math.floor((y + .5 - b.y) / b.height * image.height), 0, image.height - 1), p = image.pixels[iy * image.width + ix];
			if (p !== null) blendAt(out, (y * doc.width + x) * 4, pixelRGBA(doc, p), opacity, mode);
		}
		return;
	}
	const x0 = Math.max(0, cel.x), y0 = Math.max(0, cel.y), x1 = Math.min(doc.width, cel.x + image.width), y1 = Math.min(doc.height, cel.y + image.height);
	for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x++) {
		const p = image.pixels[(y - cel.y) * image.width + x - cel.x];
		if (p !== null) blendAt(out, (y * doc.width + x) * 4, pixelRGBA(doc, p), opacity, mode);
	}
}
function renderTile(doc, out, image, sx, sy, sw, sh, dx, dy, dw, dh, flipX, flipY, rotate, opacity, mode) {
	for (let y = Math.max(0, dy); y < Math.min(doc.height, dy + dh); y++) for (let x = Math.max(0, dx); x < Math.min(doc.width, dx + dw); x++) {
		let u = (x - dx + .5) / dw, v = (y - dy + .5) / dh;
		if (rotate === 90) [u, v] = [v, 1 - u];
		else if (rotate === 180) [u, v] = [1 - u, 1 - v];
		else if (rotate === 270) [u, v] = [1 - v, u];
		if (flipX) u = 1 - u;
		if (flipY) v = 1 - v;
		const ix = sx + Math.min(sw - 1, Math.floor(u * sw)), iy = sy + Math.min(sh - 1, Math.floor(v * sh));
		if (ix < 0 || iy < 0 || ix >= image.width || iy >= image.height) continue;
		const p = image.pixels[iy * image.width + ix];
		if (p != null) blendAt(out, (y * doc.width + x) * 4, pixelRGBA(doc, p), opacity, mode);
	}
}
function renderTilemap(doc, out, layer, frame, opacity, mode) {
	const map = layer.tilemaps?.[frame.id];
	if (map) {
		const ts = doc.tilesets.find((t) => t.id === map.tilesetId);
		if (!ts) return;
		const tiles = new Map((ts.tiles ?? []).map((t) => [t.id, t]));
		for (let i = 0; i < map.cells.length; i++) {
			const cell = map.cells[i];
			if (!cell) continue;
			const tile = tiles.get(cell.tileId), image = doc.images[tile?.imageId], rect = tile?.sourceRect;
			if (image) renderTile(doc, out, image, rect?.x ?? 0, rect?.y ?? 0, rect?.width ?? image.width, rect?.height ?? image.height, (map.x ?? 0) + i % map.columns * ts.tileWidth, (map.y ?? 0) + Math.floor(i / map.columns) * ts.tileHeight, ts.tileWidth, ts.tileHeight, cell.flipX, cell.flipY, cell.rotate ?? 0, opacity * (map.opacity ?? 1), mode);
		}
		return;
	}
	const cel = frame.cels[layer.id], image = doc.images[cel?.imageId], tilemap = image?.tilemap, ts = doc.tilesets.find((t) => t.id === layer.tilesetId), atlas = doc.images[ts?.imageId];
	if (!tilemap || !ts || !atlas) return;
	const tw = ts.tileWidth, th = ts.tileHeight, cols = Math.floor(atlas.width / tw);
	if (cols < 1) return;
	for (let i = 0; i < tilemap.tiles.length; i++) {
		const value = tilemap.tiles[i] >>> 0, index = (value & (tilemap.idMask ?? 536870911)) >>> 0;
		if (ts.flags & 4 ? index === 0 : value === 4294967295) continue;
		if (index >= (ts.tileCount ?? Math.floor(atlas.height / th) * cols)) continue;
		const diagonal = !!(value & (tilemap.diagonalFlipMask ?? 536870912)), flipX = !!(value & (tilemap.xFlipMask ?? 2147483648)), flipY = !!(value & (tilemap.yFlipMask ?? 1073741824));
		renderTile(doc, out, atlas, index % cols * tw, Math.floor(index / cols) * th, tw, th, cel.x + i % image.width * tw, cel.y + Math.floor(i / image.width) * th, tw, th, flipX, diagonal ? !flipY : flipY, diagonal ? 90 : 0, opacity * cel.opacity, mode);
	}
}
/** Layers are ordered bottom-to-top. Groups composite their children in isolation. */
function renderFrame(doc, frameId = doc.frames[0]?.id) {
	const frame = doc.frames.find((f) => f.id === frameId);
	if (!frame) fail$1("Frame not found");
	let palette = doc.palette;
	for (const f of doc.frames) {
		if (f.palette) palette = f.palette;
		if (f.id === frame.id) break;
	}
	const working = palette === doc.palette ? doc : {
		...doc,
		palette
	};
	const children = /* @__PURE__ */ new Map(), positions = new Map(doc.layers.map((l, i) => [l.id, i]));
	for (const l of doc.layers) {
		const key = l.parentId ?? null;
		if (!children.has(key)) children.set(key, []);
		children.get(key).push(l);
	}
	for (const list of children.values()) list.sort((a, b) => {
		const za = frame.cels[a.id]?.zIndex ?? 0, zb = frame.cels[b.id]?.zIndex ?? 0;
		return positions.get(a.id) + za - positions.get(b.id) - zb || za - zb || positions.get(a.id) - positions.get(b.id);
	});
	function renderGroup(parent, depth) {
		if (depth > 24) fail$1("Layer nesting exceeds rendering limit");
		const out = new Uint8ClampedArray(doc.width * doc.height * 4);
		for (const layer of children.get(parent) ?? []) {
			if (!layer.visible || layer.opacity === 0) continue;
			let display = working;
			const transparent = doc.metadata?.aseprite?.transparentIndex;
			if (doc.colorMode === "indexed" && Number.isInteger(transparent) && !(layer.asepriteFlags & 8)) {
				display = {
					...working,
					palette: [...working.palette]
				};
				if (transparent < display.palette.length) display.palette[transparent] = "#00000000";
			}
			if (layer.type === "group") {
				const sub = renderGroup(layer.id, depth + 1);
				for (let i = 0; i < sub.length; i += 4) if (sub[i + 3]) blendAt(out, i, sub.subarray(i, i + 4), layer.opacity, layer.blendMode);
			} else if (layer.type === "tilemap") renderTilemap(display, out, layer, frame, layer.opacity, layer.blendMode);
			else {
				const cel = frame.cels[layer.id];
				if (cel) renderImage(display, out, doc.images[cel.imageId], cel, layer.opacity * cel.opacity, layer.blendMode);
			}
		}
		return out;
	}
	return renderGroup(null, 0);
}
function shallowDocument(doc) {
	return {
		...doc,
		palette: [...doc.palette],
		layers: doc.layers.map((l) => ({ ...l })),
		frames: doc.frames.map((f) => ({
			...f,
			cels: Object.fromEntries(Object.entries(f.cels).map(([k, c]) => [k, { ...c }]))
		})),
		images: { ...doc.images },
		clips: doc.clips.map((c) => ({
			...c,
			frameIds: [...c.frameIds]
		})),
		slices: doc.slices.map((s) => ({
			...s,
			...s.bounds ? { bounds: { ...s.bounds } } : {}
		})),
		tilesets: doc.tilesets.map((t) => ({
			...t,
			...t.tiles ? { tiles: t.tiles.map((a) => ({ ...a })) } : {}
		})),
		metadata: { ...doc.metadata }
	};
}
function fresh(doc, prefix) {
	const keys = new Set([
		doc.id,
		...doc.layers.map((l) => l.id),
		...doc.frames.map((f) => f.id),
		...Object.keys(doc.images),
		...doc.clips.map((c) => c.id),
		...doc.slices.map((s) => s.id),
		...doc.tilesets.map((t) => t.id)
	]);
	let n = 1;
	while (keys.has(`${prefix}-${n}`)) n++;
	return `${prefix}-${n}`;
}
function frameFor(doc, fid) {
	const f = doc.frames.find((f) => f.id === (fid ?? doc.frames[0].id));
	if (!f) fail$1("Frame not found");
	return f;
}
function layerFor(doc, lid, write = false) {
	const l = doc.layers.find((l) => l.id === (lid ?? doc.layers.find((l) => l.type === "image")?.id));
	if (!l) fail$1("Layer not found");
	if (write) {
		let a = l;
		while (a) {
			if (a.locked) fail$1("Layer is locked", "LOCKED_LAYER");
			a = a.parentId ? doc.layers.find((l) => l.id === a.parentId) : null;
		}
	}
	return l;
}
function targetFrames(doc, c) {
	const ids = c.frameIds ?? (c.frameId ? [c.frameId] : [doc.frames[0].id]);
	if (!Array.isArray(ids) || !ids.length || new Set(ids).size !== ids.length) fail$1("Frame range must be a nonempty list of unique ids");
	return ids.map((fid) => frameFor(doc, fid));
}
function reserve(doc, count, replacing) {
	if (Object.values(doc.images).reduce((s, i) => s + i.width * i.height, 0) - (replacing ? doc.images[replacing].width * doc.images[replacing].height : 0) + count > LIMITS.pixels) fail$1("Document exceeds the stored pixel budget", "MEMORY_BUDGET");
}
function writable(doc, c, changed) {
	const layer = layerFor(doc, c.layerId, true);
	if (!["image", "reference"].includes(layer.type)) fail$1("Drawing requires an image or reference layer");
	const frame = frameFor(doc, c.frameId);
	let cel = frame.cels[layer.id];
	if (!cel) {
		reserve(doc, doc.width * doc.height);
		const imageId = fresh(doc, "image");
		doc.images[imageId] = {
			width: doc.width,
			height: doc.height,
			pixels: Array(doc.width * doc.height).fill(null)
		};
		cel = frame.cels[layer.id] = {
			imageId,
			x: 0,
			y: 0,
			opacity: 1
		};
		changed.add(imageId);
	}
	let image = doc.images[cel.imageId];
	if (image.tilemap) fail$1("Raster drawing cannot edit tile indices");
	if (cel.preciseBounds?.flags & 1) {
		const b = cel.preciseBounds, x = integer(Math.floor(b.x), "Rasterized cel x", -65535, 65535), y = integer(Math.floor(b.y), "Rasterized cel y", -65535, 65535), width = integer(Math.ceil(b.x + b.width) - x, "Rasterized width", 1, LIMITS.imageEdge), height = integer(Math.ceil(b.y + b.height) - y, "Rasterized height", 1, LIMITS.imageEdge), source = image, imageId = fresh(doc, "image");
		delete frame.cels[layer.id];
		gcImages(doc);
		reserve(doc, width * height);
		const pixels = Array(width * height).fill(null);
		for (let py = 0; py < height; py++) for (let px = 0; px < width; px++) {
			const wx = x + px + .5, wy = y + py + .5;
			if (wx < b.x || wy < b.y || wx >= b.x + b.width || wy >= b.y + b.height) continue;
			const ix = clamp(Math.floor((wx - b.x) / b.width * source.width), 0, source.width - 1), iy = clamp(Math.floor((wy - b.y) / b.height * source.height), 0, source.height - 1);
			pixels[py * width + px] = source.pixels[iy * source.width + ix];
		}
		image = doc.images[imageId] = {
			width,
			height,
			pixels
		};
		cel = frame.cels[layer.id] = {
			...cel,
			imageId,
			x,
			y,
			preciseBounds: {
				...b,
				flags: b.flags & -2
			}
		};
		changed.add(imageId);
	}
	if (!changed.has(cel.imageId)) {
		image = doc.images[cel.imageId] = {
			...image,
			pixels: [...image.pixels]
		};
		changed.add(cel.imageId);
	}
	const x0 = Math.min(cel.x, 0), y0 = Math.min(cel.y, 0), w = Math.max(cel.x + image.width, doc.width) - x0, h = Math.max(cel.y + image.height, doc.height) - y0;
	if (w !== image.width || h !== image.height) {
		if (w > LIMITS.imageEdge || h > LIMITS.imageEdge) fail$1("Image expansion exceeds bounds");
		reserve(doc, w * h, cel.imageId);
		const pixels = Array(w * h).fill(null), ox = cel.x - x0, oy = cel.y - y0;
		for (let y = 0; y < image.height; y++) for (let x = 0; x < image.width; x++) pixels[(y + oy) * w + x + ox] = image.pixels[y * image.width + x];
		image = doc.images[cel.imageId] = {
			...image,
			width: w,
			height: h,
			pixels
		};
		for (const f of doc.frames) for (const linked of Object.values(f.cels)) if (linked.imageId === cel.imageId) {
			linked.x -= ox;
			linked.y -= oy;
		}
	}
	return {
		frame,
		layer,
		cel,
		image
	};
}
function selectionMask(doc, mask) {
	if (mask === void 0 || mask === null) return null;
	if (!Array.isArray(mask) && !(mask instanceof Uint8Array) || mask.length !== doc.width * doc.height) fail$1("Selection must match canvas dimensions");
	for (const x of mask) if (x !== 0 && x !== 1 && x !== false && x !== true) fail$1("Selection values must be 0 or 1");
	return mask;
}
function point(p, label = "Point") {
	if (!record(p)) fail$1(`${label} is missing`);
	return {
		x: Math.round(finite(p.x, `${label} x`, -65535, 65535)),
		y: Math.round(finite(p.y, `${label} y`, -65535, 65535)),
		...p.pressure === void 0 ? {} : { pressure: finite(p.pressure, "Pressure", 0, 1) }
	};
}
function points(ps, min = 1, max = 65536) {
	if (!Array.isArray(ps) || ps.length < min || ps.length > max) fail$1(`Expected ${min}–${max} points`);
	return ps.map((p) => point(p));
}
function context(doc, c, changed) {
	const t = writable(doc, c, changed), mask = selectionMask(doc, c.selection), wrap = c.wrap === true ? "both" : c.wrap ?? "none";
	if (![
		"none",
		"x",
		"y",
		"both"
	].includes(wrap)) fail$1("Invalid drawing wrap mode");
	let ops = 0;
	return {
		...t,
		doc,
		command: c,
		mask,
		put(x, y, color) {
			if (++ops > LIMITS.operations) fail$1("Drawing operation exceeds work budget");
			x = Math.round(x);
			y = Math.round(y);
			if (wrap === "x" || wrap === "both") x = (x % doc.width + doc.width) % doc.width;
			if (wrap === "y" || wrap === "both") y = (y % doc.height + doc.height) % doc.height;
			if (x < 0 || y < 0 || x >= doc.width || y >= doc.height || mask && !mask[y * doc.width + x]) return;
			const ix = x - t.cel.x, iy = y - t.cel.y;
			if (ix >= 0 && iy >= 0 && ix < t.image.width && iy < t.image.height) t.image.pixels[iy * t.image.width + ix] = color;
		},
		get(x, y) {
			if (wrap === "x" || wrap === "both") x = (x % doc.width + doc.width) % doc.width;
			if (wrap === "y" || wrap === "both") y = (y % doc.height + doc.height) % doc.height;
			x = Math.round(x) - t.cel.x;
			y = Math.round(y) - t.cel.y;
			return x < 0 || y < 0 || x >= t.image.width || y >= t.image.height ? null : t.image.pixels[y * t.image.width + x];
		}
	};
}
function clippedLine(a, b, width, height, pad = 0) {
	let lo = 0, hi = 1;
	const dx = b.x - a.x, dy = b.y - a.y;
	for (const [p, q] of [
		[-dx, a.x + pad],
		[dx, width - 1 + pad - a.x],
		[-dy, a.y + pad],
		[dy, height - 1 + pad - a.y]
	]) if (p === 0) {
		if (q < 0) return null;
	} else {
		const r = q / p;
		if (p < 0) lo = Math.max(lo, r);
		else hi = Math.min(hi, r);
		if (lo > hi) return null;
	}
	return [{
		x: Math.round(a.x + lo * dx),
		y: Math.round(a.y + lo * dy)
	}, {
		x: Math.round(a.x + hi * dx),
		y: Math.round(a.y + hi * dy)
	}];
}
function linePoints(a, b, width, height, pad = 0) {
	const clip = clippedLine(a, b, width, height, pad);
	if (!clip) return [];
	let [{ x: x0, y: y0 }, { x: x1, y: y1 }] = clip;
	const out = [], dx = Math.abs(x1 - x0), sx = x0 < x1 ? 1 : -1, dy = -Math.abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
	let e = dx + dy;
	for (;;) {
		out.push({
			x: x0,
			y: y0
		});
		if (x0 === x1 && y0 === y1) break;
		const e2 = 2 * e;
		if (e2 >= dy) {
			e += dy;
			x0 += sx;
		}
		if (e2 <= dx) {
			e += dx;
			y0 += sy;
		}
	}
	return out;
}
function brush(c, doc) {
	const size = integer(c.size ?? 1, "Brush size", 1, 256);
	let mask = null;
	if (c.mask) {
		const m = c.mask;
		integer(m.width, "Mask width", 1, 256);
		integer(m.height, "Mask height", 1, 256);
		if (!Array.isArray(m.pixels) || m.pixels.length !== m.width * m.height) fail$1("Brush mask dimensions mismatch");
		if (m.colors && (!Array.isArray(m.colors) || m.colors.length !== m.pixels.length)) fail$1("Brush colors dimensions mismatch");
		mask = {
			...m,
			colors: m.colors?.map((p) => encodeColor(doc, p))
		};
	}
	const symmetry = c.symmetry ?? "none";
	if (![
		"none",
		"x",
		"y",
		"both"
	].includes(symmetry)) fail$1("Invalid symmetry");
	return {
		size,
		mask,
		symmetry,
		round: c.brush === "circle",
		color: c.erase ? null : encodeColor(doc, c.color === void 0 ? doc.palette[0] : c.color)
	};
}
function stamp(ctx, p, b) {
	if (p.pressure === 0) return;
	const pressure = p.pressure ?? 1, size = Math.max(1, Math.round(b.size * pressure)), w = b.mask ? b.mask.width : size, h = b.mask ? b.mask.height : size;
	const xs = b.symmetry === "x" || b.symmetry === "both" ? [p.x, ctx.doc.width - 1 - p.x] : [p.x], ys = b.symmetry === "y" || b.symmetry === "both" ? [p.y, ctx.doc.height - 1 - p.y] : [p.y];
	for (const cx of new Set(xs)) for (const cy of new Set(ys)) for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
		if (b.mask && !b.mask.pixels[y * w + x]) continue;
		if (!b.mask && b.round && (x - (w - 1) / 2) ** 2 + (y - (h - 1) / 2) ** 2 > (size / 2) ** 2) continue;
		const dx = cx + x - Math.floor(w / 2), dy = cy + y - Math.floor(h / 2);
		let color = b.mask?.colors ? b.mask.colors[y * w + x] : b.color;
		if (ctx.command.ink === "lighten" || ctx.command.ink === "darken") {
			const old = pixelRGBA(ctx.doc, ctx.get(dx, dy)), delta = 255 * finite(ctx.command.amount ?? .12, "Shade amount", 0, 1) * (ctx.command.ink === "lighten" ? 1 : -1);
			color = old[3] ? encodeColor(ctx.doc, hex$1([
				old[0] + delta,
				old[1] + delta,
				old[2] + delta,
				old[3]
			])) : null;
		}
		ctx.put(dx, dy, color);
	}
}
function drawStroke(ctx, ps, c) {
	if (c.pressure === false) ps = ps.map((p) => ({
		...p,
		pressure: 1
	}));
	const b = brush(c, ctx.doc), path = [];
	for (let i = 0; i < ps.length; i++) {
		if (i === 0) {
			path.push(ps[i]);
			continue;
		}
		const segment = c.wrap && c.wrap !== "none" ? linePoints({
			x: ps[i - 1].x + 65535,
			y: ps[i - 1].y + 65535
		}, {
			x: ps[i].x + 65535,
			y: ps[i].y + 65535
		}, 131071, 131071).map((p) => ({
			x: p.x - 65535,
			y: p.y - 65535
		})) : linePoints(ps[i - 1], ps[i], ctx.doc.width, ctx.doc.height, Math.max(b.size, b.mask?.width ?? 0, b.mask?.height ?? 0));
		for (let j = 0; j < segment.length; j++) {
			if (path.at(-1)?.x === segment[j].x && path.at(-1)?.y === segment[j].y) continue;
			path.push({
				...segment[j],
				pressure: (ps[i - 1].pressure ?? 1) + ((ps[i].pressure ?? 1) - (ps[i - 1].pressure ?? 1)) * j / Math.max(1, segment.length - 1)
			});
			if (path.length > 1048576) fail$1("Stroke exceeds work budget");
		}
	}
	const filtered = [];
	for (const p of path) {
		const a = filtered.at(-2), b0 = filtered.at(-1);
		if (c.pixelPerfect && b.size === 1 && !b.mask && a && b0 && Math.abs(a.x - p.x) === 1 && Math.abs(a.y - p.y) === 1 && Math.abs(a.x - b0.x) + Math.abs(a.y - b0.y) === 1 && Math.abs(p.x - b0.x) + Math.abs(p.y - b0.y) === 1) filtered.pop();
		filtered.push(p);
	}
	for (const p of filtered) stamp(ctx, p, b);
}
function bounds(c) {
	return {
		x: integer(c.x, "X", -65535, 65535),
		y: integer(c.y, "Y", -65535, 65535),
		width: integer(c.width, "Shape width", 1, 65535),
		height: integer(c.height, "Shape height", 1, 65535)
	};
}
function drawShape(ctx, c, ellipse = false) {
	const b = bounds(c), color = encodeColor(ctx.doc, c.color === void 0 ? ctx.doc.palette[0] : c.color), thickness = integer(c.size ?? 1, "Outline size", 1, 256);
	const x1 = Math.max(0, b.x), y1 = Math.max(0, b.y), x2 = Math.min(ctx.doc.width, b.x + b.width), y2 = Math.min(ctx.doc.height, b.y + b.height);
	for (let y = y1; y < y2; y++) for (let x = x1; x < x2; x++) {
		const dx = x - b.x + .5 - b.width / 2, dy = y - b.y + .5 - b.height / 2;
		const outer = ellipse ? (dx / (b.width / 2)) ** 2 + (dy / (b.height / 2)) ** 2 <= 1 : true;
		const iw = b.width / 2 - thickness, ih = b.height / 2 - thickness;
		const inner = ellipse ? iw > 0 && ih > 0 && (dx / iw) ** 2 + (dy / ih) ** 2 < 1 : x >= b.x + thickness && y >= b.y + thickness && x < b.x + b.width - thickness && y < b.y + b.height - thickness;
		if (outer && (c.filled || !inner)) ctx.put(x, y, color);
	}
}
function floodMask(doc, get, c) {
	const seed = point(c), mask = Array(doc.width * doc.height).fill(0);
	if (seed.x < 0 || seed.y < 0 || seed.x >= doc.width || seed.y >= doc.height) return mask;
	const target = pixelRGBA(doc, get(seed.x, seed.y)), tolerance = finite(c.tolerance ?? 0, "Tolerance", 0, 255);
	const matches = (x, y) => {
		const p = pixelRGBA(doc, get(x, y));
		return Math.max(...p.map((v, k) => Math.abs(v - target[k]))) <= tolerance;
	};
	if (c.contiguous === false) {
		for (let y = 0; y < doc.height; y++) for (let x = 0; x < doc.width; x++) if (matches(x, y)) mask[y * doc.width + x] = 1;
		return mask;
	}
	const queue = new Int32Array(doc.width * doc.height);
	let read = 0, write = 0;
	const enqueue = (x, y) => {
		if (x < 0 || y < 0 || x >= doc.width || y >= doc.height) return;
		const i = y * doc.width + x;
		if (mask[i] !== 0) return;
		mask[i] = 2;
		if (matches(x, y)) {
			mask[i] = 1;
			queue[write++] = i;
		}
	};
	enqueue(seed.x, seed.y);
	while (read < write) {
		const i = queue[read++], x = i % doc.width, y = Math.floor(i / doc.width);
		enqueue(x - 1, y);
		enqueue(x + 1, y);
		enqueue(x, y - 1);
		enqueue(x, y + 1);
	}
	return mask.map((v) => v === 1 ? 1 : 0);
}
const BITMAP_FONT = Object.freeze({
	width: 5,
	height: 7,
	glyphs: Object.freeze(Object.fromEntries(Object.entries({
		"A": [
			"01110",
			"10001",
			"10001",
			"11111",
			"10001",
			"10001",
			"10001"
		],
		"B": [
			"11110",
			"10001",
			"10001",
			"11110",
			"10001",
			"10001",
			"11110"
		],
		"C": [
			"01111",
			"10000",
			"10000",
			"10000",
			"10000",
			"10000",
			"01111"
		],
		"D": [
			"11110",
			"10001",
			"10001",
			"10001",
			"10001",
			"10001",
			"11110"
		],
		"E": [
			"11111",
			"10000",
			"10000",
			"11110",
			"10000",
			"10000",
			"11111"
		],
		"F": [
			"11111",
			"10000",
			"10000",
			"11110",
			"10000",
			"10000",
			"10000"
		],
		"G": [
			"01111",
			"10000",
			"10000",
			"10111",
			"10001",
			"10001",
			"01111"
		],
		"H": [
			"10001",
			"10001",
			"10001",
			"11111",
			"10001",
			"10001",
			"10001"
		],
		"I": [
			"11111",
			"00100",
			"00100",
			"00100",
			"00100",
			"00100",
			"11111"
		],
		"J": [
			"00111",
			"00010",
			"00010",
			"00010",
			"10010",
			"10010",
			"01100"
		],
		"K": [
			"10001",
			"10010",
			"10100",
			"11000",
			"10100",
			"10010",
			"10001"
		],
		"L": [
			"10000",
			"10000",
			"10000",
			"10000",
			"10000",
			"10000",
			"11111"
		],
		"M": [
			"10001",
			"11011",
			"10101",
			"10101",
			"10001",
			"10001",
			"10001"
		],
		"N": [
			"10001",
			"11001",
			"10101",
			"10011",
			"10001",
			"10001",
			"10001"
		],
		"O": [
			"01110",
			"10001",
			"10001",
			"10001",
			"10001",
			"10001",
			"01110"
		],
		"P": [
			"11110",
			"10001",
			"10001",
			"11110",
			"10000",
			"10000",
			"10000"
		],
		"Q": [
			"01110",
			"10001",
			"10001",
			"10001",
			"10101",
			"10010",
			"01101"
		],
		"R": [
			"11110",
			"10001",
			"10001",
			"11110",
			"10100",
			"10010",
			"10001"
		],
		"S": [
			"01111",
			"10000",
			"10000",
			"01110",
			"00001",
			"00001",
			"11110"
		],
		"T": [
			"11111",
			"00100",
			"00100",
			"00100",
			"00100",
			"00100",
			"00100"
		],
		"U": [
			"10001",
			"10001",
			"10001",
			"10001",
			"10001",
			"10001",
			"01110"
		],
		"V": [
			"10001",
			"10001",
			"10001",
			"10001",
			"10001",
			"01010",
			"00100"
		],
		"W": [
			"10001",
			"10001",
			"10001",
			"10101",
			"10101",
			"10101",
			"01010"
		],
		"X": [
			"10001",
			"10001",
			"01010",
			"00100",
			"01010",
			"10001",
			"10001"
		],
		"Y": [
			"10001",
			"10001",
			"01010",
			"00100",
			"00100",
			"00100",
			"00100"
		],
		"Z": [
			"11111",
			"00001",
			"00010",
			"00100",
			"01000",
			"10000",
			"11111"
		],
		"0": [
			"01110",
			"10001",
			"10011",
			"10101",
			"11001",
			"10001",
			"01110"
		],
		"1": [
			"00100",
			"01100",
			"00100",
			"00100",
			"00100",
			"00100",
			"01110"
		],
		"2": [
			"01110",
			"10001",
			"00001",
			"00010",
			"00100",
			"01000",
			"11111"
		],
		"3": [
			"11110",
			"00001",
			"00001",
			"01110",
			"00001",
			"00001",
			"11110"
		],
		"4": [
			"00010",
			"00110",
			"01010",
			"10010",
			"11111",
			"00010",
			"00010"
		],
		"5": [
			"11111",
			"10000",
			"10000",
			"11110",
			"00001",
			"00001",
			"11110"
		],
		"6": [
			"01110",
			"10000",
			"10000",
			"11110",
			"10001",
			"10001",
			"01110"
		],
		"7": [
			"11111",
			"00001",
			"00010",
			"00100",
			"01000",
			"01000",
			"01000"
		],
		"8": [
			"01110",
			"10001",
			"10001",
			"01110",
			"10001",
			"10001",
			"01110"
		],
		"9": [
			"01110",
			"10001",
			"10001",
			"01111",
			"00001",
			"00001",
			"01110"
		],
		"?": [
			"01110",
			"10001",
			"00010",
			"00100",
			"00100",
			"00000",
			"00100"
		],
		"!": [
			"00100",
			"00100",
			"00100",
			"00100",
			"00100",
			"00000",
			"00100"
		],
		".": [
			"00000",
			"00000",
			"00000",
			"00000",
			"00000",
			"00110",
			"00110"
		],
		",": [
			"00000",
			"00000",
			"00000",
			"00000",
			"00110",
			"00110",
			"00100"
		],
		":": [
			"00000",
			"00110",
			"00110",
			"00000",
			"00110",
			"00110",
			"00000"
		],
		";": [
			"00000",
			"00110",
			"00110",
			"00000",
			"00110",
			"00110",
			"00100"
		],
		"-": [
			"00000",
			"00000",
			"00000",
			"11111",
			"00000",
			"00000",
			"00000"
		],
		"_": [
			"00000",
			"00000",
			"00000",
			"00000",
			"00000",
			"00000",
			"11111"
		],
		"+": [
			"00000",
			"00100",
			"00100",
			"11111",
			"00100",
			"00100",
			"00000"
		],
		"=": [
			"00000",
			"00000",
			"11111",
			"00000",
			"11111",
			"00000",
			"00000"
		],
		"/": [
			"00001",
			"00010",
			"00010",
			"00100",
			"01000",
			"01000",
			"10000"
		],
		"\\": [
			"10000",
			"01000",
			"01000",
			"00100",
			"00010",
			"00010",
			"00001"
		],
		"(": [
			"00010",
			"00100",
			"01000",
			"01000",
			"01000",
			"00100",
			"00010"
		],
		")": [
			"01000",
			"00100",
			"00010",
			"00010",
			"00010",
			"00100",
			"01000"
		],
		"[": [
			"01110",
			"01000",
			"01000",
			"01000",
			"01000",
			"01000",
			"01110"
		],
		"]": [
			"01110",
			"00010",
			"00010",
			"00010",
			"00010",
			"00010",
			"01110"
		],
		"<": [
			"00010",
			"00100",
			"01000",
			"10000",
			"01000",
			"00100",
			"00010"
		],
		">": [
			"01000",
			"00100",
			"00010",
			"00001",
			"00010",
			"00100",
			"01000"
		],
		"#": [
			"01010",
			"01010",
			"11111",
			"01010",
			"11111",
			"01010",
			"01010"
		],
		"*": [
			"00000",
			"10101",
			"01110",
			"11111",
			"01110",
			"10101",
			"00000"
		],
		"\"": [
			"01010",
			"01010",
			"00000",
			"00000",
			"00000",
			"00000",
			"00000"
		],
		"'": [
			"00100",
			"00100",
			"00000",
			"00000",
			"00000",
			"00000",
			"00000"
		],
		" ": [
			"00000",
			"00000",
			"00000",
			"00000",
			"00000",
			"00000",
			"00000"
		]
	}).map(([k, v]) => [k, Object.freeze(v.join("").split("").map(Number))])))
});
function drawText(ctx, c) {
	const pos = point(c), scale = integer(c.scale ?? 1, "Text scale", 1, 64), font = c.font ?? BITMAP_FONT, w = integer(font.width, "Glyph width", 1, 64), h = integer(font.height, "Glyph height", 1, 64);
	if (typeof c.text !== "string" || c.text.length > 4096) fail$1("Text must contain at most 4096 characters");
	const spacing = integer(c.spacing ?? 1, "Text spacing", 0, 64), lineHeight = integer(c.lineHeight ?? h + 1, "Line height", 1, 128), color = encodeColor(ctx.doc, c.color === void 0 ? ctx.doc.palette[0] : c.color);
	let x = pos.x, y = pos.y;
	for (const ch of c.text) {
		if (ch === "\n") {
			x = pos.x;
			y += lineHeight * scale;
			continue;
		}
		const glyph = font.glyphs[ch] ?? font.glyphs[ch.toUpperCase()] ?? font.glyphs["?"];
		if (!Array.isArray(glyph) || glyph.length !== w * h) fail$1(`Missing or invalid glyph: ${ch}`);
		for (let gy = 0; gy < h; gy++) for (let gx = 0; gx < w; gx++) if (glyph[gy * w + gx]) for (let py = 0; py < scale; py++) for (let px = 0; px < scale; px++) ctx.put(x + gx * scale + px, y + gy * scale + py, color);
		x += (w + spacing) * scale;
	}
}
function gradient(ctx, c) {
	const a = point(c.from, "Gradient start"), b = point(c.to, "Gradient end"), ac = pixelRGBA(ctx.doc, encodeColor(ctx.doc, c.color === void 0 ? ctx.doc.palette[0] : c.color)), bc = pixelRGBA(ctx.doc, encodeColor(ctx.doc, c.endColor === void 0 ? ctx.doc.palette.at(-1) : c.endColor)), dx = b.x - a.x, dy = b.y - a.y, den = dx * dx + dy * dy;
	if (!den) fail$1("Gradient endpoints must differ");
	const bayer = [
		0,
		8,
		2,
		10,
		12,
		4,
		14,
		6,
		3,
		11,
		1,
		9,
		15,
		7,
		13,
		5
	];
	for (let y = 0; y < ctx.doc.height; y++) for (let x = 0; x < ctx.doc.width; x++) {
		let t = clamp(((x - a.x) * dx + (y - a.y) * dy) / den);
		if (c.dither) {
			const threshold = (bayer[y % 4 * 4 + x % 4] + .5) / 16;
			ctx.put(x, y, encodeColor(ctx.doc, hex$1(t >= threshold ? bc : ac)));
		} else ctx.put(x, y, encodeColor(ctx.doc, hex$1(ac.map((v, k) => v + (bc[k] - v) * t))));
	}
}
function drawCurve(ctx, c) {
	const ps = points(c.points, 3, 4);
	if (ps.length !== 3 && ps.length !== 4) fail$1("Curve requires 3 or 4 control points");
	const length = ps.slice(1).reduce((s, p, i) => s + Math.hypot(p.x - ps[i].x, p.y - ps[i].y), 0), steps = Math.max(4, Math.min(16384, Math.ceil(length * 2))), path = [];
	for (let i = 0; i <= steps; i++) {
		const t = i / steps, u = 1 - t;
		path.push(ps.length === 3 ? {
			x: Math.round(u * u * ps[0].x + 2 * u * t * ps[1].x + t * t * ps[2].x),
			y: Math.round(u * u * ps[0].y + 2 * u * t * ps[1].y + t * t * ps[2].y)
		} : {
			x: Math.round(u ** 3 * ps[0].x + 3 * u * u * t * ps[1].x + 3 * u * t * t * ps[2].x + t ** 3 * ps[3].x),
			y: Math.round(u ** 3 * ps[0].y + 3 * u * u * t * ps[1].y + 3 * u * t * t * ps[2].y + t ** 3 * ps[3].y)
		});
	}
	drawStroke(ctx, path, c);
}
function drawPolygon(ctx, c) {
	const ps = points(c.points, c.filled ? 3 : 2, 4096), color = encodeColor(ctx.doc, c.color === void 0 ? ctx.doc.palette[0] : c.color);
	if (c.filled) {
		const minY = Math.max(0, Math.min(...ps.map((p) => p.y))), maxY = Math.min(ctx.doc.height - 1, Math.max(...ps.map((p) => p.y)));
		for (let y = minY; y <= maxY; y++) {
			const scan = y + .5, intersections = [];
			for (let i = 0, j = ps.length - 1; i < ps.length; j = i++) {
				const a = ps[i], b = ps[j];
				if (a.y > scan !== b.y > scan) intersections.push(a.x + (scan - a.y) * (b.x - a.x) / (b.y - a.y));
			}
			intersections.sort((a, b) => a - b);
			for (let i = 0; i + 1 < intersections.length; i += 2) for (let x = Math.max(0, Math.ceil(intersections[i] - .5)); x < Math.min(ctx.doc.width, Math.ceil(intersections[i + 1] - .5)); x++) ctx.put(x, y, color);
		}
	}
	drawStroke(ctx, [...ps, ps[0]], c);
}
function maskBounds(mask, width, height) {
	let x = width, y = height, x2 = -1, y2 = -1;
	for (let i = 0; i < mask.length; i++) if (mask[i]) {
		const px = i % width, py = Math.floor(i / width);
		x = Math.min(x, px);
		y = Math.min(y, py);
		x2 = Math.max(x2, px);
		y2 = Math.max(y2, py);
	}
	return x2 < 0 ? null : {
		x,
		y,
		width: x2 - x + 1,
		height: y2 - y + 1
	};
}
function scale2x(pixels, width, height) {
	const out = Array(width * height * 4), at = (x, y) => pixels[clamp(y, 0, height - 1) * width + clamp(x, 0, width - 1)];
	for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
		const B = at(x, y - 1), D = at(x - 1, y), E = at(x, y), F = at(x + 1, y), H = at(x, y + 1), i = y * 2 * width * 2 + x * 2;
		out[i] = D === B && D !== H && B !== F ? D : E;
		out[i + 1] = B === F && B !== D && F !== H ? F : E;
		out[i + width * 2] = D === H && D !== B && H !== F ? D : E;
		out[i + width * 2 + 1] = H === F && D !== H && B !== F ? F : E;
	}
	return out;
}
function selectionTransform(doc, c, changed) {
	const mask = selectionMask(doc, c.selection);
	if (!mask) fail$1("Transform requires a selection");
	const b = maskBounds(mask, doc.width, doc.height);
	if (!b) return;
	const ctx = context(doc, {
		...c,
		selection: null
	}, changed), snapshot = [...ctx.image.pixels], get = (x, y) => {
		const ix = x - ctx.cel.x, iy = y - ctx.cel.y;
		return ix < 0 || iy < 0 || ix >= ctx.image.width || iy >= ctx.image.height ? null : snapshot[iy * ctx.image.width + ix];
	}, op = c.operation ?? "move", method = c.method ?? "nearest";
	if (![
		"move",
		"scale",
		"rotate",
		"flipX",
		"flipY"
	].includes(op)) fail$1("Unsupported selection transform");
	if (!["nearest", "pixel-safe"].includes(method)) fail$1("Unsupported transform sampling method");
	if (method === "pixel-safe" && op !== "rotate") fail$1("Pixel-safe sampling is only used for rotation");
	const dx = finite(c.dx ?? 0, "Move x", -65535, 65535), dy = finite(c.dy ?? 0, "Move y", -65535, 65535), sx = op === "scale" ? finite(c.scaleX ?? 1, "Scale x", .01, 64) : op === "flipX" ? -1 : 1, sy = op === "scale" ? finite(c.scaleY ?? c.scaleX ?? 1, "Scale y", .01, 64) : op === "flipY" ? -1 : 1, angle = op === "rotate" ? finite(c.angle ?? 0, "Angle", -36e3, 36e3) * Math.PI / 180 : 0, cos = Math.cos(angle), sin = Math.sin(angle), cx = c.pivot?.x ?? b.x + b.width / 2, cy = c.pivot?.y ?? b.y + b.height / 2;
	finite(cx, "Pivot x", -65535, 65535);
	finite(cy, "Pivot y", -65535, 65535);
	let enlarged = null;
	const outside = Symbol("outside");
	if (method === "pixel-safe") {
		if (b.width * b.height * 16 > LIMITS.pixels) fail$1("Pixel-safe rotation exceeds its temporary pixel budget; reduce the selection or choose nearest");
		const source = Array(b.width * b.height);
		for (let y = 0; y < b.height; y++) for (let x = 0; x < b.width; x++) source[y * b.width + x] = mask[(y + b.y) * doc.width + x + b.x] ? get(x + b.x, y + b.y) : outside;
		enlarged = scale2x(scale2x(source, b.width, b.height), b.width * 2, b.height * 2);
	}
	if (!c.copy) {
		for (let y = b.y; y < b.y + b.height; y++) for (let x = b.x; x < b.x + b.width; x++) if (mask[y * doc.width + x]) ctx.put(x, y, null);
	}
	for (let y = 0; y < doc.height; y++) for (let x = 0; x < doc.width; x++) if (enlarged) {
		const votes = /* @__PURE__ */ new Map();
		for (let oy = 0; oy < 4; oy++) for (let ox = 0; ox < 4; ox++) {
			const tx = x + (ox + .5) / 4 - cx - dx, ty = y + (oy + .5) / 4 - cy - dy, px = Math.floor(((tx * cos + ty * sin) / sx + cx - b.x) * 4 + 1e-9), py = Math.floor(((-tx * sin + ty * cos) / sy + cy - b.y) * 4 + 1e-9), color = px >= 0 && py >= 0 && px < b.width * 4 && py < b.height * 4 ? enlarged[py * b.width * 4 + px] : outside;
			votes.set(color, (votes.get(color) ?? 0) + 1);
		}
		let best = outside, count = -1;
		for (const [color, n] of votes) if (n > count || n === count && best === outside && color !== outside) {
			best = color;
			count = n;
		}
		if (best !== outside) ctx.put(x, y, best);
	} else {
		const tx = x + .5 - cx - dx, ty = y + .5 - cy - dy, sourceX = Math.floor((tx * cos + ty * sin) / sx + cx + 1e-9), sourceY = Math.floor((-tx * sin + ty * cos) / sy + cy + 1e-9);
		if (sourceX >= 0 && sourceY >= 0 && sourceX < doc.width && sourceY < doc.height && mask[sourceY * doc.width + sourceX]) ctx.put(x, y, get(sourceX, sourceY));
	}
}
function applyEffect(doc, c, changed) {
	const effect = c.effect;
	if (![
		"replace",
		"outline",
		"brightness",
		"contrast",
		"hue",
		"saturation",
		"convolution",
		"despeckle"
	].includes(effect)) fail$1("Unsupported effect");
	const handled = /* @__PURE__ */ new Set();
	for (const frame of targetFrames(doc, c)) {
		const cel0 = frame.cels[c.layerId ?? doc.layers.find((l) => l.type === "image")?.id];
		if (cel0 && handled.has(cel0.imageId)) continue;
		const ctx = context(doc, {
			...c,
			frameId: frame.id
		}, changed);
		handled.add(ctx.cel.imageId);
		const source = [...ctx.image.pixels], sample = (x, y) => {
			x = clamp(x, 0, doc.width - 1) - ctx.cel.x;
			y = clamp(y, 0, doc.height - 1) - ctx.cel.y;
			return x < 0 || y < 0 || x >= ctx.image.width || y >= ctx.image.height ? null : source[y * ctx.image.width + x];
		};
		const color = ["replace", "outline"].includes(effect) ? encodeColor(doc, c.toColor === void 0 ? c.color === void 0 ? doc.palette[0] : c.color : c.toColor) : null, from = effect === "replace" && c.fromColor !== void 0 ? encodeColor(doc, c.fromColor) : void 0, amount = [
			"brightness",
			"contrast",
			"hue",
			"saturation"
		].includes(effect) ? finite(c.amount ?? (effect === "hue" ? 30 : .1), "Effect amount", effect === "hue" ? -360 : effect === "contrast" ? -.99 : -1, effect === "hue" ? 360 : effect === "contrast" ? .99 : 1) : 0, radius = effect === "outline" ? integer(c.radius ?? 1, "Outline radius", 1, 64) : 1;
		let kernel, size, divisor;
		if (effect === "convolution") {
			kernel = c.kernel;
			if (!Array.isArray(kernel) || kernel.length < 1 || kernel.length > 225 || !Number.isInteger(Math.sqrt(kernel.length)) || Math.sqrt(kernel.length) % 2 !== 1) fail$1("Convolution requires an odd square kernel up to 15×15");
			for (const n of kernel) finite(n, "Kernel coefficient", -1e3, 1e3);
			size = Math.sqrt(kernel.length);
			divisor = finite(c.divisor ?? (kernel.reduce((a, b) => a + b, 0) || 1), "Kernel divisor", -1e6, 1e6);
			if (divisor === 0) fail$1("Kernel divisor cannot be zero");
			finite(c.bias ?? 0, "Kernel bias", -255, 255);
		}
		if ((ctx.mask ? ctx.mask.reduce((sum, v) => sum + (v ? 1 : 0), 0) : doc.width * doc.height) * (effect === "outline" ? (radius * 2 + 1) ** 2 : effect === "convolution" ? kernel.length : effect === "despeckle" ? 9 : 1) > LIMITS.operations) fail$1("Effect exceeds work budget; use a smaller canvas or radius");
		for (let y = 0; y < doc.height; y++) for (let x = 0; x < doc.width; x++) {
			if (ctx.mask && !ctx.mask[y * doc.width + x]) continue;
			const p = sample(x, y), v = pixelRGBA(doc, p);
			let result = p;
			if (effect === "replace") {
				if (from === void 0 ? p !== null : hex$1(pixelRGBA(doc, from)) === hex$1(v)) result = color;
			} else if (effect === "outline") {
				if (v[3] === 0) {
					let hit = false;
					for (let oy = -radius; oy <= radius && !hit; oy++) for (let ox = -radius; ox <= radius; ox++) {
						if (c.diagonal === false && Math.abs(ox) + Math.abs(oy) > radius) continue;
						if (x + ox < 0 || y + oy < 0 || x + ox >= doc.width || y + oy >= doc.height) continue;
						if (pixelRGBA(doc, sample(x + ox, y + oy))[3]) {
							hit = true;
							break;
						}
					}
					if (hit) result = color;
				}
			} else if (effect === "convolution") {
				const sum = [
					0,
					0,
					0,
					0
				];
				for (let ky = 0; ky < size; ky++) for (let kx = 0; kx < size; kx++) {
					const q = pixelRGBA(doc, sample(x + kx - (size - 1) / 2, y + ky - (size - 1) / 2)), weight = kernel[ky * size + kx];
					for (let k = 0; k < 4; k++) sum[k] += q[k] * weight;
				}
				result = encodeColor(doc, hex$1(sum.map((n, k) => k === 3 && !c.affectAlpha ? v[3] : n / divisor + (k === 3 ? 0 : c.bias ?? 0))));
			} else if (effect === "despeckle") {
				const samples = [];
				for (let oy = -1; oy <= 1; oy++) for (let ox = -1; ox <= 1; ox++) samples.push(pixelRGBA(doc, sample(x + ox, y + oy)));
				result = encodeColor(doc, hex$1([
					0,
					1,
					2,
					3
				].map((k) => samples.map((p) => p[k]).sort((a, b) => a - b)[4])));
			} else if (v[3]) {
				if (effect === "brightness") for (let k = 0; k < 3; k++) v[k] += amount * 255;
				else if (effect === "contrast") {
					const factor = (1 + amount) / (1 - amount);
					for (let k = 0; k < 3; k++) v[k] = (v[k] - 127.5) * factor + 127.5;
				} else {
					const hsl = rgbHsl(v);
					if (effect === "hue") hsl[0] += amount / 360;
					else hsl[1] = clamp(hsl[1] + amount);
					v.splice(0, 3, ...hslRgb(hsl));
				}
				result = encodeColor(doc, hex$1(v));
			}
			ctx.put(x, y, result);
		}
	}
}
function gcImages(doc) {
	const used = new Set(doc.frames.flatMap((f) => Object.values(f.cels).map((c) => c.imageId)));
	for (const ts of doc.tilesets) {
		if (ts.imageId) used.add(ts.imageId);
		for (const t of ts.tiles ?? []) used.add(t.imageId);
	}
	for (const key of Object.keys(doc.images)) if (!used.has(key)) delete doc.images[key];
}
function resizeImage(image, width, height) {
	const pixels = Array(width * height).fill(null);
	for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) pixels[y * width + x] = image.pixels[Math.min(image.height - 1, Math.floor(y * image.height / height)) * image.width + Math.min(image.width - 1, Math.floor(x * image.width / width))];
	return {
		...image,
		width,
		height,
		pixels
	};
}
function resizeDocument(doc, c) {
	const width = integer(c.width, "Width", 1, LIMITS.edge), height = integer(c.height, "Height", 1, LIMITS.edge), mode = c.mode ?? "canvas";
	if (!["canvas", "scale"].includes(mode)) fail$1("Invalid resize mode");
	const sx = width / doc.width, sy = height / doc.height, dx = c.anchor === "center" ? Math.floor((width - doc.width) / 2) : 0, dy = c.anchor === "center" ? Math.floor((height - doc.height) / 2) : 0;
	if (mode === "scale") {
		const referenced = new Set(doc.frames.flatMap((f) => Object.values(f.cels).map((c) => c.imageId))), plans = [];
		let pixels = 0;
		for (const [key, image] of Object.entries(doc.images)) if (referenced.has(key) && !image.tilemap) {
			const w = Math.max(1, Math.round(image.width * sx)), h = Math.max(1, Math.round(image.height * sy));
			integer(w, "Scaled image width", 1, LIMITS.imageEdge);
			integer(h, "Scaled image height", 1, LIMITS.imageEdge);
			pixels += w * h;
			plans.push([
				key,
				w,
				h
			]);
		} else pixels += image.width * image.height;
		if (pixels > LIMITS.pixels) fail$1("Scaled document exceeds pixel budget");
		for (const [key, w, h] of plans) doc.images[key] = resizeImage(doc.images[key], w, h);
		for (const frame of doc.frames) for (const cel of Object.values(frame.cels)) {
			cel.x = Math.round(cel.x * sx);
			cel.y = Math.round(cel.y * sy);
		}
	} else for (const frame of doc.frames) for (const cel of Object.values(frame.cels)) {
		cel.x += dx;
		cel.y += dy;
	}
	doc.slices = doc.slices.map((s) => {
		if (!s.bounds) return {
			...s,
			keys: s.keys.map((k) => ({
				...k,
				x: Math.round(mode === "scale" ? k.x * sx : k.x + dx),
				y: Math.round(mode === "scale" ? k.y * sy : k.y + dy),
				width: Math.round(k.width * (mode === "scale" ? sx : 1)),
				height: Math.round(k.height * (mode === "scale" ? sy : 1))
			}))
		};
		const x = clamp(Math.round(mode === "scale" ? s.bounds.x * sx : s.bounds.x + dx), 0, width - 1), y = clamp(Math.round(mode === "scale" ? s.bounds.y * sy : s.bounds.y + dy), 0, height - 1);
		return {
			...s,
			bounds: {
				x,
				y,
				width: clamp(Math.round(s.bounds.width * (mode === "scale" ? sx : 1)), 1, width - x),
				height: clamp(Math.round(s.bounds.height * (mode === "scale" ? sy : 1)), 1, height - y)
			}
		};
	});
	doc.width = width;
	doc.height = height;
}
function easing(t, name = "linear") {
	t = clamp(t);
	switch (name) {
		case "linear": return t;
		case "easeIn": return t * t;
		case "easeOut": return 1 - (1 - t) ** 2;
		case "easeInOut": return t < .5 ? 2 * t * t : 1 - (-2 * t + 2) ** 2 / 2;
		case "bounce": {
			const n = 7.5625, d = 2.75;
			if (t < 1 / d) return n * t * t;
			if (t < 2 / d) return n * (t -= 1.5 / d) * t + .75;
			if (t < 2.5 / d) return n * (t -= 2.25 / d) * t + .9375;
			return n * (t -= 2.625 / d) * t + .984375;
		}
		default: fail$1("Unsupported easing");
	}
}
function tween(doc, c) {
	const layer = layerFor(doc, c.layerId, true);
	if (layer.type === "group" || layer.type === "tilemap") fail$1("Tween requires a raster layer");
	const frames = targetFrames(doc, c), source = frameFor(doc, c.sourceFrameId ?? frames[0].id).cels[layer.id];
	if (!source) fail$1("Tween source cel is empty");
	const from = c.from ?? {}, to = c.to ?? {}, start = {
		x: finite(from.x ?? source.x, "Start x", -65535, 65535),
		y: finite(from.y ?? source.y, "Start y", -65535, 65535),
		opacity: finite(from.opacity ?? source.opacity, "Start opacity", 0, 1)
	}, end = {
		x: finite(to.x ?? start.x, "End x", -65535, 65535),
		y: finite(to.y ?? start.y, "End y", -65535, 65535),
		opacity: finite(to.opacity ?? start.opacity, "End opacity", 0, 1)
	};
	frames.forEach((f, i) => {
		const t = easing(frames.length === 1 ? 0 : i / (frames.length - 1), c.easing ?? "linear");
		const cel = {
			...source,
			x: Math.round(start.x + (end.x - start.x) * t),
			y: Math.round(start.y + (end.y - start.y) * t),
			opacity: start.opacity + (end.opacity - start.opacity) * t
		};
		if (c.bake !== false) {
			const image = doc.images[source.imageId];
			reserve(doc, image.width * image.height);
			const key = fresh(doc, "image");
			doc.images[key] = {
				...image,
				pixels: [...image.pixels]
			};
			cel.imageId = key;
		}
		f.cels[layer.id] = cel;
	});
	doc.metadata.motion = {
		...doc.metadata.motion ?? {},
		[c.id ?? "last-tween"]: {
			type: "tween",
			layerId: layer.id,
			frameIds: frames.map((f) => f.id),
			from: start,
			to: end,
			easing: c.easing ?? "linear",
			bake: c.bake !== false
		}
	};
}
function seededRandom(seed) {
	let n = seed >>> 0;
	return () => {
		n += 1831565813;
		let t = n;
		t = Math.imul(t ^ t >>> 15, t | 1);
		t ^= t + Math.imul(t ^ t >>> 7, t | 61);
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
function particles(doc, c, changed) {
	const layer = layerFor(doc, c.layerId, true);
	if (layer.type !== "image") fail$1("Particles require an image layer");
	const frames = targetFrames(doc, c), seed = integer(c.seed ?? 1, "Seed", 0, 4294967295), count = integer(c.count ?? 32, "Particle count", 1, 4096), x = finite(c.x ?? doc.width / 2, "Emitter x", -65535, 65535), y = finite(c.y ?? doc.height / 2, "Emitter y", -65535, 65535), speed = finite(c.speed ?? 20, "Speed", 0, 4096), spread = finite(c.spread ?? 360, "Spread", 0, 360), angle = finite(c.angle ?? -90, "Direction", -36e3, 36e3), gravity = finite(c.gravity ?? 12, "Gravity", -4096, 4096), lifetime = finite(c.lifetime ?? 2, "Lifetime seconds", .01, 3600), size = integer(c.size ?? 1, "Particle size", 1, 64), random = seededRandom(seed), emission = finite(c.emission ?? 0, "Emission seconds", 0, 3600), color = c.color === void 0 ? doc.palette[0] : c.color;
	const ps = Array.from({ length: count }, () => {
		const a = (angle + (random() - .5) * spread) * Math.PI / 180, v = speed * (.5 + random() * .5);
		return {
			vx: Math.cos(a) * v,
			vy: Math.sin(a) * v,
			birth: random() * emission,
			life: lifetime * (.7 + .3 * random())
		};
	});
	let time = 0;
	for (const frame of frames) {
		if (c.clear !== false) {
			delete frame.cels[layer.id];
			gcImages(doc);
		}
		const ctx = context(doc, {
			...c,
			frameId: frame.id
		}, changed), b = brush({
			size,
			color,
			brush: c.brush ?? "square"
		}, doc);
		for (const p of ps) {
			const t = time - p.birth;
			if (t < 0 || t > p.life) continue;
			const a = c.fade === false ? 1 : 1 - t / p.life, base = pixelRGBA(doc, b.color);
			stamp(ctx, {
				x: Math.round(x + p.vx * t),
				y: Math.round(y + p.vy * t + .5 * gravity * t * t)
			}, {
				...b,
				color: encodeColor(doc, hex$1([
					base[0],
					base[1],
					base[2],
					base[3] * a
				]))
			});
		}
		time += frame.durationMs / 1e3;
	}
	doc.metadata.motion = {
		...doc.metadata.motion ?? {},
		[c.id ?? "last-particles"]: {
			type: "particles",
			layerId: layer.id,
			frameIds: frames.map((f) => f.id),
			seed,
			count,
			x,
			y,
			speed,
			spread,
			angle,
			gravity,
			lifetime,
			size,
			emission,
			color,
			fade: c.fade !== false
		}
	};
}
function setCel(doc, c) {
	const frame = frameFor(doc, c.frameId), layer = layerFor(doc, c.layerId, true);
	if (!["image", "reference"].includes(layer.type)) fail$1("Set cel requires a raster layer");
	const width = integer(c.width ?? doc.width, "Image width", 1, LIMITS.imageEdge), height = integer(c.height ?? doc.height, "Image height", 1, LIMITS.imageEdge);
	if (width * height > LIMITS.pixels || !Array.isArray(c.pixels) || c.pixels.length !== width * height) fail$1("Imported image dimensions mismatch");
	const pixels = c.pixels.map((v) => encodeColor(doc, v));
	const existing = frame.cels[layer.id], key = c.editLinked && existing ? existing.imageId : fresh(doc, "image");
	if (existing && !c.editLinked) delete frame.cels[layer.id];
	gcImages(doc);
	reserve(doc, width * height, own(doc.images, key) ? key : void 0);
	doc.images[key] = {
		width,
		height,
		pixels
	};
	frame.cels[layer.id] = {
		imageId: key,
		x: integer(c.x ?? 0, "Cel x", -65535, 65535),
		y: integer(c.y ?? 0, "Cel y", -65535, 65535),
		opacity: finite(c.opacity ?? 1, "Cel opacity", 0, 1)
	};
}
function paletteEdit(doc, c, remap) {
	if (!Array.isArray(c.palette) || !c.palette.length || c.palette.length > LIMITS.palette) fail$1("Invalid palette");
	const palette = c.palette.map(normalizeColor), previous = doc.palette;
	if (doc.colorMode === "indexed") {
		let mapping;
		if (remap) {
			mapping = c.mapping;
			if (mapping) {
				if (!Array.isArray(mapping) || mapping.length !== previous.length) fail$1("Palette mapping must include every old index");
				mapping = mapping.map((i) => i === null ? null : integer(i, "Remapped index", 0, palette.length - 1));
			} else mapping = previous.map((p) => nearest(palette, rgba(p)));
		} else for (const image of Object.values(doc.images)) for (const p of image.pixels) if (p !== null && p >= palette.length) fail$1("Removing used palette entries requires remapping");
		if (mapping) {
			for (const [key, image] of Object.entries(doc.images)) if (!image.tilemap) doc.images[key] = {
				...image,
				pixels: image.pixels.map((p) => p === null ? null : mapping[p])
			};
		}
	} else if (remap) {
		const mapping = c.mapping;
		if (mapping && (!Array.isArray(mapping) || mapping.length !== previous.length)) fail$1("Palette mapping must include every old entry");
		const colorMap = new Map(previous.map((p, i) => [p, mapping ? mapping[i] === null ? null : palette[integer(mapping[i], "Remapped index", 0, palette.length - 1)] : palette[nearest(palette, rgba(p))]]));
		for (const [key, image] of Object.entries(doc.images)) if (!image.tilemap) doc.images[key] = {
			...image,
			pixels: image.pixels.map((p) => p === null ? null : encodeColor({
				...doc,
				palette
			}, colorMap.has(p) ? colorMap.get(p) : palette[nearest(palette, rgba(p))]))
		};
	}
	doc.palette = palette;
}
function addTileset(doc, c) {
	const input = c.tileset;
	if (!record(input)) fail$1("Tileset is missing");
	const ts = {
		...jsonCopy(input),
		id: input.id ?? fresh(doc, "tileset"),
		name: input.name ?? "Tileset",
		tileWidth: integer(input.tileWidth, "Tile width", 1, LIMITS.edge),
		tileHeight: integer(input.tileHeight, "Tile height", 1, LIMITS.edge),
		tiles: []
	};
	if (doc.tilesets.some((t) => t.id === ts.id)) fail$1("Tileset id exists");
	if (!Array.isArray(input.tiles) || input.tiles.length > 65536) fail$1("Tileset requires a tile list");
	for (const [i, t] of input.tiles.entries()) {
		let imageId = t.imageId;
		if (t.pixels) {
			if (!Array.isArray(t.pixels) || t.pixels.length !== ts.tileWidth * ts.tileHeight) fail$1("Tile pixels size mismatch");
			reserve(doc, t.pixels.length);
			imageId = fresh(doc, "image");
			doc.images[imageId] = {
				width: ts.tileWidth,
				height: ts.tileHeight,
				pixels: t.pixels.map((p) => encodeColor(doc, p))
			};
		}
		if (!own(doc.images, imageId)) fail$1("Tile image missing");
		ts.tiles.push({
			id: t.id ?? `tile-${i + 1}`,
			imageId
		});
	}
	doc.tilesets.push(ts);
}
function nativeMap(doc, layer, frame, ts) {
	const cel = frame.cels[layer.id], image = doc.images[cel?.imageId], raw = image?.tilemap;
	if (!raw) return null;
	const ids = new Map((ts.tiles ?? []).filter((t) => Number.isInteger(t.asepriteTileId)).map((t) => [t.asepriteTileId, t.id]));
	const cells = raw.tiles.map((rawValue) => {
		const value = rawValue >>> 0, index = (value & (raw.idMask ?? 536870911)) >>> 0;
		if (ts.flags & 4 ? index === 0 : value === 4294967295) return null;
		const tileId = ids.get(index);
		if (!tileId) return null;
		const diagonal = !!(value & (raw.diagonalFlipMask ?? 536870912)), flipY = !!(value & (raw.yFlipMask ?? 1073741824));
		return {
			tileId,
			flipX: !!(value & (raw.xFlipMask ?? 2147483648)),
			flipY: diagonal ? !flipY : flipY,
			rotate: diagonal ? 90 : 0
		};
	});
	return {
		tilesetId: ts.id,
		columns: image.width,
		rows: image.height,
		cells,
		x: cel.x,
		y: cel.y,
		opacity: cel.opacity,
		sourceImageId: cel.imageId
	};
}
function getTile(doc, tilesetId, tileId) {
	const ts = doc.tilesets.find((t) => t.id === tilesetId), tile = ts?.tiles?.find((t) => t.id === tileId);
	if (!tile) fail$1("Tile not found");
	const image = doc.images[tile.imageId], r = tile.sourceRect ?? {
		x: 0,
		y: 0,
		width: image.width,
		height: image.height
	}, pixels = Array(ts.tileWidth * ts.tileHeight);
	for (let y = 0; y < ts.tileHeight; y++) for (let x = 0; x < ts.tileWidth; x++) pixels[y * ts.tileWidth + x] = image.pixels[(r.y + Math.min(r.height - 1, Math.floor(y * r.height / ts.tileHeight))) * image.width + r.x + Math.min(r.width - 1, Math.floor(x * r.width / ts.tileWidth))];
	return {
		width: ts.tileWidth,
		height: ts.tileHeight,
		pixels
	};
}
function paintTilemap(doc, c) {
	const layer = layerFor(doc, c.layerId, true);
	if (layer.type !== "tilemap") fail$1("Tile painting requires a tilemap layer");
	const frame = frameFor(doc, c.frameId), ts = doc.tilesets.find((t) => t.id === (c.tilesetId ?? layer.tilemaps?.[frame.id]?.tilesetId ?? layer.tilesetId));
	if (!ts) fail$1("Tileset missing");
	const previous = layer.tilemaps?.[frame.id] ?? nativeMap(doc, layer, frame, ts), columns = integer(c.columns ?? previous?.columns ?? Math.ceil(doc.width / ts.tileWidth), "Tile columns", 1, 2048), rows = integer(c.rows ?? previous?.rows ?? Math.ceil(doc.height / ts.tileHeight), "Tile rows", 1, 2048);
	if (columns * rows > 1048576) fail$1("Tilemap too large");
	const cells = Array(columns * rows).fill(null);
	if (previous) for (let y = 0; y < Math.min(rows, previous.rows); y++) for (let x = 0; x < Math.min(columns, previous.columns); x++) cells[y * columns + x] = previous.cells[y * previous.columns + x];
	if (!Array.isArray(c.points) || c.points.length > 65536) fail$1("Invalid tile paint points");
	for (const p of c.points) {
		const x = integer(p.x, "Tile x", 0, columns - 1), y = integer(p.y, "Tile y", 0, rows - 1);
		cells[y * columns + x] = p.tileId == null ? null : {
			tileId: id(p.tileId),
			flipX: !!p.flipX,
			flipY: !!p.flipY,
			rotate: p.rotate ?? 0
		};
	}
	const map = {
		...previous ?? {},
		tilesetId: ts.id,
		columns,
		rows,
		cells
	};
	validateTilemap(doc, map);
	layer.tilemaps = {
		...layer.tilemaps ?? {},
		[frame.id]: map
	};
	layer.tilesetId = ts.id;
}
function stampImage(doc, c, changed) {
	const width = integer(c.width, "Stamp width", 1, LIMITS.imageEdge), height = integer(c.height, "Stamp height", 1, LIMITS.imageEdge);
	if (width * height > LIMITS.pixels || !Array.isArray(c.pixels) || c.pixels.length !== width * height) fail$1("Stamp pixels size mismatch");
	const x0 = integer(c.x ?? 0, "Stamp x", -65535, 65535), y0 = integer(c.y ?? 0, "Stamp y", -65535, 65535), opacity = finite(c.opacity ?? 1, "Stamp opacity", 0, 1), transparent = c.transparent ?? "skip";
	if (!["skip", "replace"].includes(transparent)) fail$1("Invalid transparent-pixel mode");
	const pixels = c.pixels.map((p) => encodeColor(doc, p)), ctx = context(doc, c, changed);
	for (let y = Math.max(0, -y0); y < Math.min(height, doc.height - y0); y++) for (let x = Math.max(0, -x0); x < Math.min(width, doc.width - x0); x++) {
		const source = pixels[y * width + x];
		if (source === null) {
			if (transparent === "replace") ctx.put(x + x0, y + y0, null);
			continue;
		}
		if (c.blend === false && opacity === 1) ctx.put(x + x0, y + y0, source);
		else {
			const out = new Uint8ClampedArray(pixelRGBA(doc, ctx.get(x + x0, y + y0)));
			blendAt(out, 0, pixelRGBA(doc, source), opacity, "normal");
			ctx.put(x + x0, y + y0, encodeColor(doc, hex$1([...out])));
		}
	}
}
function editTilemap(doc, c) {
	const layer = layerFor(doc, c.layerId, true);
	if (layer.type !== "tilemap") fail$1("Tile editing requires a tilemap layer");
	const frame = frameFor(doc, c.frameId), ts = doc.tilesets.find((t) => t.id === (layer.tilemaps?.[frame.id]?.tilesetId ?? layer.tilesetId));
	if (!ts) fail$1("Tileset missing");
	const map = layer.tilemaps?.[frame.id] ?? nativeMap(doc, layer, frame, ts);
	if (!map) fail$1("Paint an initial tilemap cell before editing tiles");
	const x = integer(c.x, "Tile x", 0, map.columns - 1), y = integer(c.y, "Tile y", 0, map.rows - 1), mode = c.mode ?? "auto";
	if (![
		"manual",
		"auto",
		"stack"
	].includes(mode)) fail$1("Tile edit mode must be manual, auto, or stack");
	if (!Array.isArray(c.pixels) || c.pixels.length !== ts.tileWidth * ts.tileHeight) fail$1("Tile pixel dimensions mismatch");
	const pixels = c.pixels.map((p) => encodeColor(doc, p)), previous = map.cells[y * map.columns + x];
	let tile;
	if (mode === "manual") {
		tile = ts.tiles.find((t) => t.id === previous?.tileId);
		if (!tile) fail$1("Manual editing requires a nonempty tile");
		const source = doc.images[tile.imageId];
		if (tile.sourceRect) {
			const r = tile.sourceRect, updated = [...source.pixels];
			for (let y = 0; y < r.height; y++) for (let x = 0; x < r.width; x++) updated[(r.y + y) * source.width + r.x + x] = pixels[Math.min(ts.tileHeight - 1, Math.floor(y * ts.tileHeight / r.height)) * ts.tileWidth + Math.min(ts.tileWidth - 1, Math.floor(x * ts.tileWidth / r.width))];
			doc.images[tile.imageId] = {
				...source,
				pixels: updated
			};
		} else {
			reserve(doc, pixels.length, tile.imageId);
			doc.images[tile.imageId] = {
				...source,
				width: ts.tileWidth,
				height: ts.tileHeight,
				pixels
			};
		}
	} else {
		if (mode === "auto") tile = ts.tiles.find((t) => getTile(doc, ts.id, t.id).pixels.every((p, i) => p === pixels[i]));
		if (!tile) {
			if (ts.tiles.length >= 65536) fail$1("Tileset limit reached");
			reserve(doc, pixels.length);
			const imageId = fresh(doc, "image");
			doc.images[imageId] = {
				width: ts.tileWidth,
				height: ts.tileHeight,
				pixels
			};
			let n = 1;
			while (ts.tiles.some((t) => t.id === `tile-${n}`)) n++;
			tile = {
				id: `tile-${n}`,
				imageId
			};
			ts.tiles.push(tile);
		}
		const cells = [...map.cells];
		cells[y * map.columns + x] = {
			tileId: tile.id,
			flipX: previous?.flipX ?? false,
			flipY: previous?.flipY ?? false,
			rotate: previous?.rotate ?? 0
		};
		layer.tilemaps = {
			...layer.tilemaps,
			[frame.id]: {
				...map,
				cells
			}
		};
	}
}
function duplicateLayer(doc, c) {
	const source = layerFor(doc, c.layerId), ids = new Set([source.id]);
	let again = true;
	while (again) {
		again = false;
		for (const l of doc.layers) if (ids.has(l.parentId) && !ids.has(l.id)) {
			ids.add(l.id);
			again = true;
		}
	}
	const originals = doc.layers.filter((l) => ids.has(l.id));
	if (doc.layers.length + originals.length > LIMITS.layers) fail$1("Layer limit reached");
	const copies = [], idMap = /* @__PURE__ */ new Map(), imageMap = /* @__PURE__ */ new Map();
	for (const l of originals) {
		const copy = {
			...jsonCopy(l),
			id: fresh(doc, "layer"),
			name: l.id === source.id ? name(c.name, `${l.name} copy`) : l.name
		};
		idMap.set(l.id, copy.id);
		doc.layers.push(copy);
		copies.push(copy);
	}
	for (const copy of copies) if (idMap.has(copy.parentId)) copy.parentId = idMap.get(copy.parentId);
	doc.layers = doc.layers.filter((l) => !copies.includes(l));
	const at = doc.layers.indexOf(originals.at(-1)) + 1;
	doc.layers.splice(at, 0, ...copies);
	for (const frame of doc.frames) for (const original of originals) {
		const cel = frame.cels[original.id];
		if (!cel) continue;
		let imageId = cel.imageId;
		if (!c.linked) if (imageMap.has(imageId)) imageId = imageMap.get(imageId);
		else {
			const image = doc.images[imageId], key = fresh(doc, "image");
			reserve(doc, image.width * image.height);
			doc.images[key] = {
				...image,
				pixels: [...image.pixels],
				...image.tilemap ? { tilemap: jsonCopy(image.tilemap) } : {}
			};
			imageMap.set(imageId, key);
			imageId = key;
		}
		frame.cels[idMap.get(original.id)] = {
			...cel,
			imageId
		};
	}
}
function mergeDown(doc, c) {
	const top = layerFor(doc, c.layerId, true), at = doc.layers.indexOf(top), bottom = [...doc.layers.slice(0, at)].reverse().find((l) => l.parentId === top.parentId);
	if (!bottom) fail$1("No lower sibling layer to merge");
	layerFor(doc, bottom.id, true);
	if (top.type !== "image" || bottom.type !== "image" || top.blendMode !== "normal" || bottom.blendMode !== "normal") fail$1("Merge down currently supports two normal-blend image layers");
	const renderDoc = {
		...doc,
		layers: [{
			...bottom,
			parentId: null
		}, {
			...top,
			parentId: null
		}]
	};
	for (const frame of doc.frames) {
		const rgbaPixels = renderFrame(renderDoc, frame.id), pixels = Array(doc.width * doc.height);
		let painted = false;
		for (let i = 0; i < pixels.length; i++) {
			pixels[i] = rgbaPixels[i * 4 + 3] ? encodeColor(doc, hex$1([...rgbaPixels.subarray(i * 4, i * 4 + 4)])) : null;
			if (pixels[i] !== null) painted = true;
		}
		delete frame.cels[top.id];
		delete frame.cels[bottom.id];
		gcImages(doc);
		if (painted) {
			reserve(doc, pixels.length);
			const imageId = fresh(doc, "image");
			doc.images[imageId] = {
				width: doc.width,
				height: doc.height,
				pixels
			};
			frame.cels[bottom.id] = {
				imageId,
				x: 0,
				y: 0,
				opacity: 1
			};
		}
	}
	bottom.opacity = 1;
	bottom.visible = bottom.visible || top.visible;
	doc.layers = doc.layers.filter((l) => l.id !== top.id);
}
/** A failed command never changes its input. Untouched image objects retain identity. */
function applyCommand(input, command) {
	if (!record(command) || typeof command.type !== "string") fail$1("Command type is missing", "INVALID_COMMAND");
	if (input?.format !== "pixelwall-document" || input.version !== 4) fail$1("Normalize the document before editing");
	const doc = shallowDocument(input), c = command, changed = /* @__PURE__ */ new Set();
	switch (c.type) {
		case "batch": {
			if (!Array.isArray(c.commands) || c.commands.length > 1024) fail$1("Invalid command batch");
			let result = input;
			for (const command of c.commands) result = applyCommand(result, command);
			return result;
		}
		case "document.update":
			if (!record(c.patch)) fail$1("Document patch missing");
			for (const key of Object.keys(c.patch)) if (!["name", "metadata"].includes(key)) fail$1(`Document field ${key} cannot be patched`);
			if (c.patch.name !== void 0) doc.name = name(c.patch.name, "Untitled Sprite");
			if (c.patch.metadata !== void 0) doc.metadata = jsonCopy(c.patch.metadata);
			break;
		case "document.resize":
			resizeDocument(doc, c);
			break;
		case "document.colorMode": {
			if (![
				"rgba",
				"indexed",
				"grayscale"
			].includes(c.colorMode)) fail$1("Unsupported color mode");
			const source = { ...doc };
			doc.colorMode = c.colorMode;
			for (const [key, image] of Object.entries(doc.images)) if (!image.tilemap) doc.images[key] = {
				...image,
				pixels: image.pixels.map((p) => p === null ? null : encodeColor(doc, hex$1(pixelRGBA(source, p))))
			};
			break;
		}
		case "layer.add": {
			const v = c.layer ?? {};
			const layer = {
				id: v.id ?? fresh(doc, "layer"),
				name: v.name ?? `Layer ${doc.layers.length + 1}`,
				type: v.type ?? "image",
				parentId: v.parentId ?? null,
				visible: v.visible !== false,
				locked: !!v.locked,
				opacity: v.opacity ?? 1,
				blendMode: v.blendMode ?? "normal",
				...jsonCopy(v)
			};
			if (layer.parentId) layerFor(doc, layer.parentId, true);
			if (doc.layers.some((l) => l.id === layer.id)) fail$1("Layer id exists");
			const index = integer(c.index ?? doc.layers.length, "Layer index", 0, doc.layers.length);
			doc.layers.splice(index, 0, layer);
			break;
		}
		case "layer.update": {
			const layer = layerFor(doc, c.layerId);
			if (!record(c.patch)) fail$1("Layer patch missing");
			for (const key of Object.keys(c.patch)) if (![
				"name",
				"parentId",
				"visible",
				"locked",
				"opacity",
				"blendMode",
				"reference",
				"tilesetId"
			].includes(key)) fail$1(`Layer field ${key} cannot be patched`);
			Object.assign(layer, jsonCopy(c.patch));
			break;
		}
		case "layer.reorder": {
			const layer = layerFor(doc, c.layerId, true), index = integer(c.index, "Layer index", 0, doc.layers.length - 1);
			doc.layers.splice(doc.layers.indexOf(layer), 1);
			doc.layers.splice(index, 0, layer);
			break;
		}
		case "layer.duplicate":
			duplicateLayer(doc, c);
			break;
		case "layer.mergeDown":
			mergeDown(doc, c);
			break;
		case "layer.remove": {
			const layer = layerFor(doc, c.layerId, true), remove = new Set([layer.id]);
			let again = true;
			while (again) {
				again = false;
				for (const l of doc.layers) if (remove.has(l.parentId) && !remove.has(l.id)) {
					remove.add(l.id);
					again = true;
				}
			}
			if (remove.size === doc.layers.length) fail$1("Document must retain a layer");
			doc.layers = doc.layers.filter((l) => !remove.has(l.id));
			for (const f of doc.frames) for (const key of remove) delete f.cels[key];
			break;
		}
		case "frame.add": {
			if (doc.frames.length >= LIMITS.frames) fail$1("Frame limit reached");
			const after = c.afterFrameId ? doc.frames.indexOf(frameFor(doc, c.afterFrameId)) : doc.frames.length - 1, newId = c.id ?? fresh(doc, "frame");
			if (doc.frames.some((f) => f.id === newId)) fail$1("Frame id exists");
			doc.frames.splice(after + 1, 0, {
				id: newId,
				durationMs: integer(c.durationMs ?? 125, "Duration", 1, 65535),
				cels: {}
			});
			if (c.clipId) {
				const clip = doc.clips.find((clip) => clip.id === c.clipId);
				if (!clip) fail$1("Clip missing");
				const pos = clip.frameIds.indexOf(c.afterFrameId);
				clip.frameIds.splice(pos < 0 ? clip.frameIds.length : pos + 1, 0, newId);
			}
			break;
		}
		case "frame.duplicate": {
			const frames = targetFrames(doc, c);
			if (doc.frames.length + frames.length > LIMITS.frames) fail$1("Frame limit reached");
			let at = c.afterFrameId ? doc.frames.indexOf(frameFor(doc, c.afterFrameId)) : doc.frames.indexOf(frames.at(-1));
			for (const f of frames) {
				const fid = fresh(doc, "frame"), cels = {};
				for (const [lid, cel] of Object.entries(f.cels)) if (c.linked) cels[lid] = { ...cel };
				else {
					const source = doc.images[cel.imageId];
					reserve(doc, source.width * source.height);
					const imageId = fresh(doc, "image");
					doc.images[imageId] = {
						...source,
						pixels: [...source.pixels],
						...source.tilemap ? { tilemap: jsonCopy(source.tilemap) } : {}
					};
					cels[lid] = {
						...cel,
						imageId
					};
				}
				doc.frames.splice(++at, 0, {
					...f,
					id: fid,
					cels
				});
				for (const layer of doc.layers) if (layer.tilemaps?.[f.id]) layer.tilemaps = {
					...layer.tilemaps,
					[fid]: jsonCopy(layer.tilemaps[f.id])
				};
				if (c.clipId) {
					const clip = doc.clips.find((v) => v.id === c.clipId);
					if (!clip) fail$1("Clip missing");
					clip.frameIds.push(fid);
				}
			}
			break;
		}
		case "frame.update":
			if (!record(c.patch) || Object.keys(c.patch).some((k) => ![
				"durationMs",
				"name",
				"pivot"
			].includes(k))) fail$1("Invalid frame patch");
			for (const f of targetFrames(doc, c)) Object.assign(f, jsonCopy(c.patch));
			break;
		case "frame.reorder": {
			const frames = targetFrames(doc, c), selected = new Set(frames.map((f) => f.id)), others = doc.frames.filter((f) => !selected.has(f.id)), index = integer(c.index, "Frame insertion index", 0, others.length);
			others.splice(index, 0, ...frames);
			doc.frames = others;
			break;
		}
		case "frame.reverse": {
			const frames = targetFrames(doc, c), ids = new Set(frames.map((f) => f.id)), reverse = [...frames].reverse();
			let i = 0;
			doc.frames = doc.frames.map((f) => ids.has(f.id) ? reverse[i++] : f);
			break;
		}
		case "frame.remove": {
			const ids = new Set(targetFrames(doc, c).map((f) => f.id));
			if (ids.size === doc.frames.length) fail$1("Document must retain a frame");
			doc.frames = doc.frames.filter((f) => !ids.has(f.id));
			doc.slices = doc.slices.map((s) => s.keys ? {
				...s,
				keys: s.keys.filter((k) => !ids.has(k.frameId))
			} : s);
			doc.clips = doc.clips.map((clip) => ({
				...clip,
				frameIds: clip.frameIds.filter((fid) => !ids.has(fid))
			})).filter((clip) => clip.frameIds.length);
			for (const layer of doc.layers) if (layer.tilemaps) {
				layer.tilemaps = { ...layer.tilemaps };
				for (const fid of ids) delete layer.tilemaps[fid];
			}
			break;
		}
		case "cel.set":
			setCel(doc, c);
			break;
		case "image.stamp":
			stampImage(doc, c, changed);
			break;
		case "cel.link": {
			const layer = layerFor(doc, c.layerId, true), source = frameFor(doc, c.sourceFrameId).cels[layer.id];
			if (!source) fail$1("Source cel is empty");
			for (const f of targetFrames(doc, c)) f.cels[layer.id] = { ...source };
			break;
		}
		case "cel.unlink": {
			const layer = layerFor(doc, c.layerId, true);
			for (const f of targetFrames(doc, c)) {
				const cel = f.cels[layer.id];
				if (!cel) continue;
				const source = doc.images[cel.imageId];
				reserve(doc, source.width * source.height);
				const key = fresh(doc, "image");
				doc.images[key] = {
					...source,
					pixels: [...source.pixels],
					...source.tilemap ? { tilemap: jsonCopy(source.tilemap) } : {}
				};
				cel.imageId = key;
			}
			break;
		}
		case "cel.move": {
			const layer = layerFor(doc, c.layerId, true);
			for (const f of targetFrames(doc, c)) {
				const cel = f.cels[layer.id];
				if (!cel) continue;
				cel.x = integer(c.x ?? cel.x, "Cel x", -65535, 65535);
				cel.y = integer(c.y ?? cel.y, "Cel y", -65535, 65535);
				if (c.opacity !== void 0) cel.opacity = finite(c.opacity, "Cel opacity", 0, 1);
			}
			break;
		}
		case "cel.clear": {
			const layer = layerFor(doc, c.layerId, true);
			for (const f of targetFrames(doc, c)) delete f.cels[layer.id];
			break;
		}
		case "draw.stroke":
			drawStroke(context(doc, c, changed), points(c.points), c);
			break;
		case "draw.line":
			drawStroke(context(doc, c, changed), [point(c.from), point(c.to)], c);
			break;
		case "draw.rect":
			drawShape(context(doc, c, changed), c, false);
			break;
		case "draw.ellipse":
			drawShape(context(doc, c, changed), c, true);
			break;
		case "draw.polygon":
			drawPolygon(context(doc, c, changed), c);
			break;
		case "draw.curve":
			drawCurve(context(doc, c, changed), c);
			break;
		case "draw.fill": {
			const ctx = context(doc, c, changed), mask = floodMask(doc, ctx.get, c), color = encodeColor(doc, c.color === void 0 ? doc.palette[0] : c.color);
			for (let i = 0; i < mask.length; i++) if (mask[i]) ctx.put(i % doc.width, Math.floor(i / doc.width), color);
			break;
		}
		case "draw.gradient":
			gradient(context(doc, c, changed), c);
			break;
		case "draw.text":
			drawText(context(doc, c, changed), c);
			break;
		case "selection.transform":
			selectionTransform(doc, c, changed);
			break;
		case "selection.clear": {
			const ctx = context(doc, c, changed);
			if (!ctx.mask) fail$1("Clear selection requires a selection mask");
			for (let y = 0; y < doc.height; y++) for (let x = 0; x < doc.width; x++) ctx.put(x, y, null);
			break;
		}
		case "palette.update":
			paletteEdit(doc, c, false);
			break;
		case "palette.remap":
			paletteEdit(doc, c, true);
			break;
		case "effect.apply":
			applyEffect(doc, c, changed);
			break;
		case "animation.tween":
			tween(doc, c);
			break;
		case "animation.particles":
			particles(doc, c, changed);
			break;
		case "tileset.add":
			addTileset(doc, c);
			break;
		case "tileset.update": {
			const ts = doc.tilesets.find((t) => t.id === c.tilesetId);
			if (!ts) fail$1("Tileset missing");
			if (!record(c.patch) || Object.keys(c.patch).some((k) => ![
				"name",
				"tileWidth",
				"tileHeight",
				"tiles",
				"imageId",
				"baseIndex"
			].includes(k))) fail$1("Invalid tileset patch");
			Object.assign(ts, jsonCopy(c.patch));
			break;
		}
		case "tileset.remove":
			if (doc.layers.some((l) => l.tilesetId === c.tilesetId || Object.values(l.tilemaps ?? {}).some((m) => m.tilesetId === c.tilesetId))) fail$1("Cannot remove a tileset used by a layer");
			if (!doc.tilesets.some((t) => t.id === c.tilesetId)) fail$1("Tileset missing");
			doc.tilesets = doc.tilesets.filter((t) => t.id !== c.tilesetId);
			break;
		case "tilemap.paint":
			paintTilemap(doc, c);
			break;
		case "tilemap.edit":
			editTilemap(doc, c);
			break;
		case "clip.add": {
			const v = c.clip ?? {};
			doc.clips.push({
				id: v.id ?? fresh(doc, "clip"),
				name: v.name ?? "Animation",
				frameIds: v.frameIds ?? doc.frames.map((f) => f.id),
				direction: v.direction ?? "forward",
				loop: v.loop !== false
			});
			break;
		}
		case "clip.update": {
			const clip = doc.clips.find((v) => v.id === c.clipId);
			if (!clip) fail$1("Clip missing");
			if (!record(c.patch) || Object.keys(c.patch).some((k) => ![
				"name",
				"frameIds",
				"direction",
				"loop"
			].includes(k))) fail$1("Invalid clip patch");
			Object.assign(clip, jsonCopy(c.patch));
			break;
		}
		case "clip.remove":
			if (!doc.clips.some((v) => v.id === c.clipId)) fail$1("Clip missing");
			doc.clips = doc.clips.filter((v) => v.id !== c.clipId);
			break;
		case "slice.add": {
			const v = c.slice ?? {};
			doc.slices.push({
				...jsonCopy(v),
				id: v.id ?? fresh(doc, "slice"),
				name: v.name ?? "Slice"
			});
			break;
		}
		case "slice.update": {
			const s = doc.slices.find((v) => v.id === c.sliceId);
			if (!s) fail$1("Slice missing");
			if (!record(c.patch) || Object.keys(c.patch).some((k) => ![
				"name",
				"bounds",
				"pivot",
				"ninePatch"
			].includes(k))) fail$1("Invalid slice patch");
			Object.assign(s, jsonCopy(c.patch));
			break;
		}
		case "slice.remove":
			if (!doc.slices.some((v) => v.id === c.sliceId)) fail$1("Slice missing");
			doc.slices = doc.slices.filter((v) => v.id !== c.sliceId);
			break;
		default: fail$1(`Unknown command: ${c.type}`, "UNKNOWN_COMMAND");
	}
	gcImages(doc);
	return normalizeDocument(doc, { shareImages: true });
}
const TARGET = {
	frameId: "Optional frame id; defaults to first frame.",
	layerId: "Optional raster layer id; defaults to first image layer."
};
const RANGE = { frameIds: "Nonempty list of unique frame ids; or pass frameId for one frame." };
const DRAW = {
	...TARGET,
	color: "Hex RGB/RGBA string, palette index, or null (transparent).",
	selection: "Optional canvas-size array of 0/1; restricts affected pixels."
};
const STROKE = {
	...DRAW,
	size: "Integer 1–256 (default 1).",
	brush: "square | circle",
	mask: "Optional {width,height,pixels:[0|1],colors?:[RGBA|null]}; maximum 256×256.",
	symmetry: "none | x | y | both",
	wrap: "none | x | y | both; true is both. Wraps brush pixels and line paths for seamless tiles.",
	pressure: "false ignores point pressures; true or omitted uses supplied point pressures.",
	pixelPerfect: "Boolean; removes 1px orthogonal corners along the sampled path.",
	erase: "Boolean; stamps transparency.",
	ink: "paint | lighten | darken",
	amount: "Shading amount 0–1 (default .12)."
};
/** Machine-readable public catalog. Every listed command is executable. */
const COMMANDS = Object.freeze([
	[
		"batch",
		"Apply an ordered command list atomically.",
		{ commands: "Array of up to 1024 command objects." }
	],
	[
		"document.update",
		"Rename the document or replace metadata.",
		{ patch: "{name?:string,metadata?:object}" }
	],
	[
		"document.resize",
		"Resize canvas or nearest-neighbor artwork.",
		{
			width: "Integer 1–2048",
			height: "Integer 1–2048",
			mode: "canvas | scale",
			anchor: "top-left | center (canvas mode)"
		}
	],
	[
		"document.colorMode",
		"Convert pixel storage between working color modes.",
		{ colorMode: "rgba | indexed | grayscale" }
	],
	[
		"layer.add",
		"Insert image, group, reference, or tilemap layer.",
		{
			layer: "{id?,name?,type?,parentId?,visible?,locked?,opacity?,blendMode?}",
			index: "Optional bottom-to-top insertion index."
		}
	],
	[
		"layer.update",
		"Update layer properties.",
		{
			layerId: "Layer id",
			patch: "{name?,parentId?,visible?,locked?,opacity?,blendMode?,reference?,tilesetId?}"
		}
	],
	[
		"layer.reorder",
		"Move a layer within bottom-to-top order.",
		{
			layerId: "Layer id",
			index: "Zero-based destination index."
		}
	],
	[
		"layer.duplicate",
		"Duplicate a layer or group hierarchy with independent image copies.",
		{
			layerId: "Layer id",
			name: "Optional duplicate name",
			linked: "True shares original image objects; false preserves linking only within the copied hierarchy."
		}
	],
	[
		"layer.mergeDown",
		"Bake two normal-blend sibling image layers into the lower layer.",
		{ layerId: "Upper image layer id. Group, reference, tilemap or non-normal blend layers reject the operation." }
	],
	[
		"layer.remove",
		"Remove a layer and all descendants.",
		{ layerId: "Layer id; at least one layer must remain." }
	],
	[
		"frame.add",
		"Insert an empty animation frame.",
		{
			id: "Optional new id",
			afterFrameId: "Optional preceding frame id",
			durationMs: "1–65535; default125",
			clipId: "Optional clip receiving the frame."
		}
	],
	[
		"frame.duplicate",
		"Duplicate a frame range with independent or shared images.",
		{
			...RANGE,
			frameId: "Single frame id",
			afterFrameId: "Optional insertion anchor",
			linked: "Boolean; default false",
			clipId: "Optional clip to append duplicates to."
		}
	],
	[
		"frame.update",
		"Change duration or metadata for a frame range.",
		{
			...RANGE,
			frameId: "Single frame id",
			patch: "{durationMs?:1–65535,name?:string,pivot?:object}"
		}
	],
	[
		"frame.reorder",
		"Move a frame range to an insertion index.",
		{
			...RANGE,
			index: "Index among unselected frames."
		}
	],
	[
		"frame.reverse",
		"Reverse the selected animation frames.",
		RANGE
	],
	[
		"frame.remove",
		"Remove frames and repair clips/tilemaps.",
		RANGE
	],
	[
		"cel.set",
		"Import or replace a cel with decoded pixels.",
		{
			...TARGET,
			width: "Image width",
			height: "Image height",
			pixels: "Flat RGBA|null|palette-index array, width×height",
			x: "Optional integer offset",
			y: "Optional integer offset",
			opacity: "0–1",
			editLinked: "False by default; true replaces the shared image."
		}
	],
	[
		"image.stamp",
		"Paste image pixels into an existing cel.",
		{
			...DRAW,
			width: "Stamp width",
			height: "Stamp height",
			pixels: "Flat decoded RGBA|null|palette-index array.",
			x: "Destination left; default0",
			y: "Destination top; default0",
			transparent: "skip (default) | replace",
			blend: "true (default) composites source-over; false replaces pixels.",
			opacity: "0–1; default1"
		}
	],
	[
		"cel.link",
		"Reference one cel image from multiple frames.",
		{
			...RANGE,
			layerId: "Layer id",
			sourceFrameId: "Frame containing the source cel."
		}
	],
	[
		"cel.unlink",
		"Give selected cels independent images.",
		{
			...RANGE,
			layerId: "Layer id"
		}
	],
	[
		"cel.move",
		"Change cel offsets or opacity across frames.",
		{
			...RANGE,
			layerId: "Layer id",
			x: "Integer -65535…65535",
			y: "Integer -65535…65535",
			opacity: "Optional 0–1"
		}
	],
	[
		"cel.clear",
		"Remove cels from selected frames.",
		{
			...RANGE,
			layerId: "Layer id"
		}
	],
	[
		"draw.stroke",
		"Paint a pressure-aware freehand path with custom brush and symmetry.",
		{
			...STROKE,
			points: "Array of {x,y,pressure?:0–1}."
		}
	],
	[
		"draw.line",
		"Draw a straight pixel line.",
		{
			...STROKE,
			from: "{x,y}",
			to: "{x,y}"
		}
	],
	[
		"draw.rect",
		"Draw a rectangle.",
		{
			...DRAW,
			x: "Integer left",
			y: "Integer top",
			width: "Positive width",
			height: "Positive height",
			filled: "Boolean",
			size: "Outline thickness1–256"
		}
	],
	[
		"draw.ellipse",
		"Draw an ellipse.",
		{
			...DRAW,
			x: "Integer left",
			y: "Integer top",
			width: "Positive width",
			height: "Positive height",
			filled: "Boolean",
			size: "Outline thickness1–256"
		}
	],
	[
		"draw.polygon",
		"Draw a closed polygon or its filled interior.",
		{
			...STROKE,
			points: "2–4096 vertices {x,y}; at least3 for fill.",
			filled: "Boolean"
		}
	],
	[
		"draw.curve",
		"Rasterize quadratic or cubic Bézier curve.",
		{
			...STROKE,
			points: "[start,control,end] or [start,control1,control2,end]."
		}
	],
	[
		"draw.fill",
		"Flood fill matching connected pixels or all matching colors.",
		{
			...DRAW,
			x: "Seed x",
			y: "Seed y",
			tolerance: "Channel tolerance0–255",
			contiguous: "Boolean; default true"
		}
	],
	[
		"draw.gradient",
		"Paint an RGBA gradient or ordered two-color Bayer dither.",
		{
			...DRAW,
			from: "{x,y}",
			to: "{x,y}",
			endColor: "Ending color",
			dither: "Boolean; default false"
		}
	],
	[
		"draw.text",
		"Rasterize text with included 5×7 bitmap font or custom glyphs.",
		{
			...DRAW,
			x: "Text x",
			y: "Text y",
			text: "Up to4096 characters",
			scale: "Integer1–64",
			spacing: "Glyph spacing0–64",
			lineHeight: "Line advance1–128",
			font: "Optional {width,height,glyphs:{character:[0|1]}}."
		}
	],
	[
		"selection.transform",
		"Move, scale, rotate, flip, or copy a masked raster region.",
		{
			...TARGET,
			selection: "Canvas-size array of0/1; required.",
			operation: "move | scale | rotate | flipX | flipY",
			dx: "Translation pixels",
			dy: "Translation pixels",
			scaleX: "Scale .01–64",
			scaleY: "Scale .01–64",
			angle: "Clockwise degrees",
			method: "nearest (default) | pixel-safe (rotation only). Pixel-safe uses two Scale2x passes and4×4 majority downsampling; it is not RotSprite. Temporary image limited to16,777,216 pixels.",
			pivot: "Optional {x,y}; defaults to selection center.",
			copy: "False moves/cuts, true copies."
		}
	],
	[
		"selection.clear",
		"Erase pixels under a mask.",
		{
			...TARGET,
			selection: "Canvas-size array of0/1; required."
		}
	],
	[
		"palette.update",
		"Edit palette entries; indexed pixels retain their indices.",
		{ palette: "1–65536 RGBA hex colors. Cannot remove used indexed entries." }
	],
	[
		"palette.remap",
		"Replace palette and remap pixel colors.",
		{
			palette: "New RGBA palette.",
			mapping: "Optional old-index→new-index array; null clears that entry. Omit to find nearest colors."
		}
	],
	[
		"effect.apply",
		"Apply destructive raster effect to selected unique images.",
		{
			...DRAW,
			...RANGE,
			effect: "replace | outline | brightness | contrast | hue | saturation | convolution | despeckle",
			fromColor: "Replace source color; omit to replace all opaque pixels.",
			toColor: "Replacement color.",
			amount: "Brightness/saturation -1…1; contrast -.99….99; hue degrees-360…360.",
			radius: "Outline radius1–64",
			diagonal: "Boolean, default true.",
			kernel: "Odd square numeric array, up to15×15.",
			divisor: "Optional nonzero convolution divisor.",
			bias: "Optional convolution RGB bias-255…255.",
			affectAlpha: "Convolve alpha as well."
		}
	],
	[
		"animation.tween",
		"Bake or link reusable deterministic 2D position/opacity tween.",
		{
			...RANGE,
			layerId: "Raster layer id",
			sourceFrameId: "Optional source cel frame.",
			from: "{x?,y?,opacity?}",
			to: "{x?,y?,opacity?}",
			easing: "linear | easeIn | easeOut | easeInOut | bounce",
			bake: "Default true creates independent images; false links images.",
			id: "Optional reusable preset key in metadata.motion."
		}
	],
	[
		"animation.particles",
		"Bake deterministic 2D particle simulation into cels.",
		{
			...RANGE,
			layerId: "Image layer id",
			seed: "Unsigned32-bit integer",
			count: "1–4096",
			x: "Emitter x",
			y: "Emitter y",
			speed: "Pixels/second0–4096",
			angle: "Emission direction degrees (default -90)",
			spread: "Cone width0–360 degrees",
			gravity: "Pixels/second²",
			lifetime: "Seconds.01–3600",
			emission: "Emission interval in seconds",
			color: "RGBA or palette index",
			size: "1–64",
			fade: "Boolean; default true",
			clear: "Replace target cels unless false.",
			id: "Optional reusable preset key in metadata.motion."
		}
	],
	[
		"tileset.add",
		"Create an independent tileset from images or tile pixels.",
		{ tileset: "{id?,name?,tileWidth,tileHeight,tiles:[{id?,imageId}|{id?,pixels}]}" }
	],
	[
		"tileset.update",
		"Update independent tileset properties and references.",
		{
			tilesetId: "Tileset id",
			patch: "{name?,tileWidth?,tileHeight?,tiles?,imageId?,baseIndex?}"
		}
	],
	[
		"tileset.remove",
		"Remove a tileset unused by layers.",
		{ tilesetId: "Tileset id" }
	],
	[
		"tilemap.paint",
		"Paint independently referenced tiles into a frame tilemap.",
		{
			...TARGET,
			tilesetId: "Tileset id; defaults to existing map.",
			columns: "Optional tile grid width",
			rows: "Optional tile grid height",
			points: "[{x,y,tileId:string|null,flipX?,flipY?,rotate?:0|90|180|270}]"
		}
	],
	[
		"tilemap.edit",
		"Edit intrinsic tile pixels in manual, automatic reuse, or stack mode.",
		{
			...TARGET,
			x: "Tile column",
			y: "Tile row",
			pixels: "Complete tileWidth×tileHeight decoded color array.",
			mode: "manual edits referenced tile globally; auto reuses identical tile or adds one; stack always creates a new tile. Cell transforms remain unchanged."
		}
	],
	[
		"clip.add",
		"Create an animation tag/clip.",
		{ clip: "{id?,name?,frameIds?,direction?:forward|reverse|pingpong|pingpong_reverse,loop?}" }
	],
	[
		"clip.update",
		"Update an animation tag/clip.",
		{
			clipId: "Clip id",
			patch: "{name?,frameIds?,direction?,loop?}"
		}
	],
	[
		"clip.remove",
		"Remove an animation tag/clip.",
		{ clipId: "Clip id" }
	],
	[
		"slice.add",
		"Create an export slice with optional pivot and nine-patch.",
		{ slice: "{id?,name?,bounds:{x,y,width,height},pivot?,ninePatch?}" }
	],
	[
		"slice.update",
		"Update a slice.",
		{
			sliceId: "Slice id",
			patch: "{name?,bounds?,pivot?,ninePatch?}"
		}
	],
	[
		"slice.remove",
		"Remove a slice.",
		{ sliceId: "Slice id" }
	]
].map(([type, description, parameters]) => Object.freeze({
	type,
	description,
	parameters: Object.freeze(parameters)
})));
//#endregion
//#region node_modules/fflate/esm/index.mjs
var require = createRequire("/");
var _a;
try {
	_a = require("worker_threads"), _a.Worker, _a.isMarkedAsUntransferable;
} catch (e) {}
var u8 = Uint8Array, u16 = Uint16Array, i32 = Int32Array;
var fleb = new u8([
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1,
	1,
	1,
	1,
	2,
	2,
	2,
	2,
	3,
	3,
	3,
	3,
	4,
	4,
	4,
	4,
	5,
	5,
	5,
	5,
	0,
	0,
	0,
	0
]);
var fdeb = new u8([
	0,
	0,
	0,
	0,
	1,
	1,
	2,
	2,
	3,
	3,
	4,
	4,
	5,
	5,
	6,
	6,
	7,
	7,
	8,
	8,
	9,
	9,
	10,
	10,
	11,
	11,
	12,
	12,
	13,
	13,
	0,
	0
]);
var clim = new u8([
	16,
	17,
	18,
	0,
	8,
	7,
	9,
	6,
	10,
	5,
	11,
	4,
	12,
	3,
	13,
	2,
	14,
	1,
	15
]);
var freb = function(eb, start) {
	var b = new u16(31);
	for (var i = 0; i < 31; ++i) b[i] = start += 1 << eb[i - 1];
	var r = new i32(b[30]);
	for (var i = 1; i < 30; ++i) for (var j = b[i]; j < b[i + 1]; ++j) r[j] = j - b[i] << 5 | i;
	return {
		b,
		r
	};
};
var _a = freb(fleb, 2), fl = _a.b, revfl = _a.r;
fl[28] = 258, revfl[258] = 28;
var _b = freb(fdeb, 0), fd = _b.b, revfd = _b.r;
var rev = new u16(32768);
for (var i = 0; i < 32768; ++i) {
	var x = (i & 43690) >> 1 | (i & 21845) << 1;
	x = (x & 52428) >> 2 | (x & 13107) << 2;
	x = (x & 61680) >> 4 | (x & 3855) << 4;
	rev[i] = ((x & 65280) >> 8 | (x & 255) << 8) >> 1;
}
var hMap = (function(cd, mb, r) {
	var s = cd.length;
	var i = 0;
	var l = new u16(mb);
	for (; i < s; ++i) if (cd[i]) ++l[cd[i] - 1];
	var le = new u16(mb);
	for (i = 1; i < mb; ++i) le[i] = le[i - 1] + l[i - 1] << 1;
	var co;
	if (r) {
		co = new u16(1 << mb);
		var rvb = 15 - mb;
		for (i = 0; i < s; ++i) if (cd[i]) {
			var sv = i << 4 | cd[i];
			var r_1 = mb - cd[i];
			var v = le[cd[i] - 1]++ << r_1;
			for (var m = v | (1 << r_1) - 1; v <= m; ++v) co[rev[v] >> rvb] = sv;
		}
	} else {
		co = new u16(s);
		for (i = 0; i < s; ++i) if (cd[i]) co[i] = rev[le[cd[i] - 1]++] >> 15 - cd[i];
	}
	return co;
});
var flt = new u8(288);
for (var i = 0; i < 144; ++i) flt[i] = 8;
for (var i = 144; i < 256; ++i) flt[i] = 9;
for (var i = 256; i < 280; ++i) flt[i] = 7;
for (var i = 280; i < 288; ++i) flt[i] = 8;
var fdt = new u8(32);
for (var i = 0; i < 32; ++i) fdt[i] = 5;
var flm = /* @__PURE__ */ hMap(flt, 9, 0), flrm = /* @__PURE__ */ hMap(flt, 9, 1);
var fdm = /* @__PURE__ */ hMap(fdt, 5, 0), fdrm = /* @__PURE__ */ hMap(fdt, 5, 1);
var max = function(a) {
	var m = a[0];
	for (var i = 1; i < a.length; ++i) if (a[i] > m) m = a[i];
	return m;
};
var bits = function(d, p, m) {
	var o = p / 8 | 0;
	return (d[o] | d[o + 1] << 8) >> (p & 7) & m;
};
var bits16 = function(d, p) {
	var o = p / 8 | 0;
	return (d[o] | d[o + 1] << 8 | d[o + 2] << 16) >> (p & 7);
};
var shft = function(p) {
	return (p + 7) / 8 | 0;
};
var slc = function(v, s, e) {
	if (s == null || s < 0) s = 0;
	if (e == null || e > v.length) e = v.length;
	return new u8(v.subarray(s, e));
};
var ec = [
	"unexpected EOF",
	"invalid block type",
	"invalid length/literal",
	"invalid distance",
	"stream finished",
	"no stream handler",
	,
	"no callback",
	"invalid UTF-8 data",
	"extra field too long",
	"date not in range 1980-2099",
	"filename too long",
	"stream finishing",
	"invalid zip data"
];
var err = function(ind, msg, nt) {
	var e = new Error(msg || ec[ind]);
	e.code = ind;
	if (Error.captureStackTrace) Error.captureStackTrace(e, err);
	if (!nt) throw e;
	return e;
};
var inflt = function(dat, st, buf, dict) {
	var sl = dat.length, dl = dict ? dict.length : 0;
	if (!sl || st.f && !st.l) return buf || new u8(0);
	var noBuf = !buf;
	var resize = noBuf || st.i != 2;
	var noSt = st.i;
	if (noBuf) buf = new u8(sl * 3);
	var cbuf = function(l) {
		var bl = buf.length;
		if (l > bl) {
			var nbuf = new u8(Math.max(bl * 2, l));
			nbuf.set(buf);
			buf = nbuf;
		}
	};
	var final = st.f || 0, pos = st.p || 0, bt = st.b || 0, lm = st.l, dm = st.d, lbt = st.m, dbt = st.n;
	var tbts = sl * 8;
	do {
		if (!lm) {
			final = bits(dat, pos, 1);
			var type = bits(dat, pos + 1, 3);
			pos += 3;
			if (!type) {
				var s = shft(pos) + 4, l = dat[s - 4] | dat[s - 3] << 8, t = s + l;
				if (t > sl) {
					if (noSt) err(0);
					break;
				}
				if (resize) cbuf(bt + l);
				buf.set(dat.subarray(s, t), bt);
				st.b = bt += l, st.p = pos = t * 8, st.f = final;
				continue;
			} else if (type == 1) lm = flrm, dm = fdrm, lbt = 9, dbt = 5;
			else if (type == 2) {
				var hLit = bits(dat, pos, 31) + 257, hcLen = bits(dat, pos + 10, 15) + 4;
				var tl = hLit + bits(dat, pos + 5, 31) + 1;
				pos += 14;
				var ldt = new u8(tl);
				var clt = new u8(19);
				for (var i = 0; i < hcLen; ++i) clt[clim[i]] = bits(dat, pos + i * 3, 7);
				pos += hcLen * 3;
				var clb = max(clt), clbmsk = (1 << clb) - 1;
				var clm = hMap(clt, clb, 1);
				for (var i = 0; i < tl;) {
					var r = clm[bits(dat, pos, clbmsk)];
					pos += r & 15;
					var s = r >> 4;
					if (s < 16) ldt[i++] = s;
					else {
						var c = 0, n = 0;
						if (s == 16) n = 3 + bits(dat, pos, 3), pos += 2, c = ldt[i - 1];
						else if (s == 17) n = 3 + bits(dat, pos, 7), pos += 3;
						else if (s == 18) n = 11 + bits(dat, pos, 127), pos += 7;
						while (n--) ldt[i++] = c;
					}
				}
				var lt = ldt.subarray(0, hLit), dt = ldt.subarray(hLit);
				lbt = max(lt);
				dbt = max(dt);
				lm = hMap(lt, lbt, 1);
				dm = hMap(dt, dbt, 1);
			} else err(1);
			if (pos > tbts) {
				if (noSt) err(0);
				break;
			}
		}
		if (resize) cbuf(bt + 131072);
		var lms = (1 << lbt) - 1, dms = (1 << dbt) - 1;
		var lpos = pos;
		for (;; lpos = pos) {
			var c = lm[bits16(dat, pos) & lms], sym = c >> 4;
			pos += c & 15;
			if (pos > tbts) {
				if (noSt) err(0);
				break;
			}
			if (!c) err(2);
			if (sym < 256) buf[bt++] = sym;
			else if (sym == 256) {
				lpos = pos, lm = null;
				break;
			} else {
				var add = sym - 254;
				if (sym > 264) {
					var i = sym - 257, b = fleb[i];
					add = bits(dat, pos, (1 << b) - 1) + fl[i];
					pos += b;
				}
				var d = dm[bits16(dat, pos) & dms], dsym = d >> 4;
				if (!d) err(3);
				pos += d & 15;
				var dt = fd[dsym];
				if (dsym > 3) {
					var b = fdeb[dsym];
					dt += bits16(dat, pos) & (1 << b) - 1, pos += b;
				}
				if (pos > tbts) {
					if (noSt) err(0);
					break;
				}
				if (resize) cbuf(bt + 131072);
				var end = bt + add;
				if (bt < dt) {
					var shift = dl - dt, dend = Math.min(dt, end);
					if (shift + bt < 0) err(3);
					for (; bt < dend; ++bt) buf[bt] = dict[shift + bt];
				}
				for (; bt < end; ++bt) buf[bt] = buf[bt - dt];
			}
		}
		st.l = lm, st.p = lpos, st.b = bt, st.f = final;
		if (lm) final = 1, st.m = lbt, st.d = dm, st.n = dbt;
	} while (!final);
	return bt != buf.length && noBuf ? slc(buf, 0, bt) : buf.subarray(0, bt);
};
var wbits = function(d, p, v) {
	v <<= p & 7;
	var o = p / 8 | 0;
	d[o] |= v;
	d[o + 1] |= v >> 8;
};
var wbits16 = function(d, p, v) {
	v <<= p & 7;
	var o = p / 8 | 0;
	d[o] |= v;
	d[o + 1] |= v >> 8;
	d[o + 2] |= v >> 16;
};
var hTree = function(d, mb) {
	var t = [];
	for (var i = 0; i < d.length; ++i) if (d[i]) t.push({
		s: i,
		f: d[i]
	});
	var s = t.length;
	var t2 = t.slice();
	if (!s) return {
		t: et,
		l: 0
	};
	if (s == 1) {
		var v = new u8(t[0].s + 1);
		v[t[0].s] = 1;
		return {
			t: v,
			l: 1
		};
	}
	t.sort(function(a, b) {
		return a.f - b.f;
	});
	t.push({
		s: -1,
		f: 25001
	});
	var l = t[0], r = t[1], i0 = 0, i1 = 1, i2 = 2;
	t[0] = {
		s: -1,
		f: l.f + r.f,
		l,
		r
	};
	while (i1 != s - 1) {
		l = t[t[i0].f < t[i2].f ? i0++ : i2++];
		r = t[i0 != i1 && t[i0].f < t[i2].f ? i0++ : i2++];
		t[i1++] = {
			s: -1,
			f: l.f + r.f,
			l,
			r
		};
	}
	var maxSym = t2[0].s;
	for (var i = 1; i < s; ++i) if (t2[i].s > maxSym) maxSym = t2[i].s;
	var tr = new u16(maxSym + 1);
	var mbt = ln(t[i1 - 1], tr, 0);
	if (mbt > mb) {
		var i = 0, dt = 0;
		var lft = mbt - mb, cst = 1 << lft;
		t2.sort(function(a, b) {
			return tr[b.s] - tr[a.s] || a.f - b.f;
		});
		for (; i < s; ++i) {
			var i2_1 = t2[i].s;
			if (tr[i2_1] > mb) {
				dt += cst - (1 << mbt - tr[i2_1]);
				tr[i2_1] = mb;
			} else break;
		}
		dt >>= lft;
		while (dt > 0) {
			var i2_2 = t2[i].s;
			if (tr[i2_2] < mb) dt -= 1 << mb - tr[i2_2]++ - 1;
			else ++i;
		}
		for (; i >= 0 && dt; --i) {
			var i2_3 = t2[i].s;
			if (tr[i2_3] == mb) {
				--tr[i2_3];
				++dt;
			}
		}
		mbt = mb;
	}
	return {
		t: new u8(tr),
		l: mbt
	};
};
var ln = function(n, l, d) {
	return n.s == -1 ? Math.max(ln(n.l, l, d + 1), ln(n.r, l, d + 1)) : l[n.s] = d;
};
var lc = function(c) {
	var s = c.length;
	while (s && !c[--s]);
	var cl = new u16(++s);
	var cli = 0, cln = c[0], cls = 1;
	var w = function(v) {
		cl[cli++] = v;
	};
	for (var i = 1; i <= s; ++i) if (c[i] == cln && i != s) ++cls;
	else {
		if (!cln && cls > 2) {
			for (; cls > 138; cls -= 138) w(32754);
			if (cls > 2) {
				w(cls > 10 ? cls - 11 << 5 | 28690 : cls - 3 << 5 | 12305);
				cls = 0;
			}
		} else if (cls > 3) {
			w(cln), --cls;
			for (; cls > 6; cls -= 6) w(8304);
			if (cls > 2) w(cls - 3 << 5 | 8208), cls = 0;
		}
		while (cls--) w(cln);
		cls = 1;
		cln = c[i];
	}
	return {
		c: cl.subarray(0, cli),
		n: s
	};
};
var clen = function(cf, cl) {
	var l = 0;
	for (var i = 0; i < cl.length; ++i) l += cf[i] * cl[i];
	return l;
};
var wfblk = function(out, pos, dat) {
	var s = dat.length;
	var o = shft(pos + 2);
	out[o] = s & 255;
	out[o + 1] = s >> 8;
	out[o + 2] = out[o] ^ 255;
	out[o + 3] = out[o + 1] ^ 255;
	for (var i = 0; i < s; ++i) out[o + i + 4] = dat[i];
	return (o + 4 + s) * 8;
};
var wblk = function(dat, out, final, syms, lf, df, eb, li, bs, bl, p) {
	wbits(out, p++, final);
	++lf[256];
	var _a = hTree(lf, 15), dlt = _a.t, mlb = _a.l;
	var _b = hTree(df, 15), ddt = _b.t, mdb = _b.l;
	var _c = lc(dlt), lclt = _c.c, nlc = _c.n;
	var _d = lc(ddt), lcdt = _d.c, ndc = _d.n;
	var lcfreq = new u16(19);
	for (var i = 0; i < lclt.length; ++i) ++lcfreq[lclt[i] & 31];
	for (var i = 0; i < lcdt.length; ++i) ++lcfreq[lcdt[i] & 31];
	var _e = hTree(lcfreq, 7), lct = _e.t, mlcb = _e.l;
	var nlcc = 19;
	for (; nlcc > 4 && !lct[clim[nlcc - 1]]; --nlcc);
	var flen = bl + 5 << 3;
	var ftlen = clen(lf, flt) + clen(df, fdt) + eb;
	var dtlen = clen(lf, dlt) + clen(df, ddt) + eb + 14 + 3 * nlcc + clen(lcfreq, lct) + 2 * lcfreq[16] + 3 * lcfreq[17] + 7 * lcfreq[18];
	if (bs >= 0 && flen <= ftlen && flen <= dtlen) return wfblk(out, p, dat.subarray(bs, bs + bl));
	var lm, ll, dm, dl;
	wbits(out, p, 1 + (dtlen < ftlen)), p += 2;
	if (dtlen < ftlen) {
		lm = hMap(dlt, mlb, 0), ll = dlt, dm = hMap(ddt, mdb, 0), dl = ddt;
		var llm = hMap(lct, mlcb, 0);
		wbits(out, p, nlc - 257);
		wbits(out, p + 5, ndc - 1);
		wbits(out, p + 10, nlcc - 4);
		p += 14;
		for (var i = 0; i < nlcc; ++i) wbits(out, p + 3 * i, lct[clim[i]]);
		p += 3 * nlcc;
		var lcts = [lclt, lcdt];
		for (var it = 0; it < 2; ++it) {
			var clct = lcts[it];
			for (var i = 0; i < clct.length; ++i) {
				var len = clct[i] & 31;
				wbits(out, p, llm[len]), p += lct[len];
				if (len > 15) wbits(out, p, clct[i] >> 5 & 127), p += clct[i] >> 12;
			}
		}
	} else lm = flm, ll = flt, dm = fdm, dl = fdt;
	for (var i = 0; i < li; ++i) {
		var sym = syms[i];
		if (sym > 255) {
			var len = sym >> 18 & 31;
			wbits16(out, p, lm[len + 257]), p += ll[len + 257];
			if (len > 7) wbits(out, p, sym >> 23 & 31), p += fleb[len];
			var dst = sym & 31;
			wbits16(out, p, dm[dst]), p += dl[dst];
			if (dst > 3) wbits16(out, p, sym >> 5 & 8191), p += fdeb[dst];
		} else wbits16(out, p, lm[sym]), p += ll[sym];
	}
	wbits16(out, p, lm[256]);
	return p + ll[256];
};
var deo = /* @__PURE__ */ new i32([
	65540,
	131080,
	131088,
	131104,
	262176,
	1048704,
	1048832,
	2114560,
	2117632
]);
var et = /* @__PURE__ */ new u8(0);
var dflt = function(dat, lvl, plvl, pre, post, st) {
	var s = st.z || dat.length;
	var o = new u8(pre + s + 5 * (1 + Math.ceil(s / 7e3)) + post);
	var w = o.subarray(pre, o.length - post);
	var lst = st.l;
	var pos = (st.r || 0) & 7;
	if (lvl) {
		if (pos) w[0] = st.r >> 3;
		var opt = deo[lvl - 1];
		var n = opt >> 13, c = opt & 8191;
		var msk_1 = (1 << plvl) - 1;
		var prev = st.p || new u16(32768), head = st.h || new u16(msk_1 + 1);
		var bs1_1 = Math.ceil(plvl / 3), bs2_1 = 2 * bs1_1;
		var hsh = function(i) {
			return (dat[i] ^ dat[i + 1] << bs1_1 ^ dat[i + 2] << bs2_1) & msk_1;
		};
		var syms = new i32(25e3);
		var lf = new u16(288), df = new u16(32);
		var lc_1 = 0, eb = 0, i = st.i || 0, li = 0, wi = st.w || 0, bs = 0;
		for (; i + 2 < s; ++i) {
			var hv = hsh(i);
			var imod = i & 32767, pimod = head[hv];
			prev[imod] = pimod;
			head[hv] = imod;
			if (wi <= i) {
				var rem = s - i;
				if ((lc_1 > 7e3 || li > 24576) && (rem > 423 || !lst)) {
					pos = wblk(dat, w, 0, syms, lf, df, eb, li, bs, i - bs, pos);
					li = lc_1 = eb = 0, bs = i;
					for (var j = 0; j < 286; ++j) lf[j] = 0;
					for (var j = 0; j < 30; ++j) df[j] = 0;
				}
				var l = 2, d = 0, ch_1 = c, dif = imod - pimod & 32767;
				if (rem > 2 && hv == hsh(i - dif)) {
					var maxn = Math.min(n, rem) - 1;
					var maxd = Math.min(32767, i);
					var ml = Math.min(258, rem);
					while (dif <= maxd && --ch_1 && imod != pimod) {
						if (dat[i + l] == dat[i + l - dif]) {
							var nl = 0;
							for (; nl < ml && dat[i + nl] == dat[i + nl - dif]; ++nl);
							if (nl > l) {
								l = nl, d = dif;
								if (nl > maxn) break;
								var mmd = Math.min(dif, nl - 2);
								var md = 0;
								for (var j = 0; j < mmd; ++j) {
									var ti = i - dif + j & 32767;
									var cd = ti - prev[ti] & 32767;
									if (cd > md) md = cd, pimod = ti;
								}
							}
						}
						imod = pimod, pimod = prev[imod];
						dif += imod - pimod & 32767;
					}
				}
				if (d) {
					syms[li++] = 268435456 | revfl[l] << 18 | revfd[d];
					var lin = revfl[l] & 31, din = revfd[d] & 31;
					eb += fleb[lin] + fdeb[din];
					++lf[257 + lin];
					++df[din];
					wi = i + l;
					++lc_1;
				} else {
					syms[li++] = dat[i];
					++lf[dat[i]];
				}
			}
		}
		for (i = Math.max(i, wi); i < s; ++i) {
			syms[li++] = dat[i];
			++lf[dat[i]];
		}
		pos = wblk(dat, w, lst, syms, lf, df, eb, li, bs, i - bs, pos);
		if (!lst) {
			st.r = pos & 7 | w[pos / 8 | 0] << 3;
			pos -= 7;
			st.h = head, st.p = prev, st.i = i, st.w = wi;
		}
	} else {
		for (var i = st.w || 0; i < s + lst; i += 65535) {
			var e = i + 65535;
			if (e >= s) {
				w[pos / 8 | 0] = lst;
				e = s;
			}
			pos = wfblk(w, pos + 1, dat.subarray(i, e));
		}
		st.i = s;
	}
	return slc(o, 0, pre + shft(pos) + post);
};
var crct = /* @__PURE__ */ (function() {
	var t = new Int32Array(256);
	for (var i = 0; i < 256; ++i) {
		var c = i, k = 9;
		while (--k) c = (c & 1 && -306674912) ^ c >>> 1;
		t[i] = c;
	}
	return t;
})();
var crc = function() {
	var c = -1;
	return {
		p: function(d) {
			var cr = c;
			for (var i = 0; i < d.length; ++i) cr = crct[cr & 255 ^ d[i]] ^ cr >>> 8;
			c = cr;
		},
		d: function() {
			return ~c;
		}
	};
};
var adler = function() {
	var a = 1, b = 0;
	return {
		p: function(d) {
			var n = a, m = b;
			var l = d.length | 0;
			for (var i = 0; i != l;) {
				var e = Math.min(i + 2655, l);
				for (; i < e; ++i) m += n += d[i];
				n = (n & 65535) + 15 * (n >> 16), m = (m & 65535) + 15 * (m >> 16);
			}
			a = n, b = m;
		},
		d: function() {
			a %= 65521, b %= 65521;
			return (a & 255) << 24 | (a & 65280) << 8 | (b & 255) << 8 | b >> 8;
		}
	};
};
var dopt = function(dat, opt, pre, post, st) {
	if (!st) {
		st = { l: 1 };
		if (opt.dictionary) {
			var dict = opt.dictionary.subarray(-32768);
			var newDat = new u8(dict.length + dat.length);
			newDat.set(dict);
			newDat.set(dat, dict.length);
			dat = newDat;
			st.w = dict.length;
		}
	}
	return dflt(dat, opt.level == null ? 6 : opt.level, opt.mem == null ? st.l ? Math.ceil(Math.max(8, Math.min(13, Math.log(dat.length))) * 1.5) : 20 : 12 + opt.mem, pre, post, st);
};
var mrg = function(a, b) {
	var o = {};
	for (var k in a) o[k] = a[k];
	for (var k in b) o[k] = b[k];
	return o;
};
var wbytes = function(d, b, v) {
	for (; v; ++b) d[b] = v, v >>>= 8;
};
var zlh = function(c, o) {
	var lv = o.level, fl = lv == 0 ? 0 : lv < 6 ? 1 : lv == 9 ? 3 : 2;
	c[0] = 120, c[1] = fl << 6 | (o.dictionary && 32);
	c[1] |= 31 - (c[0] << 8 | c[1]) % 31;
	if (o.dictionary) {
		var h = adler();
		h.p(o.dictionary);
		wbytes(c, 2, h.d());
	}
};
var zls = function(d, dict) {
	if ((d[0] & 15) != 8 || d[0] >> 4 > 7 || (d[0] << 8 | d[1]) % 31) err(6, "invalid zlib data");
	if ((d[1] >> 5 & 1) == +!dict) err(6, "invalid zlib data: " + (d[1] & 32 ? "need" : "unexpected") + " dictionary");
	return (d[1] >> 3 & 4) + 2;
};
/**
* Compresses data with DEFLATE without any wrapper
* @param data The data to compress
* @param opts The compression options
* @returns The deflated version of the data
*/
function deflateSync(data, opts) {
	return dopt(data, opts || {}, 0, 0);
}
/**
* Compress data with Zlib
* @param data The data to compress
* @param opts The compression options
* @returns The zlib-compressed version of the data
*/
function zlibSync(data, opts) {
	if (!opts) opts = {};
	var a = adler();
	a.p(data);
	var d = dopt(data, opts, opts.dictionary ? 6 : 2, 4);
	return zlh(d, opts), wbytes(d, d.length - 4, a.d()), d;
}
function unzlibSync(data, opts) {
	return inflt(data.subarray(zls(data, opts && opts.dictionary), -4), { i: 2 }, opts && opts.out, opts && opts.dictionary);
}
var fltn = function(d, p, t, o) {
	for (var k in d) {
		var val = d[k], n = p + k, op = o;
		if (Array.isArray(val)) op = mrg(o, val[1]), val = val[0];
		if (ArrayBuffer.isView(val)) t[n] = [val, op];
		else {
			t[n += "/"] = [new u8(0), op];
			fltn(val, n, t, o);
		}
	}
};
var te = typeof TextEncoder != "undefined" && /* @__PURE__ */ new TextEncoder();
var td = typeof TextDecoder != "undefined" && /* @__PURE__ */ new TextDecoder();
try {
	td.decode(et, { stream: true });
} catch (e) {}
/**
* Converts a string into a Uint8Array for use with compression/decompression methods
* @param str The string to encode
* @param latin1 Whether or not to interpret the data as Latin-1. This should
*               not need to be true unless decoding a binary string.
* @returns The string encoded in UTF-8/Latin-1 binary
*/
function strToU8(str, latin1) {
	if (latin1) {
		var ar_1 = new u8(str.length);
		for (var i = 0; i < str.length; ++i) ar_1[i] = str.charCodeAt(i);
		return ar_1;
	}
	if (te) return te.encode(str);
	var l = str.length;
	var ar = new u8(str.length + (str.length >> 1));
	var ai = 0;
	var w = function(v) {
		ar[ai++] = v;
	};
	for (var i = 0; i < l; ++i) {
		if (ai + 5 > ar.length) {
			var n = new u8(ai + 8 + (l - i << 1));
			n.set(ar);
			ar = n;
		}
		var c = str.charCodeAt(i);
		if (c < 128 || latin1) w(c);
		else if (c < 2048) w(192 | c >> 6), w(128 | c & 63);
		else if (c > 55295 && c < 57344) c = 65536 + (c & 1047552) | str.charCodeAt(++i) & 1023, w(240 | c >> 18), w(128 | c >> 12 & 63), w(128 | c >> 6 & 63), w(128 | c & 63);
		else w(224 | c >> 12), w(128 | c >> 6 & 63), w(128 | c & 63);
	}
	return slc(ar, 0, ai);
}
var exfl = function(ex) {
	var le = 0;
	if (ex) for (var k in ex) {
		var l = ex[k].length;
		if (l > 65535) err(9);
		le += l + 4;
	}
	return le;
};
var wzh = function(d, b, f, fn, u, c, ce, co) {
	var fl = fn.length, ex = f.extra, col = co && co.length;
	var exl = exfl(ex);
	wbytes(d, b, ce != null ? 33639248 : 67324752), b += 4;
	if (ce != null) d[b++] = 20, d[b++] = f.os;
	d[b] = 20, b += 2;
	d[b++] = f.flag << 1 | (c < 0 && 8), d[b++] = u && 8;
	d[b++] = f.compression & 255, d[b++] = f.compression >> 8;
	var dt = new Date(f.mtime == null ? Date.now() : f.mtime), y = dt.getFullYear() - 1980;
	if (y < 0 || y > 119) err(10);
	wbytes(d, b, y << 25 | dt.getMonth() + 1 << 21 | dt.getDate() << 16 | dt.getHours() << 11 | dt.getMinutes() << 5 | dt.getSeconds() >> 1), b += 4;
	if (c != -1) {
		wbytes(d, b, f.crc);
		wbytes(d, b + 4, c < 0 ? -c - 2 : c);
		wbytes(d, b + 8, f.size);
	}
	wbytes(d, b + 12, fl);
	wbytes(d, b + 14, exl), b += 16;
	if (ce != null) {
		wbytes(d, b, col);
		wbytes(d, b + 6, f.attrs);
		wbytes(d, b + 10, ce), b += 14;
	}
	d.set(fn, b);
	b += fl;
	if (exl) for (var k in ex) {
		var exf = ex[k], l = exf.length;
		wbytes(d, b, +k);
		wbytes(d, b + 2, l);
		d.set(exf, b + 4), b += 4 + l;
	}
	if (col) d.set(co, b), b += col;
	return b;
};
var wzf = function(o, b, c, d, e) {
	wbytes(o, b, 101010256);
	wbytes(o, b + 8, c);
	wbytes(o, b + 10, c);
	wbytes(o, b + 12, d);
	wbytes(o, b + 16, e);
};
/**
* Synchronously creates a ZIP file. Prefer using `zip` for better performance
* with more than one file.
* @param data The directory structure for the ZIP archive
* @param opts The main options, merged with per-file options
* @returns The generated ZIP archive
*/
function zipSync(data, opts) {
	if (!opts) opts = {};
	var r = {};
	var files = [];
	fltn(data, "", r, opts);
	var o = 0;
	var tot = 0;
	for (var fn in r) {
		var _a = r[fn], file = _a[0], p = _a[1];
		var compression = p.level == 0 ? 0 : 8;
		var f = strToU8(fn), s = f.length;
		var com = p.comment, m = com && strToU8(com), ms = m && m.length;
		var exl = exfl(p.extra);
		if (s > 65535) err(11);
		var d = compression ? deflateSync(file, p) : file, l = d.length;
		var c = crc();
		c.p(file);
		files.push(mrg(p, {
			size: file.length,
			crc: c.d(),
			c: d,
			f,
			m,
			u: s != fn.length || m && com.length != ms,
			o,
			compression
		}));
		o += 30 + s + exl + l;
		tot += 76 + 2 * (s + exl) + (ms || 0) + l;
	}
	var out = new u8(tot + 22), oe = o, cdl = tot - o;
	for (var i = 0; i < files.length; ++i) {
		var f = files[i];
		wzh(out, f.o, f, f.f, f.u, f.c.length);
		var badd = 30 + f.f.length + exfl(f.extra);
		out.set(f.c, f.o + badd);
		wzh(out, o, f, f.f, f.u, f.c.length, f.o, f.m), o += 16 + badd + (f.m ? f.m.length : 0);
	}
	wzf(out, o, files.length, cdl, oe);
	return out;
}
const { GifReader, GifWriter } = (/* @__PURE__ */ __toESM((/* @__PURE__ */ __commonJSMin(((exports) => {
	function GifWriter(buf, width, height, gopts) {
		var p = 0;
		var gopts = gopts === void 0 ? {} : gopts;
		var loop_count = gopts.loop === void 0 ? null : gopts.loop;
		var global_palette = gopts.palette === void 0 ? null : gopts.palette;
		if (width <= 0 || height <= 0 || width > 65535 || height > 65535) throw new Error("Width/Height invalid.");
		function check_palette_and_num_colors(palette) {
			var num_colors = palette.length;
			if (num_colors < 2 || num_colors > 256 || num_colors & num_colors - 1) throw new Error("Invalid code/color length, must be power of 2 and 2 .. 256.");
			return num_colors;
		}
		buf[p++] = 71;
		buf[p++] = 73;
		buf[p++] = 70;
		buf[p++] = 56;
		buf[p++] = 57;
		buf[p++] = 97;
		var gp_num_colors_pow2 = 0;
		var background = 0;
		if (global_palette !== null) {
			var gp_num_colors = check_palette_and_num_colors(global_palette);
			while (gp_num_colors >>= 1) ++gp_num_colors_pow2;
			gp_num_colors = 1 << gp_num_colors_pow2;
			--gp_num_colors_pow2;
			if (gopts.background !== void 0) {
				background = gopts.background;
				if (background >= gp_num_colors) throw new Error("Background index out of range.");
				if (background === 0) throw new Error("Background index explicitly passed as 0.");
			}
		}
		buf[p++] = width & 255;
		buf[p++] = width >> 8 & 255;
		buf[p++] = height & 255;
		buf[p++] = height >> 8 & 255;
		buf[p++] = (global_palette !== null ? 128 : 0) | gp_num_colors_pow2;
		buf[p++] = background;
		buf[p++] = 0;
		if (global_palette !== null) for (var i = 0, il = global_palette.length; i < il; ++i) {
			var rgb = global_palette[i];
			buf[p++] = rgb >> 16 & 255;
			buf[p++] = rgb >> 8 & 255;
			buf[p++] = rgb & 255;
		}
		if (loop_count !== null) {
			if (loop_count < 0 || loop_count > 65535) throw new Error("Loop count invalid.");
			buf[p++] = 33;
			buf[p++] = 255;
			buf[p++] = 11;
			buf[p++] = 78;
			buf[p++] = 69;
			buf[p++] = 84;
			buf[p++] = 83;
			buf[p++] = 67;
			buf[p++] = 65;
			buf[p++] = 80;
			buf[p++] = 69;
			buf[p++] = 50;
			buf[p++] = 46;
			buf[p++] = 48;
			buf[p++] = 3;
			buf[p++] = 1;
			buf[p++] = loop_count & 255;
			buf[p++] = loop_count >> 8 & 255;
			buf[p++] = 0;
		}
		var ended = false;
		this.addFrame = function(x, y, w, h, indexed_pixels, opts) {
			if (ended === true) {
				--p;
				ended = false;
			}
			opts = opts === void 0 ? {} : opts;
			if (x < 0 || y < 0 || x > 65535 || y > 65535) throw new Error("x/y invalid.");
			if (w <= 0 || h <= 0 || w > 65535 || h > 65535) throw new Error("Width/Height invalid.");
			if (indexed_pixels.length < w * h) throw new Error("Not enough pixels for the frame size.");
			var using_local_palette = true;
			var palette = opts.palette;
			if (palette === void 0 || palette === null) {
				using_local_palette = false;
				palette = global_palette;
			}
			if (palette === void 0 || palette === null) throw new Error("Must supply either a local or global palette.");
			var num_colors = check_palette_and_num_colors(palette);
			var min_code_size = 0;
			while (num_colors >>= 1) ++min_code_size;
			num_colors = 1 << min_code_size;
			var delay = opts.delay === void 0 ? 0 : opts.delay;
			var disposal = opts.disposal === void 0 ? 0 : opts.disposal;
			if (disposal < 0 || disposal > 3) throw new Error("Disposal out of range.");
			var use_transparency = false;
			var transparent_index = 0;
			if (opts.transparent !== void 0 && opts.transparent !== null) {
				use_transparency = true;
				transparent_index = opts.transparent;
				if (transparent_index < 0 || transparent_index >= num_colors) throw new Error("Transparent color index.");
			}
			if (disposal !== 0 || use_transparency || delay !== 0) {
				buf[p++] = 33;
				buf[p++] = 249;
				buf[p++] = 4;
				buf[p++] = disposal << 2 | (use_transparency === true ? 1 : 0);
				buf[p++] = delay & 255;
				buf[p++] = delay >> 8 & 255;
				buf[p++] = transparent_index;
				buf[p++] = 0;
			}
			buf[p++] = 44;
			buf[p++] = x & 255;
			buf[p++] = x >> 8 & 255;
			buf[p++] = y & 255;
			buf[p++] = y >> 8 & 255;
			buf[p++] = w & 255;
			buf[p++] = w >> 8 & 255;
			buf[p++] = h & 255;
			buf[p++] = h >> 8 & 255;
			buf[p++] = using_local_palette === true ? 128 | min_code_size - 1 : 0;
			if (using_local_palette === true) for (var i = 0, il = palette.length; i < il; ++i) {
				var rgb = palette[i];
				buf[p++] = rgb >> 16 & 255;
				buf[p++] = rgb >> 8 & 255;
				buf[p++] = rgb & 255;
			}
			p = GifWriterOutputLZWCodeStream(buf, p, min_code_size < 2 ? 2 : min_code_size, indexed_pixels);
			return p;
		};
		this.end = function() {
			if (ended === false) {
				buf[p++] = 59;
				ended = true;
			}
			return p;
		};
		this.getOutputBuffer = function() {
			return buf;
		};
		this.setOutputBuffer = function(v) {
			buf = v;
		};
		this.getOutputBufferPosition = function() {
			return p;
		};
		this.setOutputBufferPosition = function(v) {
			p = v;
		};
	}
	function GifWriterOutputLZWCodeStream(buf, p, min_code_size, index_stream) {
		buf[p++] = min_code_size;
		var cur_subblock = p++;
		var clear_code = 1 << min_code_size;
		var code_mask = clear_code - 1;
		var eoi_code = clear_code + 1;
		var next_code = eoi_code + 1;
		var cur_code_size = min_code_size + 1;
		var cur_shift = 0;
		var cur = 0;
		function emit_bytes_to_buffer(bit_block_size) {
			while (cur_shift >= bit_block_size) {
				buf[p++] = cur & 255;
				cur >>= 8;
				cur_shift -= 8;
				if (p === cur_subblock + 256) {
					buf[cur_subblock] = 255;
					cur_subblock = p++;
				}
			}
		}
		function emit_code(c) {
			cur |= c << cur_shift;
			cur_shift += cur_code_size;
			emit_bytes_to_buffer(8);
		}
		var ib_code = index_stream[0] & code_mask;
		var code_table = {};
		emit_code(clear_code);
		for (var i = 1, il = index_stream.length; i < il; ++i) {
			var k = index_stream[i] & code_mask;
			var cur_key = ib_code << 8 | k;
			var cur_code = code_table[cur_key];
			if (cur_code === void 0) {
				cur |= ib_code << cur_shift;
				cur_shift += cur_code_size;
				while (cur_shift >= 8) {
					buf[p++] = cur & 255;
					cur >>= 8;
					cur_shift -= 8;
					if (p === cur_subblock + 256) {
						buf[cur_subblock] = 255;
						cur_subblock = p++;
					}
				}
				if (next_code === 4096) {
					emit_code(clear_code);
					next_code = eoi_code + 1;
					cur_code_size = min_code_size + 1;
					code_table = {};
				} else {
					if (next_code >= 1 << cur_code_size) ++cur_code_size;
					code_table[cur_key] = next_code++;
				}
				ib_code = k;
			} else ib_code = cur_code;
		}
		emit_code(ib_code);
		emit_code(eoi_code);
		emit_bytes_to_buffer(1);
		if (cur_subblock + 1 === p) buf[cur_subblock] = 0;
		else {
			buf[cur_subblock] = p - cur_subblock - 1;
			buf[p++] = 0;
		}
		return p;
	}
	function GifReader(buf) {
		var p = 0;
		if (buf[p++] !== 71 || buf[p++] !== 73 || buf[p++] !== 70 || buf[p++] !== 56 || (buf[p++] + 1 & 253) !== 56 || buf[p++] !== 97) throw new Error("Invalid GIF 87a/89a header.");
		var width = buf[p++] | buf[p++] << 8;
		var height = buf[p++] | buf[p++] << 8;
		var pf0 = buf[p++];
		var global_palette_flag = pf0 >> 7;
		var num_global_colors = 1 << (pf0 & 7) + 1;
		buf[p++];
		buf[p++];
		var global_palette_offset = null;
		var global_palette_size = null;
		if (global_palette_flag) {
			global_palette_offset = p;
			global_palette_size = num_global_colors;
			p += num_global_colors * 3;
		}
		var no_eof = true;
		var frames = [];
		var delay = 0;
		var transparent_index = null;
		var disposal = 0;
		var loop_count = null;
		this.width = width;
		this.height = height;
		while (no_eof && p < buf.length) switch (buf[p++]) {
			case 33:
				switch (buf[p++]) {
					case 255:
						if (buf[p] !== 11 || buf[p + 1] == 78 && buf[p + 2] == 69 && buf[p + 3] == 84 && buf[p + 4] == 83 && buf[p + 5] == 67 && buf[p + 6] == 65 && buf[p + 7] == 80 && buf[p + 8] == 69 && buf[p + 9] == 50 && buf[p + 10] == 46 && buf[p + 11] == 48 && buf[p + 12] == 3 && buf[p + 13] == 1 && buf[p + 16] == 0) {
							p += 14;
							loop_count = buf[p++] | buf[p++] << 8;
							p++;
						} else {
							p += 12;
							while (true) {
								var block_size = buf[p++];
								if (!(block_size >= 0)) throw Error("Invalid block size");
								if (block_size === 0) break;
								p += block_size;
							}
						}
						break;
					case 249:
						if (buf[p++] !== 4 || buf[p + 4] !== 0) throw new Error("Invalid graphics extension block.");
						var pf1 = buf[p++];
						delay = buf[p++] | buf[p++] << 8;
						transparent_index = buf[p++];
						if ((pf1 & 1) === 0) transparent_index = null;
						disposal = pf1 >> 2 & 7;
						p++;
						break;
					case 254:
						while (true) {
							var block_size = buf[p++];
							if (!(block_size >= 0)) throw Error("Invalid block size");
							if (block_size === 0) break;
							p += block_size;
						}
						break;
					default: throw new Error("Unknown graphic control label: 0x" + buf[p - 1].toString(16));
				}
				break;
			case 44:
				var x = buf[p++] | buf[p++] << 8;
				var y = buf[p++] | buf[p++] << 8;
				var w = buf[p++] | buf[p++] << 8;
				var h = buf[p++] | buf[p++] << 8;
				var pf2 = buf[p++];
				var local_palette_flag = pf2 >> 7;
				var interlace_flag = pf2 >> 6 & 1;
				var num_local_colors = 1 << (pf2 & 7) + 1;
				var palette_offset = global_palette_offset;
				var palette_size = global_palette_size;
				var has_local_palette = false;
				if (local_palette_flag) {
					var has_local_palette = true;
					palette_offset = p;
					palette_size = num_local_colors;
					p += num_local_colors * 3;
				}
				var data_offset = p;
				p++;
				while (true) {
					var block_size = buf[p++];
					if (!(block_size >= 0)) throw Error("Invalid block size");
					if (block_size === 0) break;
					p += block_size;
				}
				frames.push({
					x,
					y,
					width: w,
					height: h,
					has_local_palette,
					palette_offset,
					palette_size,
					data_offset,
					data_length: p - data_offset,
					transparent_index,
					interlaced: !!interlace_flag,
					delay,
					disposal
				});
				break;
			case 59:
				no_eof = false;
				break;
			default: throw new Error("Unknown gif block: 0x" + buf[p - 1].toString(16));
		}
		this.numFrames = function() {
			return frames.length;
		};
		this.loopCount = function() {
			return loop_count;
		};
		this.frameInfo = function(frame_num) {
			if (frame_num < 0 || frame_num >= frames.length) throw new Error("Frame index out of range.");
			return frames[frame_num];
		};
		this.decodeAndBlitFrameBGRA = function(frame_num, pixels) {
			var frame = this.frameInfo(frame_num);
			var num_pixels = frame.width * frame.height;
			var index_stream = new Uint8Array(num_pixels);
			GifReaderLZWOutputIndexStream(buf, frame.data_offset, index_stream, num_pixels);
			var palette_offset = frame.palette_offset;
			var trans = frame.transparent_index;
			if (trans === null) trans = 256;
			var framewidth = frame.width;
			var framestride = width - framewidth;
			var xleft = framewidth;
			var opbeg = (frame.y * width + frame.x) * 4;
			var opend = ((frame.y + frame.height) * width + frame.x) * 4;
			var op = opbeg;
			var scanstride = framestride * 4;
			if (frame.interlaced === true) scanstride += width * 4 * 7;
			var interlaceskip = 8;
			for (var i = 0, il = index_stream.length; i < il; ++i) {
				var index = index_stream[i];
				if (xleft === 0) {
					op += scanstride;
					xleft = framewidth;
					if (op >= opend) {
						scanstride = framestride * 4 + width * 4 * (interlaceskip - 1);
						op = opbeg + (framewidth + framestride) * (interlaceskip << 1);
						interlaceskip >>= 1;
					}
				}
				if (index === trans) op += 4;
				else {
					var r = buf[palette_offset + index * 3];
					var g = buf[palette_offset + index * 3 + 1];
					var b = buf[palette_offset + index * 3 + 2];
					pixels[op++] = b;
					pixels[op++] = g;
					pixels[op++] = r;
					pixels[op++] = 255;
				}
				--xleft;
			}
		};
		this.decodeAndBlitFrameRGBA = function(frame_num, pixels) {
			var frame = this.frameInfo(frame_num);
			var num_pixels = frame.width * frame.height;
			var index_stream = new Uint8Array(num_pixels);
			GifReaderLZWOutputIndexStream(buf, frame.data_offset, index_stream, num_pixels);
			var palette_offset = frame.palette_offset;
			var trans = frame.transparent_index;
			if (trans === null) trans = 256;
			var framewidth = frame.width;
			var framestride = width - framewidth;
			var xleft = framewidth;
			var opbeg = (frame.y * width + frame.x) * 4;
			var opend = ((frame.y + frame.height) * width + frame.x) * 4;
			var op = opbeg;
			var scanstride = framestride * 4;
			if (frame.interlaced === true) scanstride += width * 4 * 7;
			var interlaceskip = 8;
			for (var i = 0, il = index_stream.length; i < il; ++i) {
				var index = index_stream[i];
				if (xleft === 0) {
					op += scanstride;
					xleft = framewidth;
					if (op >= opend) {
						scanstride = framestride * 4 + width * 4 * (interlaceskip - 1);
						op = opbeg + (framewidth + framestride) * (interlaceskip << 1);
						interlaceskip >>= 1;
					}
				}
				if (index === trans) op += 4;
				else {
					var r = buf[palette_offset + index * 3];
					var g = buf[palette_offset + index * 3 + 1];
					var b = buf[palette_offset + index * 3 + 2];
					pixels[op++] = r;
					pixels[op++] = g;
					pixels[op++] = b;
					pixels[op++] = 255;
				}
				--xleft;
			}
		};
	}
	function GifReaderLZWOutputIndexStream(code_stream, p, output, output_length) {
		var min_code_size = code_stream[p++];
		var clear_code = 1 << min_code_size;
		var eoi_code = clear_code + 1;
		var next_code = eoi_code + 1;
		var cur_code_size = min_code_size + 1;
		var code_mask = (1 << cur_code_size) - 1;
		var cur_shift = 0;
		var cur = 0;
		var op = 0;
		var subblock_size = code_stream[p++];
		var code_table = new Int32Array(4096);
		var prev_code = null;
		while (true) {
			while (cur_shift < 16) {
				if (subblock_size === 0) break;
				cur |= code_stream[p++] << cur_shift;
				cur_shift += 8;
				if (subblock_size === 1) subblock_size = code_stream[p++];
				else --subblock_size;
			}
			if (cur_shift < cur_code_size) break;
			var code = cur & code_mask;
			cur >>= cur_code_size;
			cur_shift -= cur_code_size;
			if (code === clear_code) {
				next_code = eoi_code + 1;
				cur_code_size = min_code_size + 1;
				code_mask = (1 << cur_code_size) - 1;
				prev_code = null;
				continue;
			} else if (code === eoi_code) break;
			var chase_code = code < next_code ? code : prev_code;
			var chase_length = 0;
			var chase = chase_code;
			while (chase > clear_code) {
				chase = code_table[chase] >> 8;
				++chase_length;
			}
			var k = chase;
			if (op + chase_length + (chase_code !== code ? 1 : 0) > output_length) {
				console.log("Warning, gif stream longer than expected.");
				return;
			}
			output[op++] = k;
			op += chase_length;
			var b = op;
			if (chase_code !== code) output[op++] = k;
			chase = chase_code;
			while (chase_length--) {
				chase = code_table[chase];
				output[--b] = chase & 255;
				chase >>= 8;
			}
			if (prev_code !== null && next_code < 4096) {
				code_table[next_code++] = prev_code << 8 | k;
				if (next_code >= code_mask + 1 && cur_code_size < 12) {
					++cur_code_size;
					code_mask = code_mask << 1 | 1;
				}
			}
			prev_code = code;
		}
		if (op !== output_length) console.log("Warning, gif stream shorter than expected.");
		return output;
	}
	try {
		exports.GifWriter = GifWriter;
		exports.GifReader = GifReader;
	} catch (e) {}
})))(), 1)).default;
const encoder$1 = new TextEncoder(), decoder = new TextDecoder();
const ASEPRITE_BLEND_MODES = [
	"normal",
	"multiply",
	"screen",
	"overlay",
	"darken",
	"lighten",
	"color-dodge",
	"color-burn",
	"hard-light",
	"soft-light",
	"difference",
	"exclusion",
	"hue",
	"saturation",
	"color",
	"luminosity",
	"addition",
	"subtract",
	"divide"
];
const DIRECTIONS = [
	"forward",
	"reverse",
	"pingpong",
	"pingpong_reverse"
];
const MAX_PIXELS = 64 * 1024 * 1024;
function assert(value, message) {
	if (!value) throw new Error(message);
}
function bytes(value) {
	return value instanceof Uint8Array ? value : new Uint8Array(value);
}
function dimensions(w, h) {
	assert(Number.isInteger(w) && Number.isInteger(h) && w > 0 && h > 0 && w * h <= MAX_PIXELS, "Invalid or excessive image dimensions.");
}
function hex(r, g, b, a = 255) {
	return "#" + [
		r,
		g,
		b,
		a
	].map((v) => v.toString(16).padStart(2, "0")).join("");
}
function colorRgba(value, palette = []) {
	if (typeof value === "number") value = palette[value];
	if (value == null) return [
		0,
		0,
		0,
		0
	];
	assert(typeof value === "string" && /^#[0-9a-f]{6}([0-9a-f]{2})?$/i.test(value), `Invalid pixel color ${value}.`);
	return [
		parseInt(value.slice(1, 3), 16),
		parseInt(value.slice(3, 5), 16),
		parseInt(value.slice(5, 7), 16),
		value.length === 9 ? parseInt(value.slice(7, 9), 16) : 255
	];
}
function pixelsToRgba(pixels, palette = []) {
	const out = new Uint8Array(pixels.length * 4);
	pixels.forEach((p, i) => out.set(colorRgba(p, palette), i * 4));
	return out;
}
function rgbaToPixels(rgba) {
	const out = [];
	for (let i = 0; i < rgba.length; i += 4) out.push(rgba[i + 3] ? hex(...rgba.subarray(i, i + 4)) : null);
	return out;
}
var Reader = class {
	constructor(data) {
		this.b = bytes(data);
		this.v = new DataView(this.b.buffer, this.b.byteOffset, this.b.byteLength);
		this.p = 0;
	}
	need(n) {
		assert(Number.isSafeInteger(n) && n >= 0 && this.p + n <= this.b.length, "Truncated or malformed binary file.");
	}
	u8() {
		this.need(1);
		return this.v.getUint8(this.p++);
	}
	u16() {
		this.need(2);
		const v = this.v.getUint16(this.p, true);
		this.p += 2;
		return v;
	}
	i16() {
		this.need(2);
		const v = this.v.getInt16(this.p, true);
		this.p += 2;
		return v;
	}
	u32() {
		this.need(4);
		const v = this.v.getUint32(this.p, true);
		this.p += 4;
		return v;
	}
	i32() {
		this.need(4);
		const v = this.v.getInt32(this.p, true);
		this.p += 4;
		return v;
	}
	skip(n) {
		this.need(n);
		this.p += n;
		return this;
	}
	take(n) {
		this.need(n);
		const v = this.b.slice(this.p, this.p + n);
		this.p += n;
		return v;
	}
	str() {
		return decoder.decode(this.take(this.u16()));
	}
	remaining() {
		return this.take(this.b.length - this.p);
	}
};
var Writer = class {
	constructor() {
		this.b = [];
	}
	u8(v) {
		this.b.push(v & 255);
		return this;
	}
	u16(v) {
		return this.u8(v).u8(v >>> 8);
	}
	i16(v) {
		return this.u16(v);
	}
	u32(v) {
		return this.u16(v).u16(v >>> 16);
	}
	i32(v) {
		return this.u32(v);
	}
	raw(v) {
		for (const x of v) this.b.push(x);
		return this;
	}
	zero(n) {
		for (let i = 0; i < n; i++) this.b.push(0);
		return this;
	}
	str(v) {
		const b = encoder$1.encode(v || "");
		assert(b.length <= 65535, "Aseprite name exceeds 65535 UTF-8 bytes.");
		return this.u16(b.length).raw(b);
	}
	done() {
		return Uint8Array.from(this.b);
	}
};
function concat(parts) {
	const out = new Uint8Array(parts.reduce((n, p) => n + p.length, 0));
	let p = 0;
	for (const v of parts) {
		out.set(v, p);
		p += v.length;
	}
	return out;
}
function inflateExact(compressed, length) {
	assert(length <= MAX_PIXELS * 4, "Decompressed image exceeds safety limit.");
	const out = unzlibSync(compressed, { out: new Uint8Array(length + 1) });
	assert(out.length === length, "Image data length does not match its dimensions.");
	let a = 1, b = 0;
	for (const byte of out) {
		a = (a + byte) % 65521;
		b = (b + a) % 65521;
	}
	const p = compressed.length - 4, checksum = (compressed[p] << 24 | compressed[p + 1] << 16 | compressed[p + 2] << 8 | compressed[p + 3]) >>> 0;
	assert((b << 16 | a) >>> 0 === checksum, "Compressed image checksum mismatch.");
	return out;
}
function decodePixels(data, w, h, depth) {
	dimensions(w, h);
	const channels = depth / 8;
	assert(data.length === w * h * channels, "Aseprite cel data has incorrect length.");
	const out = new Array(w * h);
	for (let i = 0; i < out.length; i++) {
		const p = i * channels;
		out[i] = depth === 8 ? data[p] : depth === 16 ? hex(data[p], data[p], data[p], data[p + 1]) : hex(data[p], data[p + 1], data[p + 2], data[p + 3]);
	}
	return out;
}
function encodePixels(image, depth, palette, transparentIndex = 0) {
	dimensions(image.width, image.height);
	assert(image.pixels?.length === image.width * image.height, "Image pixel count does not match dimensions.");
	const out = new Uint8Array(image.pixels.length * depth / 8);
	image.pixels.forEach((v, i) => {
		if (depth === 8) {
			const index = v == null ? transparentIndex : typeof v === "number" ? v : palette.findIndex((p) => p.toLowerCase() === v.toLowerCase());
			assert(Number.isInteger(index) && index >= 0 && index < Math.min(palette.length, 256), `Pixel ${i} is not in the indexed palette.`);
			out[i] = index;
		} else {
			const [r, g, b, a] = colorRgba(v, palette);
			if (depth === 16) {
				assert(r === g && g === b, "Grayscale Aseprite export contains a non-grayscale pixel. Convert color mode first.");
				out.set([r, a], i * 2);
			} else out.set([
				r,
				g,
				b,
				a
			], i * 4);
		}
	});
	return out;
}
function baseDocument(w, h, name = "Imported sprite") {
	dimensions(w, h);
	return {
		format: "pixelwall-document",
		version: 4,
		id: "document-import",
		name,
		width: w,
		height: h,
		colorMode: "rgba",
		palette: [
			"#00000000",
			"#000000ff",
			"#ffffffff"
		],
		colorProfile: "sRGB",
		layers: [],
		frames: [],
		images: {},
		clips: [],
		slices: [],
		tilesets: [],
		metadata: {}
	};
}
function imageDocument(entries, options = {}) {
	assert(entries.length > 0, "No images to import.");
	const doc = baseDocument(options.width || Math.max(...entries.map((e) => e.width)), options.height || Math.max(...entries.map((e) => e.height)), options.name);
	doc.layers = [{
		id: "layer-1",
		name: "Artwork",
		type: "image",
		parentId: null,
		visible: true,
		locked: false,
		opacity: 1,
		blendMode: "normal"
	}];
	for (const [i, e] of entries.entries()) {
		dimensions(e.width, e.height);
		assert(e.rgba.length === e.width * e.height * 4, "RGBA data length is invalid.");
		const id = `image-${i + 1}`;
		doc.images[id] = {
			width: e.width,
			height: e.height,
			pixels: rgbaToPixels(e.rgba)
		};
		doc.frames.push({
			id: `frame-${i + 1}`,
			durationMs: e.durationMs || options.durationMs || 100,
			cels: { "layer-1": {
				imageId: id,
				x: e.x || 0,
				y: e.y || 0,
				opacity: 1
			} }
		});
	}
	return doc;
}
function importSequence(entries, options = {}) {
	return imageDocument(entries, options);
}
function readAseprite(input) {
	const data = bytes(input), r = new Reader(data);
	assert(data.length >= 128, "Aseprite header is truncated.");
	assert(r.u32() === data.length, "Aseprite file size does not match header.");
	assert(r.u16() === 42464, "Not an Aseprite file.");
	const count = r.u16(), width = r.u16(), height = r.u16(), depth = r.u16();
	assert([
		8,
		16,
		32
	].includes(depth), "Unsupported Aseprite color depth.");
	assert(count > 0, "Aseprite has no frames.");
	const flags = r.u32(), speed = r.u16();
	r.skip(8);
	const transparentIndex = r.u8();
	r.skip(3);
	const colors = r.u16() || 256, pixelWidth = r.u8() || 1, pixelHeight = r.u8() || 1, grid = {
		x: r.i16(),
		y: r.i16(),
		width: r.u16(),
		height: r.u16()
	};
	r.p = 128;
	const doc = baseDocument(width, height), warnings = [], meta = {
		transparentIndex,
		pixelRatio: {
			width: pixelWidth,
			height: pixelHeight
		},
		grid,
		flags,
		paletteNames: {},
		externalFiles: [],
		opaqueChunks: []
	};
	doc.colorMode = {
		8: "indexed",
		16: "grayscale",
		32: "rgba"
	}[depth];
	doc.metadata.aseprite = meta;
	let palette = Array.from({ length: colors }, () => "#000000ff"), paletteSeen = false, anyPalette = false, parents = [], lastObject = doc, pendingUserObjects = [], pendingTile = null;
	const links = [];
	for (let fi = 0; fi < count; fi++) {
		const start = r.p, frameSize = r.u32();
		assert(frameSize >= 16 && start + frameSize <= data.length, "Invalid Aseprite frame size.");
		assert(r.u16() === 61946, "Invalid Aseprite frame magic.");
		const oldCount = r.u16(), duration = r.u16();
		r.skip(2);
		const chunkCount = r.u32() || oldCount;
		const frame = {
			id: `frame-${fi + 1}`,
			durationMs: duration || speed || 100,
			cels: {}
		};
		doc.frames.push(frame);
		let paletteChanged = false;
		for (let ci = 0; ci < chunkCount; ci++) {
			const cs = r.p, chunkSize = r.u32(), type = r.u16();
			assert(chunkSize >= 6 && cs + chunkSize <= start + frameSize, "Invalid Aseprite chunk size.");
			const raw = r.take(chunkSize - 6), c = new Reader(raw);
			if (type !== 8224) {
				pendingUserObjects = [];
				pendingTile = null;
			}
			if (type === 8196) {
				assert(fi === 0, "Per-frame layer definitions are not supported.");
				const layerFlags = c.u16(), layerType = c.u16(), level = c.u16();
				c.skip(4);
				const blend = c.u16(), opacity = c.u8();
				c.skip(3);
				const name = c.str();
				assert(layerType <= 2, "Unsupported Aseprite layer type.");
				assert(blend < ASEPRITE_BLEND_MODES.length, "Unsupported Aseprite blend mode.");
				assert(level === 0 || parents[level - 1], "Invalid Aseprite layer hierarchy.");
				const layer = {
					id: `layer-${doc.layers.length + 1}`,
					name,
					type: layerType === 1 ? "group" : layerType === 2 ? "tilemap" : layerFlags & 64 ? "reference" : "image",
					parentId: level ? parents[level - 1].id : null,
					visible: !!(layerFlags & 1),
					locked: !(layerFlags & 2),
					opacity: layerType === 1 ? flags & 2 ? opacity / 255 : 1 : flags & 1 ? opacity / 255 : 1,
					blendMode: layerType === 1 && !(flags & 2) ? "normal" : ASEPRITE_BLEND_MODES[blend],
					asepriteFlags: layerFlags
				};
				if (layerType === 2) layer.asepriteTilesetIndex = c.u32();
				if (flags & 4) layer.uuid = Array.from(c.take(16));
				doc.layers.push(layer);
				parents.length = level;
				parents[level] = layer;
				lastObject = layer;
			} else if (type === 8197) {
				const li = c.u16(), x = c.i16(), y = c.i16(), opacity = c.u8() / 255, celType = c.u16(), zIndex = c.i16();
				c.skip(5);
				const layer = doc.layers[li];
				assert(layer, "Aseprite cel references a missing layer.");
				assert(!frame.cels[layer.id], "Duplicate cel for one layer/frame is unsupported.");
				const cel = {
					imageId: "",
					x,
					y,
					opacity,
					zIndex
				};
				frame.cels[layer.id] = cel;
				lastObject = cel;
				if (celType === 1) links.push({
					cel,
					fi,
					li,
					target: c.u16()
				});
				else if (celType === 0 || celType === 2) {
					const w = c.u16(), h = c.u16();
					dimensions(w, h);
					const payload = celType === 0 ? c.remaining() : inflateExact(c.remaining(), w * h * depth / 8);
					cel.imageId = `image-${fi + 1}-${li + 1}`;
					doc.images[cel.imageId] = {
						width: w,
						height: h,
						pixels: decodePixels(payload, w, h, depth)
					};
				} else if (celType === 3) {
					const w = c.u16(), h = c.u16(), bitsPerTile = c.u16();
					dimensions(w, h);
					assert([
						8,
						16,
						32
					].includes(bitsPerTile), "Unsupported Aseprite tile bit depth.");
					const tilemap = {
						bitsPerTile,
						idMask: c.u32(),
						xFlipMask: c.u32(),
						yFlipMask: c.u32(),
						diagonalFlipMask: c.u32()
					};
					c.skip(10);
					const tr = new Reader(inflateExact(c.remaining(), w * h * bitsPerTile / 8));
					tilemap.tiles = Array.from({ length: w * h }, () => bitsPerTile === 32 ? tr.u32() : bitsPerTile === 16 ? tr.u16() : tr.u8());
					cel.imageId = `image-${fi + 1}-${li + 1}`;
					doc.images[cel.imageId] = {
						width: w,
						height: h,
						pixels: [],
						tilemap
					};
				} else throw new Error(`Unsupported Aseprite cel type ${celType}.`);
			} else if (type === 8198) {
				assert(lastObject && "imageId" in lastObject, "Cel extra has no preceding cel.");
				const extraFlags = c.u32();
				lastObject.preciseBounds = {
					flags: extraFlags,
					x: c.i32() / 65536,
					y: c.i32() / 65536,
					width: c.i32() / 65536,
					height: c.i32() / 65536
				};
				c.skip(16);
			} else if (type === 8199) {
				const profile = {
					type: c.u16(),
					flags: c.u16(),
					gamma: c.i32() / 65536
				};
				c.skip(8);
				if (profile.type === 2) profile.icc = Array.from(c.take(c.u32()));
				meta.colorProfile = profile;
				if (profile.type === 2 || profile.flags & 1) warnings.push("Embedded ICC / fixed-gamma profile is preserved, but preview uses sRGB without color conversion.");
			} else if (type === 8200) {
				const n = c.u32();
				c.skip(8);
				for (let i = 0; i < n; i++) {
					const entry = {
						id: c.u32(),
						type: c.u8()
					};
					c.skip(7);
					entry.name = c.str();
					meta.externalFiles.push(entry);
				}
			} else if (type === 8217) {
				const n = c.u32(), first = c.u32(), last = c.u32();
				assert(n > 0 && n <= 65536 && first <= last && last < n, "Invalid Aseprite palette.");
				c.skip(8);
				palette.length = n;
				for (let i = first; i <= last; i++) {
					const f = c.u16();
					palette[i] = hex(c.u8(), c.u8(), c.u8(), c.u8());
					if (f & 1) meta.paletteNames[i] = c.str();
				}
				palette = Array.from(palette, (p) => p || "#000000ff");
				paletteSeen = true;
				anyPalette = true;
				paletteChanged = true;
				lastObject = doc;
			} else if (type === 4 || type === 17) {
				anyPalette = true;
				if (!paletteSeen) {
					const n = c.u16();
					let index = 0;
					for (let i = 0; i < n; i++) {
						index += c.u8();
						const ct = c.u8() || 256;
						for (let j = 0; j < ct; j++) {
							const rgb = [
								c.u8(),
								c.u8(),
								c.u8()
							].map((v) => type === 17 ? Math.round(v * 255 / 63) : v);
							palette[index++] = hex(...rgb);
						}
					}
					paletteChanged = true;
				}
			} else if (type === 8216) {
				const n = c.u16();
				c.skip(8);
				for (let i = 0; i < n; i++) {
					const from = c.u16(), to = c.u16(), direction = c.u8(), repeat = c.u16();
					assert(from <= to && to < count && direction <= 3, "Invalid Aseprite animation tag.");
					c.skip(6);
					const color = hex(c.u8(), c.u8(), c.u8());
					c.skip(1);
					const clip = {
						id: `clip-${doc.clips.length + 1}`,
						name: c.str(),
						frameIds: Array.from({ length: to - from + 1 }, (_, j) => `frame-${from + j + 1}`),
						direction: DIRECTIONS[direction],
						loop: repeat === 0,
						repeat,
						color
					};
					doc.clips.push(clip);
					pendingUserObjects.push(clip);
				}
				lastObject = doc;
			} else if (type === 8226) {
				const n = c.u32(), sliceFlags = c.u32();
				c.skip(4);
				const slice = {
					id: `slice-${doc.slices.length + 1}`,
					name: c.str(),
					keys: []
				};
				for (let i = 0; i < n; i++) {
					const frameIndex = c.u32();
					assert(frameIndex < count, "Slice refers to an unknown frame.");
					const key = {
						frameId: `frame-${frameIndex + 1}`,
						x: c.i32(),
						y: c.i32(),
						width: c.u32(),
						height: c.u32()
					};
					if (sliceFlags & 1) key.center = {
						x: c.i32(),
						y: c.i32(),
						width: c.u32(),
						height: c.u32()
					};
					if (sliceFlags & 2) key.pivot = {
						x: c.i32(),
						y: c.i32()
					};
					slice.keys.push(key);
				}
				doc.slices.push(slice);
				lastObject = slice;
			} else if (type === 8227) {
				const numericId = c.u32(), tileFlags = c.u32(), tileCount = c.u32(), tileWidth = c.u16(), tileHeight = c.u16(), baseIndex = c.i16();
				c.skip(14);
				const tileset = {
					id: `tileset-${numericId}`,
					asepriteId: numericId,
					name: c.str(),
					flags: tileFlags,
					tileCount,
					tileWidth,
					tileHeight,
					baseIndex
				};
				dimensions(tileWidth, tileHeight * Math.max(1, tileCount));
				if (tileFlags & 1) {
					tileset.externalFileId = c.u32();
					tileset.externalTilesetId = c.u32();
					warnings.push(`Tileset “${tileset.name}” links an external file; external content is not loaded automatically.`);
				}
				if (tileFlags & 2) {
					const compressed = c.take(c.u32()), h = tileHeight * tileCount;
					tileset.imageId = `tileset-image-${numericId}`;
					doc.images[tileset.imageId] = {
						width: tileWidth,
						height: h,
						pixels: decodePixels(inflateExact(compressed, tileWidth * h * depth / 8), tileWidth, h, depth)
					};
				}
				doc.tilesets.push(tileset);
				lastObject = tileset;
				pendingTile = {
					tileset,
					index: -1
				};
			} else if (type === 8224) {
				const uflags = c.u32(), userData = {};
				if (uflags & 1) userData.text = c.str();
				if (uflags & 2) userData.color = hex(c.u8(), c.u8(), c.u8(), c.u8());
				if (uflags & 4) {
					const len = c.u32();
					assert(len >= 8, "Invalid Aseprite property block.");
					const prop = new Writer().u32(len).raw(c.take(len - 4));
					userData.propertiesBytes = Array.from(prop.done());
					warnings.push("Aseprite extension properties are preserved as opaque data.");
				}
				assert(!(uflags & -8), "Unsupported Aseprite user-data flags.");
				if (pendingUserObjects.length) pendingUserObjects.shift().userData = userData;
				else if (pendingTile) {
					if (pendingTile.index < 0) pendingTile.tileset.userData = userData;
					else {
						pendingTile.tileset.tileUserData ||= [];
						pendingTile.tileset.tileUserData[pendingTile.index] = userData;
					}
					pendingTile.index++;
				} else lastObject.userData = userData;
			} else {
				meta.opaqueChunks.push({
					frameIndex: fi,
					type,
					data: Array.from(raw)
				});
				warnings.push(`Unsupported Aseprite chunk 0x${type.toString(16)} preserved in the project; native re-export is blocked to prevent data loss.`);
			}
		}
		assert(r.p === start + frameSize, "Frame size/chunk count mismatch.");
		if (paletteChanged || fi === 0) frame.palette = [...palette];
	}
	assert(r.p === data.length, "Unexpected bytes after Aseprite frames.");
	const resolve = (link, seen = /* @__PURE__ */ new Set()) => {
		assert(link.target < count, "Linked cel references an unknown frame.");
		assert(!seen.has(link), "Cyclic linked Aseprite cels.");
		seen.add(link);
		const target = doc.frames[link.target].cels[doc.layers[link.li].id];
		assert(target, "Linked cel references an empty cel.");
		if (!target.imageId) {
			const other = links.find((l) => l.cel === target);
			assert(other, "Missing linked cel target.");
			resolve(other, seen);
		}
		link.cel.imageId = target.imageId;
	};
	links.forEach((l) => resolve(l));
	for (const layer of doc.layers) if (layer.type === "tilemap") {
		const ts = doc.tilesets[layer.asepriteTilesetIndex];
		assert(ts, "Tilemap references an unknown tileset.");
		layer.tilesetId = ts.id;
	}
	doc.palette = [...doc.frames[0].palette || palette];
	if (doc.colorMode === "indexed" && !anyPalette) warnings.push("Indexed file has no explicit palette.");
	meta.warnings = [...new Set(warnings)];
	return {
		document: doc,
		warnings: meta.warnings
	};
}
function aseChunk(type, w) {
	const b = w instanceof Writer ? w.done() : w;
	return new Writer().u32(b.length + 6).u16(type).raw(b).done();
}
function userChunk(obj) {
	if (!obj?.userData) return [];
	const u = obj.userData, w = new Writer().u32((u.text != null ? 1 : 0) | (u.color ? 2 : 0) | (u.propertiesBytes ? 4 : 0));
	if (u.text != null) w.str(u.text);
	if (u.color) w.raw(colorRgba(u.color));
	if (u.propertiesBytes) w.raw(u.propertiesBytes);
	return [aseChunk(8224, w)];
}
function paletteChunk(palette, names = {}) {
	assert(palette.length > 0, "Indexed export requires a palette.");
	const w = new Writer().u32(palette.length).u32(0).u32(palette.length - 1).zero(8);
	palette.forEach((p, i) => {
		w.u16(names[i] ? 1 : 0).raw(colorRgba(p));
		if (names[i]) w.str(names[i]);
	});
	return aseChunk(8217, w);
}
function tileImage(doc, tile) {
	const image = doc.images[tile.imageId];
	assert(image && !image.tilemap, "Tile raster image is missing.");
	if (!tile.sourceRect) return image;
	const { x, y, width, height } = tile.sourceRect;
	assert([
		x,
		y,
		width,
		height
	].every(Number.isInteger) && x >= 0 && y >= 0 && width > 0 && height > 0 && x + width <= image.width && y + height <= image.height, "Tile source rectangle exceeds its atlas.");
	const pixels = [];
	for (let yy = 0; yy < height; yy++) for (let xx = 0; xx < width; xx++) pixels.push(image.pixels[(y + yy) * image.width + x + xx]);
	return {
		width,
		height,
		pixels
	};
}
function prepareNativeTiles(input) {
	if (!input.layers.some((l) => l.tilemaps && Object.keys(l.tilemaps).length) && !input.tilesets?.some((t) => t.tiles?.length)) return input;
	const doc = structuredClone(input), indices = /* @__PURE__ */ new Map();
	for (const ts of doc.tilesets) {
		if (!ts.tiles?.length) continue;
		const ids = /* @__PURE__ */ new Map(), native = Number.isInteger(ts.asepriteId) && ts.imageId && doc.images[ts.imageId], original = native ? doc.images[ts.imageId] : null, transparent = doc.colorMode === "indexed" ? doc.metadata?.aseprite?.transparentIndex ?? 0 : null;
		let nextIndex = native ? ts.tileCount : 1;
		const assignments = [];
		for (const tile of ts.tiles) {
			const raw = native && Number.isInteger(tile.asepriteTileId) ? tile.asepriteTileId : nextIndex++;
			assert(raw >= 0 && raw < 536870911, "Tile ID exceeds the native range.");
			nextIndex = Math.max(nextIndex, raw + 1);
			ids.set(tile.id, raw);
			assignments.push({
				tile,
				index: raw
			});
		}
		const pixels = new Array(ts.tileWidth * ts.tileHeight * nextIndex).fill(transparent);
		if (original) {
			assert(original.width === ts.tileWidth && original.height === ts.tileHeight * ts.tileCount, "Native tileset atlas shape is invalid.");
			for (let i = 0; i < original.pixels.length; i++) pixels[i] = original.pixels[i];
		}
		for (const { tile, index } of assignments) {
			const image = tileImage(doc, tile);
			assert(image.width === ts.tileWidth && image.height === ts.tileHeight, "Tile dimensions do not match their tileset.");
			const offset = index * ts.tileWidth * ts.tileHeight;
			for (let i = 0; i < image.pixels.length; i++) pixels[offset + i] = image.pixels[i];
		}
		indices.set(ts.id, ids);
		ts.imageId = `ase-tileset-${ts.id}`;
		ts.tileCount = nextIndex;
		ts.flags = native ? ts.flags | 2 : (ts.flags || 0) | 6;
		doc.images[ts.imageId] = {
			width: ts.tileWidth,
			height: ts.tileHeight * ts.tileCount,
			pixels
		};
	}
	const links = /* @__PURE__ */ new Map();
	for (const layer of doc.layers) {
		if (!layer.tilemaps) continue;
		for (const [frameId, map] of Object.entries(layer.tilemaps)) {
			const frame = doc.frames.find((f) => f.id === frameId);
			assert(frame, "Tilemap references a missing frame.");
			assert(!layer.tilesetId || layer.tilesetId === map.tilesetId, "Aseprite tilemap layer cannot switch tilesets between frames.");
			layer.tilesetId = map.tilesetId;
			const ids = indices.get(map.tilesetId), ts = doc.tilesets.find((t) => t.id === map.tilesetId);
			assert(ids && ts, "Tilemap requires an embedded tileset.");
			const columns = map.columns, rows = map.rows;
			dimensions(columns, rows);
			assert(map.cells.length === columns * rows, "Tilemap cell count does not match dimensions.");
			const tilemap = {
				bitsPerTile: 32,
				idMask: 536870911,
				xFlipMask: 2147483648,
				yFlipMask: 1073741824,
				diagonalFlipMask: 536870912,
				tiles: map.cells.map((cell) => {
					if (cell == null) return ts.flags & 4 ? 0 : 4294967295;
					const id = ids.get(cell.tileId);
					assert(id != null, "Tilemap references an unknown tile.");
					let fx = !!cell.flipX, fy = !!cell.flipY, d = false;
					const rotation = ((cell.rotate || 0) % 360 + 360) % 360;
					assert([
						0,
						90,
						180,
						270
					].includes(rotation), "Aseprite tiles require quarter-turn rotations.");
					if (rotation === 90) {
						d = true;
						fy = !fy;
					}
					if (rotation === 180) {
						fx = !fx;
						fy = !fy;
					}
					if (rotation === 270) {
						d = true;
						fx = !fx;
					}
					return (id | (fx ? 2147483648 : 0) | (fy ? 1073741824 : 0) | (d ? 536870912 : 0)) >>> 0;
				})
			};
			const previous = frame.cels[layer.id], sourceId = map.sourceImageId || previous?.imageId, old = doc.images[sourceId], unchanged = old?.tilemap && old.width === columns && old.height === rows && JSON.stringify(old.tilemap) === JSON.stringify(tilemap), key = sourceId ? `${layer.id}:${sourceId}:${JSON.stringify(tilemap)}` : null;
			let imageId = unchanged ? sourceId : key && links.get(key);
			if (!imageId) {
				imageId = `ase-map-${layer.id}-${frameId}`;
				doc.images[imageId] = {
					width: columns,
					height: rows,
					pixels: [],
					tilemap
				};
				if (key) links.set(key, imageId);
			}
			frame.cels[layer.id] = {
				...previous || {
					x: map.x || 0,
					y: map.y || 0,
					opacity: 1
				},
				imageId
			};
		}
	}
	return doc;
}
function prepareIndexedTransparency(input) {
	if (input.colorMode !== "indexed" || Number.isInteger(input.metadata?.aseprite?.transparentIndex)) return input;
	const doc = structuredClone(input), palettes = [doc.palette, ...doc.frames.filter((f) => f.palette).map((f) => f.palette)], length = Math.max(...palettes.map((p) => p.length)), used = /* @__PURE__ */ new Set();
	for (const image of Object.values(doc.images)) if (!image.tilemap) {
		for (const pixel of image.pixels) if (pixel != null) used.add(typeof pixel === "number" ? pixel : doc.palette.findIndex((p) => p.toLowerCase() === pixel.toLowerCase()));
	}
	let index = doc.palette.findIndex((p, i) => colorRgba(p)[3] === 0 && palettes.every((palette) => !palette[i] || colorRgba(palette[i])[3] === 0));
	if (index < 0) if (length < 256) index = length;
	else index = Array.from({ length: 256 }, (_, i) => i).find((i) => !used.has(i));
	assert(Number.isInteger(index), "Indexed Aseprite needs a reserved transparent palette entry. Free a palette slot or convert the document to RGBA before export.");
	for (const palette of palettes) {
		while (palette.length <= index) palette.push("#000000ff");
		palette[index] = "#00000000";
	}
	doc.metadata ||= {};
	doc.metadata.aseprite = {
		...doc.metadata.aseprite || {},
		transparentIndex: index
	};
	return doc;
}
function writeAseprite(input) {
	const doc = prepareNativeTiles(prepareIndexedTransparency(input));
	dimensions(doc.width, doc.height);
	assert(doc.width <= 65535 && doc.height <= 65535, "Aseprite dimensions exceed 65535.");
	assert(doc.frames.length > 0 && doc.frames.length <= 65535, "Aseprite supports 1–65535 frames.");
	const meta = doc.metadata?.aseprite || {};
	assert(!meta.opaqueChunks?.length, "Native export blocked: unsupported Aseprite chunks are retained in this project. Save the PixelWall project to preserve them.");
	const depth = {
		rgba: 32,
		indexed: 8,
		grayscale: 16
	}[doc.colorMode];
	assert(depth, "Unsupported color mode.");
	assert(depth !== 8 || doc.palette.length > 0 && doc.palette.length <= 256, "Indexed Aseprite requires a palette of 1–256 colors.");
	const layers = [], walk = (parent, ancestors = []) => {
		for (const l of doc.layers.filter((l) => (l.parentId || null) === parent)) {
			assert(!ancestors.includes(l.id), "Cyclic layer hierarchy.");
			layers.push(l);
			walk(l.id, [...ancestors, l.id]);
		}
	};
	walk(null);
	assert(layers.length === doc.layers.length, "Layer hierarchy contains a missing parent or cycle.");
	assert(layers.length <= 65535, "Too many Aseprite layers.");
	const frames = [], seenImages = /* @__PURE__ */ new Map(), hasUuid = layers.some((l) => l.uuid);
	for (let fi = 0; fi < doc.frames.length; fi++) {
		const frame = doc.frames[fi], chunks = [];
		assert(Number.isInteger(frame.durationMs) && frame.durationMs > 0 && frame.durationMs <= 65535, "Aseprite frame duration must be 1–65535 ms.");
		if (fi === 0) {
			const cp = meta.colorProfile || {
				type: 1,
				flags: 0,
				gamma: 0
			}, cw = new Writer().u16(cp.type).u16(cp.flags).i32(Math.round(cp.gamma * 65536)).zero(8);
			if (cp.type === 2) {
				assert(cp.icc?.length, "Missing embedded color profile.");
				cw.u32(cp.icc.length).raw(cp.icc);
			}
			chunks.push(aseChunk(8199, cw));
			if (meta.externalFiles?.length) {
				const w = new Writer().u32(meta.externalFiles.length).zero(8);
				for (const e of meta.externalFiles) w.u32(e.id).u8(e.type).zero(7).str(e.name);
				chunks.push(aseChunk(8200, w));
			}
			for (const [ti, ts] of (doc.tilesets || []).entries()) {
				assert(!ts.tiles?.length || ts.imageId, "Native Aseprite tileset export requires a stacked atlas image.");
				const flags = (ts.flags ?? 4) | (ts.imageId ? 2 : 0) | (ts.externalFileId != null ? 1 : 0), w = new Writer().u32(ts.asepriteId ?? ti).u32(flags).u32(ts.tileCount).u16(ts.tileWidth).u16(ts.tileHeight).i16(ts.baseIndex ?? 1).zero(14).str(ts.name);
				if (flags & 1) w.u32(ts.externalFileId).u32(ts.externalTilesetId);
				if (flags & 2) {
					const image = doc.images[ts.imageId];
					assert(image && image.width === ts.tileWidth && image.height === ts.tileHeight * ts.tileCount, "Invalid embedded tileset atlas.");
					const compressed = zlibSync(encodePixels(image, depth, doc.palette, meta.transparentIndex || 0));
					w.u32(compressed.length).raw(compressed);
				}
				chunks.push(aseChunk(8227, w), ...userChunk(ts));
				if (ts.tileUserData?.length) {
					if (!ts.userData) chunks.push(aseChunk(8224, new Writer().u32(0)));
					for (const ud of ts.tileUserData) chunks.push(...userChunk({ userData: ud || {} }));
				}
			}
			for (const l of layers) {
				const type = l.type === "group" ? 1 : l.type === "tilemap" ? 2 : 0;
				assert([
					"group",
					"tilemap",
					"reference",
					"image"
				].includes(l.type), "Unsupported layer type.");
				const blend = ASEPRITE_BLEND_MODES.indexOf(l.blendMode || "normal");
				assert(blend >= 0, `Unsupported blend mode ${l.blendMode}.`);
				let level = 0, p = l.parentId;
				while (p) {
					level++;
					p = layers.find((x) => x.id === p)?.parentId;
				}
				let lf = (l.asepriteFlags || 0) & -68;
				if (l.visible !== false) lf |= 1;
				if (!l.locked) lf |= 2;
				if (l.type === "reference") lf |= 64;
				const w = new Writer().u16(lf).u16(type).u16(level).u16(0).u16(0).u16(blend).u8(Math.round((l.opacity ?? 1) * 255)).zero(3).str(l.name);
				if (type === 2) {
					const index = doc.tilesets.findIndex((t) => t.id === l.tilesetId);
					assert(index >= 0, "Tilemap layer has no tileset.");
					w.u32(index);
				}
				if (hasUuid) w.raw(l.uuid || new Uint8Array(16));
				chunks.push(aseChunk(8196, w), ...userChunk(l));
			}
		}
		const pal = frame.palette || (fi === 0 ? doc.palette : null);
		if (pal?.length) {
			chunks.push(paletteChunk(pal, meta.paletteNames));
			if (fi === 0) chunks.push(...userChunk(doc));
		}
		if (fi === 0) {
			if (doc.clips?.length) {
				const w = new Writer().u16(doc.clips.length).zero(8);
				for (const clip of doc.clips) {
					const indices = clip.frameIds.map((id) => doc.frames.findIndex((f) => f.id === id));
					assert(indices.length && indices.every((n, i) => n >= 0 && (i === 0 || n === indices[i - 1] + 1)), "Aseprite tags require a contiguous forward frame range.");
					const direction = DIRECTIONS.indexOf(clip.direction || "forward");
					assert(direction >= 0, "Unsupported clip direction.");
					w.u16(indices[0]).u16(indices.at(-1)).u8(direction).u16(clip.repeat ?? (clip.loop ? 0 : 1)).zero(6).raw(colorRgba(clip.color || "#000000").slice(0, 3)).u8(0).str(clip.name);
				}
				chunks.push(aseChunk(8216, w));
				if (doc.clips.some((c) => c.userData)) for (const clip of doc.clips) chunks.push(...userChunk({ userData: clip.userData || {} }));
			}
			for (const rawSlice of doc.slices || []) {
				const slice = rawSlice.keys ? rawSlice : {
					...rawSlice,
					keys: [{
						frameId: doc.frames[0].id,
						...rawSlice.bounds,
						...rawSlice.pivot ? { pivot: rawSlice.pivot } : {},
						...rawSlice.ninePatch ? { center: rawSlice.ninePatch } : {}
					}]
				};
				const hasCenter = slice.keys.some((k) => k.center), hasPivot = slice.keys.some((k) => k.pivot), w = new Writer().u32(slice.keys.length).u32((hasCenter ? 1 : 0) | (hasPivot ? 2 : 0)).u32(0).str(slice.name);
				for (const key of slice.keys) {
					const index = doc.frames.findIndex((f) => f.id === key.frameId);
					assert(index >= 0, "Slice refers to a missing frame.");
					w.u32(index).i32(key.x).i32(key.y).u32(key.width).u32(key.height);
					if (hasCenter) {
						assert(key.center, "All Aseprite slice keys must share nine-patch fields.");
						const c = key.center;
						w.i32(c.x).i32(c.y).u32(c.width).u32(c.height);
					}
					if (hasPivot) {
						assert(key.pivot, "All Aseprite slice keys must share pivot fields.");
						w.i32(key.pivot.x).i32(key.pivot.y);
					}
				}
				chunks.push(aseChunk(8226, w), ...userChunk(slice));
			}
		}
		for (const [li, layer] of layers.entries()) {
			const cel = frame.cels[layer.id];
			if (!cel) continue;
			assert(layer.type !== "group", "Aseprite group cannot contain a cel.");
			assert([
				cel.x,
				cel.y,
				cel.zIndex || 0
			].every((v) => Number.isInteger(v) && v >= -32768 && v <= 32767), "Aseprite cel positions and z-index must be signed 16-bit integers.");
			const image = doc.images[cel.imageId];
			assert(image, "Cel references a missing image.");
			assert(image.width <= 65535 && image.height <= 65535, "Aseprite cel dimensions exceed limit.");
			const key = `${layer.id}\0${cel.imageId}`, linked = seenImages.get(key), type = linked != null ? 1 : image.tilemap ? 3 : 2, w = new Writer().u16(li).i16(cel.x).i16(cel.y).u8(Math.round((cel.opacity ?? 1) * 255)).u16(type).i16(cel.zIndex || 0).zero(5);
			if (type === 1) w.u16(linked);
			else {
				seenImages.set(key, fi);
				w.u16(image.width).u16(image.height);
				if (type === 3) {
					const t = image.tilemap;
					assert([
						8,
						16,
						32
					].includes(t.bitsPerTile), "Invalid tile bits.");
					assert(t.tiles.length === image.width * image.height, "Tilemap cell count mismatch.");
					w.u16(t.bitsPerTile).u32(t.idMask).u32(t.xFlipMask).u32(t.yFlipMask).u32(t.diagonalFlipMask).zero(10);
					const tw = new Writer();
					for (const value of t.tiles) if (t.bitsPerTile === 32) tw.u32(value);
					else if (t.bitsPerTile === 16) tw.u16(value);
					else tw.u8(value);
					w.raw(zlibSync(tw.done()));
				} else w.raw(zlibSync(encodePixels(image, depth, frame.palette || doc.palette, meta.transparentIndex || 0)));
			}
			chunks.push(aseChunk(8197, w));
			if (cel.preciseBounds) {
				const b = cel.preciseBounds;
				chunks.push(aseChunk(8198, new Writer().u32(b.flags ?? 1).i32(Math.round(b.x * 65536)).i32(Math.round(b.y * 65536)).i32(Math.round(b.width * 65536)).i32(Math.round(b.height * 65536)).zero(16)));
			}
			chunks.push(...userChunk(cel));
		}
		const body = concat(chunks), fw = new Writer().u32(body.length + 16).u16(61946).u16(Math.min(chunks.length, 65535)).u16(frame.durationMs).zero(2).u32(chunks.length).raw(body);
		frames.push(fw.done());
	}
	const body = concat(frames);
	return concat([new Writer().u32(body.length + 128).u16(42464).u16(doc.frames.length).u16(doc.width).u16(doc.height).u16(depth).u32(3 | (hasUuid ? 4 : 0)).u16(doc.frames[0].durationMs).zero(8).u8(meta.transparentIndex || 0).zero(3).u16(doc.palette?.length || 0).u8(meta.pixelRatio?.width || 1).u8(meta.pixelRatio?.height || 1).i16(meta.grid?.x || 0).i16(meta.grid?.y || 0).u16(meta.grid?.width || 0).u16(meta.grid?.height || 0).zero(84).done(), body]);
}
const crcTable = Uint32Array.from({ length: 256 }, (_, n) => {
	for (let k = 0; k < 8; k++) n = n & 1 ? 3988292384 ^ n >>> 1 : n >>> 1;
	return n >>> 0;
});
function crc32(data) {
	let c = 4294967295;
	for (const b of data) c = crcTable[(c ^ b) & 255] ^ c >>> 8;
	return (c ^ 4294967295) >>> 0;
}
function be32(n) {
	return Uint8Array.of(n >>> 24, n >>> 16, n >>> 8, n);
}
function pngChunk(name, payload) {
	const body = concat([encoder$1.encode(name), payload]);
	return concat([
		be32(payload.length),
		body,
		be32(crc32(body))
	]);
}
function writePng(width, height, rgba) {
	dimensions(width, height);
	assert(rgba.length === width * height * 4, "PNG RGBA data length mismatch.");
	const head = concat([
		be32(width),
		be32(height),
		Uint8Array.of(8, 6, 0, 0, 0)
	]), scan = new Uint8Array(height * (width * 4 + 1));
	for (let y = 0; y < height; y++) scan.set(rgba.subarray(y * width * 4, (y + 1) * width * 4), y * (width * 4 + 1) + 1);
	return concat([
		Uint8Array.of(137, 80, 78, 71, 13, 10, 26, 10),
		pngChunk("IHDR", head),
		pngChunk("sRGB", Uint8Array.of(0)),
		pngChunk("IDAT", zlibSync(scan)),
		pngChunk("IEND", new Uint8Array())
	]);
}
function paeth(a, b, c) {
	const p = a + b - c, pa = Math.abs(p - a), pb = Math.abs(p - b), pc = Math.abs(p - c);
	return pa <= pb && pa <= pc ? a : pb <= pc ? b : c;
}
function readPng(input) {
	const data = bytes(input);
	assert(data.length >= 33 && [
		137,
		80,
		78,
		71,
		13,
		10,
		26,
		10
	].every((b, i) => data[i] === b), "Not a PNG image.");
	const v = new DataView(data.buffer, data.byteOffset, data.byteLength), idat = [], warnings = [];
	let p = 8, width, height, bitDepth, colorType, interlace, palette = null, transparency = null, ended = false, header = false;
	while (p < data.length) {
		assert(p + 12 <= data.length, "Truncated PNG chunk.");
		const len = v.getUint32(p), type = decoder.decode(data.subarray(p + 4, p + 8));
		assert(p + len + 12 <= data.length, "Truncated PNG payload.");
		const body = data.subarray(p + 8, p + 8 + len);
		assert(crc32(data.subarray(p + 4, p + 8 + len)) === v.getUint32(p + 8 + len), `PNG ${type} checksum mismatch.`);
		if (type === "IHDR") {
			assert(!header && p === 8 && len === 13, "Invalid PNG header.");
			header = true;
			width = v.getUint32(p + 8);
			height = v.getUint32(p + 12);
			dimensions(width, height);
			bitDepth = body[8];
			colorType = body[9];
			assert(body[10] === 0 && body[11] === 0 && body[12] <= 1, "Unsupported PNG compression, filter or interlace.");
			interlace = body[12];
			assert({
				0: [
					1,
					2,
					4,
					8,
					16
				],
				2: [8, 16],
				3: [
					1,
					2,
					4,
					8
				],
				4: [8, 16],
				6: [8, 16]
			}[colorType]?.includes(bitDepth), "Unsupported PNG color type/bit depth.");
		} else if (type === "PLTE") {
			assert(len % 3 === 0 && len > 0 && len <= 768, "Invalid PNG palette.");
			palette = body;
		} else if (type === "tRNS") transparency = body;
		else if (type === "IDAT") idat.push(body);
		else if (type === "IEND") {
			ended = true;
			p += 12;
			break;
		} else if (type === "acTL") throw new Error("Animated PNG is not supported; import PNG frames or a GIF instead.");
		else if (type === "iCCP" || type === "gAMA") warnings.push("PNG color-profile metadata is not converted; imported pixels use sRGB.");
		else if (type[0] === type[0].toUpperCase()) throw new Error(`Unsupported critical PNG chunk ${type}.`);
		p += len + 12;
	}
	assert(header && ended && idat.length, "Incomplete PNG file.");
	assert(p === data.length, "Unexpected bytes after PNG end.");
	if (colorType === 3) assert(palette, "Indexed PNG is missing its palette.");
	if (bitDepth === 16) warnings.push("16-bit PNG channels are reduced to 8 bits for pixel editing.");
	const channels = {
		0: 1,
		2: 3,
		3: 1,
		4: 2,
		6: 4
	}[colorType], passes = interlace ? [
		[
			0,
			0,
			8,
			8
		],
		[
			4,
			0,
			8,
			8
		],
		[
			0,
			4,
			4,
			8
		],
		[
			2,
			0,
			4,
			4
		],
		[
			0,
			2,
			2,
			4
		],
		[
			1,
			0,
			2,
			2
		],
		[
			0,
			1,
			1,
			2
		]
	] : [[
		0,
		0,
		1,
		1
	]], scanLen = passes.reduce((n, [x, y, dx, dy]) => {
		const w = Math.ceil((width - x) / dx), h = Math.ceil((height - y) / dy);
		return n + (w > 0 && h > 0 ? (1 + Math.ceil(w * channels * bitDepth / 8)) * h : 0);
	}, 0), raw = inflateExact(concat(idat), scanLen), rgba = new Uint8Array(width * height * 4);
	let offset = 0;
	for (const [x0, y0, dx, dy] of passes) {
		const w = Math.ceil((width - x0) / dx), h = Math.ceil((height - y0) / dy);
		if (w <= 0 || h <= 0) continue;
		const rowBytes = Math.ceil(w * channels * bitDepth / 8), bpp = Math.max(1, Math.ceil(channels * bitDepth / 8));
		let prev = new Uint8Array(rowBytes);
		for (let y = 0; y < h; y++) {
			const filter = raw[offset++];
			assert(filter <= 4, "Invalid PNG filter.");
			const row = raw.slice(offset, offset + rowBytes);
			offset += rowBytes;
			for (let i = 0; i < rowBytes; i++) {
				const a = i >= bpp ? row[i - bpp] : 0, b = prev[i], c = i >= bpp ? prev[i - bpp] : 0;
				row[i] = row[i] + (filter === 1 ? a : filter === 2 ? b : filter === 3 ? Math.floor((a + b) / 2) : filter === 4 ? paeth(a, b, c) : 0) & 255;
			}
			const sample = (i) => bitDepth === 16 ? row[i * 2] << 8 | row[i * 2 + 1] : bitDepth === 8 ? row[i] : row[Math.floor(i * bitDepth / 8)] >>> 8 - bitDepth - i * bitDepth % 8 & (1 << bitDepth) - 1, to8 = (n) => Math.round(n * 255 / (bitDepth === 16 ? 65535 : (1 << bitDepth) - 1));
			for (let x = 0; x < w; x++) {
				const q = x * channels, out = ((y0 + y * dy) * width + x0 + x * dx) * 4;
				let r, g, b, a = 255;
				if (colorType === 3) {
					const index = sample(q);
					assert(index * 3 + 2 < palette.length, "PNG pixel references a missing palette color.");
					r = palette[index * 3];
					g = palette[index * 3 + 1];
					b = palette[index * 3 + 2];
					a = transparency?.[index] ?? 255;
				} else if (colorType === 0 || colorType === 4) {
					const gray = sample(q);
					r = g = b = to8(gray);
					a = colorType === 4 ? to8(sample(q + 1)) : transparency && gray === (transparency[0] << 8 | transparency[1]) ? 0 : 255;
				} else {
					const rv = sample(q), gv = sample(q + 1), bv = sample(q + 2);
					r = to8(rv);
					g = to8(gv);
					b = to8(bv);
					a = colorType === 6 ? to8(sample(q + 3)) : transparency && rv === (transparency[0] << 8 | transparency[1]) && gv === (transparency[2] << 8 | transparency[3]) && bv === (transparency[4] << 8 | transparency[5]) ? 0 : 255;
				}
				rgba.set([
					r,
					g,
					b,
					a
				], out);
			}
			prev = row;
		}
	}
	return {
		width,
		height,
		rgba,
		warnings: [...new Set(warnings)]
	};
}
function importGif(input, options = {}) {
	const data = bytes(input);
	assert(data.length >= 13 && /^GIF8[79]a$/.test(decoder.decode(data.subarray(0, 6))), "Not a GIF image.");
	const reader = new GifReader(data), { width, height } = reader;
	dimensions(width, height);
	const entries = [], canvas = new Uint8Array(width * height * 4), warnings = ["GIF imports use its indexed colors and frame timing; GIF has binary transparency."];
	assert(reader.numFrames() > 0, "GIF has no frames.");
	assert(width * height * reader.numFrames() <= MAX_PIXELS, "GIF animation exceeds the import pixel limit.");
	let previous = null, restore = null;
	const hasGlobalPalette = !!(data[10] & 128), bgOffset = 13 + data[11] * 3;
	const bg = hasGlobalPalette && bgOffset + 2 < data.length ? [
		data[bgOffset],
		data[bgOffset + 1],
		data[bgOffset + 2],
		255
	] : [
		0,
		0,
		0,
		0
	];
	for (let i = 0; i < reader.numFrames(); i++) {
		const info = reader.frameInfo(i);
		if (previous?.disposal === 2) {
			const fill = previous.transparent_index != null ? [
				0,
				0,
				0,
				0
			] : bg;
			for (let y = previous.y; y < previous.y + previous.height; y++) for (let x = previous.x; x < previous.x + previous.width; x++) canvas.set(fill, (y * width + x) * 4);
		} else if (previous?.disposal === 3 && restore) canvas.set(restore);
		if (i === 0 && info.transparent_index == null) for (let p = 0; p < canvas.length; p += 4) canvas.set(bg, p);
		restore = info.disposal === 3 ? canvas.slice() : null;
		const decoded = new Uint8Array(canvas.length);
		reader.decodeAndBlitFrameRGBA(i, decoded);
		for (let p = 0; p < decoded.length; p += 4) if (decoded[p + 3]) canvas.set(decoded.subarray(p, p + 4), p);
		entries.push({
			width,
			height,
			rgba: canvas.slice(),
			durationMs: info.delay ? info.delay * 10 : 100
		});
		previous = info;
	}
	const document = imageDocument(entries, {
		...options,
		name: options.name || "Imported GIF"
	});
	document.metadata.gif = { loopCount: reader.loopCount() };
	return {
		document,
		warnings
	};
}
function importSheet(image, options = {}) {
	const { width, height, rgba } = image;
	dimensions(width, height);
	assert(rgba.length === width * height * 4, "Sprite sheet pixels mismatch.");
	const cellWidth = Number(options.frameWidth || options.cellWidth), cellHeight = Number(options.frameHeight || options.cellHeight), margin = Number(options.margin ?? options.padding ?? 0), spacing = Number(options.spacing || 0);
	dimensions(cellWidth, cellHeight);
	assert([margin, spacing].every((n) => Number.isInteger(n) && n >= 0), "Sheet margin and spacing must be nonnegative integers.");
	const availableColumns = Math.floor((width - margin * 2 + spacing) / (cellWidth + spacing)), columns = options.columns || availableColumns, rows = Math.floor((height - margin * 2 + spacing) / (cellHeight + spacing));
	assert(Number.isInteger(columns) && columns > 0 && columns <= availableColumns && rows > 0, "Frame dimensions do not fit the sheet.");
	const count = options.count ?? columns * rows;
	assert(Number.isInteger(count) && count > 0 && count <= columns * rows, "Requested sheet frame count exceeds available cells.");
	const entries = [];
	for (let i = 0; i < count; i++) {
		const col = options.order === "column" ? Math.floor(i / rows) : i % columns, row = options.order === "column" ? i % rows : Math.floor(i / columns), x = margin + col * (cellWidth + spacing), y = margin + row * (cellHeight + spacing), out = new Uint8Array(cellWidth * cellHeight * 4);
		for (let yy = 0; yy < cellHeight; yy++) out.set(rgba.subarray(((y + yy) * width + x) * 4, ((y + yy) * width + x + cellWidth) * 4), yy * cellWidth * 4);
		entries.push({
			width: cellWidth,
			height: cellHeight,
			rgba: out
		});
	}
	return imageDocument(entries, options);
}
function frameBounds(entry, trim) {
	let x = 0, y = 0, w = entry.width, h = entry.height;
	if (trim) {
		let x1 = w, y1 = h, x2 = -1, y2 = -1;
		for (let py = 0; py < h; py++) for (let px = 0; px < w; px++) if (entry.rgba[(py * w + px) * 4 + 3]) {
			x1 = Math.min(x1, px);
			y1 = Math.min(y1, py);
			x2 = Math.max(x2, px);
			y2 = Math.max(y2, py);
		}
		if (x2 < 0) return {
			x: 0,
			y: 0,
			w: 1,
			h: 1,
			empty: true
		};
		x = x1;
		y = y1;
		w = x2 - x1 + 1;
		h = y2 - y1 + 1;
	}
	return {
		x,
		y,
		w,
		h,
		empty: false
	};
}
const pow2 = (n) => 2 ** Math.ceil(Math.log2(Math.max(1, n)));
function intersects(a, b) {
	return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
}
function maxRects(items, width, height) {
	let free = [{
		x: 0,
		y: 0,
		w: width,
		h: height
	}];
	const placed = [];
	for (const item of items) {
		let best = null;
		for (const f of free) if (item.w <= f.w && item.h <= f.h) {
			const score = [
				Math.min(f.w - item.w, f.h - item.h),
				Math.max(f.w - item.w, f.h - item.h),
				f.y,
				f.x
			];
			if (!best || score.some((v, i) => v < best.score[i] && score.slice(0, i).every((n, j) => n === best.score[j]))) best = {
				x: f.x,
				y: f.y,
				w: item.w,
				h: item.h,
				score
			};
		}
		if (!best) return null;
		const next = [];
		for (const f of free) {
			if (!intersects(f, best)) {
				next.push(f);
				continue;
			}
			if (best.x > f.x) next.push({
				x: f.x,
				y: f.y,
				w: best.x - f.x,
				h: f.h
			});
			if (best.x + best.w < f.x + f.w) next.push({
				x: best.x + best.w,
				y: f.y,
				w: f.x + f.w - best.x - best.w,
				h: f.h
			});
			if (best.y > f.y) next.push({
				x: f.x,
				y: f.y,
				w: f.w,
				h: best.y - f.y
			});
			if (best.y + best.h < f.y + f.h) next.push({
				x: f.x,
				y: best.y + best.h,
				w: f.w,
				h: f.y + f.h - best.y - best.h
			});
		}
		free = next.filter((a, i) => !next.some((b, j) => i !== j && a.x >= b.x && a.y >= b.y && a.x + a.w <= b.x + b.w && a.y + a.h <= b.y + b.h && (a.w !== b.w || a.h !== b.h || i > j)));
		placed.push({
			...item,
			x: best.x,
			y: best.y
		});
	}
	return placed;
}
function blitTrim(atlas, atlasWidth, entry, bounds, x, y, extrude) {
	for (let py = -extrude; py < bounds.h + extrude; py++) for (let px = -extrude; px < bounds.w + extrude; px++) {
		const sx = bounds.x + Math.min(bounds.w - 1, Math.max(0, px)), source = ((bounds.y + Math.min(bounds.h - 1, Math.max(0, py))) * entry.width + sx) * 4, dest = ((y + py) * atlasWidth + x + px) * 4;
		if (!bounds.empty) atlas.set(entry.rgba.subarray(source, source + 4), dest);
	}
}
function packAtlas(entries, options = {}) {
	assert(entries.length > 0, "No frames to pack.");
	const padding = options.padding ?? 1, extrude = options.extrude ?? 0, maxSize = options.maxSize ?? 8192, border = options.border ?? padding;
	assert([
		padding,
		extrude,
		border
	].every((n) => Number.isInteger(n) && n >= 0), "Atlas spacing must be nonnegative integers.");
	assert(Number.isInteger(maxSize) && maxSize > 0 && maxSize <= 16384, "Atlas maxSize must be 1–16384.");
	const names = /* @__PURE__ */ new Set(), items = entries.map((entry, index) => {
		dimensions(entry.width, entry.height);
		assert(entry.rgba.length === entry.width * entry.height * 4, "Atlas frame pixels mismatch.");
		const name = entry.name || entry.id || `frame-${index + 1}`;
		assert(!names.has(name), "Atlas frame names must be unique.");
		names.add(name);
		const bounds = frameBounds(entry, options.trim !== false);
		return {
			index,
			name,
			entry,
			bounds,
			w: bounds.w + extrude * 2 + padding,
			h: bounds.h + extrude * 2 + padding
		};
	}).sort((a, b) => Math.max(b.w, b.h) - Math.max(a.w, a.h) || b.w * b.h - a.w * a.h || a.index - b.index);
	const layout = options.layout || "packed";
	assert([
		"packed",
		"horizontal",
		"vertical",
		"grid"
	].includes(layout), "Unknown atlas layout.");
	let placed, width, height;
	if (layout !== "packed") {
		const ordered = [...items].sort((a, b) => a.index - b.index), columns = layout === "horizontal" ? items.length : layout === "vertical" ? 1 : options.columns || Math.ceil(Math.sqrt(items.length));
		assert(Number.isInteger(columns) && columns > 0, "Atlas columns must be positive.");
		const cw = Math.max(...items.map((i) => i.w)), ch = Math.max(...items.map((i) => i.h));
		placed = ordered.map((item, index) => ({
			...item,
			x: index % columns * cw,
			y: Math.floor(index / columns) * ch
		}));
		width = columns * cw + border * 2;
		height = Math.ceil(items.length / columns) * ch + border * 2;
		if (options.powerOfTwo) {
			width = pow2(width);
			height = pow2(height);
		}
		assert(width <= maxSize && height <= maxSize, "Layout exceeds the maximum atlas size.");
	} else {
		const minW = Math.max(...items.map((i) => i.w)) + border * 2, minH = Math.max(...items.map((i) => i.h)) + border * 2, area = items.reduce((n, i) => n + i.w * i.h, 0), candidates = [];
		assert(!!options.width === !!options.height, "Specify both atlas width and height.");
		if (options.width && options.height) candidates.push([options.width, options.height]);
		else {
			const ws = [], hs = [];
			for (let w = pow2(minW); w <= maxSize; w *= 2) ws.push(w);
			for (let h = pow2(minH); h <= maxSize; h *= 2) hs.push(h);
			if (!options.powerOfTwo) {
				if (!ws.includes(maxSize)) ws.push(maxSize);
				if (!hs.includes(maxSize)) hs.push(maxSize);
			}
			for (const w of ws) for (const h of hs) if ((w - border * 2) * (h - border * 2) >= area) candidates.push([w, h]);
		}
		candidates.sort((a, b) => a[0] * a[1] - b[0] * b[1] || Math.abs(a[0] - a[1]) - Math.abs(b[0] - b[1]));
		for (const [w, h] of candidates) {
			if (w > maxSize || h > maxSize || w <= border * 2 || h <= border * 2) continue;
			const result = maxRects(items, w - border * 2, h - border * 2);
			if (result) {
				placed = result;
				width = w;
				height = h;
				break;
			}
		}
		assert(placed, "Frames do not fit the maximum atlas size; increase maxSize or export fewer frames.");
		if (!options.powerOfTwo && !options.width && !options.height) {
			width = Math.max(...placed.map((i) => i.x + i.w)) + border * 2;
			height = Math.max(...placed.map((i) => i.y + i.h)) + border * 2;
		}
	}
	dimensions(width, height);
	const rgba = new Uint8Array(width * height * 4), frames = [];
	for (const item of placed) {
		const x = item.x + border + extrude, y = item.y + border + extrude;
		blitTrim(rgba, width, item.entry, item.bounds, x, y, extrude);
		frames.push({
			filename: item.name,
			id: item.entry.id || item.name,
			frame: {
				x,
				y,
				w: item.bounds.w,
				h: item.bounds.h
			},
			rotated: false,
			trimmed: item.bounds.w !== item.entry.width || item.bounds.h !== item.entry.height || item.bounds.x !== 0 || item.bounds.y !== 0,
			spriteSourceSize: {
				x: item.bounds.x,
				y: item.bounds.y,
				w: item.bounds.w,
				h: item.bounds.h
			},
			sourceSize: {
				w: item.entry.width,
				h: item.entry.height
			},
			duration: item.entry.durationMs || 100,
			empty: item.bounds.empty,
			pivot: item.entry.pivot || {
				x: .5,
				y: .5
			},
			index: item.index
		});
	}
	frames.sort((a, b) => a.index - b.index);
	const scale = options.scale ?? 1;
	assert(Number.isFinite(Number(scale)) && Number(scale) > 0, "Atlas metadata scale must be positive.");
	const scaleBounds = (value) => value ? Object.fromEntries(Object.entries(value).map(([key, v]) => [key, [
		"x",
		"y",
		"width",
		"height"
	].includes(key) && typeof v === "number" ? v * Number(scale) : v])) : value;
	const slices = (options.slices || []).map((slice) => ({
		...slice,
		...slice.bounds ? { bounds: scaleBounds(slice.bounds) } : {},
		...slice.pivot ? { pivot: scaleBounds(slice.pivot) } : {},
		...slice.ninePatch ? { ninePatch: scaleBounds(slice.ninePatch) } : {},
		...slice.keys ? { keys: slice.keys.map((key) => ({
			...scaleBounds(key),
			...key.pivot ? { pivot: scaleBounds(key.pivot) } : {},
			...key.center ? { center: scaleBounds(key.center) } : {}
		})) } : {}
	}));
	const frameTags = (options.clips || []).flatMap((clip) => {
		const indices = entries.map((entry, index) => clip.frameIds?.includes(entry.id) ? index : -1).filter((index) => index >= 0);
		return indices.length ? [{
			...clip,
			from: indices[0],
			to: indices.at(-1),
			frameIndices: indices,
			sourceFrameIds: clip.frameIds,
			frameIds: indices.map((i) => entries[i].id),
			partial: clip.frameIds.some((id) => !entries.some((e) => e.id === id))
		}] : [];
	});
	return {
		width,
		height,
		rgba,
		frames,
		meta: {
			app: "PixelWall",
			version: "4",
			image: options.imageName || "atlas.png",
			format: "RGBA8888",
			size: {
				w: width,
				h: height
			},
			scale: String(scale),
			padding,
			extrude,
			border,
			layout,
			powerOfTwo: !!options.powerOfTwo,
			frameTags,
			sourceClips: options.clips || [],
			slices,
			sourceSlices: options.slices || []
		}
	};
}
function makeSpriteSheet(entries, options = {}) {
	assert(entries.length > 0, "No frames to export.");
	const cellWidth = Math.max(...entries.map((e) => e.width)), cellHeight = Math.max(...entries.map((e) => e.height)), columns = options.columns || entries.length, padding = options.padding || 0;
	assert(Number.isInteger(columns) && columns > 0 && Number.isInteger(padding) && padding >= 0, "Invalid sheet columns/padding.");
	const rows = Math.ceil(entries.length / columns), width = columns * cellWidth + (columns - 1) * padding, height = rows * cellHeight + (rows - 1) * padding;
	dimensions(width, height);
	const rgba = new Uint8Array(width * height * 4), frames = [];
	entries.forEach((entry, i) => {
		const x = i % columns * (cellWidth + padding), y = Math.floor(i / columns) * (cellHeight + padding);
		blitTrim(rgba, width, entry, {
			x: 0,
			y: 0,
			w: entry.width,
			h: entry.height
		}, x, y, 0);
		frames.push({
			filename: entry.name || `frame-${i + 1}`,
			frame: {
				x,
				y,
				w: entry.width,
				h: entry.height
			},
			duration: entry.durationMs || 100
		});
	});
	return {
		width,
		height,
		rgba,
		frames,
		meta: {
			app: "PixelWall",
			size: {
				w: width,
				h: height
			},
			columns,
			rows,
			padding
		}
	};
}
function encodeGif(entries, options = {}) {
	assert(entries.length > 0, "No GIF frames.");
	const { width, height } = entries[0];
	dimensions(width, height);
	assert(width <= 65535 && height <= 65535, "GIF dimensions exceed limit.");
	assert(entries.every((e) => e.width === width && e.height === height), "GIF frames must share dimensions.");
	const buffer = new Uint8Array(Math.max(4096, width * height * entries.length * 2 + entries.length * 1024)), writer = new GifWriter(buffer, width, height, options.loop === -1 ? {} : { loop: options.loop ?? 0 });
	for (const entry of entries) {
		const exact = /* @__PURE__ */ new Map(), pixels = entry.rgba;
		assert(pixels.length === width * height * 4, "GIF pixel count mismatch.");
		for (let p = 0; p < pixels.length; p += 4) if (pixels[p + 3] >= 128) {
			const value = pixels[p] * 65536 + pixels[p + 1] * 256 + pixels[p + 2];
			if (!exact.has(value)) exact.set(value, exact.size + 1);
			if (exact.size > 255) break;
		}
		let palette = [0], indices = new Uint8Array(width * height);
		if (exact.size <= 255) {
			palette.push(...exact.keys());
			for (let i = 0; i < indices.length; i++) {
				const p = i * 4;
				indices[i] = pixels[p + 3] >= 128 ? exact.get(pixels[p] * 65536 + pixels[p + 1] * 256 + pixels[p + 2]) : 0;
			}
		} else {
			for (let r = 0; r < 6; r++) for (let g = 0; g < 6; g++) for (let b = 0; b < 6; b++) palette.push(r * 51 * 65536 + g * 51 * 256 + b * 51);
			for (let i = 0; i < indices.length; i++) {
				const p = i * 4;
				indices[i] = pixels[p + 3] >= 128 ? 1 + Math.round(pixels[p] / 51) * 36 + Math.round(pixels[p + 1] / 51) * 6 + Math.round(pixels[p + 2] / 51) : 0;
			}
		}
		while (palette.length < pow2(palette.length)) palette.push(0);
		if (palette.length < 2) palette.push(0);
		writer.addFrame(0, 0, width, height, indices, {
			palette,
			transparent: 0,
			disposal: 2,
			delay: Math.max(1, Math.min(65535, Math.round((entry.durationMs || 100) / 10)))
		});
	}
	return buffer.slice(0, writer.end());
}
/** Windows BMP: RGB, indexed, bitfields and RLE4/RLE8. */
function readBmp(input) {
	const data = bytes(input), r = new Reader(data);
	assert(data.length >= 26 && r.u16() === 19778, "Not a BMP image.");
	const fileSize = r.u32();
	r.skip(4);
	const pixelOffset = r.u32(), headerSize = r.u32();
	assert(fileSize === 0 || fileSize <= data.length, "Truncated BMP file.");
	assert(headerSize === 12 || [
		40,
		52,
		56,
		108,
		124
	].includes(headerSize), "Unsupported BMP header version.");
	assert(14 + headerSize <= data.length && pixelOffset >= 14 + headerSize && pixelOffset <= data.length, "Invalid BMP pixel offset.");
	let width, height, topDown = false, bits, compression = 0, colorCount = 0;
	const warnings = [];
	let maskR = 0, maskG = 0, maskB = 0, maskA = 0;
	if (headerSize === 12) {
		width = r.u16();
		height = r.u16();
		assert(r.u16() === 1, "Invalid BMP planes.");
		bits = r.u16();
	} else {
		width = r.i32();
		const signedHeight = r.i32();
		topDown = signedHeight < 0;
		height = Math.abs(signedHeight);
		assert(r.u16() === 1, "Invalid BMP planes.");
		bits = r.u16();
		compression = r.u32();
		r.skip(12);
		colorCount = r.u32();
		r.skip(4);
		if (headerSize >= 52) {
			maskR = r.u32();
			maskG = r.u32();
			maskB = r.u32();
			if (headerSize >= 56) maskA = r.u32();
		}
		if (headerSize >= 108) {
			r.p = 70;
			const space = r.u32();
			if (![1934772034, 1466527264].includes(space)) warnings.push("BMP calibrated or embedded color profile is not converted; imported pixels use sRGB.");
		}
	}
	dimensions(width, height);
	assert([
		1,
		4,
		8,
		16,
		24,
		32
	].includes(bits), "Unsupported BMP bit depth.");
	assert([
		0,
		1,
		2,
		3,
		6
	].includes(compression), "Unsupported BMP compression (JPEG/PNG-embedded BMP is not supported).");
	assert(compression !== 1 || bits === 8, "BMP RLE8 requires 8-bit pixels.");
	assert(compression !== 2 || bits === 4, "BMP RLE4 requires 4-bit pixels.");
	assert(![3, 6].includes(compression) || [16, 32].includes(bits), "BMP bitfields require 16 or 32 bits.");
	assert(!topDown || [
		0,
		3,
		6
	].includes(compression), "Top-down RLE BMP is invalid.");
	r.p = 14 + headerSize;
	if ([3, 6].includes(compression) && headerSize === 40) {
		maskR = r.u32();
		maskG = r.u32();
		maskB = r.u32();
		if (compression === 6) maskA = r.u32();
	}
	if (![3, 6].includes(compression)) {
		if (bits === 16) {
			maskR = 31744;
			maskG = 992;
			maskB = 31;
			maskA = 0;
		} else if (bits === 32) {
			maskR = 16711680;
			maskG = 65280;
			maskB = 255;
			maskA = 0;
		}
	}
	function channel(value, mask, defaultValue = 0) {
		if (!mask) return defaultValue;
		mask >>>= 0;
		let shift = 0;
		while ((mask >>> shift & 1) === 0 && shift < 32) shift++;
		const max = mask >>> shift;
		assert((max & max + 1) === 0, "Noncontiguous BMP channel mask.");
		return Math.round(((value & mask) >>> 0) / 2 ** shift * 255 / max);
	}
	if ([16, 32].includes(bits)) assert(maskR && maskG && maskB && !(maskR & maskG) && !(maskR & maskB) && !(maskG & maskB) && !(maskA & (maskR | maskG | maskB)), "Invalid overlapping BMP bit masks.");
	const palette = [];
	if (bits <= 8) {
		const count = colorCount || 2 ** bits;
		assert(count <= 2 ** bits, "BMP palette exceeds bit depth.");
		for (let i = 0; i < count; i++) {
			const b = r.u8(), g = r.u8(), red = r.u8();
			if (headerSize !== 12) r.skip(1);
			palette.push([
				red,
				g,
				b,
				255
			]);
		}
		assert(r.p <= pixelOffset, "BMP palette overlaps pixels.");
	}
	const rgba = new Uint8Array(width * height * 4), put = (x, y, index) => {
		assert(x >= 0 && x < width && y >= 0 && y < height, "BMP RLE coordinates exceed the image.");
		assert(palette[index], "BMP index refers to a missing palette color.");
		rgba.set(palette[index], ((topDown ? y : height - 1 - y) * width + x) * 4);
	};
	r.p = pixelOffset;
	if (compression === 1 || compression === 2) {
		for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) put(x, y, 0);
		let x = 0, y = 0, ended = false;
		while (r.p < data.length && !ended) {
			const count = r.u8(), value = r.u8();
			if (count) for (let i = 0; i < count; i++) put(x++, y, compression === 1 ? value : i % 2 ? value & 15 : value >>> 4);
			else if (value === 0) {
				x = 0;
				y++;
			} else if (value === 1) ended = true;
			else if (value === 2) {
				x += r.u8();
				y += r.u8();
				assert(x <= width && y < height, "BMP RLE delta exceeds image.");
			} else {
				const n = value, byteCount = compression === 1 ? n : Math.ceil(n / 2), packet = r.take(byteCount);
				for (let i = 0; i < n; i++) put(x++, y, compression === 1 ? packet[i] : i % 2 ? packet[i >> 1] & 15 : packet[i >> 1] >>> 4);
				if (byteCount % 2) r.skip(1);
			}
		}
		assert(ended, "BMP RLE has no end-of-bitmap marker.");
	} else {
		const stride = Math.ceil(width * bits / 32) * 4;
		assert(pixelOffset + stride * height <= data.length, "Truncated BMP raster.");
		for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
			const p = pixelOffset + y * stride + Math.floor(x * bits / 8), out = ((topDown ? y : height - 1 - y) * width + x) * 4;
			let color;
			if (bits <= 8) {
				const index = bits === 8 ? data[p] : bits === 4 ? x % 2 ? data[p] & 15 : data[p] >>> 4 : data[p] >>> 7 - x % 8 & 1;
				assert(palette[index], "BMP index refers to a missing palette color.");
				color = palette[index];
			} else if (bits === 24) color = [
				data[p + 2],
				data[p + 1],
				data[p],
				255
			];
			else {
				const value = bits === 16 ? data[p] | data[p + 1] << 8 : (data[p] | data[p + 1] << 8 | data[p + 2] << 16 | data[p + 3] << 24) >>> 0;
				color = [
					channel(value, maskR),
					channel(value, maskG),
					channel(value, maskB),
					channel(value, maskA, 255)
				];
			}
			rgba.set(color, out);
		}
	}
	return {
		width,
		height,
		rgba,
		warnings
	};
}
/** Emits a BITMAPV5HEADER with explicit RGBA masks and sRGB color space. */
function writeBmp(width, height, rgba) {
	dimensions(width, height);
	assert(rgba.length === width * height * 4, "BMP pixel data length mismatch.");
	const offset = 138, header = new Writer().u16(19778).u32(offset + rgba.length).zero(4).u32(offset).u32(124).i32(width).i32(-height).u16(1).u16(32).u32(3).u32(rgba.length).i32(2835).i32(2835).u32(0).u32(0).u32(16711680).u32(65280).u32(255).u32(4278190080).u32(1934772034).zero(36).zero(12).u32(4).zero(12);
	const raster = new Uint8Array(rgba.length);
	for (let i = 0; i < rgba.length; i += 4) raster.set([
		rgba[i + 2],
		rgba[i + 1],
		rgba[i],
		rgba[i + 3]
	], i);
	return concat([header.done(), raster]);
}
/** Truevision TGA v1/v2: indexed, truecolor and gray, raw or RLE. */
function readTga(input) {
	const data = bytes(input), r = new Reader(data);
	assert(data.length >= 18, "TGA header is truncated.");
	const idLength = r.u8(), colorMapType = r.u8(), type = r.u8(), mapFirst = r.u16(), mapLength = r.u16(), mapBits = r.u8(), xOrigin = r.u16(), yOrigin = r.u16(), width = r.u16(), height = r.u16(), bits = r.u8(), descriptor = r.u8();
	dimensions(width, height);
	assert([
		1,
		2,
		3,
		9,
		10,
		11
	].includes(type) && colorMapType <= 1, "Unsupported TGA image type.");
	assert((descriptor & 192) === 0, "Interleaved TGA images are unsupported.");
	const indexed = type === 1 || type === 9, gray = type === 3 || type === 11, rle = type >= 9;
	assert(!indexed || colorMapType === 1, "Indexed TGA requires a color map.");
	assert(indexed ? [8, 16].includes(bits) : gray ? [8, 16].includes(bits) : [
		15,
		16,
		24,
		32
	].includes(bits), "Unsupported TGA pixel depth.");
	r.skip(idLength);
	const warnings = [];
	let attributeType = null, footerStart = data.length;
	if (data.length >= 26 && decoder.decode(data.subarray(data.length - 18, data.length - 1)) === "TRUEVISION-XFILE.") {
		footerStart = data.length - 26;
		const footer = new Reader(data.subarray(footerStart)), extensionOffset = footer.u32(), developerOffset = footer.u32();
		if (extensionOffset) {
			assert(extensionOffset + 495 <= footerStart, "Truncated TGA extension.");
			attributeType = data[extensionOffset + 494];
			if (data[extensionOffset + 478] || data[extensionOffset + 479] || data[extensionOffset + 480] || data[extensionOffset + 481]) warnings.push("TGA gamma metadata is not converted; imported pixels use sRGB.");
			if (data.subarray(extensionOffset + 2, extensionOffset + 494).some((v) => v !== 0)) warnings.push("TGA extension metadata is not retained in the raster project.");
		}
		if (developerOffset) warnings.push("TGA developer metadata is not retained in the raster project.");
	}
	const alphaBits = descriptor & 15;
	function readColor(depth, isGray = false, fromPalette = false) {
		if (isGray) {
			const v = r.u8();
			return [
				v,
				v,
				v,
				depth === 16 ? r.u8() : 255
			];
		}
		if (depth === 15 || depth === 16) {
			const v = r.u16();
			return [
				Math.round((v >> 10 & 31) * 255 / 31),
				Math.round((v >> 5 & 31) * 255 / 31),
				Math.round((v & 31) * 255 / 31),
				depth === 16 && (alphaBits || fromPalette) ? v & 32768 ? 255 : 0 : 255
			];
		}
		const b = r.u8(), g = r.u8(), red = r.u8(), a = depth === 32 ? r.u8() : 255;
		return [
			red,
			g,
			b,
			depth === 32 && (fromPalette || alphaBits > 0 || attributeType === 3 || attributeType === 4) ? a : 255
		];
	}
	const palette = [];
	if (colorMapType === 1) {
		assert([
			15,
			16,
			24,
			32
		].includes(mapBits), "Unsupported TGA palette entry depth.");
		for (let i = 0; i < mapLength; i++) palette[mapFirst + i] = readColor(mapBits, false, true);
	}
	const readPixel = () => {
		if (indexed) {
			const index = bits === 8 ? r.u8() : r.u16();
			assert(palette[index], "TGA pixel references a missing palette color.");
			return palette[index];
		}
		return readColor(bits, gray);
	}, rgba = new Uint8Array(width * height * 4);
	let written = 0;
	const put = (color) => {
		assert(written < width * height, "TGA RLE packet exceeds image size.");
		let x = written % width, y = Math.floor(written / width);
		if (descriptor & 16) x = width - 1 - x;
		if (!(descriptor & 32)) y = height - 1 - y;
		let [red, g, b, a] = color;
		if (attributeType === 0 || attributeType === 1) a = 255;
		else if (attributeType === 4 && a > 0) {
			red = Math.min(255, Math.round(red * 255 / a));
			g = Math.min(255, Math.round(g * 255 / a));
			b = Math.min(255, Math.round(b * 255 / a));
		}
		rgba.set([
			red,
			g,
			b,
			a
		], (y * width + x) * 4);
		written++;
	};
	while (written < width * height) {
		if (!rle) {
			put(readPixel());
			continue;
		}
		const packet = r.u8(), count = (packet & 127) + 1;
		assert(written + count <= width * height, "TGA RLE packet exceeds dimensions.");
		if (packet & 128) {
			const color = readPixel();
			for (let i = 0; i < count; i++) put(color);
		} else for (let i = 0; i < count; i++) put(readPixel());
	}
	assert(r.p <= footerStart, "TGA pixels overlap its footer.");
	if (xOrigin || yOrigin) warnings.push(`TGA origin (${xOrigin}, ${yOrigin}) is not applied to the raster canvas.`);
	return {
		width,
		height,
		rgba,
		warnings: [...new Set(warnings)]
	};
}
/** Top-left BGRA TGA v2 with straight alpha. */
function writeTga(width, height, rgba, options = {}) {
	dimensions(width, height);
	assert(width <= 65535 && height <= 65535 && rgba.length === width * height * 4, "TGA dimensions or pixels are invalid.");
	const useRle = options.rle !== false, w = new Writer().u8(0).u8(0).u8(useRle ? 10 : 2).zero(9).u16(width).u16(height).u8(32).u8(40), put = (i) => w.raw([
		rgba[i * 4 + 2],
		rgba[i * 4 + 1],
		rgba[i * 4],
		rgba[i * 4 + 3]
	]), equal = (a, b) => rgba[a * 4] === rgba[b * 4] && rgba[a * 4 + 1] === rgba[b * 4 + 1] && rgba[a * 4 + 2] === rgba[b * 4 + 2] && rgba[a * 4 + 3] === rgba[b * 4 + 3];
	if (!useRle) for (let i = 0; i < width * height; i++) put(i);
	else for (let y = 0; y < height; y++) {
		let i = y * width, end = i + width;
		while (i < end) {
			let run = 1;
			while (i + run < end && run < 128 && equal(i, i + run)) run++;
			if (run > 1) {
				w.u8(128 | run - 1);
				put(i);
				i += run;
			} else {
				const start = i++;
				while (i < end && i - start < 128 && !(i + 1 < end && equal(i, i + 1))) i++;
				w.u8(i - start - 1);
				for (let j = start; j < i; j++) put(j);
			}
		}
	}
	const body = w.done();
	return concat([
		body,
		new Writer().u16(495).zero(492).u8(3).done(),
		new Writer().u32(body.length).u32(0).raw(encoder$1.encode("TRUEVISION-XFILE.")).u8(0).done()
	]);
}
/** Game-ready PNG assets, metadata, native project and per-frame Tiled maps.
* The caller MUST authorize Pro before invoking this function. */
function makeGamePackage(doc, options = {}) {
	const safe = (value) => String(value || "asset").replace(/[^a-z0-9_.-]/gi, "_"), json = (value) => strToU8(JSON.stringify(value, null, 2)), entries = options.entries || doc.frames.map((f, i) => ({
		id: f.id,
		name: `${safe(doc.name)}-${String(i + 1).padStart(4, "0")}`,
		width: doc.width,
		height: doc.height,
		rgba: renderFrame(doc, f.id),
		durationMs: f.durationMs
	}));
	const atlas = options.atlas || packAtlas(entries, {
		...options,
		clips: doc.clips,
		slices: doc.slices,
		imageName: "sprites.png"
	}), files = {
		"sprites.png": writePng(atlas.width, atlas.height, atlas.rgba),
		"sprites.json": json({
			frames: atlas.frames,
			meta: {
				...atlas.meta,
				image: "sprites.png",
				clips: doc.clips,
				slices: atlas.meta.slices || doc.slices,
				sourceSlices: doc.slices
			}
		}),
		[`${safe(doc.name)}.pixelwall`]: json(doc)
	}, manifest = {
		format: "pixelwall-game-package",
		version: 1,
		frameScale: atlas.meta.scale || "1",
		tilemapScale: "1",
		project: `${safe(doc.name)}.pixelwall`,
		atlas: {
			image: "sprites.png",
			metadata: "sprites.json"
		},
		frames: [],
		tilesets: [],
		maps: [],
		clips: doc.clips,
		slices: doc.slices,
		warnings: []
	};
	for (const [index, entry] of entries.entries()) {
		const path = `frames/${String(index + 1).padStart(4, "0")}-${safe(entry.name || entry.id)}.png`;
		files[path] = writePng(entry.width, entry.height, entry.rgba);
		manifest.frames.push({
			frameId: entry.id || doc.frames[index]?.id,
			image: path,
			width: entry.width,
			height: entry.height,
			durationMs: entry.durationMs || entry.duration || 100
		});
	}
	const palettes = [], framePalettes = /* @__PURE__ */ new Map();
	let currentPalette = doc.palette;
	for (const frame of doc.frames) {
		if (frame.palette) currentPalette = frame.palette;
		const key = doc.colorMode === "indexed" ? JSON.stringify(currentPalette) : "rgba";
		let index = palettes.findIndex((v) => v.key === key);
		if (index < 0) {
			index = palettes.length;
			palettes.push({
				key,
				palette: currentPalette
			});
		}
		framePalettes.set(frame.id, index);
	}
	const sets = /* @__PURE__ */ new Map();
	let firstgid = 1;
	for (const [tsi, ts] of (doc.tilesets || []).entries()) {
		const tiles = [];
		if (ts.tiles?.length) for (const tile of ts.tiles) {
			const image = tileImage(doc, tile);
			tiles.push({
				sourceId: tile.id,
				asepriteTileId: tile.asepriteTileId,
				image,
				width: image.width,
				height: image.height
			});
		}
		else if (ts.imageId) {
			const image = doc.images[ts.imageId];
			assert(image && !image.tilemap, "Embedded tileset image is missing.");
			const columns = Math.floor(image.width / ts.tileWidth), count = ts.tileCount ?? columns * Math.floor(image.height / ts.tileHeight);
			for (let index = 0; index < count; index++) {
				const sx = index % columns * ts.tileWidth, sy = Math.floor(index / columns) * ts.tileHeight, pixels = [];
				assert(sx + ts.tileWidth <= image.width && sy + ts.tileHeight <= image.height, "Tileset dimensions exceed its atlas.");
				for (let y = 0; y < ts.tileHeight; y++) for (let x = 0; x < ts.tileWidth; x++) pixels.push(image.pixels[(sy + y) * image.width + sx + x]);
				tiles.push({
					sourceId: index,
					image: {
						width: ts.tileWidth,
						height: ts.tileHeight,
						pixels
					},
					width: ts.tileWidth,
					height: ts.tileHeight
				});
			}
		} else throw new Error(`Tileset “${ts.name}” has no embedded pixel data. Load its external source before exporting a game package.`);
		const localIds = /* @__PURE__ */ new Map();
		tiles.forEach((tile, i) => {
			localIds.set(tile.sourceId, i);
			if (Number.isInteger(tile.asepriteTileId)) localIds.set(tile.asepriteTileId, i);
		});
		const info = {
			firstgid,
			tiles,
			localIds,
			variants: []
		};
		firstgid += tiles.length;
		assert(firstgid < 268435456, "Tiled global tile IDs exceed their supported range.");
		sets.set(ts.id, info);
		for (const [pi, variant] of palettes.entries()) {
			const folder = `tilesets/${tsi + 1}-${safe(ts.name)}${palettes.length > 1 ? `-palette-${pi + 1}` : ""}`, path = `${folder}/tileset.tsj`, tileDefs = [];
			for (const [index, tile] of tiles.entries()) {
				let palette = variant.palette;
				if (doc.colorMode === "indexed" && Number.isInteger(doc.metadata?.aseprite?.transparentIndex)) {
					palette = [...palette];
					palette[doc.metadata.aseprite.transparentIndex] = "#00000000";
				}
				const imagePath = `tile-${String(index).padStart(4, "0")}.png`;
				files[`${folder}/${imagePath}`] = writePng(tile.width, tile.height, pixelsToRgba(tile.image.pixels, palette));
				tileDefs.push({
					id: index,
					image: imagePath,
					imagewidth: tile.width,
					imageheight: tile.height,
					properties: [{
						name: "pixelwallTileId",
						type: "string",
						value: String(tile.sourceId)
					}]
				});
			}
			files[path] = json({
				type: "tileset",
				version: "1.10",
				name: ts.name,
				tilewidth: ts.tileWidth,
				tileheight: ts.tileHeight,
				tilecount: tiles.length,
				columns: 0,
				margin: 0,
				spacing: 0,
				tiles: tileDefs,
				transformations: {
					hflip: true,
					vflip: true,
					rotate: true,
					preferuntransformed: true
				}
			});
			files[`${folder}/pixelwall-tileset.json`] = json({
				...ts,
				exportedTiles: tileDefs.map((t) => ({
					id: tiles[t.id].sourceId,
					image: `${folder}/${t.image}`
				}))
			});
			info.variants.push(path);
			manifest.tilesets.push({
				id: ts.id,
				name: ts.name,
				firstgid: info.firstgid,
				paletteIndex: pi,
				source: path,
				tileWidth: ts.tileWidth,
				tileHeight: ts.tileHeight,
				count: tiles.length
			});
		}
	}
	function transformGid(gid, cell) {
		let fx = !!cell.flipX, fy = !!cell.flipY, diagonal = false;
		const rotation = ((cell.rotate || 0) % 360 + 360) % 360;
		assert([
			0,
			90,
			180,
			270
		].includes(rotation), "Tiled tiles require quarter-turn rotations.");
		if (rotation === 90) {
			diagonal = true;
			[fx, fy] = [!fy, fx];
		}
		if (rotation === 180) {
			fx = !fx;
			fy = !fy;
		}
		if (rotation === 270) {
			diagonal = true;
			[fx, fy] = [fy, !fx];
		}
		return (gid | (fx ? 2147483648 : 0) | (fy ? 1073741824 : 0) | (diagonal ? 536870912 : 0)) >>> 0;
	}
	const selectedFrameIds = new Set(entries.map((entry) => entry.id).filter(Boolean));
	for (const [fi, frame] of doc.frames.entries()) {
		if (selectedFrameIds.size && !selectedFrameIds.has(frame.id)) continue;
		const groups = /* @__PURE__ */ new Map();
		for (const layer of doc.layers) {
			if (layer.type !== "tilemap") continue;
			const native = layer.tilemaps?.[frame.id], cel = frame.cels[layer.id], image = doc.images[cel?.imageId], ase = image?.tilemap, tilesetId = native?.tilesetId || layer.tilesetId;
			if (!native && !ase) continue;
			const ts = doc.tilesets.find((t) => t.id === tilesetId), info = sets.get(tilesetId);
			assert(ts && info, "Tilemap has no exported tileset.");
			const columns = native?.columns || image.width, rows = native?.rows || image.height, key = `${ts.tileWidth}x${ts.tileHeight}`;
			if (!groups.has(key)) groups.set(key, {
				tilewidth: ts.tileWidth,
				tileheight: ts.tileHeight,
				layers: [],
				sets: /* @__PURE__ */ new Set()
			});
			const group = groups.get(key), data = native ? native.cells.map((cell) => {
				if (cell == null) return 0;
				const id = info.localIds.get(cell.tileId);
				assert(id != null, "Tilemap refers to a missing tile.");
				return transformGid(info.firstgid + id, cell);
			}) : ase.tiles.map((value) => {
				const raw = value >>> 0, index = (raw & ase.idMask) >>> 0;
				if (ts.flags & 4 ? index === 0 : raw === 4294967295) return 0;
				const localId = info.localIds.get(index);
				assert(localId != null, "Aseprite tilemap refers to a missing tile.");
				let fx = !!(raw & ase.xFlipMask), fy = !!(raw & ase.yFlipMask);
				const diagonal = !!(raw & ase.diagonalFlipMask);
				if (diagonal) [fx, fy] = [fy, fx];
				return (info.firstgid + localId | (fx ? 2147483648 : 0) | (fy ? 1073741824 : 0) | (diagonal ? 536870912 : 0)) >>> 0;
			});
			let opacity = (layer.opacity ?? 1) * (native ? native.opacity ?? 1 : cel.opacity ?? 1), visible = layer.visible !== false, parent = layer.parentId;
			while (parent) {
				const ancestor = doc.layers.find((l) => l.id === parent);
				assert(ancestor, "Tilemap group parent is missing.");
				opacity *= ancestor.opacity ?? 1;
				visible &&= ancestor.visible !== false;
				parent = ancestor.parentId;
			}
			const mode = layer.blendMode === "addition" ? "add" : layer.blendMode || "normal";
			if (![
				"normal",
				"add",
				"multiply",
				"screen",
				"overlay",
				"darken",
				"lighten",
				"color-dodge",
				"color-burn",
				"hard-light",
				"soft-light",
				"difference",
				"exclusion"
			].includes(mode)) manifest.warnings.push(`Tiled does not support the ${mode} blend mode on “${layer.name}”; the original setting is retained as a property and in the project.`);
			group.layers.push({
				type: "tilelayer",
				id: group.layers.length + 1,
				name: layer.name,
				width: columns,
				height: rows,
				x: 0,
				y: 0,
				offsetx: native ? native.x || 0 : cel.x,
				offsety: native ? native.y || 0 : cel.y,
				opacity,
				visible,
				locked: !!layer.locked,
				mode: [
					"normal",
					"add",
					"multiply",
					"screen",
					"overlay",
					"darken",
					"lighten",
					"color-dodge",
					"color-burn",
					"hard-light",
					"soft-light",
					"difference",
					"exclusion"
				].includes(mode) ? mode : "normal",
				data,
				properties: [
					{
						name: "pixelwallLayerId",
						type: "string",
						value: layer.id
					},
					{
						name: "pixelwallParentId",
						type: "string",
						value: layer.parentId || ""
					},
					{
						name: "pixelwallBlendMode",
						type: "string",
						value: layer.blendMode || "normal"
					}
				]
			});
			group.sets.add(tilesetId);
		}
		for (const [grid, group] of groups) {
			const width = Math.max(Math.ceil(doc.width / group.tilewidth), ...group.layers.map((l) => l.width)), height = Math.max(Math.ceil(doc.height / group.tileheight), ...group.layers.map((l) => l.height));
			for (const layer of group.layers) if (layer.width !== width || layer.height !== height) {
				const data = new Array(width * height).fill(0);
				for (let y = 0; y < layer.height; y++) for (let x = 0; x < layer.width; x++) data[y * width + x] = layer.data[y * layer.width + x];
				layer.width = width;
				layer.height = height;
				layer.data = data;
			}
			const path = `maps/frame-${String(fi + 1).padStart(4, "0")}-${grid}.tmj`;
			files[path] = json({
				type: "map",
				version: "1.10",
				orientation: "orthogonal",
				renderorder: "right-down",
				infinite: false,
				width,
				height,
				tilewidth: group.tilewidth,
				tileheight: group.tileheight,
				nextlayerid: group.layers.length + 1,
				nextobjectid: 1,
				layers: group.layers,
				tilesets: [...sets.keys()].map((id) => {
					const info = sets.get(id);
					return {
						firstgid: info.firstgid,
						source: `../${info.variants[framePalettes.get(frame.id)]}`
					};
				}),
				properties: [{
					name: "pixelwallFrameId",
					type: "string",
					value: frame.id
				}, {
					name: "durationMs",
					type: "int",
					value: frame.durationMs
				}]
			});
			manifest.maps.push({
				frameId: frame.id,
				durationMs: frame.durationMs,
				grid,
				source: path
			});
		}
	}
	if (manifest.maps.length && doc.layers.some((l) => l.type !== "tilemap")) manifest.warnings.push("Tiled maps contain the tilemap layers. Rendered frame PNGs and the native project retain all raster and group artwork.");
	manifest.warnings = [...new Set(manifest.warnings)];
	files["manifest.json"] = json(manifest);
	return zipSync(files);
}
const encoder = new TextEncoder();
function fromBase64url(value) {
	if (!/^[A-Za-z0-9_-]+$/.test(value)) throw new Error("Invalid license encoding");
	const raw = atob(value.replace(/-/g, "+").replace(/_/g, "/").padEnd(Math.ceil(value.length / 4) * 4, "="));
	return Uint8Array.from(raw, (char) => char.charCodeAt(0));
}
function parsePublicKeys(value) {
	if (typeof value === "string") try {
		value = JSON.parse(value);
	} catch {
		return {};
	}
	if (!value || typeof value !== "object" || Array.isArray(value)) return {};
	return Object.fromEntries(Object.entries(value).filter(([id, key]) => /^[A-Za-z0-9_-]{1,64}$/.test(id) && key?.kty === "EC" && key.crv === "P-256" && typeof key.x === "string" && typeof key.y === "string" && !key.d));
}
/** Returns verified claims or null. A disconnected clock never expires a purchase.
* @param {string} token
* @param {{publicKeys?: Record<string, JsonWebKey> | string, mode?: string, crypto?: Crypto}} [options]
*/
async function verifyOfflineLicense(token, { publicKeys, mode = "live", crypto = globalThis.crypto } = {}) {
	try {
		if (typeof token !== "string" || token.length > 4096 || !crypto?.subtle) return null;
		const parts = token.trim().split(".");
		if (parts.length !== 3 || parts[0] !== "PW2") return null;
		const payloadBytes = fromBase64url(parts[1]);
		const signature = fromBase64url(parts[2]);
		if (signature.length !== 64 || payloadBytes.length > 2e3) return null;
		const claims = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(payloadBytes));
		if (claims.version !== 2 || claims.product !== "pixelwall-pro" || claims.mode !== mode || !["live", "test"].includes(claims.mode) || !/^cs_(test|live)_[a-zA-Z0-9]{8,200}$/.test(claims.purchaseId) || !claims.purchaseId.startsWith(`cs_${mode}_`) || !Number.isSafeInteger(claims.issuedAt) || claims.issuedAt <= 0 || claims.perpetual !== true || Object.hasOwn(claims, "expiresAt")) return null;
		const jwk = parsePublicKeys(publicKeys)[claims.keyId];
		if (!jwk) return null;
		const key = await crypto.subtle.importKey("jwk", jwk, {
			name: "ECDSA",
			namedCurve: "P-256"
		}, false, ["verify"]);
		return await crypto.subtle.verify({
			name: "ECDSA",
			hash: "SHA-256"
		}, key, signature, encoder.encode(`PW2.${parts[1]}`)) ? claims : null;
	} catch {
		return null;
	}
}
//#endregion
//#region app/license-public-keys.mjs
const PINNED_PUBLIC_KEYS = Object.freeze({ "ownership-2026": {
	"key_ops": ["verify"],
	"ext": true,
	"kty": "EC",
	"x": "eNHqIYzyVtEgBb7Y1tUoZ72No3eBuUcFRBOb1hFSVjs",
	"y": "nMCEYZoKTe590TpkPVWcObIuStngIdFYVVb6V2BEa-I",
	"crv": "P-256"
} });
//#endregion
//#region app/cli.mjs
/** Standalone trusted-user CLI; no app server or AI service is required. */
const HELP = `PixelWall CLI — local sprite editing and export

  pixelwall new --width 32 --height 32 --name Hero --out hero.pixelwall
  pixelwall inspect hero.pixelwall
  pixelwall commands
  pixelwall apply hero.pixelwall --commands edits.json --out hero.pixelwall
  pixelwall script hero.pixelwall --script ./draw.mjs --out hero.pixelwall
  pixelwall import art.aseprite --out hero.pixelwall
  pixelwall import sheet.png --frame-width 32 --frame-height 32 --out hero.pixelwall
  pixelwall import-sequence frame1.png frame2.png --duration 100 --out hero.pixelwall
  pixelwall render hero.pixelwall --frame 0 --scale 4 --out hero.png
  pixelwall export hero.pixelwall --format aseprite --out hero.aseprite
  pixelwall export hero.pixelwall --format gif --out hero.gif --license license.txt
  pixelwall export hero.pixelwall --format sheet --columns 4 --out hero.png --license license.txt
  pixelwall export hero.pixelwall --format atlas --trim --padding 2 --extrude 1 --power-of-two --out atlas.png --license license.txt
  pixelwall export hero.pixelwall --format zip --out frames.zip --license license.txt

Frames are zero-based indices or frame IDs. --clip selects a clip by name or ID.
PNG/BMP/TGA, native projects and Aseprite are free; GIF, sheet, atlas and ZIP require Pro.
A signed perpetual license can also be supplied with PIXELWALL_PRO_LICENSE.
Scripts are explicitly trusted local JavaScript modules, with normal Node access.
Export default async ({document,apply}) => { apply({type:...}); } from your script.
All edits use the same document commands as the editor. No embedded AI is used.
`;
function fail(message) {
	throw new Error(message);
}
function parseArgs(argv) {
	const args = { _: [] };
	for (let i = 0; i < argv.length; i++) {
		const value = argv[i];
		if (!value.startsWith("--")) {
			args._.push(value);
			continue;
		}
		const eq = value.indexOf("="), key = value.slice(2, eq < 0 ? void 0 : eq);
		if (!key) fail("Invalid option.");
		if (eq >= 0) args[key] = value.slice(eq + 1);
		else if (argv[i + 1] && !argv[i + 1].startsWith("--")) args[key] = argv[++i];
		else args[key] = true;
	}
	return args;
}
function number(args, key, fallback) {
	if (args[key] == null) return fallback;
	const n = Number(args[key]);
	if (!Number.isFinite(n)) fail(`--${key} must be a number.`);
	return n;
}
function required(args, key) {
	const value = args[key];
	if (typeof value !== "string" || !value) fail(`--${key} is required.`);
	return value;
}
function warn(warnings) {
	for (const warning of warnings || []) process.stderr.write(`Warning: ${warning}\n`);
}
async function readDocument(path) {
	if (!path) fail("Input file is required.");
	const input = new Uint8Array(await readFile(resolve(path))), extension = extname(path).toLowerCase();
	if ([".ase", ".aseprite"].includes(extension)) {
		const result = readAseprite(input);
		warn(result.warnings);
		return normalizeDocument(result.document);
	}
	if ([
		".png",
		".bmp",
		".tga"
	].includes(extension)) {
		const image = extension === ".bmp" ? readBmp(input) : extension === ".tga" ? readTga(input) : readPng(input);
		warn(image.warnings);
		return normalizeDocument(importSequence([image], { name: path.split(/[\\/]/).at(-1) }));
	}
	if (extension === ".gif") {
		const result = importGif(input);
		warn(result.warnings);
		return normalizeDocument(result.document);
	}
	return normalizeDocument(JSON.parse(new TextDecoder().decode(input)));
}
async function atomicWrite(path, data) {
	const target = resolve(path);
	await mkdir(dirname(target), { recursive: true });
	const temp = `${target}.${process.pid}.${Date.now()}.tmp`;
	try {
		await writeFile(temp, data);
		await rename(temp, target);
	} catch (error) {
		await unlink(temp).catch(() => {});
		throw error;
	}
}
async function saveDocument(path, document) {
	await atomicWrite(path, JSON.stringify(normalizeDocument(document), null, 2) + "\n");
}
function extractLicenseToken(text) {
	if (Buffer.byteLength(text, "utf8") > 65536) fail("Ownership license file exceeds 64 KiB.");
	const candidates = text.split(/\s+/).filter((word) => word.startsWith("PW2."));
	if (candidates.length !== 1) fail(candidates.length ? "Ownership license file contains multiple PW2 codes; keep exactly one code in the file." : "Ownership license file does not contain a PW2 code.");
	const token = candidates[0];
	if (!/^PW2\.[A-Za-z0-9_-]{1,2667}\.[A-Za-z0-9_-]{86}$/.test(token)) fail("Ownership license file contains a malformed PW2 code.");
	return token;
}
async function requirePro(args) {
	let token = process.env.PIXELWALL_PRO_LICENSE || "";
	if (args.license) {
		const value = required(args, "license");
		if (value.startsWith("PW2.")) token = value;
		else {
			const path = resolve(value);
			if ((await stat(path)).size > 65536) fail("Ownership license file exceeds 64 KiB.");
			token = extractLicenseToken(await readFile(path, "utf8"));
		}
	}
	const claims = await verifyOfflineLicense(token, {
		publicKeys: PINNED_PUBLIC_KEYS,
		mode: "live"
	});
	if (!claims) fail("A valid PixelWall Pro license is required for this export. Supply --license license.txt or PIXELWALL_PRO_LICENSE.");
	return claims;
}
function scaleFrame(entry, scale) {
	if (scale === 1) return entry;
	if (!Number.isInteger(scale) || scale < 1 || scale > 64) fail("Scale must be an integer from 1 to 64.");
	const width = entry.width * scale, height = entry.height * scale;
	if (width * height > 64 * 1024 * 1024) fail("Scaled output exceeds the pixel limit.");
	const rgba = new Uint8Array(width * height * 4);
	for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
		const p = (Math.floor(y / scale) * entry.width + Math.floor(x / scale)) * 4;
		rgba.set(entry.rgba.subarray(p, p + 4), (y * width + x) * 4);
	}
	return {
		...entry,
		width,
		height,
		rgba
	};
}
function framesFor(doc, args) {
	let frames = doc.frames;
	if (args.clip) {
		const clip = doc.clips.find((c) => c.id === args.clip || c.name === args.clip);
		if (!clip) fail("Unknown clip.");
		frames = clip.frameIds.map((id) => doc.frames.find((f) => f.id === id));
		if (clip.direction === "reverse" || clip.direction === "pingpong_reverse") frames.reverse();
		if (clip.direction === "pingpong" || clip.direction === "pingpong_reverse") frames = [...frames, ...frames.slice(1, -1).reverse()];
	}
	if (args.frame != null) {
		const frame = doc.frames.find((f) => f.id === args.frame) || doc.frames[Number(args.frame)];
		if (!frame) fail("Unknown frame.");
		frames = [frame];
	}
	const scale = number(args, "scale", 1);
	return frames.map((frame, index) => scaleFrame({
		id: frame.id,
		name: `${doc.name.replace(/[^a-z0-9_-]/gi, "_")}-${String(index + 1).padStart(4, "0")}`,
		width: doc.width,
		height: doc.height,
		rgba: renderFrame(doc, frame.id),
		durationMs: frame.durationMs
	}, scale));
}
async function main(argv = process.argv.slice(2)) {
	const args = parseArgs(argv), [command, input, ...rest] = args._;
	if (!command || command === "help" || args.help) {
		process.stdout.write(HELP);
		return;
	}
	if (command === "commands") {
		process.stdout.write(JSON.stringify(COMMANDS, null, 2) + "\n");
		return;
	}
	if (command === "new") {
		const doc = createDocument({
			width: number(args, "width", 32),
			height: number(args, "height", number(args, "width", 32)),
			name: args.name || "Untitled Sprite",
			colorMode: args["color-mode"] || "rgba",
			durationMs: number(args, "duration", 100)
		});
		await saveDocument(required(args, "out"), doc);
		return;
	}
	if (command === "import-sequence") {
		const paths = [input, ...rest].filter(Boolean);
		if (!paths.length) fail("Provide one or more PNG filenames.");
		const entries = [];
		for (const path of paths) {
			const result = readPng(new Uint8Array(await readFile(resolve(path))));
			warn(result.warnings);
			entries.push(result);
		}
		await saveDocument(required(args, "out"), importSequence(entries, {
			name: args.name || "Imported sequence",
			durationMs: number(args, "duration", 100)
		}));
		return;
	}
	let doc = await readDocument(input);
	if (command === "inspect") {
		process.stdout.write(JSON.stringify({
			...describeDocument(doc),
			layerDetails: doc.layers,
			frameDetails: doc.frames.map((f) => ({
				id: f.id,
				durationMs: f.durationMs,
				cels: Object.keys(f.cels)
			})),
			clips: doc.clips,
			slices: doc.slices,
			metadata: doc.metadata
		}, null, 2) + "\n");
		return;
	}
	if (command === "import") {
		if (args["frame-width"] || args["frame-height"]) {
			if (extname(input).toLowerCase() !== ".png") fail("Sheet import requires a PNG image.");
			doc = importSheet(readPng(new Uint8Array(await readFile(resolve(input)))), {
				frameWidth: number(args, "frame-width"),
				frameHeight: number(args, "frame-height"),
				margin: number(args, "margin", 0),
				spacing: number(args, "spacing", 0),
				count: number(args, "count"),
				durationMs: number(args, "duration", 100),
				order: args.order || "row",
				name: args.name || "Imported sheet"
			});
		}
		await saveDocument(required(args, "out"), doc);
		return;
	}
	if (command === "apply") {
		const data = JSON.parse(await readFile(resolve(required(args, "commands")), "utf8")), commands = Array.isArray(data) ? data : data.commands;
		if (!Array.isArray(commands)) fail("Command file must be a JSON array or {commands:[...]}.");
		for (const cmd of commands) doc = applyCommand(doc, cmd);
		await saveDocument(required(args, "out"), doc);
		return;
	}
	if (command === "script") {
		const scriptModule = await import(pathToFileURL(resolve(required(args, "script"))).href);
		if (typeof scriptModule.default !== "function") fail("Script must export a default function.");
		const context = {
			get document() {
				return structuredClone(doc);
			},
			apply(command) {
				doc = applyCommand(doc, command);
				return structuredClone(doc);
			},
			commands: COMMANDS
		};
		const result = await scriptModule.default(context);
		if (result != null) doc = normalizeDocument(result);
		await saveDocument(required(args, "out"), doc);
		return;
	}
	if (command === "render") {
		const [entry] = framesFor(doc, {
			...args,
			frame: args.frame ?? "0"
		});
		await atomicWrite(required(args, "out"), writePng(entry.width, entry.height, entry.rgba));
		return;
	}
	if (command === "export") {
		const format = required(args, "format").toLowerCase(), out = required(args, "out");
		if (["ase", "aseprite"].includes(format)) {
			await atomicWrite(out, writeAseprite(doc));
			return;
		}
		if (format === "pixelwall" || format === "json") {
			await saveDocument(out, doc);
			return;
		}
		if ([
			"png",
			"bmp",
			"tga"
		].includes(format)) {
			const [entry] = framesFor(doc, {
				...args,
				frame: args.frame ?? "0"
			});
			await atomicWrite(out, (format === "bmp" ? writeBmp : format === "tga" ? writeTga : writePng)(entry.width, entry.height, entry.rgba));
			return;
		}
		if (![
			"gif",
			"sheet",
			"atlas",
			"zip"
		].includes(format)) fail(`Unknown export format ${format}.`);
		await requirePro(args);
		const entries = framesFor(doc, args);
		if (format === "gif") {
			warn(["GIF reduces alpha to binary transparency and quantizes images that exceed 255 opaque colors."]);
			await atomicWrite(out, encodeGif(entries, { loop: number(args, "loop", 0) }));
			return;
		}
		if (format === "zip") {
			await atomicWrite(out, makeGamePackage(doc, {
				entries,
				scale: number(args, "scale", 1),
				padding: number(args, "padding", 1),
				extrude: number(args, "extrude", 0),
				powerOfTwo: !!args["power-of-two"]
			}));
			return;
		}
		const result = format === "atlas" ? packAtlas(entries, {
			scale: number(args, "scale", 1),
			trim: args.trim !== "false",
			padding: number(args, "padding", 1),
			extrude: number(args, "extrude", 0),
			border: number(args, "border", number(args, "padding", 1)),
			powerOfTwo: !!args["power-of-two"],
			maxSize: number(args, "max-size", 8192),
			clips: doc.clips,
			slices: doc.slices,
			imageName: out.split(/[\\/]/).at(-1)
		}) : makeSpriteSheet(entries, {
			columns: number(args, "columns", entries.length),
			padding: number(args, "padding", 0)
		});
		await atomicWrite(out, writePng(result.width, result.height, result.rgba));
		await atomicWrite(args.metadata || out.replace(/\.[^.]+$/, "") + ".json", JSON.stringify({
			frames: result.frames,
			meta: result.meta
		}, null, 2) + "\n");
		return;
	}
	fail(`Unknown command ${command}. Run pixelwall help.`);
}
if (process.argv[1] && import.meta.url === pathToFileURL(realpathSync(resolve(process.argv[1]))).href) main().catch((error) => {
	process.stderr.write(`PixelWall: ${error.message}\n`);
	process.exitCode = 1;
});
//#endregion
export { extractLicenseToken, main };
