import { createRequire as pixelwallWorkerRequire } from "node:module";
import { fileURLToPath as pixelwallWorkerPath } from "node:url";
pixelwallWorkerRequire(import.meta.url);
const __filename = pixelwallWorkerPath(import.meta.url);
import { createRequire } from "node:module";
import { readFile } from "node:fs/promises";
import { existsSync } from "node:fs";
import { parentPort, workerData } from "node:worker_threads";
//#region \0rolldown/runtime.js
var __defProp = Object.defineProperty;
var __commonJSMin = (cb, mod) => () => (mod || (cb((mod = { exports: {} }).exports, mod), cb = null), mod.exports);
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var __require = /* @__PURE__ */ createRequire(import.meta.url);
//#endregion
//#region app/lua-plugin-schema.mjs
/** Data-only package command boundary. Host options enable it; Lua input cannot. */
const LUA_PLUGIN_LIMITS = Object.freeze({
	commands: 32,
	bytes: 65536,
	preferenceNodes: 4096,
	preferenceDepth: 12,
	stringBytes: 16384
});
const own$3 = (value, key) => Object.prototype.hasOwnProperty.call(value, key);
const record$4 = (value) => value && typeof value === "object" && !Array.isArray(value) && [Object.prototype, null].includes(Object.getPrototypeOf(value));
const unsafe = new Set([
	"__proto__",
	"constructor",
	"prototype"
]);
const fail$9 = (message) => {
	throw Error(`Lua package: ${message}`);
};
function object$1(value, label) {
	if (!record$4(value)) fail$9(`${label} must be a plain object.`);
	return value;
}
function keys$1(value, allowed, label) {
	for (const key of Object.keys(value)) if (!allowed.includes(key)) fail$9(`Unsupported ${label} property: ${key}.`);
}
function text$1(value, label, max = 512) {
	if (typeof value !== "string" || new TextEncoder().encode(value).length > max || value.includes("\0") || [...value].some((character) => {
		const point = character.codePointAt(0);
		return point >= 55296 && point <= 57343;
	})) fail$9(`${label} must be UTF-8 text of at most ${max} bytes.`);
	return value;
}
function size$1(value, label) {
	let json;
	try {
		json = JSON.stringify(value);
	} catch {
		fail$9(`${label} must be serializable.`);
	}
	if (!json || new TextEncoder().encode(json).length > LUA_PLUGIN_LIMITS.bytes) fail$9(`${label} exceeds 64 KiB.`);
}
/** Safe to use before reading saved preferences into a worker. Empty arrays normalize
* to empty Lua tables; null, sparse arrays, metatables/userdata and unsafe keys are unsupported. */
function validatePluginPreferences(input = {}) {
	object$1(input, "Preferences");
	let nodes = 0;
	const ancestors = /* @__PURE__ */ new Set();
	function copy(value, depth) {
		if (++nodes > LUA_PLUGIN_LIMITS.preferenceNodes || depth > LUA_PLUGIN_LIMITS.preferenceDepth) fail$9("Preferences exceed the depth or value-count limit.");
		if (typeof value === "boolean") return value;
		if (typeof value === "string") return text$1(value, "Preference string", LUA_PLUGIN_LIMITS.stringBytes);
		if (typeof value === "number") {
			if (!Number.isFinite(value) || Math.abs(value) > Number.MAX_SAFE_INTEGER) fail$9("Preference numbers must be finite and within the exact JavaScript range.");
			return value;
		}
		if (!value || typeof value !== "object" || !Array.isArray(value) && !record$4(value)) fail$9("Preferences support only plain Lua/JSON tables, strings, booleans and finite numbers.");
		if (ancestors.has(value)) fail$9("Preferences cannot be circular.");
		ancestors.add(value);
		let output;
		if (Array.isArray(value)) {
			if (value.length > LUA_PLUGIN_LIMITS.preferenceNodes || Reflect.ownKeys(value).length !== value.length + 1) fail$9("Preference arrays must be dense and bounded.");
			output = value.length ? Array.from({ length: value.length }, (_, index) => {
				const descriptor = Object.getOwnPropertyDescriptor(value, index);
				if (!descriptor || !own$3(descriptor, "value") || !descriptor.enumerable) fail$9("Preference arrays must have dense data values without accessors.");
				return copy(descriptor.value, depth + 1);
			}) : {};
		} else {
			output = {};
			const names = Reflect.ownKeys(value);
			if (names.some((key) => typeof key !== "string")) fail$9("Preference keys must be strings.");
			for (const key of names.sort()) {
				text$1(key, "Preference key", 128);
				if (unsafe.has(key)) fail$9("Unsafe preference key.");
				const descriptor = Object.getOwnPropertyDescriptor(value, key);
				if (!descriptor || !own$3(descriptor, "value") || !descriptor.enumerable) fail$9("Preference accessors and hidden properties are unsupported.");
				output[key] = copy(descriptor.value, depth + 1);
			}
		}
		ancestors.delete(value);
		return output;
	}
	const result = copy(input, 0);
	size$1(result, "Preferences");
	return result;
}
function validatePluginOptions(input) {
	object$1(input, "Plugin options");
	keys$1(input, [
		"name",
		"displayName",
		"version",
		"preferences"
	], "plugin option");
	const name = text$1(input.name, "Package name", 128);
	if (!/^[a-zA-Z0-9][a-zA-Z0-9._-]*$/.test(name) || unsafe.has(name)) fail$9("Package name is invalid.");
	const version = text$1(input.version, "Package version", 80);
	if (!version) fail$9("Package version is required.");
	return {
		name,
		displayName: text$1(input.displayName ?? name, "Package display name", 240),
		version,
		preferences: validatePluginPreferences(input.preferences)
	};
}
function validatePluginCatalog(input, expected) {
	object$1(input, "Command catalog");
	size$1(input, "Command catalog");
	keys$1(input, [
		"name",
		"displayName",
		"version",
		"commands"
	], "command catalog");
	if (!expected || input.name !== expected.name || input.displayName !== expected.displayName || input.version !== expected.version) fail$9("Command catalog package identity does not match the selected package.");
	if (!Array.isArray(input.commands) || !input.commands.length || input.commands.length > LUA_PLUGIN_LIMITS.commands) fail$9("A package session must register 1–32 commands.");
	const ids = /* @__PURE__ */ new Set();
	const commands = input.commands.map((raw) => {
		object$1(raw, "Command");
		keys$1(raw, [
			"id",
			"title",
			"group",
			"enabled",
			"checked"
		], "command");
		const id = text$1(raw.id, "Command ID", 128);
		if (!/^[a-zA-Z_][a-zA-Z0-9_.:-]*$/.test(id) || unsafe.has(id) || ids.has(id)) fail$9("Command IDs must be unique safe identifiers.");
		ids.add(id);
		const title = text$1(raw.title ?? id, "Command title", 512), group = text$1(raw.group ?? "", "Command group", 256);
		if (typeof raw.enabled !== "boolean" || own$3(raw, "checked") && typeof raw.checked !== "boolean") fail$9("Command enabled/checked states must be booleans.");
		return {
			id,
			title,
			group,
			enabled: raw.enabled,
			...own$3(raw, "checked") ? { checked: raw.checked } : {}
		};
	});
	return {
		name: expected.name,
		displayName: expected.displayName,
		version: expected.version,
		commands
	};
}
function validatePluginChoice(input, catalog) {
	object$1(input, "Command choice");
	keys$1(input, ["action", "commandId"], "command choice");
	if (input.action === "cancel") {
		if (own$3(input, "commandId")) fail$9("A cancelled choice cannot execute a command.");
		return { action: "cancel" };
	}
	if (input.action !== "run" || typeof input.commandId !== "string") fail$9("Choose one package command or cancel.");
	const command = catalog.commands.find((command) => command.id === input.commandId);
	if (!command?.enabled) fail$9("The chosen command is missing or disabled.");
	return {
		action: "run",
		commandId: command.id
	};
}
function validatePluginResult(input, expected, commandId) {
	object$1(input, "Plugin result");
	keys$1(input, [
		"name",
		"version",
		"commandId",
		"preferences",
		"preferencesChanged"
	], "plugin result");
	if (!expected || input.name !== expected.name || input.version !== expected.version || input.commandId !== commandId) fail$9("Plugin result does not match the chosen package command.");
	const preferences = validatePluginPreferences(input.preferences);
	return {
		name: expected.name,
		version: expected.version,
		commandId,
		preferences,
		preferencesChanged: JSON.stringify(preferences) !== JSON.stringify(validatePluginPreferences(expected.preferences))
	};
}
//#endregion
//#region app/lua-plugin-channel.mjs
/** One user choice per live package worker; callback functions stay in Lua. */
function createLuaPluginChannel(postMessage, plugin) {
	let pending = null, requested = false;
	return {
		requestCommand(input) {
			if (requested) return Promise.reject(Error("Only one package command selection is allowed."));
			const catalog = validatePluginCatalog(input, plugin);
			requested = true;
			return new Promise((resolve, reject) => {
				pending = {
					catalog,
					resolve,
					reject
				};
				try {
					postMessage({
						type: "plugin-command-request",
						id: 1,
						catalog
					});
				} catch (error) {
					pending = null;
					reject(error);
				}
			});
		},
		receive(message) {
			if (message?.type !== "plugin-command-response" || !pending || message.id !== 1) return false;
			const current = pending;
			pending = null;
			try {
				current.resolve(validatePluginChoice(message.response, current.catalog));
			} catch (error) {
				current.reject(error);
			}
			return true;
		}
	};
}
//#endregion
//#region app/color-profile-command.mjs
/** Pure command validation. Color transforms are computed in a bounded worker;
* the shared engine replays only profile/pixel/palette changes, never a snapshot. */
const own$2 = (value, key) => Object.prototype.hasOwnProperty.call(value, key);
const record$3 = (value) => value && typeof value === "object" && !Array.isArray(value) && [Object.prototype, null].includes(Object.getPrototypeOf(value));
const fail$8 = (message) => {
	throw Error(`Color profile: ${message}`);
};
function fields(value, allowed, label) {
	if (!record$3(value) || Object.keys(value).some((key) => !allowed.includes(key))) fail$8(`Invalid ${label}.`);
}
function normalizeColorProfile(input = {
	type: 1,
	flags: 0,
	gamma: 0
}) {
	if (input === "sRGB") input = {
		type: 1,
		flags: 0,
		gamma: 0
	};
	fields(input, [
		"type",
		"flags",
		"gamma",
		"icc",
		"name"
	], "profile");
	const { type, flags = 0, gamma = 0 } = input;
	if (![
		0,
		1,
		2
	].includes(type) || ![0, 1].includes(flags) || flags && type !== 1 || !Number.isFinite(gamma) || gamma < 0 || gamma > 10 || flags && gamma < .1) fail$8("Unsupported profile type, flags or gamma.");
	const profile = {
		type,
		flags,
		gamma
	};
	if (own$2(input, "name")) {
		if (typeof input.name !== "string" || input.name.includes("\0") || new TextEncoder().encode(input.name).length > 4096) fail$8("Profile names must be text of at most 4096 bytes.");
		profile.name = input.name;
	}
	if (type === 2) {
		const data = input.icc;
		if (!Array.isArray(data) || data.length < 132 || data.length > 4 * 1024 * 1024 || data.some((value) => !Number.isInteger(value) || value < 0 || value > 255)) fail$8("ICC data must contain 132 bytes to 4 MB.");
		const bytes = Uint8Array.from(data), view = new DataView(bytes.buffer);
		if (view.getUint32(0) !== bytes.length || String.fromCharCode(...bytes.subarray(36, 40)) !== "acsp") fail$8("Invalid ICC header.");
		if (!["RGB ", "GRAY"].includes(String.fromCharCode(...bytes.subarray(16, 20)))) fail$8("Only RGB and grayscale ICC profiles are supported.");
		const count = view.getUint32(128);
		if (count > 4096 || 132 + count * 12 > bytes.length) fail$8("Invalid ICC tag table.");
		for (let i = 0; i < count; i++) {
			const start = view.getUint32(136 + i * 12), length = view.getUint32(140 + i * 12);
			if (start < 128 || start + length > bytes.length) fail$8("ICC tag lies outside the profile.");
		}
		profile.icc = [...data];
	} else if (own$2(input, "icc")) fail$8("Only embedded ICC profiles can contain ICC data.");
	return profile;
}
function colors(value, length, mode, label) {
	if (!Array.isArray(value) || value.length !== length) fail$8(`${label} must keep its original length.`);
	return value.map((color) => {
		if (color === null && label === "Image pixels") return null;
		if (typeof color !== "string" || !/^#[\da-f]{8}$/i.test(color)) fail$8(`${label} must contain RGBA colors.`);
		color = color.toLowerCase();
		if (mode === "grayscale" && (color.slice(1, 3) !== color.slice(3, 5) || color.slice(3, 5) !== color.slice(5, 7))) fail$8("Grayscale conversion must keep equal RGB channels.");
		return color.slice(7) === "00" && label === "Image pixels" ? null : color;
	});
}
function applyColorProfileCommand(document, command) {
	fields(command, [
		"type",
		"profile",
		"replacements",
		"frameId",
		"layerId"
	], "profile command");
	const profile = normalizeColorProfile(command.profile);
	if (profile.type === 2 && String.fromCharCode(...profile.icc.slice(16, 20)) === "GRAY" && document.colorMode !== "grayscale") fail$8("A gray profile requires a grayscale sprite.");
	if (document.layers.some((layer) => layer.locked)) fail$8("Unlock every layer before changing the working color profile.");
	const changes = command.replacements;
	if (changes !== void 0) {
		fields(changes, [
			"images",
			"palette",
			"framePalettes"
		], "conversion changes");
		const raster = Object.entries(document.images).filter(([, image]) => !image.tilemap);
		if (document.colorMode === "indexed") {
			if (changes.images !== void 0 && (!Array.isArray(changes.images) || changes.images.length)) fail$8("Indexed conversion must preserve pixel indices.");
		} else {
			if (!Array.isArray(changes.images) || changes.images.length !== raster.length) fail$8("Conversion must include every existing raster image once.");
			const seen = /* @__PURE__ */ new Set();
			for (const entry of changes.images) {
				fields(entry, ["id", "pixels"], "image replacement");
				const image = document.images[entry.id];
				if (typeof entry.id !== "string" || !own$2(document.images, entry.id) || !image || image.tilemap || seen.has(entry.id)) fail$8("Conversion contains an invalid or duplicate image ID.");
				seen.add(entry.id);
				document.images[entry.id] = {
					...image,
					pixels: colors(entry.pixels, image.width * image.height, document.colorMode, "Image pixels")
				};
			}
		}
		if (document.colorMode === "grayscale") {
			if (own$2(changes, "palette") || own$2(changes, "framePalettes")) fail$8("Grayscale conversion must preserve palettes.");
		} else {
			document.palette = colors(changes.palette, document.palette.length, "rgba", "Palette");
			const frames = document.frames.filter((frame) => frame.palette);
			if (!Array.isArray(changes.framePalettes) || changes.framePalettes.length !== frames.length) fail$8("Conversion must preserve every frame palette.");
			const seen = /* @__PURE__ */ new Set();
			for (const entry of changes.framePalettes) {
				fields(entry, ["frameId", "palette"], "frame palette replacement");
				const frame = frames.find((frame) => frame.id === entry.frameId);
				if (!frame || seen.has(entry.frameId)) fail$8("Invalid or duplicate frame palette.");
				seen.add(entry.frameId);
				frame.palette = colors(entry.palette, frame.palette.length, "rgba", "Frame palette");
			}
		}
	}
	document.metadata.aseprite = {
		...document.metadata.aseprite,
		colorProfile: profile
	};
}
//#endregion
//#region app/lua-color-spaces.mjs
const LUA_COLOR_SPACE_NOT_HANDLED = Symbol("not a color-space operation");
function needsLuaColorManager(request) {
	const profile = request.document?.metadata?.aseprite?.colorProfile;
	return profile?.type === 2 || !!(profile?.flags & 1);
}
const same = (a, b) => a.type === b.type && (a.type === 0 || a.type === 2 ? a.type === 0 || a.icc.length === b.icc.length && a.icc.every((byte, index) => byte === b.icc[index]) : a.flags === b.flags && (!(a.flags & 1) || Math.abs(a.gamma - b.gamma) <= 1 / 2048));
const automaticName = (profile) => profile.type === 0 ? "None" : profile.type === 2 ? "Custom Profile" : !(profile.flags & 1) ? "sRGB" : profile.gamma === 1 ? "Linear Transfer with sRGB Gamut" : Math.abs(profile.gamma - 2.2) < 1 / 2048 ? "2.2 Transfer with sRGB Gamut" : "Custom Profile";
/** Profile values remain detached in the worker. The Lua side receives opaque
* handles, so ICC bytes never expand into editable Lua arrays or filesystem paths. */
function createLuaColorSpaces({ ref, getRef, doc, flush, mutate, retireRasterImages, colorManager }) {
	let count = 0, profileBytes = 0;
	const normalized = /* @__PURE__ */ new WeakMap(), retained = /* @__PURE__ */ new WeakSet(), defaultProfile = {
		type: 1,
		flags: 0,
		gamma: 0
	};
	function profileOf(document) {
		const value = document.metadata?.aseprite?.colorProfile ?? defaultProfile;
		if (value && typeof value === "object") {
			if (!normalized.has(value)) normalized.set(value, normalizeColorProfile(value));
			return normalized.get(value);
		}
		return normalizeColorProfile(value);
	}
	function make(profile, name = "") {
		if (++count > 512) throw Error("Lua ColorSpace value limit exceeded.");
		if (!retained.has(profile)) {
			profileBytes += profile.icc?.length ?? 0;
			if (profileBytes > 8 * 1024 * 1024) throw Error("Lua ColorSpace profile byte budget exceeded.");
			retained.add(profile);
		}
		return ref("ColorSpace", {
			profile,
			name
		});
	}
	function checked(value) {
		return getRef(value, "ColorSpace");
	}
	function validate(profile) {
		if (profile.type === 2 || profile.flags & 1) {
			if (!colorManager) throw Error("This script requires the bundled color-management runtime.");
			colorManager.profileInfo(profile);
		}
		return profile;
	}
	function change(sprite, target, convert) {
		const destination = checked(target), id = getRef(sprite, "Sprite").docId;
		flush();
		const before = doc(id), source = profileOf(before), profile = normalizeColorProfile({
			...destination.profile,
			name: destination.name || automaticName(destination.profile)
		});
		validate(source);
		validate(profile);
		const command = {
			type: "document.colorProfile",
			profile
		};
		if (convert && source.type !== 0 && profile.type !== 0 && !same(source, profile)) {
			if (!colorManager) throw Error("This script requires the bundled color-management runtime.");
			const transform = (colors) => colorManager.transformColors(colors, source, profile);
			const changes = {}, celImages = new Set(before.frames.flatMap((frame) => Object.values(frame.cels).map((cel) => cel.imageId)));
			if (before.colorMode !== "indexed") changes.images = Object.entries(before.images).filter(([, image]) => !image.tilemap).map(([imageId, image]) => {
				if (!celImages.has(imageId)) return {
					id: imageId,
					pixels: [...image.pixels]
				};
				const unique = [...new Set(image.pixels.filter((pixel) => pixel !== null))], converted = transform(unique), lookup = new Map(unique.map((pixel, index) => [pixel, converted[index]]));
				return {
					id: imageId,
					pixels: image.pixels.map((pixel) => pixel === null ? null : lookup.get(pixel))
				};
			});
			if (before.colorMode !== "grayscale") {
				changes.palette = transform(before.palette);
				changes.framePalettes = before.frames.filter((frame) => frame.palette).map((frame) => ({
					frameId: frame.id,
					palette: transform(frame.palette)
				}));
			}
			command.replacements = changes;
		}
		mutate(id, command);
		if (convert && before.colorMode !== "indexed") retireRasterImages(id);
		return target;
	}
	return {
		capture(value) {
			const holder = checked(value);
			return {
				profile: holder.profile,
				name: holder.name
			};
		},
		fromValue(value) {
			return make(value.profile, value.name);
		},
		sameValues(left, right) {
			return same(left.profile, right.profile);
		},
		documentValue(document) {
			const profile = validate(profileOf(document));
			return {
				profile,
				name: profile.name || automaticName(profile)
			};
		},
		create(options) {
			if (options.source) {
				const source = checked(options.source);
				return make(source.profile, source.name);
			}
			return make({
				type: options.srgb ? 1 : 0,
				flags: 0,
				gamma: 0
			});
		},
		equal(left, right) {
			return same(checked(left).profile, checked(right).profile);
		},
		get(target, key) {
			if (target.__kind === "ColorSpace") {
				if (key !== "name") throw Error(`Unsupported ColorSpace.${key}.`);
				return checked(target).name;
			}
			if (target.__kind === "Sprite" && key === "colorSpace") {
				const profile = validate(profileOf(doc(getRef(target, "Sprite").docId)));
				return make(profile, profile.name || automaticName(profile));
			}
			return LUA_COLOR_SPACE_NOT_HANDLED;
		},
		set(target, key, value) {
			if (target.__kind === "ColorSpace") {
				if (key !== "name") throw Error(`Unsupported ColorSpace.${key}.`);
				const holder = checked(target);
				if (typeof value === "string") holder.name = normalizeColorProfile({
					...holder.profile,
					name: value
				}).name;
				return;
			}
			if (target.__kind === "Sprite" && key === "colorSpace") return change(target, value, false);
			return LUA_COLOR_SPACE_NOT_HANDLED;
		},
		method(target, name, args) {
			if (target.__kind === "Sprite" && ["assignColorSpace", "convertColorSpace"].includes(name)) {
				if (args.length !== 1) throw Error(`Sprite:${name} requires one ColorSpace.`);
				return change(target, args[0], name === "convertColorSpace");
			}
			return LUA_COLOR_SPACE_NOT_HANDLED;
		}
	};
}
//#endregion
//#region node_modules/lcms-wasm/dist/lcms.js
var lcms_exports = /* @__PURE__ */ __exportAll({
	BYTES_SH: () => BYTES_SH,
	CHANNELS_SH: () => CHANNELS_SH,
	COLORSPACE_SH: () => COLORSPACE_SH,
	DOSWAP_SH: () => DOSWAP_SH,
	ENDIAN16_SH: () => ENDIAN16_SH,
	EXTRA_SH: () => EXTRA_SH,
	FLAVOR_SH: () => FLAVOR_SH,
	FLOAT_SH: () => FLOAT_SH,
	INTENT_ABSOLUTE_COLORIMETRIC: () => 3,
	INTENT_PERCEPTUAL: () => 0,
	INTENT_RELATIVE_COLORIMETRIC: () => 1,
	INTENT_SATURATION: () => 2,
	LCMS_VERSION: () => LCMS_VERSION,
	OPTIMIZED_SH: () => OPTIMIZED_SH,
	PLANAR_SH: () => PLANAR_SH,
	PT_ANY: () => 0,
	PT_CMY: () => 5,
	PT_CMYK: () => 6,
	PT_GRAY: () => 3,
	PT_HLS: () => 13,
	PT_HSV: () => 12,
	PT_Lab: () => 10,
	PT_LabV2: () => 30,
	PT_MCH1: () => 15,
	PT_MCH10: () => 24,
	PT_MCH11: () => 25,
	PT_MCH12: () => 26,
	PT_MCH13: () => 27,
	PT_MCH14: () => 28,
	PT_MCH15: () => 29,
	PT_MCH2: () => 16,
	PT_MCH3: () => 17,
	PT_MCH4: () => 18,
	PT_MCH5: () => 19,
	PT_MCH6: () => 20,
	PT_MCH7: () => 21,
	PT_MCH8: () => 22,
	PT_MCH9: () => 23,
	PT_RGB: () => 4,
	PT_XYZ: () => 9,
	PT_YCbCr: () => 7,
	PT_YUV: () => 8,
	PT_YUVK: () => 11,
	PT_Yxy: () => 14,
	SWAPFIRST_SH: () => SWAPFIRST_SH,
	TYPE_ABGR_16: () => TYPE_ABGR_16,
	TYPE_ABGR_16_PLANAR: () => TYPE_ABGR_16_PLANAR,
	TYPE_ABGR_16_SE: () => TYPE_ABGR_16_SE,
	TYPE_ABGR_8: () => TYPE_ABGR_8,
	TYPE_ABGR_8_PLANAR: () => TYPE_ABGR_8_PLANAR,
	TYPE_ALabV2_8: () => TYPE_ALabV2_8,
	TYPE_ALab_8: () => TYPE_ALab_8,
	TYPE_ARGB_16: () => TYPE_ARGB_16,
	TYPE_ARGB_8: () => TYPE_ARGB_8,
	TYPE_ARGB_8_PLANAR: () => TYPE_ARGB_8_PLANAR,
	TYPE_BGRA_16: () => TYPE_BGRA_16,
	TYPE_BGRA_16_SE: () => TYPE_BGRA_16_SE,
	TYPE_BGRA_8: () => TYPE_BGRA_8,
	TYPE_BGRA_8_PLANAR: () => TYPE_BGRA_8_PLANAR,
	TYPE_BGR_16: () => TYPE_BGR_16,
	TYPE_BGR_16_PLANAR: () => TYPE_BGR_16_PLANAR,
	TYPE_BGR_16_SE: () => TYPE_BGR_16_SE,
	TYPE_BGR_8: () => TYPE_BGR_8,
	TYPE_BGR_8_PLANAR: () => TYPE_BGR_8_PLANAR,
	TYPE_BGR_DBL: () => TYPE_BGR_DBL,
	TYPE_CMYK10_16: () => TYPE_CMYK10_16,
	TYPE_CMYK10_16_SE: () => TYPE_CMYK10_16_SE,
	TYPE_CMYK10_8: () => TYPE_CMYK10_8,
	TYPE_CMYK11_16: () => TYPE_CMYK11_16,
	TYPE_CMYK11_16_SE: () => TYPE_CMYK11_16_SE,
	TYPE_CMYK11_8: () => TYPE_CMYK11_8,
	TYPE_CMYK12_16: () => TYPE_CMYK12_16,
	TYPE_CMYK12_16_SE: () => TYPE_CMYK12_16_SE,
	TYPE_CMYK12_8: () => TYPE_CMYK12_8,
	TYPE_CMYK5_16: () => TYPE_CMYK5_16,
	TYPE_CMYK5_16_SE: () => TYPE_CMYK5_16_SE,
	TYPE_CMYK5_8: () => TYPE_CMYK5_8,
	TYPE_CMYK6_16: () => TYPE_CMYK6_16,
	TYPE_CMYK6_16_PLANAR: () => TYPE_CMYK6_16_PLANAR,
	TYPE_CMYK6_16_SE: () => TYPE_CMYK6_16_SE,
	TYPE_CMYK6_8: () => TYPE_CMYK6_8,
	TYPE_CMYK6_8_PLANAR: () => TYPE_CMYK6_8_PLANAR,
	TYPE_CMYK7_16: () => TYPE_CMYK7_16,
	TYPE_CMYK7_16_SE: () => TYPE_CMYK7_16_SE,
	TYPE_CMYK7_8: () => TYPE_CMYK7_8,
	TYPE_CMYK8_16: () => TYPE_CMYK8_16,
	TYPE_CMYK8_16_SE: () => TYPE_CMYK8_16_SE,
	TYPE_CMYK8_8: () => TYPE_CMYK8_8,
	TYPE_CMYK9_16: () => TYPE_CMYK9_16,
	TYPE_CMYK9_16_SE: () => TYPE_CMYK9_16_SE,
	TYPE_CMYK9_8: () => TYPE_CMYK9_8,
	TYPE_CMYKA_8: () => TYPE_CMYKA_8,
	TYPE_CMYK_16: () => TYPE_CMYK_16,
	TYPE_CMYK_16_PLANAR: () => TYPE_CMYK_16_PLANAR,
	TYPE_CMYK_16_REV: () => TYPE_CMYK_16_REV,
	TYPE_CMYK_16_SE: () => TYPE_CMYK_16_SE,
	TYPE_CMYK_8: () => TYPE_CMYK_8,
	TYPE_CMYK_8_PLANAR: () => TYPE_CMYK_8_PLANAR,
	TYPE_CMYK_8_REV: () => TYPE_CMYK_8_REV,
	TYPE_CMYK_DBL: () => TYPE_CMYK_DBL,
	TYPE_CMY_16: () => TYPE_CMY_16,
	TYPE_CMY_16_PLANAR: () => TYPE_CMY_16_PLANAR,
	TYPE_CMY_16_SE: () => TYPE_CMY_16_SE,
	TYPE_CMY_8: () => TYPE_CMY_8,
	TYPE_CMY_8_PLANAR: () => TYPE_CMY_8_PLANAR,
	TYPE_GRAYA_16: () => TYPE_GRAYA_16,
	TYPE_GRAYA_16_PLANAR: () => TYPE_GRAYA_16_PLANAR,
	TYPE_GRAYA_16_SE: () => TYPE_GRAYA_16_SE,
	TYPE_GRAYA_8: () => TYPE_GRAYA_8,
	TYPE_GRAYA_8_PLANAR: () => TYPE_GRAYA_8_PLANAR,
	TYPE_GRAY_16: () => TYPE_GRAY_16,
	TYPE_GRAY_16_REV: () => TYPE_GRAY_16_REV,
	TYPE_GRAY_16_SE: () => TYPE_GRAY_16_SE,
	TYPE_GRAY_8: () => TYPE_GRAY_8,
	TYPE_GRAY_8_REV: () => TYPE_GRAY_8_REV,
	TYPE_GRAY_DBL: () => TYPE_GRAY_DBL,
	TYPE_KCMY_16: () => TYPE_KCMY_16,
	TYPE_KCMY_16_REV: () => TYPE_KCMY_16_REV,
	TYPE_KCMY_16_SE: () => TYPE_KCMY_16_SE,
	TYPE_KCMY_8: () => TYPE_KCMY_8,
	TYPE_KCMY_8_REV: () => TYPE_KCMY_8_REV,
	TYPE_KYMC10_16: () => TYPE_KYMC10_16,
	TYPE_KYMC10_16_SE: () => TYPE_KYMC10_16_SE,
	TYPE_KYMC10_8: () => TYPE_KYMC10_8,
	TYPE_KYMC11_16: () => TYPE_KYMC11_16,
	TYPE_KYMC11_16_SE: () => TYPE_KYMC11_16_SE,
	TYPE_KYMC11_8: () => TYPE_KYMC11_8,
	TYPE_KYMC12_16: () => TYPE_KYMC12_16,
	TYPE_KYMC12_16_SE: () => TYPE_KYMC12_16_SE,
	TYPE_KYMC12_8: () => TYPE_KYMC12_8,
	TYPE_KYMC5_16: () => TYPE_KYMC5_16,
	TYPE_KYMC5_16_SE: () => TYPE_KYMC5_16_SE,
	TYPE_KYMC5_8: () => TYPE_KYMC5_8,
	TYPE_KYMC7_16: () => TYPE_KYMC7_16,
	TYPE_KYMC7_16_SE: () => TYPE_KYMC7_16_SE,
	TYPE_KYMC7_8: () => TYPE_KYMC7_8,
	TYPE_KYMC8_16: () => TYPE_KYMC8_16,
	TYPE_KYMC8_16_SE: () => TYPE_KYMC8_16_SE,
	TYPE_KYMC8_8: () => TYPE_KYMC8_8,
	TYPE_KYMC9_16: () => TYPE_KYMC9_16,
	TYPE_KYMC9_16_SE: () => TYPE_KYMC9_16_SE,
	TYPE_KYMC9_8: () => TYPE_KYMC9_8,
	TYPE_KYMC_16: () => TYPE_KYMC_16,
	TYPE_KYMC_16_SE: () => TYPE_KYMC_16_SE,
	TYPE_KYMC_8: () => TYPE_KYMC_8,
	TYPE_LabV2_16: () => TYPE_LabV2_16,
	TYPE_LabV2_8: () => TYPE_LabV2_8,
	TYPE_Lab_16: () => TYPE_Lab_16,
	TYPE_Lab_8: () => TYPE_Lab_8,
	TYPE_Lab_DBL: () => TYPE_Lab_DBL,
	TYPE_RGBA_16: () => TYPE_RGBA_16,
	TYPE_RGBA_16_PLANAR: () => TYPE_RGBA_16_PLANAR,
	TYPE_RGBA_16_SE: () => TYPE_RGBA_16_SE,
	TYPE_RGBA_8: () => TYPE_RGBA_8,
	TYPE_RGBA_8_PLANAR: () => TYPE_RGBA_8_PLANAR,
	TYPE_RGB_16: () => TYPE_RGB_16,
	TYPE_RGB_16_PLANAR: () => TYPE_RGB_16_PLANAR,
	TYPE_RGB_16_SE: () => TYPE_RGB_16_SE,
	TYPE_RGB_8: () => TYPE_RGB_8,
	TYPE_RGB_8_PLANAR: () => TYPE_RGB_8_PLANAR,
	TYPE_RGB_DBL: () => TYPE_RGB_DBL,
	TYPE_XYZ_16: () => TYPE_XYZ_16,
	TYPE_XYZ_DBL: () => TYPE_XYZ_DBL,
	TYPE_YUVK_16: () => TYPE_YUVK_16,
	TYPE_YUVK_8: () => TYPE_YUVK_8,
	TYPE_Yxy_16: () => TYPE_Yxy_16,
	T_BYTES: () => T_BYTES,
	T_CHANNELS: () => T_CHANNELS,
	T_COLORSPACE: () => T_COLORSPACE,
	T_DOSWAP: () => T_DOSWAP,
	T_ENDIAN16: () => T_ENDIAN16,
	T_EXTRA: () => T_EXTRA,
	T_FLAVOR: () => T_FLAVOR,
	T_FLOAT: () => T_FLOAT,
	T_OPTIMIZED: () => T_OPTIMIZED,
	T_PLANAR: () => T_PLANAR,
	T_SWAPFIRST: () => T_SWAPFIRST,
	cmsFLAGS_BLACKPOINTCOMPENSATION: () => cmsFLAGS_BLACKPOINTCOMPENSATION,
	cmsFLAGS_COPY_ALPHA: () => cmsFLAGS_COPY_ALPHA,
	cmsFLAGS_GAMUTCHECK: () => cmsFLAGS_GAMUTCHECK,
	cmsFLAGS_HIGHRESPRECALC: () => cmsFLAGS_HIGHRESPRECALC,
	cmsFLAGS_LOWRESPRECALC: () => cmsFLAGS_LOWRESPRECALC,
	cmsFLAGS_NOCACHE: () => 64,
	cmsFLAGS_NOOPTIMIZE: () => 256,
	cmsFLAGS_NOWHITEONWHITEFIXUP: () => 4,
	cmsFLAGS_NULLTRANSFORM: () => 512,
	cmsFLAGS_SOFTPROOFING: () => cmsFLAGS_SOFTPROOFING,
	cmsInfoCopyright: () => 3,
	cmsInfoDescription: () => 0,
	cmsInfoManufacturer: () => 1,
	cmsInfoModel: () => 2,
	cmsMAXCHANNELS: () => 16,
	cmsSigBlueColorantTag: () => cmsSigBlueColorantTag,
	cmsSigCmyData: () => cmsSigCmyData,
	cmsSigCmykData: () => cmsSigCmykData,
	cmsSigGrayData: () => cmsSigGrayData,
	cmsSigGreenColorantTag: () => cmsSigGreenColorantTag,
	cmsSigHlsData: () => cmsSigHlsData,
	cmsSigHsvData: () => cmsSigHsvData,
	cmsSigLabData: () => cmsSigLabData,
	cmsSigLuvData: () => cmsSigLuvData,
	cmsSigRedColorantTag: () => cmsSigRedColorantTag,
	cmsSigRgbData: () => cmsSigRgbData,
	cmsSigXYZData: () => cmsSigXYZData,
	cmsSigYCbCrData: () => cmsSigYCbCrData,
	cmsSigYxyData: () => cmsSigYxyData,
	default: () => instantiate,
	instantiate: () => instantiate
});
const LCMS_VERSION = 2160;
const cmsSigRedColorantTag = 1918392666;
const cmsSigGreenColorantTag = 1733843290;
const cmsSigBlueColorantTag = 1649957210;
const cmsSigXYZData = 1482250784;
const cmsSigLabData = 1281450528;
const cmsSigLuvData = 1282766368;
const cmsSigYCbCrData = 1497588338;
const cmsSigYxyData = 1501067552;
const cmsSigRgbData = 1380401696;
const cmsSigGrayData = 1196573017;
const cmsSigHsvData = 1213421088;
const cmsSigHlsData = 1212961568;
const cmsSigCmykData = 1129142603;
const cmsSigCmyData = 1129142560;
const FLOAT_SH = (a) => a << 22;
const OPTIMIZED_SH = (s) => s << 21;
const COLORSPACE_SH = (s) => s << 16;
const SWAPFIRST_SH = (s) => s << 14;
const FLAVOR_SH = (s) => s << 13;
const PLANAR_SH = (p) => p << 12;
const ENDIAN16_SH = (e) => e << 11;
const DOSWAP_SH = (e) => e << 10;
const EXTRA_SH = (e) => e << 7;
const CHANNELS_SH = (c) => c << 3;
const BYTES_SH = (b) => b;
const T_FLOAT = (a) => a >> 22 & 1;
const T_OPTIMIZED = (o) => o >> 21 & 1;
const T_COLORSPACE = (s) => s >> 16 & 31;
const T_SWAPFIRST = (s) => s >> 14 & 1;
const T_FLAVOR = (s) => s >> 13 & 1;
const T_PLANAR = (p) => p >> 12 & 1;
const T_ENDIAN16 = (e) => e >> 11 & 1;
const T_DOSWAP = (e) => e >> 10 & 1;
const T_EXTRA = (e) => e >> 7 & 7;
const T_CHANNELS = (c) => c >> 3 & 15;
const T_BYTES = (b) => b & 7;
const TYPE_GRAY_8 = COLORSPACE_SH(3) | CHANNELS_SH(1) | BYTES_SH(1);
const TYPE_GRAY_8_REV = COLORSPACE_SH(3) | CHANNELS_SH(1) | BYTES_SH(1) | FLAVOR_SH(1);
const TYPE_GRAY_16 = COLORSPACE_SH(3) | CHANNELS_SH(1) | BYTES_SH(2);
const TYPE_GRAY_16_REV = COLORSPACE_SH(3) | CHANNELS_SH(1) | BYTES_SH(2) | FLAVOR_SH(1);
const TYPE_GRAY_16_SE = COLORSPACE_SH(3) | CHANNELS_SH(1) | BYTES_SH(2) | ENDIAN16_SH(1);
const TYPE_GRAYA_8 = COLORSPACE_SH(3) | EXTRA_SH(1) | CHANNELS_SH(1) | BYTES_SH(1);
const TYPE_GRAYA_16 = COLORSPACE_SH(3) | EXTRA_SH(1) | CHANNELS_SH(1) | BYTES_SH(2);
const TYPE_GRAYA_16_SE = COLORSPACE_SH(3) | EXTRA_SH(1) | CHANNELS_SH(1) | BYTES_SH(2) | ENDIAN16_SH(1);
const TYPE_GRAYA_8_PLANAR = COLORSPACE_SH(3) | EXTRA_SH(1) | CHANNELS_SH(1) | BYTES_SH(1) | PLANAR_SH(1);
const TYPE_GRAYA_16_PLANAR = COLORSPACE_SH(3) | EXTRA_SH(1) | CHANNELS_SH(1) | BYTES_SH(2) | PLANAR_SH(1);
const TYPE_RGB_8 = COLORSPACE_SH(4) | CHANNELS_SH(3) | BYTES_SH(1);
const TYPE_RGB_8_PLANAR = COLORSPACE_SH(4) | CHANNELS_SH(3) | BYTES_SH(1) | PLANAR_SH(1);
const TYPE_BGR_8 = COLORSPACE_SH(4) | CHANNELS_SH(3) | BYTES_SH(1) | DOSWAP_SH(1);
const TYPE_BGR_8_PLANAR = COLORSPACE_SH(4) | CHANNELS_SH(3) | BYTES_SH(1) | DOSWAP_SH(1) | PLANAR_SH(1);
const TYPE_RGB_16 = COLORSPACE_SH(4) | CHANNELS_SH(3) | BYTES_SH(2);
const TYPE_RGB_16_PLANAR = COLORSPACE_SH(4) | CHANNELS_SH(3) | BYTES_SH(2) | PLANAR_SH(1);
const TYPE_RGB_16_SE = COLORSPACE_SH(4) | CHANNELS_SH(3) | BYTES_SH(2) | ENDIAN16_SH(1);
const TYPE_BGR_16 = COLORSPACE_SH(4) | CHANNELS_SH(3) | BYTES_SH(2) | DOSWAP_SH(1);
const TYPE_BGR_16_PLANAR = COLORSPACE_SH(4) | CHANNELS_SH(3) | BYTES_SH(2) | DOSWAP_SH(1) | PLANAR_SH(1);
const TYPE_BGR_16_SE = COLORSPACE_SH(4) | CHANNELS_SH(3) | BYTES_SH(2) | DOSWAP_SH(1) | ENDIAN16_SH(1);
const TYPE_RGBA_8 = COLORSPACE_SH(4) | EXTRA_SH(1) | CHANNELS_SH(3) | BYTES_SH(1);
const TYPE_RGBA_8_PLANAR = COLORSPACE_SH(4) | EXTRA_SH(1) | CHANNELS_SH(3) | BYTES_SH(1) | PLANAR_SH(1);
const TYPE_RGBA_16 = COLORSPACE_SH(4) | EXTRA_SH(1) | CHANNELS_SH(3) | BYTES_SH(2);
const TYPE_RGBA_16_PLANAR = COLORSPACE_SH(4) | EXTRA_SH(1) | CHANNELS_SH(3) | BYTES_SH(2) | PLANAR_SH(1);
const TYPE_RGBA_16_SE = COLORSPACE_SH(4) | EXTRA_SH(1) | CHANNELS_SH(3) | BYTES_SH(2) | ENDIAN16_SH(1);
const TYPE_ARGB_8 = COLORSPACE_SH(4) | EXTRA_SH(1) | CHANNELS_SH(3) | BYTES_SH(1) | SWAPFIRST_SH(1);
const TYPE_ARGB_8_PLANAR = COLORSPACE_SH(4) | EXTRA_SH(1) | CHANNELS_SH(3) | BYTES_SH(1) | SWAPFIRST_SH(1) | PLANAR_SH(1);
const TYPE_ARGB_16 = COLORSPACE_SH(4) | EXTRA_SH(1) | CHANNELS_SH(3) | BYTES_SH(2) | SWAPFIRST_SH(1);
const TYPE_ABGR_8 = COLORSPACE_SH(4) | EXTRA_SH(1) | CHANNELS_SH(3) | BYTES_SH(1) | DOSWAP_SH(1);
const TYPE_ABGR_8_PLANAR = COLORSPACE_SH(4) | EXTRA_SH(1) | CHANNELS_SH(3) | BYTES_SH(1) | DOSWAP_SH(1) | PLANAR_SH(1);
const TYPE_ABGR_16 = COLORSPACE_SH(4) | EXTRA_SH(1) | CHANNELS_SH(3) | BYTES_SH(2) | DOSWAP_SH(1);
const TYPE_ABGR_16_PLANAR = COLORSPACE_SH(4) | EXTRA_SH(1) | CHANNELS_SH(3) | BYTES_SH(2) | DOSWAP_SH(1) | PLANAR_SH(1);
const TYPE_ABGR_16_SE = COLORSPACE_SH(4) | EXTRA_SH(1) | CHANNELS_SH(3) | BYTES_SH(2) | DOSWAP_SH(1) | ENDIAN16_SH(1);
const TYPE_BGRA_8 = COLORSPACE_SH(4) | EXTRA_SH(1) | CHANNELS_SH(3) | BYTES_SH(1) | DOSWAP_SH(1) | SWAPFIRST_SH(1);
const TYPE_BGRA_8_PLANAR = COLORSPACE_SH(4) | EXTRA_SH(1) | CHANNELS_SH(3) | BYTES_SH(1) | DOSWAP_SH(1) | SWAPFIRST_SH(1) | PLANAR_SH(1);
const TYPE_BGRA_16 = COLORSPACE_SH(4) | EXTRA_SH(1) | CHANNELS_SH(3) | BYTES_SH(2) | DOSWAP_SH(1) | SWAPFIRST_SH(1);
const TYPE_BGRA_16_SE = COLORSPACE_SH(4) | EXTRA_SH(1) | CHANNELS_SH(3) | BYTES_SH(2) | ENDIAN16_SH(1) | DOSWAP_SH(1) | SWAPFIRST_SH(1);
const TYPE_CMY_8 = COLORSPACE_SH(5) | CHANNELS_SH(3) | BYTES_SH(1);
const TYPE_CMY_8_PLANAR = COLORSPACE_SH(5) | CHANNELS_SH(3) | BYTES_SH(1) | PLANAR_SH(1);
const TYPE_CMY_16 = COLORSPACE_SH(5) | CHANNELS_SH(3) | BYTES_SH(2);
const TYPE_CMY_16_PLANAR = COLORSPACE_SH(5) | CHANNELS_SH(3) | BYTES_SH(2) | PLANAR_SH(1);
const TYPE_CMY_16_SE = COLORSPACE_SH(5) | CHANNELS_SH(3) | BYTES_SH(2) | ENDIAN16_SH(1);
const TYPE_CMYK_8 = COLORSPACE_SH(6) | CHANNELS_SH(4) | BYTES_SH(1);
const TYPE_CMYKA_8 = COLORSPACE_SH(6) | EXTRA_SH(1) | CHANNELS_SH(4) | BYTES_SH(1);
const TYPE_CMYK_8_REV = COLORSPACE_SH(6) | CHANNELS_SH(4) | BYTES_SH(1) | FLAVOR_SH(1);
const TYPE_YUVK_8 = TYPE_CMYK_8_REV;
const TYPE_CMYK_8_PLANAR = COLORSPACE_SH(6) | CHANNELS_SH(4) | BYTES_SH(1) | PLANAR_SH(1);
const TYPE_CMYK_16 = COLORSPACE_SH(6) | CHANNELS_SH(4) | BYTES_SH(2);
const TYPE_CMYK_16_REV = COLORSPACE_SH(6) | CHANNELS_SH(4) | BYTES_SH(2) | FLAVOR_SH(1);
const TYPE_YUVK_16 = TYPE_CMYK_16_REV;
const TYPE_CMYK_16_PLANAR = COLORSPACE_SH(6) | CHANNELS_SH(4) | BYTES_SH(2) | PLANAR_SH(1);
const TYPE_CMYK_16_SE = COLORSPACE_SH(6) | CHANNELS_SH(4) | BYTES_SH(2) | ENDIAN16_SH(1);
const TYPE_KYMC_8 = COLORSPACE_SH(6) | CHANNELS_SH(4) | BYTES_SH(1) | DOSWAP_SH(1);
const TYPE_KYMC_16 = COLORSPACE_SH(6) | CHANNELS_SH(4) | BYTES_SH(2) | DOSWAP_SH(1);
const TYPE_KYMC_16_SE = COLORSPACE_SH(6) | CHANNELS_SH(4) | BYTES_SH(2) | DOSWAP_SH(1) | ENDIAN16_SH(1);
const TYPE_KCMY_8 = COLORSPACE_SH(6) | CHANNELS_SH(4) | BYTES_SH(1) | SWAPFIRST_SH(1);
const TYPE_KCMY_8_REV = COLORSPACE_SH(6) | CHANNELS_SH(4) | BYTES_SH(1) | FLAVOR_SH(1) | SWAPFIRST_SH(1);
const TYPE_KCMY_16 = COLORSPACE_SH(6) | CHANNELS_SH(4) | BYTES_SH(2) | SWAPFIRST_SH(1);
const TYPE_KCMY_16_REV = COLORSPACE_SH(6) | CHANNELS_SH(4) | BYTES_SH(2) | FLAVOR_SH(1) | SWAPFIRST_SH(1);
const TYPE_KCMY_16_SE = COLORSPACE_SH(6) | CHANNELS_SH(4) | BYTES_SH(2) | ENDIAN16_SH(1) | SWAPFIRST_SH(1);
const TYPE_CMYK5_8 = COLORSPACE_SH(19) | CHANNELS_SH(5) | BYTES_SH(1);
const TYPE_CMYK5_16 = COLORSPACE_SH(19) | CHANNELS_SH(5) | BYTES_SH(2);
const TYPE_CMYK5_16_SE = COLORSPACE_SH(19) | CHANNELS_SH(5) | BYTES_SH(2) | ENDIAN16_SH(1);
const TYPE_KYMC5_8 = COLORSPACE_SH(19) | CHANNELS_SH(5) | BYTES_SH(1) | DOSWAP_SH(1);
const TYPE_KYMC5_16 = COLORSPACE_SH(19) | CHANNELS_SH(5) | BYTES_SH(2) | DOSWAP_SH(1);
const TYPE_KYMC5_16_SE = COLORSPACE_SH(19) | CHANNELS_SH(5) | BYTES_SH(2) | DOSWAP_SH(1) | ENDIAN16_SH(1);
const TYPE_CMYK6_8 = COLORSPACE_SH(20) | CHANNELS_SH(6) | BYTES_SH(1);
const TYPE_CMYK6_8_PLANAR = COLORSPACE_SH(20) | CHANNELS_SH(6) | BYTES_SH(1) | PLANAR_SH(1);
const TYPE_CMYK6_16 = COLORSPACE_SH(20) | CHANNELS_SH(6) | BYTES_SH(2);
const TYPE_CMYK6_16_PLANAR = COLORSPACE_SH(20) | CHANNELS_SH(6) | BYTES_SH(2) | PLANAR_SH(1);
const TYPE_CMYK6_16_SE = COLORSPACE_SH(20) | CHANNELS_SH(6) | BYTES_SH(2) | ENDIAN16_SH(1);
const TYPE_CMYK7_8 = COLORSPACE_SH(21) | CHANNELS_SH(7) | BYTES_SH(1);
const TYPE_CMYK7_16 = COLORSPACE_SH(21) | CHANNELS_SH(7) | BYTES_SH(2);
const TYPE_CMYK7_16_SE = COLORSPACE_SH(21) | CHANNELS_SH(7) | BYTES_SH(2) | ENDIAN16_SH(1);
const TYPE_KYMC7_8 = COLORSPACE_SH(21) | CHANNELS_SH(7) | BYTES_SH(1) | DOSWAP_SH(1);
const TYPE_KYMC7_16 = COLORSPACE_SH(21) | CHANNELS_SH(7) | BYTES_SH(2) | DOSWAP_SH(1);
const TYPE_KYMC7_16_SE = COLORSPACE_SH(21) | CHANNELS_SH(7) | BYTES_SH(2) | DOSWAP_SH(1) | ENDIAN16_SH(1);
const TYPE_CMYK8_8 = COLORSPACE_SH(22) | CHANNELS_SH(8) | BYTES_SH(1);
const TYPE_CMYK8_16 = COLORSPACE_SH(22) | CHANNELS_SH(8) | BYTES_SH(2);
const TYPE_CMYK8_16_SE = COLORSPACE_SH(22) | CHANNELS_SH(8) | BYTES_SH(2) | ENDIAN16_SH(1);
const TYPE_KYMC8_8 = COLORSPACE_SH(22) | CHANNELS_SH(8) | BYTES_SH(1) | DOSWAP_SH(1);
const TYPE_KYMC8_16 = COLORSPACE_SH(22) | CHANNELS_SH(8) | BYTES_SH(2) | DOSWAP_SH(1);
const TYPE_KYMC8_16_SE = COLORSPACE_SH(22) | CHANNELS_SH(8) | BYTES_SH(2) | DOSWAP_SH(1) | ENDIAN16_SH(1);
const TYPE_CMYK9_8 = COLORSPACE_SH(23) | CHANNELS_SH(9) | BYTES_SH(1);
const TYPE_CMYK9_16 = COLORSPACE_SH(23) | CHANNELS_SH(9) | BYTES_SH(2);
const TYPE_CMYK9_16_SE = COLORSPACE_SH(23) | CHANNELS_SH(9) | BYTES_SH(2) | ENDIAN16_SH(1);
const TYPE_KYMC9_8 = COLORSPACE_SH(23) | CHANNELS_SH(9) | BYTES_SH(1) | DOSWAP_SH(1);
const TYPE_KYMC9_16 = COLORSPACE_SH(23) | CHANNELS_SH(9) | BYTES_SH(2) | DOSWAP_SH(1);
const TYPE_KYMC9_16_SE = COLORSPACE_SH(23) | CHANNELS_SH(9) | BYTES_SH(2) | DOSWAP_SH(1) | ENDIAN16_SH(1);
const TYPE_CMYK10_8 = COLORSPACE_SH(24) | CHANNELS_SH(10) | BYTES_SH(1);
const TYPE_CMYK10_16 = COLORSPACE_SH(24) | CHANNELS_SH(10) | BYTES_SH(2);
const TYPE_CMYK10_16_SE = COLORSPACE_SH(24) | CHANNELS_SH(10) | BYTES_SH(2) | ENDIAN16_SH(1);
const TYPE_KYMC10_8 = COLORSPACE_SH(24) | CHANNELS_SH(10) | BYTES_SH(1) | DOSWAP_SH(1);
const TYPE_KYMC10_16 = COLORSPACE_SH(24) | CHANNELS_SH(10) | BYTES_SH(2) | DOSWAP_SH(1);
const TYPE_KYMC10_16_SE = COLORSPACE_SH(24) | CHANNELS_SH(10) | BYTES_SH(2) | DOSWAP_SH(1) | ENDIAN16_SH(1);
const TYPE_CMYK11_8 = COLORSPACE_SH(25) | CHANNELS_SH(11) | BYTES_SH(1);
const TYPE_CMYK11_16 = COLORSPACE_SH(25) | CHANNELS_SH(11) | BYTES_SH(2);
const TYPE_CMYK11_16_SE = COLORSPACE_SH(25) | CHANNELS_SH(11) | BYTES_SH(2) | ENDIAN16_SH(1);
const TYPE_KYMC11_8 = COLORSPACE_SH(25) | CHANNELS_SH(11) | BYTES_SH(1) | DOSWAP_SH(1);
const TYPE_KYMC11_16 = COLORSPACE_SH(25) | CHANNELS_SH(11) | BYTES_SH(2) | DOSWAP_SH(1);
const TYPE_KYMC11_16_SE = COLORSPACE_SH(25) | CHANNELS_SH(11) | BYTES_SH(2) | DOSWAP_SH(1) | ENDIAN16_SH(1);
const TYPE_CMYK12_8 = COLORSPACE_SH(26) | CHANNELS_SH(12) | BYTES_SH(1);
const TYPE_CMYK12_16 = COLORSPACE_SH(26) | CHANNELS_SH(12) | BYTES_SH(2);
const TYPE_CMYK12_16_SE = COLORSPACE_SH(26) | CHANNELS_SH(12) | BYTES_SH(2) | ENDIAN16_SH(1);
const TYPE_KYMC12_8 = COLORSPACE_SH(26) | CHANNELS_SH(12) | BYTES_SH(1) | DOSWAP_SH(1);
const TYPE_KYMC12_16 = COLORSPACE_SH(26) | CHANNELS_SH(12) | BYTES_SH(2) | DOSWAP_SH(1);
const TYPE_KYMC12_16_SE = COLORSPACE_SH(26) | CHANNELS_SH(12) | BYTES_SH(2) | DOSWAP_SH(1) | ENDIAN16_SH(1);
const TYPE_XYZ_16 = COLORSPACE_SH(9) | CHANNELS_SH(3) | BYTES_SH(2);
const TYPE_Lab_8 = COLORSPACE_SH(10) | CHANNELS_SH(3) | BYTES_SH(1);
const TYPE_LabV2_8 = COLORSPACE_SH(30) | CHANNELS_SH(3) | BYTES_SH(1);
const TYPE_ALab_8 = COLORSPACE_SH(10) | CHANNELS_SH(3) | BYTES_SH(1) | EXTRA_SH(1) | SWAPFIRST_SH(1);
const TYPE_ALabV2_8 = COLORSPACE_SH(30) | CHANNELS_SH(3) | BYTES_SH(1) | EXTRA_SH(1) | SWAPFIRST_SH(1);
const TYPE_Lab_16 = COLORSPACE_SH(10) | CHANNELS_SH(3) | BYTES_SH(2);
const TYPE_LabV2_16 = COLORSPACE_SH(30) | CHANNELS_SH(3) | BYTES_SH(2);
const TYPE_Yxy_16 = COLORSPACE_SH(14) | CHANNELS_SH(3) | BYTES_SH(2);
const TYPE_XYZ_DBL = FLOAT_SH(1) | COLORSPACE_SH(9) | CHANNELS_SH(3) | BYTES_SH(0);
const TYPE_Lab_DBL = FLOAT_SH(1) | COLORSPACE_SH(10) | CHANNELS_SH(3) | BYTES_SH(0);
const TYPE_GRAY_DBL = FLOAT_SH(1) | COLORSPACE_SH(3) | CHANNELS_SH(1) | BYTES_SH(0);
const TYPE_RGB_DBL = FLOAT_SH(1) | COLORSPACE_SH(4) | CHANNELS_SH(3) | BYTES_SH(0);
const TYPE_BGR_DBL = FLOAT_SH(1) | COLORSPACE_SH(4) | CHANNELS_SH(3) | BYTES_SH(0) | DOSWAP_SH(1);
const TYPE_CMYK_DBL = FLOAT_SH(1) | COLORSPACE_SH(6) | CHANNELS_SH(4) | BYTES_SH(0);
const cmsFLAGS_GAMUTCHECK = 4096;
const cmsFLAGS_SOFTPROOFING = 16384;
const cmsFLAGS_BLACKPOINTCOMPENSATION = 8192;
const cmsFLAGS_HIGHRESPRECALC = 1024;
const cmsFLAGS_LOWRESPRECALC = 2048;
const cmsFLAGS_COPY_ALPHA = 67108864;
var instantiate = (() => {
	var _scriptDir = import.meta.url;
	return (async function(moduleArg = {}) {
		var Module = moduleArg;
		var readyPromiseResolve, readyPromiseReject;
		Module["ready"] = new Promise((resolve, reject) => {
			readyPromiseResolve = resolve;
			readyPromiseReject = reject;
		});
		[
			"_free",
			"_malloc",
			"_cmsXYZ2xyY",
			"_cmsReadTag",
			"_cmsGetHeaderRenderingIntent",
			"_cmsGetTransformOutputFormat",
			"_cmsGetTransformInputFormat",
			"_cmsDoTransform",
			"_cmsDeleteTransform",
			"_cmsCreateProofingTransform",
			"_cmsCreateTransform",
			"_cmsFormatterForColorspaceOfProfile",
			"_cmsGetColorSpace",
			"_cmsGetProfileInfoASCII",
			"_cmsCreateLab4Profile",
			"_cmsCreateXYZProfile",
			"_cmsCreate_sRGBProfile",
			"_cmsCloseProfile",
			"_cmsOpenProfileFromMem",
			"getExceptionMessage",
			"$incrementExceptionRefcount",
			"$decrementExceptionRefcount",
			"_memory",
			"___indirect_function_table",
			"onRuntimeInitialized"
		].forEach((prop) => {
			if (!Object.getOwnPropertyDescriptor(Module["ready"], prop)) Object.defineProperty(Module["ready"], prop, {
				get: () => abort("You are getting " + prop + " on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js"),
				set: () => abort("You are setting " + prop + " on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js")
			});
		});
		var moduleOverrides = Object.assign({}, Module);
		var ENVIRONMENT_IS_WEB = typeof window == "object";
		var ENVIRONMENT_IS_WORKER = typeof importScripts == "function";
		var ENVIRONMENT_IS_NODE = typeof process == "object" && typeof process.versions == "object" && typeof process.versions.node == "string";
		var ENVIRONMENT_IS_SHELL = !ENVIRONMENT_IS_WEB && !ENVIRONMENT_IS_NODE && !ENVIRONMENT_IS_WORKER;
		if (Module["ENVIRONMENT"]) throw new Error("Module.ENVIRONMENT has been deprecated. To force the environment, use the ENVIRONMENT compile-time option (for example, -sENVIRONMENT=web or -sENVIRONMENT=node)");
		var scriptDirectory = "";
		function locateFile(path) {
			if (Module["locateFile"]) return Module["locateFile"](path, scriptDirectory);
			return scriptDirectory + path;
		}
		var read_, readBinary;
		if (ENVIRONMENT_IS_NODE) {
			if (typeof process == "undefined" || !process.release || process.release.name !== "node") throw new Error("not compiled for this environment (did you build to HTML and try to run it not on the web, or set ENVIRONMENT to something - like node - and run it someplace else - like on the web?)");
			var nodeVersion = process.versions.node;
			var numericVersion = nodeVersion.split(".").slice(0, 3);
			numericVersion = numericVersion[0] * 1e4 + numericVersion[1] * 100 + numericVersion[2].split("-")[0] * 1;
			if (numericVersion < 16e4) throw new Error("This emscripten-generated code requires node v16.0.0 (detected v" + nodeVersion + ")");
			const { createRequire } = await import("module");
			var require = createRequire(import.meta.url);
			var fs = require("fs");
			var nodePath = require("path");
			if (ENVIRONMENT_IS_WORKER) scriptDirectory = nodePath.dirname(scriptDirectory) + "/";
			else scriptDirectory = require("url").fileURLToPath(new URL("./", import.meta.url));
			read_ = (filename, binary) => {
				filename = isFileURI(filename) ? new URL(filename) : nodePath.normalize(filename);
				return fs.readFileSync(filename, binary ? void 0 : "utf8");
			};
			readBinary = (filename) => {
				var ret = read_(filename, true);
				if (!ret.buffer) ret = new Uint8Array(ret);
				assert(ret.buffer);
				return ret;
			};
			if (!Module["thisProgram"] && process.argv.length > 1) process.argv[1].replace(/\\/g, "/");
			process.argv.slice(2);
		} else if (ENVIRONMENT_IS_SHELL) {
			if (typeof process == "object" && typeof require === "function" || typeof window == "object" || typeof importScripts == "function") throw new Error("not compiled for this environment (did you build to HTML and try to run it not on the web, or set ENVIRONMENT to something - like node - and run it someplace else - like on the web?)");
			if (typeof read != "undefined") read_ = read;
			readBinary = (f) => {
				if (typeof readbuffer == "function") return new Uint8Array(readbuffer(f));
				let data = read(f, "binary");
				assert(typeof data == "object");
				return data;
			};
			if (typeof clearTimeout == "undefined") globalThis.clearTimeout = (id) => {};
			if (typeof setTimeout == "undefined") globalThis.setTimeout = (f) => typeof f == "function" ? f() : abort();
			if (typeof scriptArgs != "undefined") scriptArgs;
			else if (typeof arguments != "undefined") arguments;
			if (typeof quit == "function") {}
			if (typeof print != "undefined") {
				if (typeof console == "undefined") console = {};
				console.log = print;
				console.warn = console.error = typeof printErr != "undefined" ? printErr : print;
			}
		} else if (ENVIRONMENT_IS_WEB || ENVIRONMENT_IS_WORKER) {
			if (ENVIRONMENT_IS_WORKER) scriptDirectory = self.location.href;
			else if (typeof document != "undefined" && document.currentScript) scriptDirectory = document.currentScript.src;
			if (_scriptDir) scriptDirectory = _scriptDir;
			if (scriptDirectory.startsWith("blob:")) scriptDirectory = "";
			else scriptDirectory = scriptDirectory.substr(0, scriptDirectory.replace(/[?#].*/, "").lastIndexOf("/") + 1);
			if (!(typeof window == "object" || typeof importScripts == "function")) throw new Error("not compiled for this environment (did you build to HTML and try to run it not on the web, or set ENVIRONMENT to something - like node - and run it someplace else - like on the web?)");
			read_ = (url) => {
				var xhr = new XMLHttpRequest();
				xhr.open("GET", url, false);
				xhr.send(null);
				return xhr.responseText;
			};
			if (ENVIRONMENT_IS_WORKER) readBinary = (url) => {
				var xhr = new XMLHttpRequest();
				xhr.open("GET", url, false);
				xhr.responseType = "arraybuffer";
				xhr.send(null);
				return new Uint8Array(xhr.response);
			};
		} else throw new Error("environment detection error");
		var out = Module["print"] || console.log.bind(console);
		var err = Module["printErr"] || console.error.bind(console);
		Object.assign(Module, moduleOverrides);
		moduleOverrides = null;
		checkIncomingModuleAPI();
		if (Module["arguments"]) Module["arguments"];
		legacyModuleProp("arguments", "arguments_");
		if (Module["thisProgram"]) Module["thisProgram"];
		legacyModuleProp("thisProgram", "thisProgram");
		if (Module["quit"]) Module["quit"];
		legacyModuleProp("quit", "quit_");
		assert(typeof Module["memoryInitializerPrefixURL"] == "undefined", "Module.memoryInitializerPrefixURL option was removed, use Module.locateFile instead");
		assert(typeof Module["pthreadMainPrefixURL"] == "undefined", "Module.pthreadMainPrefixURL option was removed, use Module.locateFile instead");
		assert(typeof Module["cdInitializerPrefixURL"] == "undefined", "Module.cdInitializerPrefixURL option was removed, use Module.locateFile instead");
		assert(typeof Module["filePackagePrefixURL"] == "undefined", "Module.filePackagePrefixURL option was removed, use Module.locateFile instead");
		assert(typeof Module["read"] == "undefined", "Module.read option was removed (modify read_ in JS)");
		assert(typeof Module["readAsync"] == "undefined", "Module.readAsync option was removed (modify readAsync in JS)");
		assert(typeof Module["readBinary"] == "undefined", "Module.readBinary option was removed (modify readBinary in JS)");
		assert(typeof Module["setWindowTitle"] == "undefined", "Module.setWindowTitle option was removed (modify emscripten_set_window_title in JS)");
		assert(typeof Module["TOTAL_MEMORY"] == "undefined", "Module.TOTAL_MEMORY has been renamed Module.INITIAL_MEMORY");
		legacyModuleProp("asm", "wasmExports");
		legacyModuleProp("read", "read_");
		legacyModuleProp("readAsync", "readAsync");
		legacyModuleProp("readBinary", "readBinary");
		legacyModuleProp("setWindowTitle", "setWindowTitle");
		assert(!ENVIRONMENT_IS_SHELL, "shell environment detected but not enabled at build time.  Add `shell` to `-sENVIRONMENT` to enable.");
		var wasmBinary;
		if (Module["wasmBinary"]) wasmBinary = Module["wasmBinary"];
		legacyModuleProp("wasmBinary", "wasmBinary");
		if (typeof WebAssembly != "object") abort("no native wasm support detected");
		var wasmMemory;
		var ABORT = false;
		function assert(condition, text) {
			if (!condition) abort("Assertion failed" + (text ? ": " + text : ""));
		}
		var HEAP8, HEAPU8, HEAP16, HEAP32, HEAPU32, HEAPF32, HEAPF64;
		function updateMemoryViews() {
			var b = wasmMemory.buffer;
			Module["HEAP8"] = HEAP8 = new Int8Array(b);
			Module["HEAP16"] = HEAP16 = new Int16Array(b);
			Module["HEAPU8"] = HEAPU8 = new Uint8Array(b);
			Module["HEAPU16"] = new Uint16Array(b);
			Module["HEAP32"] = HEAP32 = new Int32Array(b);
			Module["HEAPU32"] = HEAPU32 = new Uint32Array(b);
			Module["HEAPF32"] = HEAPF32 = new Float32Array(b);
			Module["HEAPF64"] = HEAPF64 = new Float64Array(b);
		}
		assert(!Module["STACK_SIZE"], "STACK_SIZE can no longer be set at runtime.  Use -sSTACK_SIZE at link time");
		assert(typeof Int32Array != "undefined" && typeof Float64Array !== "undefined" && Int32Array.prototype.subarray != void 0 && Int32Array.prototype.set != void 0, "JS engine does not provide full typed array support");
		assert(!Module["wasmMemory"], "Use of `wasmMemory` detected.  Use -sIMPORTED_MEMORY to define wasmMemory externally");
		assert(!Module["INITIAL_MEMORY"], "Detected runtime INITIAL_MEMORY setting.  Use -sIMPORTED_MEMORY to define wasmMemory dynamically");
		function writeStackCookie() {
			var max = _emscripten_stack_get_end();
			assert((max & 3) == 0);
			if (max == 0) max += 4;
			HEAPU32[max >> 2] = 34821223;
			HEAPU32[max + 4 >> 2] = 2310721022;
			HEAPU32[0] = 1668509029;
		}
		function checkStackCookie() {
			if (ABORT) return;
			var max = _emscripten_stack_get_end();
			if (max == 0) max += 4;
			var cookie1 = HEAPU32[max >> 2];
			var cookie2 = HEAPU32[max + 4 >> 2];
			if (cookie1 != 34821223 || cookie2 != 2310721022) abort(`Stack overflow! Stack cookie has been overwritten at ${ptrToString(max)}, expected hex dwords 0x89BACDFE and 0x2135467, but received ${ptrToString(cookie2)} ${ptrToString(cookie1)}`);
			if (HEAPU32[0] != 1668509029) abort("Runtime error: The application has corrupted its heap memory area (address zero)!");
		}
		(function() {
			var h16 = new Int16Array(1);
			var h8 = new Int8Array(h16.buffer);
			h16[0] = 25459;
			if (h8[0] !== 115 || h8[1] !== 99) throw "Runtime error: expected the system to be little-endian! (Run with -sSUPPORT_BIG_ENDIAN to bypass)";
		})();
		var __ATPRERUN__ = [];
		var __ATINIT__ = [];
		var __ATPOSTRUN__ = [];
		var runtimeInitialized = false;
		function preRun() {
			if (Module["preRun"]) {
				if (typeof Module["preRun"] == "function") Module["preRun"] = [Module["preRun"]];
				while (Module["preRun"].length) addOnPreRun(Module["preRun"].shift());
			}
			callRuntimeCallbacks(__ATPRERUN__);
		}
		function initRuntime() {
			assert(!runtimeInitialized);
			runtimeInitialized = true;
			checkStackCookie();
			callRuntimeCallbacks(__ATINIT__);
		}
		function postRun() {
			checkStackCookie();
			if (Module["postRun"]) {
				if (typeof Module["postRun"] == "function") Module["postRun"] = [Module["postRun"]];
				while (Module["postRun"].length) addOnPostRun(Module["postRun"].shift());
			}
			callRuntimeCallbacks(__ATPOSTRUN__);
		}
		function addOnPreRun(cb) {
			__ATPRERUN__.unshift(cb);
		}
		function addOnInit(cb) {
			__ATINIT__.unshift(cb);
		}
		function addOnPostRun(cb) {
			__ATPOSTRUN__.unshift(cb);
		}
		assert(Math.imul, "This browser does not support Math.imul(), build with LEGACY_VM_SUPPORT or POLYFILL_OLD_MATH_FUNCTIONS to add in a polyfill");
		assert(Math.fround, "This browser does not support Math.fround(), build with LEGACY_VM_SUPPORT or POLYFILL_OLD_MATH_FUNCTIONS to add in a polyfill");
		assert(Math.clz32, "This browser does not support Math.clz32(), build with LEGACY_VM_SUPPORT or POLYFILL_OLD_MATH_FUNCTIONS to add in a polyfill");
		assert(Math.trunc, "This browser does not support Math.trunc(), build with LEGACY_VM_SUPPORT or POLYFILL_OLD_MATH_FUNCTIONS to add in a polyfill");
		var runDependencies = 0;
		var runDependencyWatcher = null;
		var dependenciesFulfilled = null;
		var runDependencyTracking = {};
		function addRunDependency(id) {
			runDependencies++;
			Module["monitorRunDependencies"]?.(runDependencies);
			if (id) {
				assert(!runDependencyTracking[id]);
				runDependencyTracking[id] = 1;
				if (runDependencyWatcher === null && typeof setInterval != "undefined") runDependencyWatcher = setInterval(() => {
					if (ABORT) {
						clearInterval(runDependencyWatcher);
						runDependencyWatcher = null;
						return;
					}
					var shown = false;
					for (var dep in runDependencyTracking) {
						if (!shown) {
							shown = true;
							err("still waiting on run dependencies:");
						}
						err(`dependency: ${dep}`);
					}
					if (shown) err("(end of list)");
				}, 1e4);
			} else err("warning: run dependency added without ID");
		}
		function removeRunDependency(id) {
			runDependencies--;
			Module["monitorRunDependencies"]?.(runDependencies);
			if (id) {
				assert(runDependencyTracking[id]);
				delete runDependencyTracking[id];
			} else err("warning: run dependency removed without ID");
			if (runDependencies == 0) {
				if (runDependencyWatcher !== null) {
					clearInterval(runDependencyWatcher);
					runDependencyWatcher = null;
				}
				if (dependenciesFulfilled) {
					var callback = dependenciesFulfilled;
					dependenciesFulfilled = null;
					callback();
				}
			}
		}
		function abort(what) {
			Module["onAbort"]?.(what);
			what = "Aborted(" + what + ")";
			err(what);
			ABORT = true;
			var e = new WebAssembly.RuntimeError(what);
			readyPromiseReject(e);
			throw e;
		}
		var FS = {
			error() {
				abort("Filesystem support (FS) was not included. The problem is that you are using files from JS, but files were not used from C/C++, so filesystem support was not auto-included. You can force-include filesystem support with -sFORCE_FILESYSTEM");
			},
			init() {
				FS.error();
			},
			createDataFile() {
				FS.error();
			},
			createPreloadedFile() {
				FS.error();
			},
			createLazyFile() {
				FS.error();
			},
			open() {
				FS.error();
			},
			mkdev() {
				FS.error();
			},
			registerDevice() {
				FS.error();
			},
			analyzePath() {
				FS.error();
			},
			ErrnoError() {
				FS.error();
			}
		};
		Module["FS_createDataFile"] = FS.createDataFile;
		Module["FS_createPreloadedFile"] = FS.createPreloadedFile;
		var dataURIPrefix = "data:application/octet-stream;base64,";
		var isDataURI = (filename) => filename.startsWith(dataURIPrefix);
		var isFileURI = (filename) => filename.startsWith("file://");
		function createExportWrapper(name) {
			return function() {
				assert(runtimeInitialized, `native function \`${name}\` called before runtime initialization`);
				var f = wasmExports[name];
				assert(f, `exported native function \`${name}\` not found`);
				return f.apply(null, arguments);
			};
		}
		class EmscriptenEH extends Error {}
		class CppException extends EmscriptenEH {
			constructor(excPtr) {
				super(excPtr);
				this.excPtr = excPtr;
				const excInfo = getExceptionMessage(excPtr);
				this.name = excInfo[0];
				this.message = excInfo[1];
			}
		}
		var wasmBinaryFile;
		if (Module["locateFile"]) {
			wasmBinaryFile = "lcms.wasm";
			if (!isDataURI(wasmBinaryFile)) wasmBinaryFile = locateFile(wasmBinaryFile);
		} else wasmBinaryFile = new URL("lcms.wasm", import.meta.url).href;
		function getBinarySync(file) {
			if (file == wasmBinaryFile && wasmBinary) return new Uint8Array(wasmBinary);
			if (readBinary) return readBinary(file);
			throw "both async and sync fetching of the wasm failed";
		}
		function getBinaryPromise(binaryFile) {
			if (!wasmBinary && (ENVIRONMENT_IS_WEB || ENVIRONMENT_IS_WORKER)) {
				if (typeof fetch == "function") return fetch(binaryFile, { credentials: "same-origin" }).then((response) => {
					if (!response["ok"]) throw `failed to load wasm binary file at '${binaryFile}'`;
					return response["arrayBuffer"]();
				}).catch(() => getBinarySync(binaryFile));
			}
			return Promise.resolve().then(() => getBinarySync(binaryFile));
		}
		function instantiateArrayBuffer(binaryFile, imports, receiver) {
			return getBinaryPromise(binaryFile).then((binary) => WebAssembly.instantiate(binary, imports)).then((instance) => instance).then(receiver, (reason) => {
				err(`failed to asynchronously prepare wasm: ${reason}`);
				if (isFileURI(wasmBinaryFile)) err(`warning: Loading from a file URI (${wasmBinaryFile}) is not supported in most browsers. See https://emscripten.org/docs/getting_started/FAQ.html#how-do-i-run-a-local-webserver-for-testing-why-does-my-program-stall-in-downloading-or-preparing`);
				abort(reason);
			});
		}
		function instantiateAsync(binary, binaryFile, imports, callback) {
			if (!binary && typeof WebAssembly.instantiateStreaming == "function" && !isDataURI(binaryFile) && !ENVIRONMENT_IS_NODE && typeof fetch == "function") return fetch(binaryFile, { credentials: "same-origin" }).then((response) => {
				return WebAssembly.instantiateStreaming(response, imports).then(callback, function(reason) {
					err(`wasm streaming compile failed: ${reason}`);
					err("falling back to ArrayBuffer instantiation");
					return instantiateArrayBuffer(binaryFile, imports, callback);
				});
			});
			return instantiateArrayBuffer(binaryFile, imports, callback);
		}
		function createWasm() {
			var info = {
				"env": wasmImports,
				"wasi_snapshot_preview1": wasmImports
			};
			function receiveInstance(instance, module) {
				wasmExports = instance.exports;
				wasmMemory = wasmExports["memory"];
				assert(wasmMemory, "memory not found in wasm exports");
				updateMemoryViews();
				wasmTable = wasmExports["__indirect_function_table"];
				assert(wasmTable, "table not found in wasm exports");
				addOnInit(wasmExports["__wasm_call_ctors"]);
				removeRunDependency("wasm-instantiate");
				return wasmExports;
			}
			addRunDependency("wasm-instantiate");
			var trueModule = Module;
			function receiveInstantiationResult(result) {
				assert(Module === trueModule, "the Module object should not be replaced during async compilation - perhaps the order of HTML elements is wrong?");
				trueModule = null;
				receiveInstance(result["instance"]);
			}
			if (Module["instantiateWasm"]) try {
				return Module["instantiateWasm"](info, receiveInstance);
			} catch (e) {
				err(`Module.instantiateWasm callback failed with error: ${e}`);
				readyPromiseReject(e);
			}
			instantiateAsync(wasmBinary, wasmBinaryFile, info, receiveInstantiationResult).catch(readyPromiseReject);
			return {};
		}
		function legacyModuleProp(prop, newName, incomming = true) {
			if (!Object.getOwnPropertyDescriptor(Module, prop)) Object.defineProperty(Module, prop, {
				configurable: true,
				get() {
					let extra = incomming ? " (the initial value can be provided on Module, but after startup the value is only looked for on a local variable of that name)" : "";
					abort(`\`Module.${prop}\` has been replaced by \`${newName}\`` + extra);
				}
			});
		}
		function ignoredModuleProp(prop) {
			if (Object.getOwnPropertyDescriptor(Module, prop)) abort(`\`Module.${prop}\` was supplied but \`${prop}\` not included in INCOMING_MODULE_JS_API`);
		}
		function isExportedByForceFilesystem(name) {
			return name === "FS_createPath" || name === "FS_createDataFile" || name === "FS_createPreloadedFile" || name === "FS_unlink" || name === "addRunDependency" || name === "FS_createLazyFile" || name === "FS_createDevice" || name === "removeRunDependency";
		}
		function missingGlobal(sym, msg) {
			if (typeof globalThis !== "undefined") Object.defineProperty(globalThis, sym, {
				configurable: true,
				get() {
					warnOnce(`\`${sym}\` is not longer defined by emscripten. ${msg}`);
				}
			});
		}
		missingGlobal("buffer", "Please use HEAP8.buffer or wasmMemory.buffer");
		missingGlobal("asm", "Please use wasmExports instead");
		function missingLibrarySymbol(sym) {
			if (typeof globalThis !== "undefined" && !Object.getOwnPropertyDescriptor(globalThis, sym)) Object.defineProperty(globalThis, sym, {
				configurable: true,
				get() {
					var msg = `\`${sym}\` is a library symbol and not included by default; add it to your library.js __deps or to DEFAULT_LIBRARY_FUNCS_TO_INCLUDE on the command line`;
					var librarySymbol = sym;
					if (!librarySymbol.startsWith("_")) librarySymbol = "$" + sym;
					msg += ` (e.g. -sDEFAULT_LIBRARY_FUNCS_TO_INCLUDE='${librarySymbol}')`;
					if (isExportedByForceFilesystem(sym)) msg += ". Alternatively, forcing filesystem support (-sFORCE_FILESYSTEM) can export this for you";
					warnOnce(msg);
				}
			});
			unexportedRuntimeSymbol(sym);
		}
		function unexportedRuntimeSymbol(sym) {
			if (!Object.getOwnPropertyDescriptor(Module, sym)) Object.defineProperty(Module, sym, {
				configurable: true,
				get() {
					var msg = `'${sym}' was not exported. add it to EXPORTED_RUNTIME_METHODS (see the Emscripten FAQ)`;
					if (isExportedByForceFilesystem(sym)) msg += ". Alternatively, forcing filesystem support (-sFORCE_FILESYSTEM) can export this for you";
					abort(msg);
				}
			});
		}
		var callRuntimeCallbacks = (callbacks) => {
			while (callbacks.length > 0) callbacks.shift()(Module);
		};
		var withStackSave = (f) => {
			var stack = stackSave();
			var ret = f();
			stackRestore(stack);
			return ret;
		};
		var UTF8Decoder = typeof TextDecoder != "undefined" ? new TextDecoder("utf8") : void 0;
		var UTF8ArrayToString = (heapOrArray, idx, maxBytesToRead) => {
			var endIdx = idx + maxBytesToRead;
			var endPtr = idx;
			while (heapOrArray[endPtr] && !(endPtr >= endIdx)) ++endPtr;
			if (endPtr - idx > 16 && heapOrArray.buffer && UTF8Decoder) return UTF8Decoder.decode(heapOrArray.subarray(idx, endPtr));
			var str = "";
			while (idx < endPtr) {
				var u0 = heapOrArray[idx++];
				if (!(u0 & 128)) {
					str += String.fromCharCode(u0);
					continue;
				}
				var u1 = heapOrArray[idx++] & 63;
				if ((u0 & 224) == 192) {
					str += String.fromCharCode((u0 & 31) << 6 | u1);
					continue;
				}
				var u2 = heapOrArray[idx++] & 63;
				if ((u0 & 240) == 224) u0 = (u0 & 15) << 12 | u1 << 6 | u2;
				else {
					if ((u0 & 248) != 240) warnOnce("Invalid UTF-8 leading byte " + ptrToString(u0) + " encountered when deserializing a UTF-8 string in wasm memory to a JS string!");
					u0 = (u0 & 7) << 18 | u1 << 12 | u2 << 6 | heapOrArray[idx++] & 63;
				}
				if (u0 < 65536) str += String.fromCharCode(u0);
				else {
					var ch = u0 - 65536;
					str += String.fromCharCode(55296 | ch >> 10, 56320 | ch & 1023);
				}
			}
			return str;
		};
		var UTF8ToString = (ptr, maxBytesToRead) => {
			assert(typeof ptr == "number", `UTF8ToString expects a number (got ${typeof ptr})`);
			return ptr ? UTF8ArrayToString(HEAPU8, ptr, maxBytesToRead) : "";
		};
		var getExceptionMessageCommon = (ptr) => withStackSave(() => {
			var type_addr_addr = stackAlloc(4);
			var message_addr_addr = stackAlloc(4);
			___get_exception_message(ptr, type_addr_addr, message_addr_addr);
			var type_addr = HEAPU32[type_addr_addr >> 2];
			var message_addr = HEAPU32[message_addr_addr >> 2];
			var type = UTF8ToString(type_addr);
			_free(type_addr);
			var message;
			if (message_addr) {
				message = UTF8ToString(message_addr);
				_free(message_addr);
			}
			return [type, message];
		});
		var getExceptionMessage = (ptr) => getExceptionMessageCommon(ptr);
		Module["getExceptionMessage"] = getExceptionMessage;
		function getValue(ptr, type = "i8") {
			if (type.endsWith("*")) type = "*";
			switch (type) {
				case "i1": return HEAP8[ptr >> 0];
				case "i8": return HEAP8[ptr >> 0];
				case "i16": return HEAP16[ptr >> 1];
				case "i32": return HEAP32[ptr >> 2];
				case "i64": abort("to do getValue(i64) use WASM_BIGINT");
				case "float": return HEAPF32[ptr >> 2];
				case "double": return HEAPF64[ptr >> 3];
				case "*": return HEAPU32[ptr >> 2];
				default: abort(`invalid type for getValue: ${type}`);
			}
		}
		Module["noExitRuntime"];
		var ptrToString = (ptr) => {
			assert(typeof ptr === "number");
			ptr >>>= 0;
			return "0x" + ptr.toString(16).padStart(8, "0");
		};
		function setValue(ptr, value, type = "i8") {
			if (type.endsWith("*")) type = "*";
			switch (type) {
				case "i1":
					HEAP8[ptr >> 0] = value;
					break;
				case "i8":
					HEAP8[ptr >> 0] = value;
					break;
				case "i16":
					HEAP16[ptr >> 1] = value;
					break;
				case "i32":
					HEAP32[ptr >> 2] = value;
					break;
				case "i64": abort("to do setValue(i64) use WASM_BIGINT");
				case "float":
					HEAPF32[ptr >> 2] = value;
					break;
				case "double":
					HEAPF64[ptr >> 3] = value;
					break;
				case "*":
					HEAPU32[ptr >> 2] = value;
					break;
				default: abort(`invalid type for setValue: ${type}`);
			}
		}
		var warnOnce = (text) => {
			warnOnce.shown ||= {};
			if (!warnOnce.shown[text]) {
				warnOnce.shown[text] = 1;
				if (ENVIRONMENT_IS_NODE) text = "warning: " + text;
				err(text);
			}
		};
		var ___assert_fail = (condition, filename, line, func) => {
			abort(`Assertion failed: ${UTF8ToString(condition)}, at: ` + [
				filename ? UTF8ToString(filename) : "unknown filename",
				line,
				func ? UTF8ToString(func) : "unknown function"
			]);
		};
		var exceptionCaught = [];
		var uncaughtExceptionCount = 0;
		var ___cxa_begin_catch = (ptr) => {
			var info = new ExceptionInfo(ptr);
			if (!info.get_caught()) {
				info.set_caught(true);
				uncaughtExceptionCount--;
			}
			info.set_rethrown(false);
			exceptionCaught.push(info);
			___cxa_increment_exception_refcount(info.excPtr);
			return info.get_exception_ptr();
		};
		var exceptionLast = 0;
		class ExceptionInfo {
			constructor(excPtr) {
				this.excPtr = excPtr;
				this.ptr = excPtr - 24;
			}
			set_type(type) {
				HEAPU32[this.ptr + 4 >> 2] = type;
			}
			get_type() {
				return HEAPU32[this.ptr + 4 >> 2];
			}
			set_destructor(destructor) {
				HEAPU32[this.ptr + 8 >> 2] = destructor;
			}
			get_destructor() {
				return HEAPU32[this.ptr + 8 >> 2];
			}
			set_caught(caught) {
				caught = caught ? 1 : 0;
				HEAP8[this.ptr + 12 >> 0] = caught;
			}
			get_caught() {
				return HEAP8[this.ptr + 12 >> 0] != 0;
			}
			set_rethrown(rethrown) {
				rethrown = rethrown ? 1 : 0;
				HEAP8[this.ptr + 13 >> 0] = rethrown;
			}
			get_rethrown() {
				return HEAP8[this.ptr + 13 >> 0] != 0;
			}
			init(type, destructor) {
				this.set_adjusted_ptr(0);
				this.set_type(type);
				this.set_destructor(destructor);
			}
			set_adjusted_ptr(adjustedPtr) {
				HEAPU32[this.ptr + 16 >> 2] = adjustedPtr;
			}
			get_adjusted_ptr() {
				return HEAPU32[this.ptr + 16 >> 2];
			}
			get_exception_ptr() {
				if (___cxa_is_pointer_type(this.get_type())) return HEAPU32[this.excPtr >> 2];
				var adjusted = this.get_adjusted_ptr();
				if (adjusted !== 0) return adjusted;
				return this.excPtr;
			}
		}
		var ___resumeException = (ptr) => {
			if (!exceptionLast) exceptionLast = new CppException(ptr);
			throw exceptionLast;
		};
		var findMatchingCatch = (args) => {
			var thrown = exceptionLast?.excPtr;
			if (!thrown) {
				setTempRet0(0);
				return 0;
			}
			var info = new ExceptionInfo(thrown);
			info.set_adjusted_ptr(thrown);
			var thrownType = info.get_type();
			if (!thrownType) {
				setTempRet0(0);
				return thrown;
			}
			for (var arg in args) {
				var caughtType = args[arg];
				if (caughtType === 0 || caughtType === thrownType) break;
				if (___cxa_can_catch(caughtType, thrownType, info.ptr + 16)) {
					setTempRet0(caughtType);
					return thrown;
				}
			}
			setTempRet0(thrownType);
			return thrown;
		};
		var ___cxa_find_matching_catch_2 = () => findMatchingCatch([]);
		var ___cxa_find_matching_catch_3 = (arg0) => findMatchingCatch([arg0]);
		var SYSCALLS = {
			varargs: void 0,
			get() {
				assert(SYSCALLS.varargs != void 0);
				var ret = HEAP32[+SYSCALLS.varargs >> 2];
				SYSCALLS.varargs += 4;
				return ret;
			},
			getp() {
				return SYSCALLS.get();
			},
			getStr(ptr) {
				return UTF8ToString(ptr);
			}
		};
		function ___syscall_fcntl64(fd, cmd, varargs) {
			SYSCALLS.varargs = varargs;
			return 0;
		}
		function ___syscall_ioctl(fd, op, varargs) {
			SYSCALLS.varargs = varargs;
			return 0;
		}
		function ___syscall_openat(dirfd, path, flags, varargs) {
			SYSCALLS.varargs = varargs;
			abort("it should not be possible to operate on streams when !SYSCALLS_REQUIRE_FILESYSTEM");
		}
		var ___syscall_rmdir = (path) => {
			abort("it should not be possible to operate on streams when !SYSCALLS_REQUIRE_FILESYSTEM");
		};
		var ___syscall_unlinkat = (dirfd, path, flags) => {
			abort("it should not be possible to operate on streams when !SYSCALLS_REQUIRE_FILESYSTEM");
		};
		var convertI32PairToI53Checked = (lo, hi) => {
			assert(lo == lo >>> 0 || lo == (lo | 0));
			assert(hi === (hi | 0));
			return hi + 2097152 >>> 0 < 4194305 - !!lo ? (lo >>> 0) + hi * 4294967296 : NaN;
		};
		function __gmtime_js(time_low, time_high, tmPtr) {
			var time = convertI32PairToI53Checked(time_low, time_high);
			var date = /* @__PURE__ */ new Date(time * 1e3);
			HEAP32[tmPtr >> 2] = date.getUTCSeconds();
			HEAP32[tmPtr + 4 >> 2] = date.getUTCMinutes();
			HEAP32[tmPtr + 8 >> 2] = date.getUTCHours();
			HEAP32[tmPtr + 12 >> 2] = date.getUTCDate();
			HEAP32[tmPtr + 16 >> 2] = date.getUTCMonth();
			HEAP32[tmPtr + 20 >> 2] = date.getUTCFullYear() - 1900;
			HEAP32[tmPtr + 24 >> 2] = date.getUTCDay();
			var start = Date.UTC(date.getUTCFullYear(), 0, 1, 0, 0, 0, 0);
			var yday = (date.getTime() - start) / (1e3 * 60 * 60 * 24) | 0;
			HEAP32[tmPtr + 28 >> 2] = yday;
		}
		var lengthBytesUTF8 = (str) => {
			var len = 0;
			for (var i = 0; i < str.length; ++i) {
				var c = str.charCodeAt(i);
				if (c <= 127) len++;
				else if (c <= 2047) len += 2;
				else if (c >= 55296 && c <= 57343) {
					len += 4;
					++i;
				} else len += 3;
			}
			return len;
		};
		var stringToUTF8Array = (str, heap, outIdx, maxBytesToWrite) => {
			assert(typeof str === "string", `stringToUTF8Array expects a string (got ${typeof str})`);
			if (!(maxBytesToWrite > 0)) return 0;
			var startIdx = outIdx;
			var endIdx = outIdx + maxBytesToWrite - 1;
			for (var i = 0; i < str.length; ++i) {
				var u = str.charCodeAt(i);
				if (u >= 55296 && u <= 57343) {
					var u1 = str.charCodeAt(++i);
					u = 65536 + ((u & 1023) << 10) | u1 & 1023;
				}
				if (u <= 127) {
					if (outIdx >= endIdx) break;
					heap[outIdx++] = u;
				} else if (u <= 2047) {
					if (outIdx + 1 >= endIdx) break;
					heap[outIdx++] = 192 | u >> 6;
					heap[outIdx++] = 128 | u & 63;
				} else if (u <= 65535) {
					if (outIdx + 2 >= endIdx) break;
					heap[outIdx++] = 224 | u >> 12;
					heap[outIdx++] = 128 | u >> 6 & 63;
					heap[outIdx++] = 128 | u & 63;
				} else {
					if (outIdx + 3 >= endIdx) break;
					if (u > 1114111) warnOnce("Invalid Unicode code point " + ptrToString(u) + " encountered when serializing a JS string to a UTF-8 string in wasm memory! (Valid unicode code points should be in range 0-0x10FFFF).");
					heap[outIdx++] = 240 | u >> 18;
					heap[outIdx++] = 128 | u >> 12 & 63;
					heap[outIdx++] = 128 | u >> 6 & 63;
					heap[outIdx++] = 128 | u & 63;
				}
			}
			heap[outIdx] = 0;
			return outIdx - startIdx;
		};
		var stringToUTF8 = (str, outPtr, maxBytesToWrite) => {
			assert(typeof maxBytesToWrite == "number", "stringToUTF8(str, outPtr, maxBytesToWrite) is missing the third parameter that specifies the length of the output buffer!");
			return stringToUTF8Array(str, HEAPU8, outPtr, maxBytesToWrite);
		};
		var stringToNewUTF8 = (str) => {
			var size = lengthBytesUTF8(str) + 1;
			var ret = _malloc(size);
			if (ret) stringToUTF8(str, ret, size);
			return ret;
		};
		var __tzset_js = (timezone, daylight, tzname) => {
			var currentYear = (/* @__PURE__ */ new Date()).getFullYear();
			var winter = new Date(currentYear, 0, 1);
			var summer = new Date(currentYear, 6, 1);
			var winterOffset = winter.getTimezoneOffset();
			var summerOffset = summer.getTimezoneOffset();
			var stdTimezoneOffset = Math.max(winterOffset, summerOffset);
			HEAPU32[timezone >> 2] = stdTimezoneOffset * 60;
			HEAP32[daylight >> 2] = Number(winterOffset != summerOffset);
			function extractZone(date) {
				var match = date.toTimeString().match(/\(([A-Za-z ]+)\)$/);
				return match ? match[1] : "GMT";
			}
			var winterName = extractZone(winter);
			var summerName = extractZone(summer);
			var winterNamePtr = stringToNewUTF8(winterName);
			var summerNamePtr = stringToNewUTF8(summerName);
			if (summerOffset < winterOffset) {
				HEAPU32[tzname >> 2] = winterNamePtr;
				HEAPU32[tzname + 4 >> 2] = summerNamePtr;
			} else {
				HEAPU32[tzname >> 2] = summerNamePtr;
				HEAPU32[tzname + 4 >> 2] = winterNamePtr;
			}
		};
		var _abort = () => {
			abort("native code called abort()");
		};
		var _emscripten_date_now = () => Date.now();
		var _emscripten_memcpy_js = (dest, src, num) => HEAPU8.copyWithin(dest, src, src + num);
		var getHeapMax = () => 2147483648;
		var growMemory = (size) => {
			var b = wasmMemory.buffer;
			var pages = (size - b.byteLength + 65535) / 65536;
			try {
				wasmMemory.grow(pages);
				updateMemoryViews();
				return 1;
			} catch (e) {
				err(`growMemory: Attempted to grow heap from ${b.byteLength} bytes to ${size} bytes, but got error: ${e}`);
			}
		};
		var _emscripten_resize_heap = (requestedSize) => {
			var oldSize = HEAPU8.length;
			requestedSize >>>= 0;
			assert(requestedSize > oldSize);
			var maxHeapSize = getHeapMax();
			if (requestedSize > maxHeapSize) {
				err(`Cannot enlarge memory, requested ${requestedSize} bytes, but the limit is ${maxHeapSize} bytes!`);
				return false;
			}
			var alignUp = (x, multiple) => x + (multiple - x % multiple) % multiple;
			for (var cutDown = 1; cutDown <= 4; cutDown *= 2) {
				var overGrownHeapSize = oldSize * (1 + .2 / cutDown);
				overGrownHeapSize = Math.min(overGrownHeapSize, requestedSize + 100663296);
				var newSize = Math.min(maxHeapSize, alignUp(Math.max(requestedSize, overGrownHeapSize), 65536));
				if (growMemory(newSize)) return true;
			}
			err(`Failed to grow the heap from ${oldSize} bytes to ${newSize} bytes, not enough memory!`);
			return false;
		};
		var _fd_close = (fd) => {
			abort("fd_close called without SYSCALLS_REQUIRE_FILESYSTEM");
		};
		var _fd_read = (fd, iov, iovcnt, pnum) => {
			abort("fd_read called without SYSCALLS_REQUIRE_FILESYSTEM");
		};
		function _fd_seek(fd, offset_low, offset_high, whence, newOffset) {
			convertI32PairToI53Checked(offset_low, offset_high);
			return 70;
		}
		var printCharBuffers = [
			null,
			[],
			[]
		];
		var printChar = (stream, curr) => {
			var buffer = printCharBuffers[stream];
			assert(buffer);
			if (curr === 0 || curr === 10) {
				(stream === 1 ? out : err)(UTF8ArrayToString(buffer, 0));
				buffer.length = 0;
			} else buffer.push(curr);
		};
		var _fd_write = (fd, iov, iovcnt, pnum) => {
			var num = 0;
			for (var i = 0; i < iovcnt; i++) {
				var ptr = HEAPU32[iov >> 2];
				var len = HEAPU32[iov + 4 >> 2];
				iov += 8;
				for (var j = 0; j < len; j++) printChar(fd, HEAPU8[ptr + j]);
				num += len;
			}
			HEAPU32[pnum >> 2] = num;
			return 0;
		};
		var wasmTableMirror = [];
		var wasmTable;
		var getWasmTableEntry = (funcPtr) => {
			var func = wasmTableMirror[funcPtr];
			if (!func) {
				if (funcPtr >= wasmTableMirror.length) wasmTableMirror.length = funcPtr + 1;
				wasmTableMirror[funcPtr] = func = wasmTable.get(funcPtr);
			}
			assert(wasmTable.get(funcPtr) == func, "JavaScript-side Wasm function table mirror is out of date!");
			return func;
		};
		var getCFunc = (ident) => {
			var func = Module["_" + ident];
			assert(func, "Cannot call unknown function " + ident + ", make sure it is exported");
			return func;
		};
		var writeArrayToMemory = (array, buffer) => {
			assert(array.length >= 0, "writeArrayToMemory array must have a length (should be an array or typed array)");
			HEAP8.set(array, buffer);
		};
		var stringToUTF8OnStack = (str) => {
			var size = lengthBytesUTF8(str) + 1;
			var ret = stackAlloc(size);
			stringToUTF8(str, ret, size);
			return ret;
		};
		var ccall = (ident, returnType, argTypes, args, opts) => {
			var toC = {
				"string": (str) => {
					var ret = 0;
					if (str !== null && str !== void 0 && str !== 0) ret = stringToUTF8OnStack(str);
					return ret;
				},
				"array": (arr) => {
					var ret = stackAlloc(arr.length);
					writeArrayToMemory(arr, ret);
					return ret;
				}
			};
			function convertReturnValue(ret) {
				if (returnType === "string") return UTF8ToString(ret);
				if (returnType === "boolean") return Boolean(ret);
				return ret;
			}
			var func = getCFunc(ident);
			var cArgs = [];
			var stack = 0;
			assert(returnType !== "array", "Return type should not be \"array\".");
			if (args) for (var i = 0; i < args.length; i++) {
				var converter = toC[argTypes[i]];
				if (converter) {
					if (stack === 0) stack = stackSave();
					cArgs[i] = converter(args[i]);
				} else cArgs[i] = args[i];
			}
			var ret = func.apply(null, cArgs);
			function onDone(ret) {
				if (stack !== 0) stackRestore(stack);
				return convertReturnValue(ret);
			}
			ret = onDone(ret);
			return ret;
		};
		var cwrap = (ident, returnType, argTypes, opts) => function() {
			return ccall(ident, returnType, argTypes, arguments, opts);
		};
		function checkIncomingModuleAPI() {
			ignoredModuleProp("fetchSettings");
		}
		var wasmImports = {
			__assert_fail: ___assert_fail,
			__cxa_begin_catch: ___cxa_begin_catch,
			__cxa_find_matching_catch_2: ___cxa_find_matching_catch_2,
			__cxa_find_matching_catch_3: ___cxa_find_matching_catch_3,
			__resumeException: ___resumeException,
			__syscall_fcntl64: ___syscall_fcntl64,
			__syscall_ioctl: ___syscall_ioctl,
			__syscall_openat: ___syscall_openat,
			__syscall_rmdir: ___syscall_rmdir,
			__syscall_unlinkat: ___syscall_unlinkat,
			_gmtime_js: __gmtime_js,
			_tzset_js: __tzset_js,
			abort: _abort,
			emscripten_date_now: _emscripten_date_now,
			emscripten_memcpy_js: _emscripten_memcpy_js,
			emscripten_resize_heap: _emscripten_resize_heap,
			fd_close: _fd_close,
			fd_read: _fd_read,
			fd_seek: _fd_seek,
			fd_write: _fd_write,
			invoke_ii,
			invoke_iii,
			invoke_v,
			invoke_vi,
			invoke_vii,
			invoke_viii,
			invoke_viiii
		};
		var wasmExports = createWasm();
		Module["_cmsGetColorSpace"] = createExportWrapper("cmsGetColorSpace");
		Module["_cmsXYZ2xyY"] = createExportWrapper("cmsXYZ2xyY");
		Module["_cmsCloseProfile"] = createExportWrapper("cmsCloseProfile");
		Module["_cmsDeleteTransform"] = createExportWrapper("cmsDeleteTransform");
		Module["_cmsDoTransform"] = createExportWrapper("cmsDoTransform");
		var _malloc = Module["_malloc"] = createExportWrapper("malloc");
		var _free = Module["_free"] = createExportWrapper("free");
		Module["_cmsFormatterForColorspaceOfProfile"] = createExportWrapper("cmsFormatterForColorspaceOfProfile");
		Module["_cmsGetHeaderRenderingIntent"] = createExportWrapper("cmsGetHeaderRenderingIntent");
		Module["_cmsOpenProfileFromMem"] = createExportWrapper("cmsOpenProfileFromMem");
		Module["_cmsReadTag"] = createExportWrapper("cmsReadTag");
		Module["_cmsGetProfileInfoASCII"] = createExportWrapper("cmsGetProfileInfoASCII");
		Module["_cmsCreateTransform"] = createExportWrapper("cmsCreateTransform");
		Module["_cmsCreateXYZProfile"] = createExportWrapper("cmsCreateXYZProfile");
		Module["_cmsCreateLab4Profile"] = createExportWrapper("cmsCreateLab4Profile");
		Module["_cmsCreate_sRGBProfile"] = createExportWrapper("cmsCreate_sRGBProfile");
		Module["_cmsCreateProofingTransform"] = createExportWrapper("cmsCreateProofingTransform");
		Module["_cmsGetTransformInputFormat"] = createExportWrapper("cmsGetTransformInputFormat");
		Module["_cmsGetTransformOutputFormat"] = createExportWrapper("cmsGetTransformOutputFormat");
		var _setThrew = createExportWrapper("setThrew");
		var setTempRet0 = createExportWrapper("setTempRet0");
		var _emscripten_stack_init = () => (_emscripten_stack_init = wasmExports["emscripten_stack_init"])();
		var _emscripten_stack_get_free = () => (_emscripten_stack_get_free = wasmExports["emscripten_stack_get_free"])();
		var _emscripten_stack_get_base = () => (_emscripten_stack_get_base = wasmExports["emscripten_stack_get_base"])();
		var _emscripten_stack_get_end = () => (_emscripten_stack_get_end = wasmExports["emscripten_stack_get_end"])();
		var stackSave = createExportWrapper("stackSave");
		var stackRestore = createExportWrapper("stackRestore");
		var stackAlloc = createExportWrapper("stackAlloc");
		var _emscripten_stack_get_current = () => (_emscripten_stack_get_current = wasmExports["emscripten_stack_get_current"])();
		var ___cxa_increment_exception_refcount = createExportWrapper("__cxa_increment_exception_refcount");
		var ___get_exception_message = createExportWrapper("__get_exception_message");
		var ___cxa_can_catch = createExportWrapper("__cxa_can_catch");
		var ___cxa_is_pointer_type = createExportWrapper("__cxa_is_pointer_type");
		Module["dynCall_jiji"] = createExportWrapper("dynCall_jiji");
		function invoke_ii(index, a1) {
			var sp = stackSave();
			try {
				return getWasmTableEntry(index)(a1);
			} catch (e) {
				stackRestore(sp);
				if (!(e instanceof EmscriptenEH)) throw e;
				_setThrew(1, 0);
			}
		}
		function invoke_v(index) {
			var sp = stackSave();
			try {
				getWasmTableEntry(index)();
			} catch (e) {
				stackRestore(sp);
				if (!(e instanceof EmscriptenEH)) throw e;
				_setThrew(1, 0);
			}
		}
		function invoke_vii(index, a1, a2) {
			var sp = stackSave();
			try {
				getWasmTableEntry(index)(a1, a2);
			} catch (e) {
				stackRestore(sp);
				if (!(e instanceof EmscriptenEH)) throw e;
				_setThrew(1, 0);
			}
		}
		function invoke_vi(index, a1) {
			var sp = stackSave();
			try {
				getWasmTableEntry(index)(a1);
			} catch (e) {
				stackRestore(sp);
				if (!(e instanceof EmscriptenEH)) throw e;
				_setThrew(1, 0);
			}
		}
		function invoke_viiii(index, a1, a2, a3, a4) {
			var sp = stackSave();
			try {
				getWasmTableEntry(index)(a1, a2, a3, a4);
			} catch (e) {
				stackRestore(sp);
				if (!(e instanceof EmscriptenEH)) throw e;
				_setThrew(1, 0);
			}
		}
		function invoke_iii(index, a1, a2) {
			var sp = stackSave();
			try {
				return getWasmTableEntry(index)(a1, a2);
			} catch (e) {
				stackRestore(sp);
				if (!(e instanceof EmscriptenEH)) throw e;
				_setThrew(1, 0);
			}
		}
		function invoke_viii(index, a1, a2, a3) {
			var sp = stackSave();
			try {
				getWasmTableEntry(index)(a1, a2, a3);
			} catch (e) {
				stackRestore(sp);
				if (!(e instanceof EmscriptenEH)) throw e;
				_setThrew(1, 0);
			}
		}
		Module["ccall"] = ccall;
		Module["cwrap"] = cwrap;
		[
			"writeI53ToI64",
			"writeI53ToI64Clamped",
			"writeI53ToI64Signaling",
			"writeI53ToU64Clamped",
			"writeI53ToU64Signaling",
			"readI53FromI64",
			"readI53FromU64",
			"convertI32PairToI53",
			"convertU32PairToI53",
			"zeroMemory",
			"exitJS",
			"isLeapYear",
			"ydayFromDate",
			"arraySum",
			"addDays",
			"inetPton4",
			"inetNtop4",
			"inetPton6",
			"inetNtop6",
			"readSockaddr",
			"writeSockaddr",
			"initRandomFill",
			"randomFill",
			"getCallstack",
			"emscriptenLog",
			"convertPCtoSourceLocation",
			"readEmAsmArgs",
			"jstoi_q",
			"getExecutableName",
			"listenOnce",
			"autoResumeAudioContext",
			"dynCallLegacy",
			"getDynCaller",
			"dynCall",
			"handleException",
			"keepRuntimeAlive",
			"runtimeKeepalivePush",
			"runtimeKeepalivePop",
			"callUserCallback",
			"maybeExit",
			"asmjsMangle",
			"asyncLoad",
			"alignMemory",
			"mmapAlloc",
			"HandleAllocator",
			"getNativeTypeSize",
			"STACK_SIZE",
			"STACK_ALIGN",
			"POINTER_SIZE",
			"ASSERTIONS",
			"uleb128Encode",
			"sigToWasmTypes",
			"generateFuncType",
			"convertJsFunctionToWasm",
			"getEmptyTableSlot",
			"updateTableMap",
			"getFunctionAddress",
			"addFunction",
			"removeFunction",
			"reallyNegative",
			"unSign",
			"strLen",
			"reSign",
			"formatString",
			"intArrayFromString",
			"intArrayToString",
			"AsciiToString",
			"stringToAscii",
			"UTF16ToString",
			"stringToUTF16",
			"lengthBytesUTF16",
			"UTF32ToString",
			"stringToUTF32",
			"lengthBytesUTF32",
			"registerKeyEventCallback",
			"maybeCStringToJsString",
			"findEventTarget",
			"getBoundingClientRect",
			"fillMouseEventData",
			"registerMouseEventCallback",
			"registerWheelEventCallback",
			"registerUiEventCallback",
			"registerFocusEventCallback",
			"fillDeviceOrientationEventData",
			"registerDeviceOrientationEventCallback",
			"fillDeviceMotionEventData",
			"registerDeviceMotionEventCallback",
			"screenOrientation",
			"fillOrientationChangeEventData",
			"registerOrientationChangeEventCallback",
			"fillFullscreenChangeEventData",
			"registerFullscreenChangeEventCallback",
			"JSEvents_requestFullscreen",
			"JSEvents_resizeCanvasForFullscreen",
			"registerRestoreOldStyle",
			"hideEverythingExceptGivenElement",
			"restoreHiddenElements",
			"setLetterbox",
			"softFullscreenResizeWebGLRenderTarget",
			"doRequestFullscreen",
			"fillPointerlockChangeEventData",
			"registerPointerlockChangeEventCallback",
			"registerPointerlockErrorEventCallback",
			"requestPointerLock",
			"fillVisibilityChangeEventData",
			"registerVisibilityChangeEventCallback",
			"registerTouchEventCallback",
			"fillGamepadEventData",
			"registerGamepadEventCallback",
			"registerBeforeUnloadEventCallback",
			"fillBatteryEventData",
			"battery",
			"registerBatteryEventCallback",
			"setCanvasElementSize",
			"getCanvasElementSize",
			"demangle",
			"jsStackTrace",
			"stackTrace",
			"getEnvStrings",
			"checkWasiClock",
			"wasiRightsToMuslOFlags",
			"wasiOFlagsToMuslOFlags",
			"createDyncallWrapper",
			"safeSetTimeout",
			"setImmediateWrapped",
			"clearImmediateWrapped",
			"polyfillSetImmediate",
			"getPromise",
			"makePromise",
			"idsToPromises",
			"makePromiseCallback",
			"Browser_asyncPrepareDataCounter",
			"setMainLoop",
			"getSocketFromFD",
			"getSocketAddress",
			"heapObjectForWebGLType",
			"heapAccessShiftForWebGLHeap",
			"webgl_enable_ANGLE_instanced_arrays",
			"webgl_enable_OES_vertex_array_object",
			"webgl_enable_WEBGL_draw_buffers",
			"webgl_enable_WEBGL_multi_draw",
			"emscriptenWebGLGet",
			"computeUnpackAlignedImageSize",
			"colorChannelsInGlTextureFormat",
			"emscriptenWebGLGetTexPixelData",
			"__glGenObject",
			"emscriptenWebGLGetUniform",
			"webglGetUniformLocation",
			"webglPrepareUniformLocationsBeforeFirstUse",
			"webglGetLeftBracePos",
			"emscriptenWebGLGetVertexAttrib",
			"__glGetActiveAttribOrUniform",
			"writeGLArray",
			"registerWebGlEventCallback",
			"runAndAbortIfError",
			"SDL_unicode",
			"SDL_ttfContext",
			"SDL_audio",
			"ALLOC_NORMAL",
			"ALLOC_STACK",
			"allocate",
			"writeStringToMemory",
			"writeAsciiToMemory",
			"setErrNo"
		].forEach(missingLibrarySymbol);
		[
			"run",
			"addOnPreRun",
			"addOnInit",
			"addOnPreMain",
			"addOnExit",
			"addOnPostRun",
			"addRunDependency",
			"removeRunDependency",
			"FS_createFolder",
			"FS_createPath",
			"FS_createLazyFile",
			"FS_createLink",
			"FS_createDevice",
			"FS_readFile",
			"out",
			"err",
			"callMain",
			"abort",
			"wasmMemory",
			"wasmExports",
			"stackAlloc",
			"stackSave",
			"stackRestore",
			"getTempRet0",
			"setTempRet0",
			"writeStackCookie",
			"checkStackCookie",
			"convertI32PairToI53Checked",
			"ptrToString",
			"getHeapMax",
			"growMemory",
			"ENV",
			"MONTH_DAYS_REGULAR",
			"MONTH_DAYS_LEAP",
			"MONTH_DAYS_REGULAR_CUMULATIVE",
			"MONTH_DAYS_LEAP_CUMULATIVE",
			"ERRNO_CODES",
			"ERRNO_MESSAGES",
			"DNS",
			"Protocols",
			"Sockets",
			"timers",
			"warnOnce",
			"UNWIND_CACHE",
			"readEmAsmArgsArray",
			"jstoi_s",
			"wasmTable",
			"noExitRuntime",
			"getCFunc",
			"freeTableIndexes",
			"functionsInTableMap",
			"setValue",
			"getValue",
			"PATH",
			"PATH_FS",
			"UTF8Decoder",
			"UTF8ArrayToString",
			"UTF8ToString",
			"stringToUTF8Array",
			"stringToUTF8",
			"lengthBytesUTF8",
			"UTF16Decoder",
			"stringToNewUTF8",
			"stringToUTF8OnStack",
			"writeArrayToMemory",
			"JSEvents",
			"specialHTMLTargets",
			"findCanvasEventTarget",
			"currentFullscreenStrategy",
			"restoreOldWindowedStyle",
			"ExitStatus",
			"flush_NO_FILESYSTEM",
			"promiseMap",
			"uncaughtExceptionCount",
			"exceptionLast",
			"exceptionCaught",
			"ExceptionInfo",
			"findMatchingCatch",
			"getExceptionMessageCommon",
			"incrementExceptionRefcount",
			"decrementExceptionRefcount",
			"getExceptionMessage",
			"Browser",
			"wget",
			"SYSCALLS",
			"tempFixedLengthArray",
			"miniTempWebGLFloatBuffers",
			"miniTempWebGLIntBuffers",
			"GL",
			"emscripten_webgl_power_preferences",
			"AL",
			"GLUT",
			"EGL",
			"GLEW",
			"IDBStore",
			"SDL",
			"SDL_gfx",
			"allocateUTF8",
			"allocateUTF8OnStack"
		].forEach(unexportedRuntimeSymbol);
		var calledRun;
		dependenciesFulfilled = function runCaller() {
			if (!calledRun) run();
			if (!calledRun) dependenciesFulfilled = runCaller;
		};
		function stackCheckInit() {
			_emscripten_stack_init();
			writeStackCookie();
		}
		function run() {
			if (runDependencies > 0) return;
			stackCheckInit();
			preRun();
			if (runDependencies > 0) return;
			function doRun() {
				if (calledRun) return;
				calledRun = true;
				Module["calledRun"] = true;
				if (ABORT) return;
				initRuntime();
				readyPromiseResolve(Module);
				if (Module["onRuntimeInitialized"]) Module["onRuntimeInitialized"]();
				assert(!Module["_main"], "compiled without a main, but one is present. if you added it from JS, use Module[\"onRuntimeInitialized\"]");
				postRun();
			}
			if (Module["setStatus"]) {
				Module["setStatus"]("Running...");
				setTimeout(function() {
					setTimeout(function() {
						Module["setStatus"]("");
					}, 1);
					doRun();
				}, 1);
			} else doRun();
			checkStackCookie();
		}
		if (Module["preInit"]) {
			if (typeof Module["preInit"] == "function") Module["preInit"] = [Module["preInit"]];
			while (Module["preInit"].length > 0) Module["preInit"].pop()();
		}
		run();
		Module.cmsOpenProfileFromMem = cwrap("cmsOpenProfileFromMem", "number", ["array", "number"]);
		Module.cmsCloseProfile = cwrap("cmsCloseProfile", void 0, ["number"]);
		Module.cmsCreate_sRGBProfile = cwrap("cmsCreate_sRGBProfile", "number", []);
		Module.cmsCreateXYZProfile = cwrap("cmsCreateXYZProfile", "number", [], []);
		Module.cmsGetHeaderRenderingIntent = cwrap("cmsGetHeaderRenderingIntent", "number", ["number"]);
		Module.cmsCreateLab4Profile = cmsCreateLab4Profile;
		function cmsCreateLab4Profile(wpArr) {
			var whitePoint = 0;
			if (wpArr) {
				whitePoint = _malloc(24);
				for (var i = 0; i < 3; i++) setValue(whitePoint + i * 8, wpArr[i], "double");
			}
			var prof = ccall("cmsCreateLab4Profile", "number", ["number"], [whitePoint]);
			if (whitePoint) _free(whitePoint);
			return prof;
		}
		Module.cmsGetProfileInfoASCII = cmsGetProfileInfoASCII;
		function cmsGetProfileInfoASCII(hProfile, info, languageCode, countryCode) {
			var len = ccall("cmsGetProfileInfoASCII", "number", [
				"number",
				"number",
				"string",
				"string",
				"number",
				"number"
			], [
				hProfile,
				info,
				languageCode,
				countryCode,
				0,
				0
			]);
			var ptr = _malloc(len);
			var len = ccall("cmsGetProfileInfoASCII", "number", [
				"number",
				"number",
				"string",
				"string",
				"number",
				"number"
			], [
				hProfile,
				info,
				languageCode,
				countryCode,
				ptr,
				len
			]);
			var text = UTF8ToString(ptr, len);
			_free(ptr);
			return text;
		}
		Module.cmsGetColorSpace = cwrap("cmsGetColorSpace", "number", ["number"]);
		Module.cmsGetColorSpaceASCII = (profile) => {
			return {
				1482250784: "XYZ",
				1281450528: "Lab",
				1282766368: "Luv",
				1497588338: "YCbr",
				1501067552: "Yxy",
				1380401696: "RGB",
				1196573017: "GRAY",
				1213421088: "HSV",
				1212961568: "HLS",
				1129142603: "CMYK",
				1129142560: "CMY"
			}[Module.cmsGetColorSpace(profile)] || null;
		};
		Module.cmsFormatterForColorspaceOfProfile = cmsFormatterForColorspaceOfProfile;
		function cmsFormatterForColorspaceOfProfile(hProfile, nBytes, isFloat) {
			return ccall("cmsFormatterForColorspaceOfProfile", "number", [
				"number",
				"number",
				"number"
			], [
				hProfile,
				nBytes,
				isFloat
			]);
		}
		Module.cmsCreateTransform = cmsCreateTransform;
		function cmsCreateTransform(hInput, inputFormat, hOutput, outputFormat, intent, flags) {
			return ccall("cmsCreateTransform", "number", [
				"number",
				"number",
				"number",
				"number",
				"number",
				"number"
			], [
				hInput,
				inputFormat,
				hOutput,
				outputFormat,
				intent,
				flags
			]);
		}
		Module.cmsCreateProofingTransform = cmsCreateProofingTransform;
		function cmsCreateProofingTransform(hInput, inputFormat, hOutput, outputFormat, proofing, intent, proofingIntent, flags) {
			return ccall("cmsCreateProofingTransform", "number", [
				"number",
				"number",
				"number",
				"number",
				"number",
				"number",
				"number",
				"number"
			], [
				hInput,
				inputFormat,
				hOutput,
				outputFormat,
				proofing,
				intent,
				proofingIntent,
				flags
			]);
		}
		Module.cmsDeleteTransform = cmsDeleteTransform;
		function cmsDeleteTransform(transform) {
			if (!transform) throw new Error("cmsDeleteTransform expects a non-false transform parameter");
			ccall("cmsDeleteTransform", void 0, ["number"], [transform]);
		}
		Module.cmsGetTransformInputFormat = cmsGetTransformInputFormat;
		function cmsGetTransformInputFormat(transform) {
			return ccall("cmsGetTransformInputFormat", "number", ["number"], [transform]);
		}
		Module.cmsGetTransformOutputFormat = cmsGetTransformOutputFormat;
		function cmsGetTransformOutputFormat(transform) {
			return ccall("cmsGetTransformOutputFormat", "number", ["number"], [transform]);
		}
		function getArrayType(bytes, float) {
			if (float) {
				if (bytes == 8) throw new Error("Float64Array not supported by LittleCMS");
				if (bytes == 2) throw new Error("Float16Array not supported by LittleCMS");
				return Float32Array;
			}
			if (bytes === 4) throw new Error("Uint32Array not supported by LittleCMS");
			if (bytes === 2) return Uint16Array;
			return Uint8Array;
		}
		Module.cmsDoTransform = cmsDoTransform;
		function cmsDoTransform(transform, inputArr, size) {
			var inputFormat = cmsGetTransformInputFormat(transform);
			var outputFormat = cmsGetTransformOutputFormat(transform);
			var inputIsFloat = Boolean(T_FLOAT(inputFormat));
			var outputIsFloat = Boolean(T_FLOAT(outputFormat));
			var inputChannels = T_CHANNELS(inputFormat) + T_EXTRA(inputFormat);
			var outputChannels = T_CHANNELS(outputFormat) + T_EXTRA(inputFormat);
			var inputBytes = T_BYTES(inputFormat);
			var outputBytes = T_BYTES(outputFormat);
			inputBytes = inputBytes < 1 ? 4 : inputBytes;
			outputBytes = outputBytes < 1 ? 4 : outputBytes;
			var inputLength = inputChannels * size;
			var inputBuffer = _malloc(inputLength * inputBytes);
			var dataOnHeap;
			const InputType = getArrayType(inputBytes, inputIsFloat);
			const OutputType = getArrayType(outputBytes, outputIsFloat);
			dataOnHeap = new InputType(Module.HEAPU8.buffer, inputBuffer, inputLength);
			dataOnHeap.set(inputArr);
			var outputLength = outputChannels * size;
			var outputBuffer = _malloc(outputLength * outputBytes);
			ccall("cmsDoTransform", void 0, [
				"number",
				"number",
				"number",
				"number"
			], [
				transform,
				inputBuffer,
				outputBuffer,
				size
			]);
			var outputArr = new OutputType(Module.HEAPU8.buffer, outputBuffer, outputLength).slice();
			_free(inputBuffer);
			_free(outputBuffer);
			return outputArr;
		}
		Module.cmsReadTag = cmsReadTag;
		function cmsReadTag(hProfile, sig) {
			return ccall("cmsReadTag", void 0, ["number", "number"], [hProfile, sig]);
		}
		Module.cmsReadTag_XYZ = cmsReadTag_XYZ;
		function cmsReadTag_XYZ(hProfile, sig) {
			var ptr = cmsReadTag(hProfile, sig);
			if (!ptr) return null;
			var xyz = new Float64Array(3);
			xyz[0] = getValue(ptr, "double");
			xyz[1] = getValue(ptr + 8, "double");
			xyz[2] = getValue(ptr + 16, "double");
			return xyz;
		}
		Module.cmsXYZ2xyY = cmsXYZ2xyY;
		function cmsXYZ2xyY(xyz) {
			var srcPtr = _malloc(24);
			var dstPtr = _malloc(24);
			setValue(srcPtr, xyz[0], "double");
			setValue(srcPtr + 8, xyz[1], "double");
			setValue(srcPtr + 16, xyz[2], "double");
			ccall("cmsXYZ2xyY", void 0, ["number", "number"], [dstPtr, srcPtr]);
			var xyY = new Float64Array(3);
			xyY[0] = getValue(dstPtr, "double");
			xyY[1] = getValue(dstPtr + 8, "double");
			xyY[2] = getValue(dstPtr + 16, "double");
			_free(srcPtr);
			_free(dstPtr);
			return xyY;
		}
		return moduleArg.ready;
	});
})();
//#endregion
//#region app/tile-render-flags.mjs
const TILE_BACKDROP_CLEAR = Symbol("temporary tile backdrop clearing");
//#endregion
//#region app/native-indexed.mjs
/*! Portable modified adaptation of the separately MIT-licensed Aseprite Document
* and Render Libraries, v1.3.18.5. Copyright (c) 2018-present Igara Studio S.A.;
* Copyright (c) 2001-2018 David Capello. File-specific copyright includes
* 2020-2024 Igara Studio S.A. (octree), 2019-2022 Igara Studio S.A. and
* 2017 David Capello (dithering), 2001-2017 David Capello (median cut).
* Modifications: JavaScript sparse storage, resource validation, pure inputs and
* outputs, integer arithmetic and explicit modes. Full provenance:
* docs/indexed-NOTICES.txt, distributed as runtimes/indexed-NOTICES.txt.
*
* Permission is hereby granted, free of charge, to any person obtaining
* a copy of this software and associated documentation files (the
* "Software"), to deal in the Software without restriction, including
* without limitation the rights to use, copy, modify, merge, publish,
* distribute, sublicense, and/or sell copies of the Software, and to
* permit persons to whom the Software is furnished to do so, subject to
* the following conditions:
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
* IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
* DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
* ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
* DEALINGS IN THE SOFTWARE.
*/
const MAX_WORK$1 = 67108864, MAX_PIXELS$1 = 16777216, MAX_NODES = 1048576;
const fail$7 = (message) => {
	throw Error(`Native indexed conversion: ${message}`);
};
const integer$8 = (n, low, high, label) => {
	if (!Number.isSafeInteger(n) || n < low || n > high) fail$7(`invalid ${label}.`);
	return n;
};
const clamp$2 = (n) => Math.max(0, Math.min(255, n));
const div = (n, d) => Math.trunc(n / d);
const packed$1 = (c) => (c[0] | c[1] << 8 | c[2] << 16 | c[3] << 24) >>> 0;
const hex$5 = (c) => "#" + c.map((v) => v.toString(16).padStart(2, "0")).join("");
const parse = (c) => {
	if (c === null) return [
		0,
		0,
		0,
		0
	];
	if (typeof c !== "string" || !/^#[0-9a-f]{8}$/i.test(c)) fail$7("colors must be RGBA hex strings or null.");
	return [
		1,
		3,
		5,
		7
	].map((i) => parseInt(c.slice(i, i + 2), 16));
};
function meter(input) {
	const budget = input ?? { remaining: MAX_WORK$1 };
	integer$8(budget.remaining, 0, MAX_WORK$1, "work budget");
	return (n) => {
		budget.remaining -= n;
		if (budget.remaining < 0) fail$7("work limit exceeded.");
	};
}
/** Exact palette-search arithmetic. Octree preserves last exact duplicate entries;
* RGB5A3 first expands quantized channels, then searches. No premultiplication. */
function createNativeRgbMap(palette, input = {}) {
	if (!Array.isArray(palette) || !palette.length || palette.length > 256) fail$7("palette must contain 1–256 entries.");
	const colors = palette.map(parse), mask = input.transparentIndex == null ? -1 : integer$8(input.transparentIndex, 0, palette.length - 1, "transparent index");
	const algorithm = input.rgbmap ?? "octree", fit = input.fitCriteria ?? "default", spend = meter(input.budget);
	if (!["octree", "rgb5a3"].includes(algorithm)) fail$7("unsupported RGB map.");
	if (![
		"default",
		"rgb",
		"linearizedRGB",
		"ciexyz",
		"cielab"
	].includes(fit)) fail$7("unsupported fitting criterion.");
	function space(c) {
		if (fit === "rgb" || fit === "default") return c;
		const lin = c.slice(0, 3).map((v) => {
			v /= 255;
			return v <= .04045 ? v / 12.92 : ((v + .055) / 1.055) ** 2.4;
		});
		if (fit === "linearizedRGB") return lin;
		const [r, g, b] = lin, x = 41.24564 * r + 35.75761 * g + 18.04375 * b, y = 21.26729 * r + 71.51522 * g + 7.2175 * b, z = 1.93339 * r + 11.9192 * g + 95.03041 * b;
		if (fit === "ciexyz") return [
			x,
			y,
			z
		];
		const f = (t) => t > .00885645171 ? t ** .3333333333333333 : t / .12841855 + .137931034, fy = f(y / 100);
		return [
			116 * fy - 16,
			500 * (f(x / 95.0489) - fy),
			200 * (fy - f(z / 108.884))
		];
	}
	const spaces = colors.map(space), exact = /* @__PURE__ */ new Map(), cache = /* @__PURE__ */ new Map();
	function best(c) {
		spend(colors.length);
		if ((fit === "default" ? c[3] >> 3 : c[3]) === 0 && mask >= 0) return mask;
		let result = 0, least = Infinity;
		const v = space(c);
		for (let i = 0; i < colors.length; i++) {
			if (i === mask) continue;
			const p = colors[i];
			const distance = fit === "default" ? ((c[0] >> 3) - (p[0] >> 3)) ** 2 * 900 + ((c[1] >> 3) - (p[1] >> 3)) ** 2 * 3481 + ((c[2] >> 3) - (p[2] >> 3)) ** 2 * 121 + ((c[3] >> 3) - (p[3] >> 3)) ** 2 * 64 : (v[0] - spaces[i][0]) ** 2 + (v[1] - spaces[i][1]) ** 2 + (v[2] - spaces[i][2]) ** 2 + ((c[3] - p[3]) / 128) ** 2;
			if (distance < least) {
				least = distance;
				result = i;
			}
		}
		return result;
	}
	if (algorithm === "octree") for (let i = 0; i < colors.length; i++) exact.set(packed$1(colors[i]), i === mask ? best(colors[i]) : i);
	function map(c) {
		spend(1);
		let key;
		if (algorithm === "octree") {
			key = packed$1(c);
			if (exact.has(key)) return exact.get(key);
		} else {
			c = c.map((v, i) => i < 3 ? v >> 3 << 3 | v >> 5 : v >> 5 << 5 | v >> 5 << 2 | v >> 6);
			key = packed$1(c);
		}
		if (cache.has(key)) return cache.get(key);
		const index = best(c);
		if (cache.size < 65536) cache.set(key, index);
		return index;
	}
	return {
		map,
		colors,
		transparentIndex: mask
	};
}
function bayer$1(n) {
	let m = [[0, 2], [3, 1]];
	for (let size = 2; size < n; size *= 2) {
		const next = Array.from({ length: size * 2 }, () => []);
		for (let y = 0; y < size * 2; y++) for (let x = 0; x < size * 2; x++) next[y][x] = 4 * m[y % size][x % size] + [[0, 2], [3, 1]][Math.floor(y / size)][Math.floor(x / size)];
		m = next;
	}
	return m;
}
const colorDistance = (a, b) => (a[3] && b[3] ? Math.abs(a[0] - b[0]) * 2126 + Math.abs(a[1] - b[1]) * 7152 + Math.abs(a[2] - b[2]) * 722 : 0) + Math.abs(a[3] - b[3]) * 2e4;
function mapNativeIndexedImage(image, palette, input = {}) {
	const width = integer$8(image.width, 1, 65535, "width"), height = integer$8(image.height, 1, 65535, "height");
	if (width * height > MAX_PIXELS$1 || !Array.isArray(image.pixels) || image.pixels.length !== width * height) fail$7("invalid raster pixels.");
	const budget = input.budget ?? { remaining: MAX_WORK$1 };
	if (input.background !== void 0 && typeof input.background !== "boolean") fail$7("background must be boolean.");
	const { map, colors, transparentIndex: mapMask } = createNativeRgbMap(palette, {
		...input,
		budget
	}), mask = input.background ? -1 : mapMask, spend = meter(budget), output = Array(width * height);
	let mode = input.dithering ?? "none";
	if (![
		"none",
		"aseprite-ordered",
		"aseprite-old",
		"aseprite-error-diffusion"
	].includes(mode)) fail$7("unsupported native dithering.");
	const strength = input.ditherStrength ?? 1;
	if (typeof strength !== "number" || !Number.isFinite(strength) || strength < 0 || strength > 1) fail$7("invalid dither strength.");
	if (mode.startsWith("aseprite-") && mode !== "aseprite-error-diffusion" && strength !== 1) fail$7("native ordered dithering does not have a strength control.");
	if (input.sourceColorMode === "grayscale") mode = "none";
	const matrixName = input.ditherMatrix ?? "bayer4x4";
	if (![
		"bayer2x2",
		"bayer4x4",
		"bayer8x8"
	].includes(matrixName)) fail$7("unsupported Bayer matrix.");
	const size = Number(matrixName[5]), matrix = bayer$1(size), maximum = size * size - 1;
	const tw = integer$8(input.tileWidth ?? width, 1, width, "tile width"), th = integer$8(input.tileHeight ?? height, 1, height, "tile height");
	if (width % tw || height % th) fail$7("atlas dimensions must be multiples of the tile grid.");
	const orderedCache = /* @__PURE__ */ new Map();
	function ordered(c) {
		const key = packed$1(c);
		if (orderedCache.has(key)) return orderedCache.get(key);
		const index = map(c), c0 = colors[index];
		let alternate = index, mix = 0;
		if (mode === "aseprite-old") {
			alternate = map(c.map((v, i) => clamp$2(2 * v - c0[i])));
			const D = colorDistance(c0, colors[alternate]);
			mix = D ? div(maximum * colorDistance(c0, c), D) : 0;
		} else {
			let closest = Infinity;
			spend(colors.length);
			for (let i = 0; i < colors.length; i++) {
				if (i === mask) continue;
				const c1 = colors[i];
				let m = 0, divisor = 0;
				for (let k = 0; k < 4; k++) if ((k === 3 || c[3] && c0[3] && c1[3]) && c1[k] !== c0[k]) {
					const weight = [
						2126,
						7152,
						722,
						2e4
					][k];
					m += div(weight * maximum * (c[k] - c0[k]), c1[k] - c0[k]);
					divisor += weight;
				}
				if (m) m = Math.max(0, Math.min(maximum, divisor ? div(m, divisor) : m));
				const distance = colorDistance(c, c0.map((v, k) => v + div((c1[k] - v) * m, maximum))) + div(colorDistance(c0, c1), 10);
				if (distance < closest) {
					closest = distance;
					alternate = i;
					mix = m;
				}
			}
		}
		const result = {
			index,
			alternate,
			mix
		};
		if (orderedCache.size < 65536) orderedCache.set(key, result);
		return result;
	}
	for (let top = 0; top < height; top += th) for (let left = 0; left < width; left += tw) {
		const stride = tw + 2;
		let row = Array.from({ length: 4 }, () => new Int32Array(stride)), next = Array.from({ length: 4 }, () => new Int32Array(stride));
		for (let y = 0; y < th; y++) {
			const reverse = mode === "aseprite-error-diffusion" && y & 1;
			for (let step = 0; step < tw; step++) {
				const x = reverse ? tw - 1 - step : step, at = (top + y) * width + left + x, c = parse(image.pixels[at]);
				spend(1);
				let index;
				if (mode === "aseprite-error-diffusion") {
					const v = c.map((n, k) => clamp$2(n + row[k][x + 1]));
					index = map(v);
					const p = index === mask || colors[index][3] === 0 ? [...c.slice(0, 3), 0] : colors[index];
					for (let k = 0; k < 4; k++) {
						const q = div((v[k] - p[k]) * Math.trunc(strength * 100), 100), sign = reverse ? -1 : 1;
						row[k][x + 1 + sign] += div(q * 7, 16);
						next[k][x + 1 - sign] += div(q * 3, 16);
						next[k][x + 1] += div(q * 5, 16);
						next[k][x + 1 + sign] += div(q, 16);
					}
				} else if (c[3] === 0 && (mask >= 0 || mode === "none")) index = mapMask < 0 ? 0 : mapMask;
				else if (mode === "none") index = map(c);
				else {
					const choice = ordered(c);
					index = matrix[y % size][x % size] < choice.mix ? choice.alternate : choice.index;
				}
				output[at] = index === mask ? null : index;
			}
			row = next;
			next = Array.from({ length: 4 }, () => new Int32Array(stride));
		}
	}
	return output;
}
function histogram(samples, withAlpha, spend) {
	const colors = /* @__PURE__ */ new Map();
	let count = 0;
	for (const sample of samples) {
		spend(1);
		const c = parse(sample);
		if (++count > MAX_PIXELS$1) fail$7("sample pixel limit exceeded.");
		if (!c[3]) continue;
		if (!withAlpha) c[3] = 255;
		const key = packed$1(c), entry = colors.get(key);
		if (entry) entry.count++;
		else {
			if (colors.size >= MAX_NODES) fail$7("distinct color limit exceeded.");
			colors.set(key, {
				c,
				count: 1
			});
		}
	}
	return [...colors.values()];
}
function octreePalette(entries, count, mask, spend) {
	function build(depth) {
		let nodes = 1;
		const root = {
			parent: null,
			children: [],
			sum: [
				0,
				0,
				0,
				0
			],
			count: 0
		};
		for (const entry of entries) {
			let node = root;
			for (let level = 0; level < depth; level++) {
				spend(1);
				const bit = 128 >> level, i = entry.c.reduce((v, c, k) => v | (c & bit ? 1 << k : 0), 0);
				if (!node.children[i]) {
					if (++nodes > MAX_NODES) fail$7("octree node limit exceeded.");
					node.children[i] = {
						parent: node,
						children: [],
						sum: [
							0,
							0,
							0,
							0
						],
						count: 0
					};
				}
				node = node.children[i];
			}
			node.count += entry.count;
			for (let k = 0; k < 4; k++) node.sum[k] += entry.c[k] * entry.count;
		}
		const leaves = [];
		function collect(node) {
			for (const child of node.children) if (child) if (child.count) leaves.push(child);
			else collect(child);
		}
		collect(root);
		return leaves;
	}
	const reserve = mask >= 0, available = count - (reserve ? 1 : 0);
	let depth = 7, leaves = build(depth);
	if (leaves.length < available) {
		depth = 8;
		leaves = build(depth);
	}
	let aux = [], reducing = true;
	for (let level = depth; level >= 0; level--) {
		for (let i = leaves.length - 1; i >= 0; i--) {
			spend(1);
			if (leaves.length + aux.length <= available) {
				leaves.push(...aux.reverse());
				reducing = false;
				break;
			}
			if (!leaves.length) {
				if (aux.length <= 16 && available < 16 && available > 0) {
					aux.sort((a, b) => b.count - a.count);
					leaves = aux.slice(0, available);
					reducing = false;
				}
				break;
			}
			const parent = leaves[leaves.length - 1].parent;
			for (let c = 15; c >= 0; c--) {
				const child = parent.children[c];
				if (child?.count) {
					parent.count += child.count;
					for (let k = 0; k < 4; k++) parent.sum[k] += child.sum[k];
					if (leaves[leaves.length - 1] === child) leaves.pop();
				}
			}
			aux.push(parent);
		}
		if (!reducing) break;
		leaves.push(...aux.reverse());
		aux = [];
	}
	const colors = leaves.map((node) => node.sum.map((sum) => {
		if (sum > 2147483647) fail$7("octree accumulator exceeds verified signed-integer range.");
		return div(sum, node.count) + (sum % node.count > Math.floor(node.count / 2) ? 1 : 0);
	}));
	if (reserve) {
		while (colors.length < mask) colors.push([
			0,
			0,
			0,
			255
		]);
		colors.splice(mask, 0, [
			0,
			0,
			0,
			0
		]);
	}
	return colors.map(hex$5);
}
function rgb5Palette(entries, count, mask, withAlpha, spend) {
	const reserve = count > 1 && mask >= 0 && mask < count, available = count - (reserve ? 1 : 0);
	let colors;
	if (entries.length <= 256 && entries.length <= available) colors = entries.map((e) => e.c);
	else {
		const histogram = /* @__PURE__ */ new Map();
		for (const e of entries) {
			spend(1);
			const c = [
				e.c[0] >> 3,
				e.c[1] >> 2,
				e.c[2] >> 3,
				e.c[3] >> 3
			], key = c[0] | c[1] << 5 | c[2] << 11 | c[3] << 16, previous = histogram.get(key);
			if (previous) previous.count += e.count;
			else histogram.set(key, {
				c,
				count: e.count
			});
		}
		const make = (items, low, high) => ({
			items,
			low,
			high,
			volume: high.reduce((v, n, k) => v * (n - low[k] + 1), 1)
		});
		const queue = [];
		function push(value) {
			queue.push(value);
			let i = queue.length - 1;
			while (i > 0) {
				const parent = i - 1 >> 1;
				if (queue[parent].volume >= value.volume) break;
				queue[i] = queue[parent];
				i = parent;
			}
			queue[i] = value;
		}
		function pop() {
			const result = queue[0], last = queue.pop();
			if (queue.length) {
				let i = 0;
				while (i * 2 + 1 < queue.length) {
					let child = i * 2 + 1;
					if (child + 1 < queue.length && queue[child].volume < queue[child + 1].volume) child++;
					queue[i] = queue[child];
					i = child;
				}
				queue[i] = last;
				while (i > 0) {
					const parent = i - 1 >> 1;
					if (queue[parent].volume >= last.volume) break;
					queue[i] = queue[parent];
					i = parent;
					queue[i] = last;
				}
			}
			return result;
		}
		function mean(box) {
			const sums = [
				0,
				0,
				0,
				0
			];
			let n = 0;
			for (const e of box.items) {
				spend(1);
				n += e.count;
				for (let k = 0; k < 4; k++) sums[k] += e.c[k] * e.count;
			}
			return n ? sums.map((s, k) => div(255 * div(s, n), [
				31,
				63,
				31,
				31
			][k])) : [
				0,
				0,
				0,
				255
			];
		}
		push(make([...histogram.values()], [
			0,
			0,
			0,
			0
		], [
			31,
			63,
			31,
			31
		]));
		colors = [];
		while (queue.length && queue.length < available) {
			const box = pop(), low = [
				31,
				63,
				31,
				31
			], high = [
				0,
				0,
				0,
				0
			];
			let points = 0;
			for (const e of box.items) {
				spend(1);
				points += e.count;
				for (let k = 0; k < 4; k++) {
					low[k] = Math.min(low[k], e.c[k]);
					high[k] = Math.max(high[k], e.c[k]);
				}
			}
			let axis = 0;
			for (let k = 1; k < 4; k++) if (high[k] - low[k] > high[axis] - low[axis]) axis = k;
			const planes = /* @__PURE__ */ new Map();
			for (const e of box.items) planes.set(e.c[axis], (planes.get(e.c[axis]) ?? 0) + e.count);
			let first = 0, cut = null;
			for (let i = low[axis]; i <= high[axis]; i++) {
				const plane = planes.get(i) ?? 0;
				first += plane;
				const second = points - first;
				if (first > second) {
					if (second > 0) cut = i;
					else if (first - plane > 0) cut = i - 1;
					break;
				}
			}
			if (cut === null) if (colors.length < available) colors.push(mean(box));
			else break;
			else {
				const h = [...high], l = [...low];
				h[axis] = cut;
				l[axis] = cut + 1;
				push(make(box.items.filter((e) => e.c[axis] <= cut), low, h));
				push(make(box.items.filter((e) => e.c[axis] > cut), l, high));
			}
		}
		while (queue.length && colors.length < available) colors.push(mean(pop()));
	}
	if (reserve) {
		while (colors.length < mask) colors.push([
			0,
			0,
			0,
			255
		]);
		colors.splice(mask, 0, [
			0,
			0,
			0,
			withAlpha ? 0 : 255
		]);
	} else if (!colors.length) colors = [[
		0,
		0,
		0,
		255
	]];
	return colors.map(hex$5);
}
/** Samples must be full composited frames for native sprite quantization. */
function quantizeNativePalette(samples, input = {}) {
	const algorithm = input.quantization ?? "octree", max = integer$8(input.maxColors ?? 256, 2, 256, "palette color limit");
	if (!["octree", "rgb5a3"].includes(algorithm)) fail$7("unsupported native quantizer.");
	const alpha = input.withAlpha ?? true;
	if (typeof alpha !== "boolean") fail$7("withAlpha must be boolean.");
	const mask = input.transparentIndex === null ? -1 : integer$8(input.transparentIndex ?? 0, 0, max - 1, "transparent index"), spend = meter(input.budget);
	const entries = histogram(samples, alpha, spend);
	const result = algorithm === "octree" ? octreePalette(entries, max, mask, spend) : rgb5Palette(entries, max, mask, alpha, spend);
	if (!result.length) fail$7("native quantizer produced an empty palette.");
	return result;
}
//#endregion
//#region app/native-color-commands.mjs
/** Native color-command semantics kept separate from the editor's global remap workflow. */
const fail$6 = (message) => {
	throw Error(`Color command: ${message}`);
};
const integer$7 = (value, min, max, label) => {
	if (!Number.isSafeInteger(value) || value < min || value > max) fail$6(`invalid ${label}.`);
	return value;
};
const rgba$1 = (pixel) => pixel == null ? [
	0,
	0,
	0,
	0
] : [
	1,
	3,
	5,
	7
].map((index) => parseInt(pixel.slice(index, index + 2), 16));
const hex$4 = (values) => "#" + values.map((value) => value.toString(16).padStart(2, "0")).join("");
const equal = (a, b) => a.length === b.length && a.every((value, index) => value === b[index]);
function nativePaletteKeys(doc, requested) {
	const keys = [];
	let palette = doc.palette;
	for (let index = 0; index < doc.frames.length; index++) {
		const frame = doc.frames[index];
		if (frame.palette) palette = frame.palette;
		if (index === 0 || !equal(palette, keys.at(-1).palette)) keys.push({
			frameId: frame.id,
			index,
			palette
		});
	}
	if (requested === void 0) return keys;
	if (!Array.isArray(requested) || !requested.length || requested.length > doc.frames.length || requested[0] !== doc.frames[0].id || new Set(requested).size !== requested.length) fail$6("invalid palette key frames.");
	const requestedKeys = requested.map((frameId) => {
		const index = doc.frames.findIndex((frame) => frame.id === frameId);
		if (index < 0) fail$6("palette key frame no longer exists.");
		let effective = keys[0];
		for (const key of keys) if (key.index <= index) effective = key;
		return {
			frameId,
			index,
			palette: effective.palette
		};
	});
	if (requestedKeys.some((key, index) => index && key.index <= requestedKeys[index - 1].index)) fail$6("palette key frames must be ordered.");
	for (const key of keys) if (!requestedKeys.some((requestedKey) => requestedKey.index === key.index)) fail$6("palette key boundaries changed.");
	return requestedKeys;
}
function setNativePalette(doc, command, api) {
	const keys = nativePaletteKeys(doc, command.paletteFrameIds);
	const frameIndex = doc.frames.findIndex((frame) => frame.id === (command.frameId ?? doc.frames[0].id));
	if (frameIndex < 0) fail$6("palette frame no longer exists.");
	let target = keys[0];
	for (const key of keys) if (key.index <= frameIndex) target = key;
	const colors = command.palette;
	if (!Array.isArray(colors) || !colors.length || colors.length > 256) fail$6("palette must contain 1–256 colors.");
	const palette = colors.map(api.normalizeColor);
	const end = keys.find((key) => key.index > target.index)?.index ?? doc.frames.length;
	if (doc.colorMode === "indexed") {
		const checked = /* @__PURE__ */ new Set();
		const check = (id) => {
			if (!id || checked.has(id)) return;
			checked.add(id);
			const image = doc.images[id];
			if (!image || image.tilemap) return;
			if (image.pixels.some((pixel) => pixel != null && pixel >= palette.length)) fail$6("palette-only shrinking would leave unsupported out-of-palette pixel indices; remap them first.");
		};
		for (let index = target.index; index < end; index++) {
			for (const cel of Object.values(doc.frames[index].cels)) check(cel.imageId);
			for (const layer of doc.layers) if (layer.type === "tilemap") {
				const tileset = doc.tilesets.find((item) => item.id === (layer.tilemaps?.[doc.frames[index].id]?.tilesetId ?? layer.tilesetId));
				if (tileset) {
					check(tileset.imageId);
					for (const tile of tileset.tiles ?? []) check(tile.imageId);
				}
			}
		}
		if (target.index === 0) for (const tileset of doc.tilesets) {
			check(tileset.imageId);
			for (const tile of tileset.tiles ?? []) check(tile.imageId);
		}
	}
	const byId = new Map(keys.map((key) => [key.frameId, key.frameId === target.frameId ? palette : key.palette]));
	for (const frame of doc.frames) if (byId.has(frame.id)) frame.palette = [...byId.get(frame.id)];
	else delete frame.palette;
	doc.palette = [...doc.frames[0].palette];
	const capacity = Math.max(...[...byId.values()].map((value) => value.length));
	while (doc.palette.length < capacity) doc.palette.push("#00000000");
	if (doc.colorMode === "indexed" && doc.metadata?.aseprite?.transparentIndex >= palette.length) doc.metadata = {
		...doc.metadata,
		aseprite: {
			...doc.metadata.aseprite,
			transparentIndex: palette.length - 1
		}
	};
}
function generateNativePalette(doc, command, api) {
	const keys = nativePaletteKeys(doc, command.paletteFrameIds);
	const index = doc.frames.findIndex((frame) => frame.id === (command.frameId ?? doc.frames[0].id));
	if (index < 0) fail$6("palette frame no longer exists.");
	let target = keys[0];
	for (const key of keys) if (key.index <= index) target = key;
	const selected = command.colors;
	if (selected !== void 0 && (!Array.isArray(selected) || selected.some((value, at) => !Number.isSafeInteger(value) || value < 0 || value >= target.palette.length || at > 0 && value <= selected[at - 1]))) fail$6("palette color range must be sorted unique valid indices.");
	if (selected && !selected.length) return;
	const count = selected ? Math.max(2, selected.length) : command.maxColors ?? 256;
	integer$7(count, 2, 256, "generated color count");
	const budget = { remaining: api.limits.operations };
	function* samples() {
		for (const frame of doc.frames) {
			budget.remaining -= doc.width * doc.height * Math.max(1, doc.layers.length);
			if (budget.remaining < 0) fail$6("palette sampling exceeds the work budget.");
			const pixels = api.renderFrame(doc, frame.id);
			for (let index = 0; index < pixels.length; index += 4) yield hex$4([...pixels.subarray(index, index + 4)]);
		}
	}
	const documentMask = doc.layers.length === 1 && doc.layers[0].asepriteFlags & 8 ? null : doc.colorMode === "indexed" ? doc.metadata?.aseprite?.transparentIndex ?? 0 : 0;
	const transparentIndex = selected && documentMask !== null ? selected.includes(documentMask) ? selected.indexOf(documentMask) : null : documentMask;
	const generated = quantizeNativePalette(samples(), {
		quantization: command.algorithm ?? "octree",
		maxColors: count,
		withAlpha: command.withAlpha ?? true,
		transparentIndex,
		budget
	});
	const palette = selected ? [...target.palette] : generated;
	if (selected) {
		if (generated.length < selected.length) fail$6("generated palette is smaller than the selected color range.");
		selected.forEach((at, generatedIndex) => {
			palette[at] = generated[generatedIndex];
		});
	}
	setNativePalette(doc, {
		frameId: target.frameId,
		paletteFrameIds: keys.map((key) => key.frameId),
		palette
	}, api);
}
function convertNativeColorMode(doc, command, api) {
	const mode = command.colorMode;
	if (![
		"rgba",
		"indexed",
		"grayscale"
	].includes(mode)) fail$6("unsupported destination color mode.");
	const rgbmap = command.rgbmap ?? "octree";
	const fit = command.fitCriteria ?? "default";
	const toGray = command.toGray ?? "luma";
	const dithering = command.dithering ?? "none";
	const matrix = command.ditherMatrix ?? "bayer4x4";
	if (!["octree", "rgb5a3"].includes(rgbmap) || ![
		"default",
		"rgb",
		"linearizedRGB",
		"ciexyz",
		"cielab"
	].includes(fit) || ![
		"luma",
		"hsv",
		"hsl"
	].includes(toGray) || ![
		"none",
		"aseprite-ordered",
		"aseprite-old",
		"aseprite-error-diffusion"
	].includes(dithering) || ![
		"bayer2x2",
		"bayer4x4",
		"bayer8x8"
	].includes(matrix)) fail$6("unsupported pixel-format options.");
	if (mode === doc.colorMode) return;
	const sourceMode = doc.colorMode;
	const budget = { remaining: api.limits.operations };
	const converted = /* @__PURE__ */ new Map();
	const hasBackground = doc.layers.some((layer) => layer.asepriteFlags & 8);
	function convert(imageId, frameId, background, grid) {
		if (converted.has(imageId)) return;
		const image = doc.images[imageId];
		if (!image || image.tilemap) return;
		const palette = api.getFramePalette(doc, frameId);
		const sourceMask = doc.metadata?.aseprite?.transparentIndex ?? 0;
		budget.remaining -= image.width * image.height;
		if (budget.remaining < 0) fail$6("pixel conversion exceeds the work budget.");
		const colors = image.pixels.map((pixel) => {
			if (pixel == null || sourceMode === "indexed" && !background && pixel === sourceMask) return null;
			const color = rgba$1(sourceMode === "indexed" ? palette[pixel] : pixel);
			if (sourceMode === "indexed" && background) color[3] = 255;
			return color[3] ? hex$4(color) : null;
		});
		let pixels;
		if (mode === "indexed") {
			const found = palette.indexOf("#00000000");
			const mask = found >= 0 ? found : hasBackground ? null : 0;
			pixels = mapNativeIndexedImage({
				...image,
				pixels: colors
			}, palette, {
				rgbmap,
				fitCriteria: fit,
				dithering,
				ditherMatrix: matrix,
				sourceColorMode: sourceMode,
				transparentIndex: mask,
				background,
				ditherStrength: command.ditherStrength ?? 1,
				budget,
				...grid
			});
		} else pixels = colors.map((pixel) => {
			if (pixel == null || mode === "rgba") return pixel;
			const color = rgba$1(pixel), rgb = color.slice(0, 3);
			const value = toGray === "hsv" ? Math.max(...rgb) : toGray === "hsl" ? Math.floor((Math.max(...rgb) + Math.min(...rgb)) / 2) : Math.floor((color[0] * 2126 + color[1] * 7152 + color[2] * 722) / 1e4);
			return hex$4([
				value,
				value,
				value,
				color[3]
			]);
		});
		converted.set(imageId, {
			...image,
			pixels
		});
	}
	for (const layer of doc.layers) if (layer.type !== "tilemap") for (const frame of doc.frames) {
		const cel = frame.cels[layer.id];
		if (cel) convert(cel.imageId, frame.id, Boolean(layer.asepriteFlags & 8));
	}
	for (const tileset of doc.tilesets) {
		if (tileset.externalFileId != null && !tileset.tiles?.length) fail$6("embed external tileset artwork before changing pixel format.");
		if (tileset.imageId) convert(tileset.imageId, doc.frames[0].id, false, {
			tileWidth: tileset.tileWidth,
			tileHeight: tileset.tileHeight
		});
		for (const tile of tileset.tiles ?? []) convert(tile.imageId, doc.frames[0].id, false);
	}
	for (const id of Object.keys(doc.images)) convert(id, doc.frames[0].id, false);
	for (const [id, image] of converted) doc.images[id] = image;
	if (mode === "indexed") for (const frame of doc.frames) for (const cel of Object.values(frame.cels)) cel.opacity = 1;
	const mask = mode === "indexed" ? Math.max(0, api.getFramePalette(doc, doc.frames[0].id).indexOf("#00000000")) : 0;
	if (mode === "grayscale") {
		const palette = Array.from({ length: 256 }, (_, index) => hex$4([
			index,
			index,
			index,
			255
		]));
		doc.palette = palette;
		for (const frame of doc.frames) delete frame.palette;
		doc.frames[0].palette = [...palette];
	}
	doc.colorMode = mode;
	doc.metadata = {
		...doc.metadata,
		aseprite: {
			...doc.metadata?.aseprite,
			transparentIndex: mask
		}
	};
}
//#endregion
//#region app/tileset-access.mjs
/** Native tile numbering for commands and scripting, matching native export. No I/O. */
function tilesetSlots(document, tileset) {
	const native = Number.isInteger(tileset.asepriteId) && (!!document.images[tileset.imageId] || !!(tileset.flags & 1));
	let count = native ? tileset.tileCount ?? 0 : 1;
	if (!Number.isSafeInteger(count) || count < 0 || count > 65536) throw Error("Invalid native tileset count.");
	const entries = /* @__PURE__ */ new Map();
	for (const tile of tileset.tiles ?? []) {
		const index = native && Number.isInteger(tile.asepriteTileId) ? tile.asepriteTileId : count++;
		if (!Number.isSafeInteger(index) || index < 0 || index >= 65536 || entries.has(index)) throw Error("Invalid or duplicate native tile index.");
		count = Math.max(count, index + 1);
		entries.set(index, tile);
	}
	return {
		native,
		count,
		entries
	};
}
function assertTilesetEditable(document, tilesetId) {
	for (const item of document.layers) if (item.tilesetId === tilesetId || Object.values(item.tilemaps ?? {}).some((map) => map.tilesetId === tilesetId)) {
		let layer = item;
		while (layer) {
			if (layer.locked) throw Error(`Layer “${layer.name}” is locked.`);
			layer = document.layers.find((value) => value.id === layer.parentId);
		}
	}
}
//#endregion
//#region app/tileset-structure.mjs
const copy$3 = (value) => structuredClone(value);
const integer$6 = (value, min, max, label) => {
	if (!Number.isSafeInteger(value) || value < min || value > max) throw Error(`${label} must be an integer from ${min} to ${max}.`);
	return value;
};
const find = (doc, id) => {
	const ts = doc.tilesets.find((item) => item.id === id);
	if (!ts) throw Error("Tileset not found.");
	return ts;
};
const blank = (doc) => doc.colorMode === "indexed" ? 0 : null;
function atlasSize(width, height, count, limits) {
	integer$6(width, 1, limits.imageEdge, "Tile width");
	integer$6(height, 1, limits.imageEdge, "Tile height");
	integer$6(count, 1, 65536, "Tile count");
	integer$6(height * count, 1, limits.imageEdge, "Tileset atlas height");
	if (width * height * count > limits.pixels) throw Error("Tileset exceeds the stored pixel budget.");
	return width * height * count;
}
function numericId(doc) {
	const used = new Set(doc.tilesets.map((ts) => ts.asepriteId));
	let value = 0;
	while (used.has(value)) value++;
	return value;
}
function tileId(entries) {
	const used = new Set(entries.map((entry) => entry.id));
	let value = 1;
	while (used.has(`tile-created-${value}`)) value++;
	return `tile-created-${value}`;
}
function raster$1(doc, ts, tile) {
	if (!tile) return Array(ts.tileWidth * ts.tileHeight).fill(doc.colorMode === "indexed" ? doc.metadata?.aseprite?.transparentIndex ?? 0 : null);
	const image = doc.images[tile.imageId];
	if (!image || image.tilemap) throw Error("Tileset artwork must be embedded before structural editing.");
	const r = tile.sourceRect ?? {
		x: 0,
		y: 0,
		width: image.width,
		height: image.height
	};
	return Array.from({ length: ts.tileWidth * ts.tileHeight }, (_, index) => {
		const x = index % ts.tileWidth, y = Math.floor(index / ts.tileWidth);
		return image.pixels[(r.y + Math.min(r.height - 1, Math.floor(y * r.height / ts.tileHeight))) * image.width + r.x + Math.min(r.width - 1, Math.floor(x * r.width / ts.tileWidth))];
	});
}
function entriesFor(doc, ts, limits) {
	if (ts.flags & 1) throw Error("Embed external tileset artwork before structural editing.");
	const slots = tilesetSlots(doc, ts);
	atlasSize(ts.tileWidth, ts.tileHeight, slots.count, limits);
	const result = [];
	for (let index = 0; index < slots.count; index++) {
		const tile = slots.entries.get(index);
		if (!tile && (slots.native || index !== 0)) throw Error("Tileset has missing tile artwork.");
		result.push({
			id: tile?.id ?? tileId(ts.tiles ?? []),
			pixels: raster$1(doc, ts, tile),
			userData: copy$3(tile?.userData ?? ts.tileUserData?.[index])
		});
	}
	return result;
}
function installAtlas(doc, ts, entries, api) {
	const native = Number.isInteger(ts.asepriteId) && !!ts.imageId;
	const count = entries.length, size = atlasSize(ts.tileWidth, ts.tileHeight, count, api.limits);
	api.reserve(doc, size);
	const imageId = api.fresh(doc, "image");
	doc.images[imageId] = {
		width: ts.tileWidth,
		height: ts.tileHeight * count,
		pixels: entries.flatMap((entry) => entry.pixels)
	};
	ts.imageId = imageId;
	ts.tileCount = count;
	ts.asepriteId ??= numericId(doc);
	ts.flags = (ts.flags ?? 0) | 2 | (native ? 0 : 4);
	ts.tiles = entries.map((entry, index) => ({
		id: entry.id,
		imageId,
		asepriteTileId: index,
		sourceRect: {
			x: 0,
			y: index * ts.tileHeight,
			width: ts.tileWidth,
			height: ts.tileHeight
		},
		...entry.userData ? { userData: copy$3(entry.userData) } : {}
	}));
	if (entries.some((entry) => entry.userData)) ts.tileUserData = entries.map((entry) => copy$3(entry.userData) ?? null);
	else delete ts.tileUserData;
}
function bits(cell, ids, flags) {
	if (cell == null) return flags & 4 ? 0 : 4294967295;
	const index = ids.get(cell.tileId);
	if (index == null) throw Error("Tilemap references an unknown tile.");
	let x = !!cell.flipX, y = !!cell.flipY, diagonal = false;
	const rotation = cell.rotate ?? 0;
	if (rotation === 90) {
		diagonal = true;
		[x, y] = [!y, x];
	} else if (rotation === 180) {
		x = !x;
		y = !y;
	} else if (rotation === 270) {
		diagonal = true;
		[x, y] = [y, !x];
	} else if (rotation !== 0) throw Error("Unsupported tile rotation.");
	return (index | (x ? 2147483648 : 0) | (y ? 1073741824 : 0) | (diagonal ? 536870912 : 0)) >>> 0;
}
/** Encode engine maps before changing resource slots. Native Lua leaves tile words unchanged. */
function nativeMaps(doc, layers, api) {
	const links = /* @__PURE__ */ new Map();
	for (const layer of layers) {
		if (!layer.tilemaps) continue;
		for (const [frameId, map] of Object.entries(layer.tilemaps)) {
			const ts = find(doc, map.tilesetId), slots = tilesetSlots(doc, ts), ids = new Map([...slots.entries].map(([index, tile]) => [tile.id, index]));
			const frame = doc.frames.find((frame) => frame.id === frameId);
			if (!frame) throw Error("Tilemap frame not found.");
			const tilemap = {
				bitsPerTile: 32,
				idMask: 536870911,
				xFlipMask: 2147483648,
				yFlipMask: 1073741824,
				diagonalFlipMask: 536870912,
				tiles: map.cells.map((cell) => bits(cell, ids, slots.native ? ts.flags : 4))
			};
			const previous = frame.cels[layer.id], sourceId = map.sourceImageId ?? previous?.imageId, source = doc.images[sourceId], key = sourceId ? `${sourceId}:${JSON.stringify([
				map.columns,
				map.rows,
				tilemap
			])}` : null;
			let imageId = source?.tilemap && source.width === map.columns && source.height === map.rows && JSON.stringify(source.tilemap) === JSON.stringify(tilemap) ? sourceId : key ? links.get(key) : null;
			if (!imageId) {
				api.reserve(doc, map.columns * map.rows);
				imageId = api.fresh(doc, "image");
				doc.images[imageId] = {
					width: map.columns,
					height: map.rows,
					pixels: [],
					tilemap
				};
				if (key) links.set(key, imageId);
			}
			frame.cels[layer.id] = {
				...previous,
				imageId,
				x: map.x ?? previous?.x ?? 0,
				y: map.y ?? previous?.y ?? 0,
				opacity: map.opacity ?? previous?.opacity ?? 1
			};
		}
		delete layer.tilemaps;
	}
}
function createNativeTileset(doc, command, api) {
	if (doc.tilesets.length >= 256) throw Error("Too many tilesets.");
	const source = command.copyTilesetId == null ? null : find(doc, command.copyTilesetId);
	const width = source?.tileWidth ?? command.tileWidth, height = source?.tileHeight ?? command.tileHeight, count = source ? tilesetSlots(doc, source).count : command.tileCount ?? 1;
	const size = atlasSize(width, height, count, api.limits);
	api.reserve(doc, size);
	const id = command.tilesetId ?? api.fresh(doc, "tileset");
	if (doc.tilesets.some((ts) => ts.id === id)) throw Error("Tileset ID already exists.");
	const origin = command.gridOrigin ?? source?.gridOrigin ?? {
		x: 0,
		y: 0
	};
	integer$6(origin.x, -65535, 65535, "Grid origin x");
	integer$6(origin.y, -65535, 65535, "Grid origin y");
	const ts = {
		id,
		name: source?.name ?? "",
		tileWidth: width,
		tileHeight: height,
		baseIndex: 1,
		flags: 6,
		asepriteId: numericId(doc),
		...source?.userData ? { userData: copy$3(source.userData) } : {},
		...origin.x || origin.y ? { gridOrigin: { ...origin } } : {}
	};
	installAtlas(doc, ts, source ? entriesFor(doc, source, api.limits) : Array.from({ length: count }, (_, index) => ({
		id: `tile-${index}`,
		pixels: Array(width * height).fill(blank(doc))
	})), api);
	doc.tilesets.push(ts);
	return ts;
}
function changeTilesetSlots(doc, command, api) {
	const ts = find(doc, command.tilesetId);
	assertTilesetEditable(doc, ts.id);
	const entries = entriesFor(doc, ts, api.limits), insert = command.type === "tileset.tileInsert", index = integer$6(command.tileIndex ?? entries.length, 1, insert ? entries.length : entries.length - 1, "Tile index");
	atlasSize(ts.tileWidth, ts.tileHeight, entries.length + (insert ? 1 : -1), api.limits);
	const layers = doc.layers.filter((layer) => layer.tilesetId === ts.id || Object.values(layer.tilemaps ?? {}).some((map) => map.tilesetId === ts.id));
	if (layers.some((layer) => [layer.tilesetId, ...Object.values(layer.tilemaps ?? {}).map((map) => map.tilesetId)].filter(Boolean).some((id) => id !== ts.id))) throw Error("Structural edits require each tilemap layer to use one tileset across frames.");
	nativeMaps(doc, layers, api);
	for (const layer of layers) layer.tilesetId = ts.id;
	if (insert && entries.some((entry) => entry.id === command.tileId)) throw Error("Tile ID already exists.");
	if (insert) entries.splice(index, 0, {
		id: command.tileId ?? tileId(entries),
		pixels: Array(ts.tileWidth * ts.tileHeight).fill(blank(doc))
	});
	else entries.splice(index, 1);
	installAtlas(doc, ts, entries, api);
}
function assignLayerTileset(doc, command, api) {
	const layer = api.layerFor(doc, command.layerId, true);
	if (layer.type !== "tilemap") throw Error("Tileset assignment requires a tilemap layer.");
	const ts = find(doc, command.tilesetId);
	if (ts.flags & 1) throw Error("Embed external tileset artwork before assigning it to a layer.");
	if (!ts.imageId || !Number.isInteger(ts.asepriteId) || ts.tiles?.some((tile) => !Number.isInteger(tile.asepriteTileId))) installAtlas(doc, ts, entriesFor(doc, ts, api.limits), api);
	nativeMaps(doc, [layer], api);
	layer.tilesetId = ts.id;
}
//#endregion
//#region app/rotation-raster.mjs
/*! PixelWall portable adaptation of the MIT Aseprite Document Library rotation
* algorithms. Copyright (c) 2018-present Igara Studio S.A.; 2001-2018 David Capello.
* RotSprite source: Copyright (c) 2020-2023 Igara Studio S.A.; 2001-2018 David Capello.
* Original Allegro rotation: Shawn Hargreaves; flipping: Andrew Geers;
* optimization: Sven Sandberg; C++ templates: David Capello.
* Full MIT permission and upstream notices: docs/rotation-NOTICES.txt,
* distributed as runtimes/rotation-NOTICES.txt. This JavaScript adaptation is
* modified from upstream: bounded owned buffers, explicit validation, pure output,
* no image-library dependencies, no global scratch storage, no mutable destination.
*
* Copyright (c) 2018-present Igara Studio S.A.
* Copyright (c) 2001-2018 David Capello
* 
* Permission is hereby granted, free of charge, to any person obtaining
* a copy of this software and associated documentation files (the
* "Software"), to deal in the Software without restriction, including
* without limitation the rights to use, copy, modify, merge, publish,
* distribute, sublicense, and/or sell copies of the Software, and to
* permit persons to whom the Software is furnished to do so, subject to
* the following conditions:
* 
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
* 
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
* LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
* OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
* WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
const UNIT = 65536, MAX_FIXED = 2147483647;
const fail$5 = (message) => {
	throw Error(message);
};
const int$1 = (value, label, min, max) => {
	if (!Number.isSafeInteger(value) || value < min || value > max) fail$5(`${label} must be an integer from ${min} to ${max}.`);
	return value;
};
const fixed = (value) => value > 32767 ? MAX_FIXED : value < -32767 ? -MAX_FIXED : Math.trunc(value * UNIT + (value < 0 ? -.5 : .5));
const multiply = (a, b) => fixed(a / UNIT * (b / UNIT));
const divide = (a, b) => b === 0 ? a < 0 ? -MAX_FIXED : MAX_FIXED : fixed(a / b);
const rounded = (value) => (value >> 16) + ((value & 32768) >>> 15);
const outOf = (value, size) => value >> 16 < 0 || value >> 16 >= size;
/** MIT scanline parallelogram port. Coordinates are outer pixel corners, TL/TR/BR/BL.
* Fixed-point ties, endpoint adjustments and edge repair deliberately match upstream. */
function mapParallelogram(sw, sh, dw, dh, points, draw) {
	const xs = points.map((p) => p[0] * UNIT), ys = points.map((p) => p[1] * UNIT);
	let top = 0;
	for (let i = 1; i < 4; i++) if (ys[i] < ys[top]) top = i;
	const right = multiply(xs[top + 1 & 3] - xs[top], ys[top - 1 & 3] - ys[top]) > multiply(xs[top - 1 & 3] - xs[top], ys[top + 1 & 3] - ys[top]) ? 1 : -1;
	const bx = [], by = [], px = [], py = [];
	for (let i = 0, index = top; i < 4; i++, index = index + right & 3) {
		bx[i] = xs[index];
		by[i] = ys[index];
		px[i] = index === 0 || index === 3 ? 0 : sw * UNIT - 1;
		py[i] = index < 2 ? 0 : sh * UNIT - 1;
	}
	const clipRight = dw * UNIT - 1;
	if (bx[3] > clipRight && bx[0] > clipRight && bx[2] > clipRight || bx[1] < 0 && bx[0] < 0 && bx[2] < 0) return;
	const bottom = Math.min(dh, by[2] + 32768 >> 16);
	let y = Math.max(0, by[0] + 32768 >> 16);
	if (y >= bottom) return;
	let extra = y * UNIT + 32768 - by[0];
	let ldx = divide(bx[3] - bx[0], by[3] - by[0]), lx = bx[0] + multiply(extra, ldx) | 0;
	let spdx = divide(px[3] - px[0], by[3] - by[0]), spx = px[0] + multiply(extra, spdx) | 0;
	let spdy = divide(py[3] - py[0], by[3] - by[0]), spy = py[0] + multiply(extra, spdy) | 0;
	let leftBottom = Math.min(bottom, by[3] + 32768 >> 16);
	let rdx = divide(bx[1] - bx[0], by[1] - by[0]), rx = bx[0] + multiply(extra, rdx) | 0, rightBottom = by[1] + 32768 >> 16;
	const determinant = (xs[1] - xs[0]) * (ys[3] - ys[0]) - (xs[3] - xs[0]) * (ys[1] - ys[0]);
	if (!determinant) return;
	const dx = Math.trunc((ys[3] - ys[0]) * UNIT * (UNIT * sw) / determinant) | 0;
	const dy = Math.trunc((ys[1] - ys[0]) * UNIT * (UNIT * sh) / -determinant) | 0;
	while (true) {
		if (y >= leftBottom) {
			if (y >= bottom) break;
			extra = y * UNIT + 32768 - by[3];
			ldx = divide(bx[2] - bx[3], by[2] - by[3]);
			lx = bx[3] + multiply(extra, ldx) | 0;
			spdx = divide(px[2] - px[3], by[2] - by[3]);
			spx = px[3] + multiply(extra, spdx) | 0;
			spdy = divide(py[2] - py[3], by[2] - by[3]);
			spy = py[3] + multiply(extra, spdy) | 0;
			leftBottom = Math.min(bottom, by[2] + 32768 >> 16);
		}
		if (y >= rightBottom) {
			extra = y * UNIT + 32768 - by[1];
			rdx = divide(bx[2] - bx[1], by[2] - by[1]);
			rx = bx[1] + multiply(extra, rdx) | 0;
			rightBottom = bottom;
		}
		let left = Math.max(0, lx + 32768 & -65536), right = Math.min(clipRight, rx - 32768 & -65536);
		let u = spx + multiply(left + 32767 - lx, dx) | 0, v = spy + multiply(left + 32767 - lx, dy) | 0;
		scanline: {
			if (left > right) break scanline;
			if (outOf(u, sw)) {
				if (u < 0 && dx <= 0 || u > 0 && dx >= 0) break scanline;
				do {
					u = u + dx | 0;
					left += UNIT;
					if (left > right) break scanline;
				} while (outOf(u, sw));
			}
			let edge = u + (right - left >> 16) * dx | 0;
			if (outOf(edge, sw)) if (edge < 0 && dx <= 0 || edge > 0 && dx >= 0) do {
				right -= UNIT;
				edge = edge - dx | 0;
				if (left > right) break scanline;
			} while (outOf(edge, sw));
			else break scanline;
			if (outOf(v, sh)) {
				if (v < 0 && dy <= 0 || v > 0 && dy >= 0) break scanline;
				do {
					v = v + dy | 0;
					left += UNIT;
					if (left > right) break scanline;
				} while (outOf(v, sh));
			}
			edge = v + (right - left >> 16) * dy | 0;
			if (outOf(edge, sh)) if (edge < 0 && dy <= 0 || edge > 0 && dy >= 0) do {
				right -= UNIT;
				edge = edge - dy | 0;
				if (left > right) break scanline;
			} while (outOf(edge, sh));
			else break scanline;
			for (let x = left >> 16, last = right >> 16; x <= last; x++, u = u + dx | 0, v = v + dy | 0) {
				const ix = u >> 16, iy = v >> 16;
				if (ix >= 0 && iy >= 0 && ix < sw && iy < sh) draw(x, y, ix, iy);
			}
		}
		y++;
		lx = lx + ldx | 0;
		spx = spx + spdx | 0;
		spy = spy + spdy | 0;
		rx = rx + rdx | 0;
	}
}
function scale2x(source, width, height) {
	const pixels = new Uint32Array(width * height * 4), row = width * 2;
	for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
		const p = source[y * width + x], a = y ? source[(y - 1) * width + x] : p, b = x < width - 1 ? source[y * width + x + 1] : p, c = x ? source[y * width + x - 1] : p, d = y < height - 1 ? source[(y + 1) * width + x] : p, at = y * 2 * row + x * 2;
		pixels[at] = c === a && c !== d && a !== b ? a : p;
		pixels[at + 1] = a === b && a !== c && b !== d ? b : p;
		pixels[at + row] = d === c && d !== b && c !== a ? c : p;
		pixels[at + row + 1] = b === d && b !== a && d !== c ? d : p;
	}
	return pixels;
}
function endpointAxis(sourceSize, destinationSize) {
	const step = divide((sourceSize - 1) * UNIT, (destinationSize - 1) * UNIT), indices = new Uint32Array(destinationSize);
	for (let i = 0, coordinate = 0; i < destinationSize; i++, coordinate = Math.min(MAX_FIXED, coordinate + step)) indices[i] = Math.min(sourceSize - 1, rounded(coordinate));
	return indices;
}
/** Pure Fast/RotSprite image mapping onto a transparent destination.
* Pixels are Aseprite-packed RGBA (R in low byte), gray+alpha, or palette indices.
* Corners are integer outer corners, not an angle: UI corner rounding is separate.
* Optional source-size 0/1 mask retains irregular selection geometry.
* Values mode carries arbitrary uint32 IDs with a reserved transparent sentinel.
* No destination blending occurs; callers composite the returned patch once. */
function rasterizeRotation({ pixels, width, height, destinationWidth, destinationHeight, corners, method = "fast", pixelFormat = "rgba", maskColor = 0, mask = null }) {
	width = int$1(width, "Source width", 1, 32767);
	height = int$1(height, "Source height", 1, 32767);
	const dw = int$1(destinationWidth, "Destination width", 1, 32767), dh = int$1(destinationHeight, "Destination height", 1, 32767);
	if (!["fast", "rotsprite"].includes(method)) fail$5("Rotation method must be fast or rotsprite.");
	if (![
		"rgba",
		"grayscale",
		"indexed",
		"bitmap",
		"values"
	].includes(pixelFormat)) fail$5("Unsupported rotation pixel format.");
	const sourceCount = width * height, destinationCount = dw * dh;
	if (sourceCount > 16777216 || destinationCount > 16777216) fail$5("Rotation exceeds its pixel budget.");
	if (!(Array.isArray(pixels) || pixels instanceof Uint32Array) || pixels.length !== sourceCount) fail$5("Rotation source pixels do not match its dimensions.");
	const maxPixel = pixelFormat === "indexed" ? 255 : pixelFormat === "bitmap" ? 1 : pixelFormat === "grayscale" ? 65535 : 4294967295;
	for (const value of pixels) int$1(value, "Rotation pixel", 0, maxPixel);
	int$1(maskColor, "Transparent mask color", 0, maxPixel);
	if (pixelFormat === "rgba" && maskColor >>> 24 || pixelFormat === "grayscale" && maskColor >>> 8) fail$5("RGBA and grayscale rotation require a transparent mask color.");
	if (mask && (!(Array.isArray(mask) || mask instanceof Uint8Array) || mask.length !== sourceCount || mask.some((value) => value !== 0 && value !== 1))) fail$5("Rotation mask must contain one 0/1 value per source pixel.");
	if (!Array.isArray(corners) || corners.length !== 4 || corners.some((p) => !Array.isArray(p) || p.length !== 2)) fail$5("Rotation requires four XY corner pairs.");
	for (const point of corners) for (const value of point) int$1(value, "Rotation corner", -32767, 32767);
	const xmin = Math.min(...corners.map((p) => p[0])), xmax = Math.max(...corners.map((p) => p[0])), ymin = Math.min(...corners.map((p) => p[1])), ymax = Math.max(...corners.map((p) => p[1])), rw = xmax - xmin, rh = ymax - ymin;
	if (rw > 32767 || rh > 32767) fail$5("Rotation corner span exceeds fixed-point range.");
	if (corners[0][0] + corners[2][0] !== corners[1][0] + corners[3][0] || corners[0][1] + corners[2][1] !== corners[1][1] + corners[3][1]) fail$5("Rotation corners must form a parallelogram.");
	const bytes = (sourceCount + destinationCount) * 5 + (method === "rotsprite" ? sourceCount * 84 * 4 + rw * rh * 64 * 5 + (mask ? (width + height) * 8 * 4 : 0) + (rw + rh) * 4 : 0);
	if (method === "rotsprite" && (Math.max(width, height, rw, rh) > 4095 || bytes > 16777216 * 4)) fail$5("RotSprite exceeds its 8x temporary pixel budget; reduce the selection or choose Fast.");
	if (bytes > 16777216 * 4) fail$5("Rotation exceeds its temporary pixel budget.");
	const output = new Uint32Array(destinationCount).fill(maskColor), coverage = new Uint8Array(destinationCount);
	const accepts = (value) => pixelFormat === "rgba" ? !(maskColor >>> 24) || (value & 16777215) !== (maskColor & 16777215) : pixelFormat === "grayscale" ? !(maskColor >>> 8) || (value & 255) !== (maskColor & 255) : value !== maskColor;
	if (!rw || !rh) return {
		width: dw,
		height: dh,
		pixels: output,
		coverage
	};
	if (method === "fast") mapParallelogram(width, height, dw, dh, corners, (x, y, ix, iy) => {
		const at = iy * width + ix, value = pixels[at];
		if ((!mask || mask[at]) && accepts(value)) {
			output[y * dw + x] = value;
			coverage[y * dw + x] = 1;
		}
	});
	else {
		let enlarged = pixels, w = width, h = height;
		for (let i = 0; i < 3; i++) {
			enlarged = scale2x(enlarged, w, h);
			w *= 2;
			h *= 2;
		}
		const high = new Uint32Array(rw * rh * 64).fill(maskColor), highCoverage = new Uint8Array(rw * rh * 64);
		const mx = mask ? endpointAxis(width, w) : null, my = mask ? endpointAxis(height, h) : null;
		mapParallelogram(w, h, rw * 8, rh * 8, corners.map(([x, y]) => [(x - xmin) * 8, (y - ymin) * 8]), (x, y, ix, iy) => {
			const value = enlarged[iy * w + ix];
			if ((!mask || mask[my[iy] * width + mx[ix]]) && accepts(value)) {
				high[y * rw * 8 + x] = value;
				highCoverage[y * rw * 8 + x] = 1;
			}
		});
		const left = Math.max(0, xmin), top = Math.max(0, ymin), targetW = Math.max(0, Math.min(rw, dw - left)), targetH = Math.max(0, Math.min(rh, dh - top));
		if (targetW && targetH) {
			const xx = endpointAxis(rw * 8, targetW), yy = endpointAxis(rh * 8, targetH);
			for (let y = 0; y < targetH; y++) for (let x = 0; x < targetW; x++) {
				const at = yy[y] * rw * 8 + xx[x], target = (y + top) * dw + x + left;
				output[target] = high[at];
				coverage[target] = highCoverage[at];
			}
		}
	}
	return {
		width: dw,
		height: dh,
		pixels: output,
		coverage
	};
}
//#endregion
//#region app/indexed-color.mjs
/** Original, deterministic palette reduction and dithering. No host access or document mutation. */
const MAX_PIXELS = 16777216, MAX_WORK = 67108864, MAX_HISTOGRAM = 65536;
const fail$4 = (message) => {
	throw Error(`Indexed conversion: ${message}`);
};
const clamp$1 = (value, low = 0, high = 255) => Math.max(low, Math.min(high, value));
const integer$5 = (value, low, high, label) => {
	if (!Number.isSafeInteger(value) || value < low || value > high) fail$4(`invalid ${label}.`);
	return value;
};
const color$1 = (value) => {
	if (value === null) return [
		0,
		0,
		0,
		0
	];
	if (typeof value !== "string" || !/^#[0-9a-f]{8}$/i.test(value)) fail$4("pixels and palette entries must be RGBA hex strings or null.");
	return [
		1,
		3,
		5,
		7
	].map((at) => parseInt(value.slice(at, at + 2), 16));
};
const hex$3 = (values) => "#" + values.map((value) => Math.round(clamp$1(value)).toString(16).padStart(2, "0")).join("");
const vector = (c) => [
	c[0] * c[3] / 255,
	c[1] * c[3] / 255,
	c[2] * c[3] / 255,
	c[3]
];
const distance = (a, b) => (a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2 + (a[2] - b[2]) ** 2 + 2 * (a[3] - b[3]) ** 2;
function workBudget(value) {
	const budget = value ?? { remaining: MAX_WORK };
	integer$5(budget.remaining, 0, MAX_WORK, "remaining work budget");
	return budget;
}
function spend(budget, amount) {
	budget.remaining -= amount;
	if (budget.remaining < 0) fail$4("work limit exceeded; reduce the image, palette, or frame count.");
}
function indexedConversionOptions(input = {}) {
	const options = {
		paletteMode: input.paletteMode ?? "existing",
		maxColors: input.maxColors ?? 256,
		quantization: input.quantization ?? "median-cut",
		withAlpha: input.withAlpha ?? true,
		dithering: input.dithering ?? "none",
		ditherMatrix: input.ditherMatrix ?? "bayer4x4",
		ditherStrength: input.ditherStrength ?? 1,
		rgbmap: input.rgbmap ?? (["octree", "rgb5a3"].includes(input.quantization) || input.dithering?.startsWith("aseprite-") ? "octree" : "pixelwall"),
		fitCriteria: input.fitCriteria ?? "default"
	};
	if (!["existing", "generate"].includes(options.paletteMode)) fail$4("palette mode must be existing or generate.");
	integer$5(options.maxColors, 2, 256, "palette color limit");
	if (![
		"median-cut",
		"octree",
		"rgb5a3"
	].includes(options.quantization)) fail$4("quantization must be median-cut, octree, or rgb5a3.");
	if (![
		"pixelwall",
		"octree",
		"rgb5a3"
	].includes(options.rgbmap)) fail$4("RGB map must be pixelwall, octree, or rgb5a3.");
	if (![
		"default",
		"rgb",
		"linearizedRGB",
		"ciexyz",
		"cielab"
	].includes(options.fitCriteria)) fail$4("unsupported fitting criterion.");
	if (options.rgbmap === "pixelwall" && options.fitCriteria !== "default") fail$4("fitting criteria require a native RGB map.");
	if (typeof options.withAlpha !== "boolean") fail$4("withAlpha must be boolean.");
	if (![
		"none",
		"ordered",
		"floyd-steinberg",
		"aseprite-ordered",
		"aseprite-old",
		"aseprite-error-diffusion"
	].includes(options.dithering)) fail$4("unsupported dithering algorithm.");
	if (options.rgbmap !== "pixelwall" && ["ordered", "floyd-steinberg"].includes(options.dithering)) fail$4("legacy dithering requires the pixelwall RGB map; choose a native dithering mode.");
	if (options.rgbmap === "pixelwall" && options.dithering.startsWith("aseprite-")) fail$4("native dithering requires an octree or rgb5a3 RGB map.");
	if (["aseprite-ordered", "aseprite-old"].includes(options.dithering) && options.ditherStrength !== 1) fail$4("native ordered dithering does not have a strength control.");
	if (![
		"bayer2x2",
		"bayer4x4",
		"bayer8x8"
	].includes(options.ditherMatrix)) fail$4("unsupported Bayer matrix.");
	if (typeof options.ditherStrength !== "number" || !Number.isFinite(options.ditherStrength) || options.ditherStrength < 0 || options.ditherStrength > 1) fail$4("dither strength must be from 0 to 1.");
	return options;
}
/** Weighted median cut in premultiplied RGBA. The reserved transparent slot counts toward maxColors. */
function quantizePalette(samples, input = {}) {
	const options = indexedConversionOptions({
		...input,
		paletteMode: "generate"
	});
	if (options.quantization !== "median-cut") return quantizeNativePalette(samples, {
		...input,
		...options
	});
	const transparentIndex = integer$5(input.transparentIndex ?? 0, 0, options.maxColors - 1, "transparent index"), budget = workBudget(input.budget);
	let histogram = /* @__PURE__ */ new Map(), binned = false;
	function keyOf(c) {
		return binned ? c.map((value) => Math.floor(value / 16)).join(",") : c.join(",");
	}
	function add(c, count = 1, sums = null) {
		const key = keyOf(c), entry = histogram.get(key), v = vector(c);
		const sum = sums ?? v.map((value) => value * count);
		if (entry) {
			entry.count += count;
			for (let k = 0; k < 4; k++) entry.sum[k] += sum[k];
		} else histogram.set(key, {
			count,
			sum,
			first: c
		});
	}
	for (const sample of samples) {
		spend(budget, 1);
		const c = color$1(sample);
		if (c[3] === 0) continue;
		if (!options.withAlpha) c[3] = 255;
		add(c);
		if (!binned && histogram.size > MAX_HISTOGRAM) {
			const entries = [...histogram.values()];
			histogram = /* @__PURE__ */ new Map();
			binned = true;
			for (const entry of entries) add(entry.first, entry.count, entry.sum);
		}
	}
	const entries = [...histogram.values()].map((entry, order) => ({
		...entry,
		order,
		v: entry.sum.map((value) => value / entry.count)
	}));
	function box(items) {
		const low = [
			Infinity,
			Infinity,
			Infinity,
			Infinity
		], high = [
			-Infinity,
			-Infinity,
			-Infinity,
			-Infinity
		];
		let count = 0;
		for (const entry of items) {
			count += entry.count;
			for (let k = 0; k < 4; k++) {
				low[k] = Math.min(low[k], entry.v[k]);
				high[k] = Math.max(high[k], entry.v[k]);
			}
		}
		let axis = 0, spread = 0;
		for (let k = 0; k < 4; k++) {
			const value = (high[k] - low[k]) ** 2 * (k === 3 ? 2 : 1);
			if (value > spread) {
				axis = k;
				spread = value;
			}
		}
		return {
			items,
			count,
			axis,
			score: items.length > 1 ? spread * count : 0
		};
	}
	const boxes = entries.length ? [box(entries)] : [], available = options.maxColors - 1;
	while (boxes.length < available) {
		let best = -1;
		for (let i = 0; i < boxes.length; i++) if (boxes[i].score > 0 && (best < 0 || boxes[i].score > boxes[best].score)) best = i;
		if (best < 0) break;
		const current = boxes[best], items = [...current.items].sort((a, b) => a.v[current.axis] - b.v[current.axis] || a.order - b.order);
		spend(budget, items.length);
		let count = 0, cut = 0;
		while (cut < items.length - 1) {
			count += items[cut++].count;
			if (count >= current.count / 2) break;
		}
		boxes.splice(best, 1, box(items.slice(0, cut)), box(items.slice(cut)));
	}
	const colors = boxes.map((item) => {
		const sum = [
			0,
			0,
			0,
			0
		];
		for (const entry of item.items) for (let k = 0; k < 4; k++) sum[k] += entry.sum[k];
		const a = sum[3] / item.count;
		return hex$3([
			sum[0] / item.count * 255 / a,
			sum[1] / item.count * 255 / a,
			sum[2] / item.count * 255 / a,
			a
		]);
	});
	const palette = [];
	const unique = [...new Set(colors)];
	const length = Math.max(transparentIndex + 1, unique.length + 1);
	for (let index = 0; index < length; index++) palette.push(index === transparentIndex ? "#00000000" : unique.shift() ?? "#00000000");
	return palette;
}
function bayer(size) {
	let matrix = [[0]];
	while (matrix.length < size) {
		const n = matrix.length, next = Array.from({ length: n * 2 }, () => Array(n * 2));
		for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) {
			next[y][x] = 4 * matrix[y][x];
			next[y][x + n] = 4 * matrix[y][x] + 2;
			next[y + n][x] = 4 * matrix[y][x] + 3;
			next[y + n][x + n] = 4 * matrix[y][x] + 1;
		}
		matrix = next;
	}
	return matrix;
}
/** Dither an RGBA raster into a palette. Regions reset both Bayer origin and diffusion for native atlas tiles. */
function mapIndexedImage(image, palette, input = {}) {
	const options = indexedConversionOptions(input);
	if (options.rgbmap !== "pixelwall") return mapNativeIndexedImage(image, palette, {
		...input,
		...options
	});
	const width = integer$5(image.width, 1, 65535, "image width"), height = integer$5(image.height, 1, 65535, "image height");
	if (width * height > MAX_PIXELS || !Array.isArray(image.pixels) || image.pixels.length !== width * height) fail$4("invalid image pixel count.");
	if (!Array.isArray(palette) || !palette.length || palette.length > 256) fail$4("indexed conversion requires a palette of 1–256 colors.");
	const transparentIndex = input.transparentIndex == null ? null : integer$5(input.transparentIndex, 0, palette.length - 1, "transparent index");
	const colors = palette.map(color$1);
	if (transparentIndex !== null) colors[transparentIndex] = [
		0,
		0,
		0,
		0
	];
	const vectors = colors.map(vector), budget = workBudget(input.budget), output = new Array(width * height), cache = /* @__PURE__ */ new Map();
	const tileWidth = integer$5(input.tileWidth ?? width, 1, width, "tile width"), tileHeight = integer$5(input.tileHeight ?? height, 1, height, "tile height");
	if (width % tileWidth || height % tileHeight) fail$4("atlas dimensions must be multiples of the tile grid.");
	const matrixSize = Number(options.ditherMatrix[5]), matrix = bayer(matrixSize), algorithm = options.ditherStrength === 0 ? "none" : options.dithering;
	function nearest(v, opaque, pair) {
		let a = -1, b = -1, da = Infinity, db = Infinity;
		spend(budget, colors.length);
		for (let index = 0; index < colors.length; index++) {
			if (opaque && (index === transparentIndex || colors[index][3] === 0)) continue;
			const d = distance(v, vectors[index]);
			if (d < da) {
				b = a;
				db = da;
				a = index;
				da = d;
			} else if (d < db) {
				b = index;
				db = d;
			}
		}
		if (a < 0) fail$4("palette has no visible color for an opaque pixel.");
		return pair ? [a, b < 0 ? a : b] : a;
	}
	for (let top = 0; top < height; top += tileHeight) for (let left = 0; left < width; left += tileWidth) {
		let errors = new Float64Array((tileWidth + 2) * 4), next = new Float64Array(errors.length);
		for (let y = 0; y < tileHeight; y++) {
			for (let x = 0; x < tileWidth; x++) {
				const at = (top + y) * width + left + x, c = color$1(image.pixels[at]);
				spend(budget, 1);
				if (c[3] === 0) {
					output[at] = null;
					continue;
				}
				const v = vector(c), opaque = c[3] === 255, slot = (x + 1) * 4;
				let chosen;
				if (algorithm === "floyd-steinberg") {
					for (let k = 0; k < 4; k++) v[k] = clamp$1(v[k] + errors[slot + k]);
					for (let k = 0; k < 3; k++) v[k] = Math.min(v[k], v[3]);
					chosen = nearest(v, opaque, false);
					for (let k = 0; k < 4; k++) {
						const error = (v[k] - vectors[chosen][k]) * options.ditherStrength;
						errors[slot + 4 + k] += error * 7 / 16;
						next[slot - 4 + k] += error * 3 / 16;
						next[slot + k] += error * 5 / 16;
						next[slot + 4 + k] += error / 16;
					}
				} else {
					const key = hex$3(c);
					let candidates = cache.get(key);
					if (!candidates) {
						candidates = nearest(v, opaque, true);
						if (cache.size < MAX_HISTOGRAM) cache.set(key, candidates);
					}
					chosen = candidates[0];
					if (algorithm === "ordered" && candidates[0] !== candidates[1]) {
						const [a, b] = [...candidates].sort((one, two) => one - two), start = vectors[a], end = vectors[b], nearestVector = vectors[chosen];
						let numerator = 0, denominator = 0;
						for (let k = 0; k < 4; k++) {
							const step = end[k] - start[k], weight = k === 3 ? 2 : 1, value = nearestVector[k] + (v[k] - nearestVector[k]) * options.ditherStrength;
							numerator += (value - start[k]) * step * weight;
							denominator += step * step * weight;
						}
						chosen = (denominator ? clamp$1(numerator / denominator, 0, 1) : 0) > (matrix[y % matrixSize][x % matrixSize] + .5) / (matrixSize * matrixSize) ? b : a;
					}
				}
				output[at] = chosen === transparentIndex || colors[chosen][3] === 0 ? null : chosen;
			}
			errors = next;
			next = new Float64Array(errors.length);
		}
	}
	return output;
}
//#endregion
//#region app/aseprite-properties.mjs
/** Native property maps from the published Aseprite file format; bounded JSON value subset. */
const MAX_BYTES = 1024 * 1024, MAX_ITEMS = 16384, MAX_DEPTH = 24;
const encoder = new TextEncoder(), decoder = new TextDecoder("utf-8", { fatal: true });
const fail$3 = (message) => {
	throw Error(`Sprite properties: ${message}`);
};
const plain = (value) => value && typeof value === "object" && !Array.isArray(value) && [Object.prototype, null].includes(Object.getPrototypeOf(value));
function decodeAsepriteProperties(input) {
	if (input == null) return {};
	if (!Array.isArray(input) && !(input instanceof Uint8Array)) fail$3("expected bytes.");
	if (input.length > MAX_BYTES || !Array.from(input).every((v) => Number.isInteger(v) && v >= 0 && v <= 255)) fail$3("invalid bytes or size limit.");
	const bytes = Uint8Array.from(input), view = new DataView(bytes.buffer);
	let at = 0, items = 0;
	const take = (n) => {
		if (n < 0 || at + n > bytes.length) fail$3("truncated data.");
		const start = at;
		at += n;
		return start;
	};
	const u8 = () => view.getUint8(take(1)), u16 = () => view.getUint16(take(2), true), u32 = () => view.getUint32(take(4), true);
	const text = () => {
		const length = u16();
		return decoder.decode(bytes.subarray(take(length), at));
	};
	function value(type, depth) {
		if (++items > MAX_ITEMS || depth > MAX_DEPTH) fail$3("item or nesting limit.");
		let result;
		if (type === 1) return u8() !== 0;
		if (type === 2) return view.getInt8(take(1));
		if (type === 3) return u8();
		if (type === 4) return view.getInt16(take(2), true);
		if (type === 5) return u16();
		if (type === 6) return view.getInt32(take(4), true);
		if (type === 7) return u32();
		if (type === 8 || type === 9) {
			const offset = take(8), big = type === 8 ? view.getBigInt64(offset, true) : view.getBigUint64(offset, true);
			result = Number(big);
			if (!Number.isSafeInteger(result)) fail$3("64-bit integer exceeds exact JavaScript range.");
			return result;
		}
		if (type === 10) return view.getInt32(take(4), true) / 65536;
		if (type === 11 || type === 12) {
			result = type === 11 ? view.getFloat32(take(4), true) : view.getFloat64(take(8), true);
			if (!Number.isFinite(result)) fail$3("nonfinite number.");
			return result;
		}
		if (type === 13) return text();
		if (type === 17) {
			const count = u32(), elementType = u16();
			if (count > MAX_ITEMS - items) fail$3("vector item limit.");
			return Array.from({ length: count }, () => value(elementType || u16(), depth + 1));
		}
		if (type === 18) return map(depth + 1);
		fail$3(`unsupported value type 0x${type.toString(16)}; existing bytes are preserved until this object is edited.`);
	}
	function map(depth) {
		if (depth > MAX_DEPTH) fail$3("nesting limit.");
		const count = u32(), result = Object.create(null);
		if (count > MAX_ITEMS - items) fail$3("map item limit.");
		for (let i = 0; i < count; i++) {
			const key = text();
			if (Object.hasOwn(result, key)) fail$3("duplicate property name.");
			result[key] = value(u16(), depth);
		}
		return result;
	}
	if (u32() !== bytes.length) fail$3("declared block size mismatch.");
	const count = u32(), result = Object.create(null);
	if (count > MAX_ITEMS) fail$3("too many property maps.");
	for (let i = 0; i < count; i++) {
		const key = u32();
		if (Object.hasOwn(result, key)) fail$3("duplicate property map.");
		result[key] = map(0);
	}
	if (at !== bytes.length) fail$3("trailing data.");
	return result;
}
function encodeAsepriteProperties(maps) {
	if (!plain(maps)) fail$3("expected property maps.");
	const out = [];
	let items = 0;
	const raw = (bytes) => {
		if (out.length + bytes.length > MAX_BYTES) fail$3("byte limit.");
		for (const byte of bytes) out.push(byte);
	};
	const numeric = (n, size, setter) => {
		const bytes = new Uint8Array(size);
		new DataView(bytes.buffer)[setter](0, n, true);
		raw(bytes);
	};
	const u16 = (n) => numeric(n, 2, "setUint16"), u32 = (n) => numeric(n, 4, "setUint32");
	const text = (value) => {
		const bytes = encoder.encode(value);
		if (bytes.length > 65535) fail$3("string exceeds native limit.");
		u16(bytes.length);
		raw(bytes);
	};
	function value(v, depth) {
		if (++items > MAX_ITEMS || depth > MAX_DEPTH) fail$3("item or nesting limit.");
		if (typeof v === "boolean") {
			u16(1);
			raw([Number(v)]);
		} else if (typeof v === "number") {
			if (!Number.isFinite(v) || Number.isInteger(v) && !Number.isSafeInteger(v)) fail$3("nonfinite or inexact number.");
			if (Number.isInteger(v) && v >= -2147483648 && v <= 2147483647) {
				u16(6);
				numeric(v, 4, "setInt32");
			} else {
				u16(12);
				numeric(v, 8, "setFloat64");
			}
		} else if (typeof v === "string") {
			u16(13);
			text(v);
		} else if (Array.isArray(v)) {
			u16(17);
			u32(v.length);
			u16(0);
			for (const item of v) value(item, depth + 1);
		} else if (plain(v)) {
			u16(18);
			map(v, depth + 1);
		} else fail$3("only booleans, exact numbers, strings, vectors and maps are supported.");
	}
	function map(values, depth) {
		if (depth > MAX_DEPTH) fail$3("nesting limit.");
		if (!plain(values)) fail$3("expected a property map.");
		const entries = Object.entries(values);
		if (entries.length > MAX_ITEMS - items) fail$3("item limit.");
		u32(entries.length);
		for (const [key, v] of entries) {
			text(key);
			value(v, depth);
		}
	}
	u32(0);
	const entries = Object.entries(maps);
	u32(entries.length);
	for (const [key, values] of entries) {
		const id = Number(key);
		if (!Number.isInteger(id) || id < 0 || id > 4294967295 || String(id) !== key) fail$3("invalid map ID.");
		u32(id);
		map(values, 0);
	}
	const result = Uint8Array.from(out);
	new DataView(result.buffer).setUint32(0, result.length, true);
	return Array.from(result);
}
function validateAsepriteUserData(value) {
	if (!plain(value) || Object.keys(value).some((key) => ![
		"text",
		"color",
		"propertiesBytes"
	].includes(key))) fail$3("invalid user data fields.");
	if (value.text != null && (typeof value.text !== "string" || encoder.encode(value.text).length > 65535)) fail$3("text exceeds native limit.");
	if (value.color != null && (typeof value.color !== "string" || !/^#[0-9a-f]{8}$/i.test(value.color))) fail$3("invalid user color.");
	if (value.propertiesBytes != null) decodeAsepriteProperties(value.propertiesBytes);
	return structuredClone(value);
}
//#endregion
//#region app/editor-core.mjs
/** PixelWall v4: a portable, transactional 2D document and raster engine. No DOM. */
const LIMITS = Object.freeze({
	edge: 65535,
	canvasPixels: 4194304,
	imageEdge: 65535,
	pixels: 16777216,
	layers: 256,
	frames: 2048,
	palette: 65536,
	operations: 67108864
});
const BLEND_MODES = Object.freeze([
	"normal",
	"multiply",
	"screen",
	"overlay",
	"darken",
	"lighten",
	"color-dodge",
	"color-burn",
	"hard-light",
	"soft-light",
	"difference",
	"exclusion",
	"addition",
	"subtract",
	"divide",
	"hue",
	"saturation",
	"color",
	"luminosity"
]);
const DEFAULT_PALETTE = [
	"#16152bff",
	"#3c315fff",
	"#7059c7ff",
	"#ff6b57ff",
	"#ffb34bff",
	"#ffe66dff",
	"#70d6b2ff",
	"#218c89ff",
	"#f8f0dfff"
];
const DIRECTIONS = [
	"forward",
	"reverse",
	"pingpong",
	"pingpong_reverse"
];
const validatedImages = /* @__PURE__ */ new WeakMap();
const clamp = (v, lo = 0, hi = 1) => Math.max(lo, Math.min(hi, v));
const own$1 = (o, k) => Object.prototype.hasOwnProperty.call(o, k);
const record$2 = (o) => o !== null && typeof o === "object" && !Array.isArray(o);
var EditorError = class extends Error {
	constructor(message, code = "INVALID_DOCUMENT") {
		super(message);
		this.name = "EditorError";
		this.code = code;
	}
};
function fail$2(message, code) {
	throw new EditorError(message, code);
}
function integer$4(v, label, min = 0, max = Number.MAX_SAFE_INTEGER) {
	if (!Number.isSafeInteger(v) || v < min || v > max) fail$2(`${label} must be an integer from ${min} to ${max}`);
	return v;
}
function finite(v, label, min = -1e6, max = 1e6) {
	if (typeof v !== "number" || !Number.isFinite(v) || v < min || v > max) fail$2(`${label} is outside ${min}…${max}`);
	return v;
}
function id(v, label = "Id") {
	if (typeof v !== "string" || !/^[a-zA-Z0-9][a-zA-Z0-9_.:-]{0,127}$/.test(v) || [
		"constructor",
		"prototype",
		"__proto__"
	].includes(v)) fail$2(`${label} is invalid`);
	return v;
}
function name(v, fallback) {
	const n = typeof v === "string" && v.trim() ? v.trim() : fallback;
	if (n.length > 240) fail$2("Name is too long");
	return n;
}
function jsonCopy(v) {
	if (v === void 0) return void 0;
	try {
		const s = JSON.stringify(v);
		if (s.length > 64 * 1024 * 1024) fail$2("Metadata is too large");
		return JSON.parse(s);
	} catch (e) {
		if (e instanceof EditorError) throw e;
		fail$2("Value must be serializable");
	}
}
function unique(items, label) {
	const s = /* @__PURE__ */ new Set();
	for (const item of items) {
		id(item.id, label);
		if (s.has(item.id)) fail$2(`Duplicate ${label}: ${item.id}`);
		s.add(item.id);
	}
	return s;
}
function rgba(value) {
	if (value === null || value === void 0) return [
		0,
		0,
		0,
		0
	];
	if (typeof value !== "string") fail$2("Color must be a hex string");
	let s = value.trim().toLowerCase();
	if (/^#[0-9a-f]{3,4}$/.test(s)) s = "#" + [...s.slice(1)].map((c) => c + c).join("");
	if (/^#[0-9a-f]{6}$/.test(s)) s += "ff";
	if (!/^#[0-9a-f]{8}$/.test(s)) fail$2(`Invalid RGBA color: ${String(value).slice(0, 30)}`);
	return [
		1,
		3,
		5,
		7
	].map((i) => parseInt(s.slice(i, i + 2), 16));
}
const hex$2 = (c) => "#" + c.map((v) => Math.round(clamp(v, 0, 255)).toString(16).padStart(2, "0")).join("");
const normalizeColor = (value) => hex$2(rgba(value));
function pixelRGBA(doc, pixel) {
	return rgba(typeof pixel === "number" ? doc.palette[pixel] : pixel);
}
/** Effective palette at a frame. Pass a layer to apply Aseprite transparent-index semantics. */
function getFramePalette(doc, frameId = doc.frames[0]?.id, layerId) {
	const frame = frameFor(doc, frameId);
	let palette = doc.palette;
	for (const current of doc.frames) {
		if (current.palette) palette = current.palette;
		if (current.id === frame.id) break;
	}
	const layer = layerId == null ? null : layerFor(doc, layerId), transparent = doc.metadata?.aseprite?.transparentIndex;
	if (doc.colorMode === "indexed" && layer && !(layer.asepriteFlags & 8) && Number.isInteger(transparent) && transparent < palette.length) {
		palette = [...palette];
		palette[transparent] = "#00000000";
	}
	return [...palette];
}
function colorContext(doc, frameId, layerId) {
	return {
		...doc,
		palette: getFramePalette(doc, frameId, layerId)
	};
}
function nearest(palette, c) {
	let result = 0, d = Infinity;
	for (let i = 0; i < palette.length; i++) {
		const p = rgba(palette[i]);
		const q = (p[0] - c[0]) ** 2 + (p[1] - c[1]) ** 2 + (p[2] - c[2]) ** 2 + 2 * (p[3] - c[3]) ** 2;
		if (q < d) {
			result = i;
			d = q;
		}
	}
	return result;
}
function encodeColor(doc, color) {
	if (color === null || color === void 0) return null;
	if (typeof color === "number") {
		integer$4(color, "Palette index", 0, doc.palette.length - 1);
		return doc.colorMode === "indexed" ? color : encodeColor(doc, doc.palette[color]);
	}
	const c = rgba(color);
	if (c[3] === 0) return null;
	if (doc.colorMode === "indexed") return nearest(doc.palette, c);
	if (doc.colorMode === "grayscale") c[0] = c[1] = c[2] = Math.round(.2126 * c[0] + .7152 * c[1] + .0722 * c[2]);
	return hex$2(c);
}
function validatePixels(image, doc, label, copy = true) {
	integer$4(image.width, `${label} width`, 1, LIMITS.imageEdge);
	integer$4(image.height, `${label} height`, 1, LIMITS.imageEdge);
	const count = image.width * image.height;
	if (count > LIMITS.pixels) fail$2("Image exceeds pixel budget");
	if (image.tilemap) {
		if (!Array.isArray(image.tilemap.tiles) || image.tilemap.tiles.length !== count) fail$2("Tilemap image size mismatch");
		for (const value of image.tilemap.tiles) integer$4(value, "Tile data", 0, 4294967295);
		if (!Array.isArray(image.pixels) || image.pixels.length !== 0 && image.pixels.length !== count) fail$2("Tilemap pixels are invalid");
		return copy ? [...image.pixels] : image.pixels;
	}
	if (!Array.isArray(image.pixels) || image.pixels.length !== count) fail$2(`${label} pixel count does not match dimensions`);
	const convert = (p) => {
		if (p === null) return null;
		if (doc.colorMode === "indexed") return integer$4(p, "Indexed pixel", 0, doc.palette.length - 1);
		if (typeof p !== "string") fail$2("RGBA pixels must be strings or null");
		const c = rgba(p);
		if (doc.colorMode === "grayscale" && (c[0] !== c[1] || c[1] !== c[2])) fail$2("Grayscale pixels must have equal RGB channels");
		return c[3] === 0 ? null : hex$2(c);
	};
	if (copy) return image.pixels.map(convert);
	for (const p of image.pixels) convert(p);
	return image.pixels;
}
function createDocument(options = {}) {
	const width = integer$4(options.width ?? options.size ?? 32, "Width", 1, LIMITS.edge), height = integer$4(options.height ?? options.size ?? width, "Height", 1, LIMITS.edge);
	return normalizeDocument({
		format: "pixelwall-document",
		version: 4,
		id: options.id ?? globalThis.crypto?.randomUUID?.() ?? `document-${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`,
		name: options.name ?? "Untitled Sprite",
		width,
		height,
		colorMode: options.colorMode ?? "rgba",
		colorProfile: "sRGB",
		palette: options.palette ?? DEFAULT_PALETTE,
		layers: [{
			id: "layer-1",
			name: "Layer 1",
			type: "image",
			parentId: null,
			visible: true,
			locked: false,
			opacity: 1,
			blendMode: "normal"
		}],
		frames: [{
			id: "frame-1",
			durationMs: options.durationMs ?? 125,
			cels: {}
		}],
		images: {},
		clips: [{
			id: "clip-1",
			name: "default",
			frameIds: ["frame-1"],
			direction: "forward",
			loop: true
		}],
		slices: [],
		tilesets: [],
		metadata: {}
	});
}
function normalizeDocument(input, options = {}) {
	if (typeof input === "string") try {
		input = JSON.parse(input);
	} catch {
		fail$2("Invalid document JSON");
	}
	if (!record$2(input)) fail$2("Document must be an object");
	if (input.format !== "pixelwall-document" || input.version !== 4) return migrateLegacy(input);
	const width = integer$4(input.width, "Width", 1, LIMITS.edge), height = integer$4(input.height, "Height", 1, LIMITS.edge);
	if (width * height > LIMITS.canvasPixels) fail$2("Canvas exceeds the 4,194,304 pixel budget", "MEMORY_BUDGET");
	if (![
		"rgba",
		"indexed",
		"grayscale"
	].includes(input.colorMode)) fail$2("Unsupported color mode");
	if (input.colorProfile && input.colorProfile !== "sRGB") fail$2("Only the sRGB working profile is supported");
	if (!Array.isArray(input.palette) || input.palette.length < 1 || input.palette.length > LIMITS.palette) fail$2("Palette must have 1–65536 colors");
	const doc = {
		...input,
		id: id(input.id ?? "document-1"),
		name: name(input.name, "Untitled Sprite"),
		width,
		height,
		colorMode: input.colorMode,
		colorProfile: "sRGB",
		palette: input.palette.map(normalizeColor)
	};
	let paletteCapacity = doc.palette.length;
	if (Array.isArray(input.frames)) {
		for (const frame of input.frames) if (frame?.palette !== void 0) {
			if (!Array.isArray(frame.palette) || frame.palette.length < 1 || frame.palette.length > LIMITS.palette) fail$2("Frame palette must have 1–65536 colors");
			for (const color of frame.palette) normalizeColor(color);
			paletteCapacity = Math.max(paletteCapacity, frame.palette.length);
		}
	}
	const pixelDocument = doc.colorMode === "indexed" && paletteCapacity !== doc.palette.length ? {
		...doc,
		palette: { length: paletteCapacity }
	} : doc;
	if (!Array.isArray(input.layers) || input.layers.length < 1 || input.layers.length > LIMITS.layers) fail$2("Document must have 1–256 layers");
	doc.layers = input.layers.map((layer, i) => {
		if (!record$2(layer)) fail$2("Invalid layer");
		const type = layer.type ?? "image";
		if (![
			"image",
			"group",
			"reference",
			"tilemap"
		].includes(type)) fail$2("Unsupported layer type");
		const blendMode = layer.blendMode ?? "normal";
		if (!BLEND_MODES.includes(blendMode)) fail$2(`Unsupported blend mode: ${blendMode}`);
		return {
			...jsonCopy(layer),
			id: id(layer.id),
			name: name(layer.name, `Layer ${i + 1}`),
			type,
			parentId: layer.parentId == null ? null : id(layer.parentId),
			visible: layer.visible !== false,
			locked: !!layer.locked,
			opacity: finite(layer.opacity ?? 1, "Layer opacity", 0, 1),
			blendMode
		};
	});
	const layerIds = unique(doc.layers, "layer id");
	const layerMap = new Map(doc.layers.map((l) => [l.id, l]));
	for (const layer of doc.layers) {
		let current = layer;
		const seen = /* @__PURE__ */ new Set();
		while (current.parentId !== null) {
			if (seen.has(current.id)) fail$2("Layer groups cannot contain cycles");
			seen.add(current.id);
			const p = layerMap.get(current.parentId);
			if (!p || p.type !== "group") fail$2("Layer parent must be an existing group");
			current = p;
		}
	}
	if (!record$2(input.images)) fail$2("Images must be an object");
	if (Object.keys(input.images).length > 131072) fail$2("Too many stored images");
	doc.images = {};
	let pixels = 0;
	const validationKey = doc.colorMode === "indexed" ? `indexed:${paletteCapacity}` : doc.colorMode;
	for (const [key, image] of Object.entries(input.images)) {
		id(key, "Image id");
		if (!record$2(image)) fail$2("Invalid image");
		pixels += image.width * image.height;
		if (pixels > LIMITS.pixels) fail$2("Document exceeds the 16,777,216 stored pixel budget");
		if (options.shareImages) {
			if (validatedImages.get(image) !== validationKey) validatePixels(image, pixelDocument, `Image ${key}`, false);
			doc.images[key] = image;
		} else doc.images[key] = {
			...image,
			...image.tilemap ? { tilemap: jsonCopy(image.tilemap) } : {},
			pixels: validatePixels(image, pixelDocument, `Image ${key}`)
		};
		validatedImages.set(doc.images[key], validationKey);
	}
	if (!Array.isArray(input.frames) || input.frames.length < 1 || input.frames.length > LIMITS.frames) fail$2("Document must have 1–2048 frames");
	let celCount = 0;
	doc.frames = input.frames.map((frame) => {
		if (!record$2(frame) || !record$2(frame.cels)) fail$2("Invalid frame");
		const cels = {};
		for (const [layerId, cel] of Object.entries(frame.cels)) {
			if (!layerIds.has(layerId) || layerMap.get(layerId).type === "group") fail$2("Cel references missing or group layer");
			if (!record$2(cel) || !own$1(doc.images, cel.imageId)) fail$2("Cel references missing image");
			if (++celCount > 131072) fail$2("Too many cels");
			cels[layerId] = {
				...jsonCopy(cel),
				imageId: id(cel.imageId),
				x: integer$4(cel.x ?? 0, "Cel x", -65535, 65535),
				y: integer$4(cel.y ?? 0, "Cel y", -65535, 65535),
				opacity: finite(cel.opacity ?? 1, "Cel opacity", 0, 1),
				...cel.zIndex !== void 0 ? { zIndex: integer$4(cel.zIndex, "Cel z-index", -2147483648, 2147483647) } : {}
			};
		}
		return {
			...jsonCopy({
				...frame,
				cels: void 0
			}),
			...frame.palette ? { palette: frame.palette.map(normalizeColor) } : {},
			id: id(frame.id),
			durationMs: integer$4(frame.durationMs ?? 125, "Frame duration", 1, 65535),
			cels
		};
	});
	const frameIds = unique(doc.frames, "frame id");
	doc.clips = (input.clips ?? []).map((clip, i) => {
		if (!record$2(clip) || !Array.isArray(clip.frameIds) || !clip.frameIds.length) fail$2("Invalid clip");
		for (const f of clip.frameIds) if (!frameIds.has(f)) fail$2("Clip references missing frame");
		if (!DIRECTIONS.includes(clip.direction ?? "forward")) fail$2("Invalid clip direction");
		if (clip.repeat !== void 0) integer$4(clip.repeat, "Tag repeats", 0, 65535);
		if (clip.color !== void 0) normalizeColor(clip.color);
		return {
			...jsonCopy(clip),
			id: id(clip.id),
			name: name(clip.name, `Clip ${i + 1}`),
			direction: clip.direction ?? "forward",
			loop: clip.loop !== false
		};
	});
	unique(doc.clips, "clip id");
	if (doc.clips.length > 512) fail$2("Too many clips");
	doc.slices = jsonCopy(input.slices ?? []);
	if (!Array.isArray(doc.slices) || doc.slices.length > 1024) fail$2("Too many slices");
	for (const slice of doc.slices) {
		id(slice.id);
		const b = slice.bounds;
		if (record$2(b)) {
			integer$4(b.x, "Slice x", 0, width - 1);
			integer$4(b.y, "Slice y", 0, height - 1);
			integer$4(b.width, "Slice width", 1, width - b.x);
			integer$4(b.height, "Slice height", 1, height - b.y);
		} else if (Array.isArray(slice.keys)) for (const key of slice.keys) {
			if (key.frameId && !frameIds.has(key.frameId)) fail$2("Slice key references missing frame");
			integer$4(key.x, "Slice key x", -2147483648, 2147483647);
			integer$4(key.y, "Slice key y", -2147483648, 2147483647);
			integer$4(key.width, "Slice key width", 0, 65535);
			integer$4(key.height, "Slice key height", 0, 65535);
		}
		else fail$2("Invalid slice");
	}
	unique(doc.slices, "slice id");
	doc.tilesets = jsonCopy(input.tilesets ?? []);
	if (!Array.isArray(doc.tilesets) || doc.tilesets.length > 256) fail$2("Too many tilesets");
	unique(doc.tilesets, "Tileset id");
	if (doc.tilesets.reduce((s, t) => s + (t.tiles?.length ?? t.tileCount ?? 0), 0) > 131072) fail$2("Too many tile definitions");
	for (const ts of doc.tilesets) {
		integer$4(ts.tileWidth, "Tile width", 1, LIMITS.edge);
		integer$4(ts.tileHeight, "Tile height", 1, LIMITS.edge);
		if (ts.imageId && !own$1(doc.images, ts.imageId)) fail$2("Tileset atlas image is missing");
		if (!ts.tiles && ts.imageId) {
			const atlas = doc.images[ts.imageId], columns = Math.floor(atlas.width / ts.tileWidth), count = ts.tileCount ?? columns * Math.floor(atlas.height / ts.tileHeight);
			integer$4(count, "Native tile count", 0, 65536);
			if (columns < 1 || count > columns * Math.floor(atlas.height / ts.tileHeight)) fail$2("Native atlas dimensions mismatch");
			ts.tiles = Array.from({ length: count }, (_, i) => ({
				id: `ase-tile-${i}`,
				imageId: ts.imageId,
				asepriteTileId: i,
				sourceRect: {
					x: i % columns * ts.tileWidth,
					y: Math.floor(i / columns) * ts.tileHeight,
					width: ts.tileWidth,
					height: ts.tileHeight
				}
			}));
		}
		if (ts.tiles) {
			if (!Array.isArray(ts.tiles) || ts.tiles.length > 65536) fail$2("Invalid tileset");
			unique(ts.tiles, "tile id");
			for (const t of ts.tiles) {
				if (!own$1(doc.images, t.imageId)) fail$2("Tile image missing");
				if (t.sourceRect) {
					const image = doc.images[t.imageId], r = t.sourceRect;
					integer$4(r.x, "Tile source x", 0, image.width - 1);
					integer$4(r.y, "Tile source y", 0, image.height - 1);
					integer$4(r.width, "Tile source width", 1, image.width - r.x);
					integer$4(r.height, "Tile source height", 1, image.height - r.y);
				}
			}
		}
	}
	for (const layer of doc.layers) {
		if (layer.tilesetId && !doc.tilesets.some((t) => t.id === layer.tilesetId)) fail$2("Layer tileset missing");
		for (const [fid, map] of Object.entries(layer.tilemaps ?? {})) {
			if (!frameIds.has(fid)) fail$2("Tilemap frame missing");
			validateTilemap(doc, map);
		}
	}
	doc.metadata = jsonCopy(input.metadata ?? {});
	if (!record$2(doc.metadata)) fail$2("Metadata must be an object");
	return doc;
}
function decodeLegacyPixels(data, bpi, colors, total) {
	if (typeof data !== "string" || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(data)) fail$2("Invalid legacy pixel encoding");
	if (bpi !== 1 && bpi !== 2) fail$2("Invalid legacy color index size");
	let bytes;
	if (typeof atob === "function") bytes = Uint8Array.from(atob(data), (c) => c.charCodeAt(0));
	else if (globalThis.Buffer) bytes = new Uint8Array(globalThis.Buffer.from(data, "base64"));
	else fail$2("Base64 decoding unavailable");
	if (bytes.length !== total * bpi) fail$2("Legacy pixel size mismatch");
	return Array.from({ length: total }, (_, i) => {
		const n = bytes[i * bpi] + (bpi === 2 ? bytes[i * bpi + 1] * 256 : 0);
		if (n > colors.length) fail$2("Legacy palette index missing");
		return n ? normalizeColor(colors[n - 1]) : null;
	});
}
function migrateLegacy(input) {
	if (typeof input === "string") try {
		input = JSON.parse(input);
	} catch {
		fail$2("Invalid document JSON");
	}
	const p = input?.project ?? input;
	if (!record$2(p) || !Array.isArray(p.frames) || !p.frames.length) fail$2("Unsupported document");
	if (p.version !== void 0 && ![
		1,
		2,
		3
	].includes(p.version)) fail$2("Unsupported document version");
	const width = integer$4(p.size ?? p.width, "Legacy width", 1, LIMITS.edge), height = integer$4(p.height ?? width, "Legacy height", 1, LIMITS.edge), total = width * height;
	if (total > LIMITS.canvasPixels) fail$2("Canvas exceeds the 4,194,304 pixel budget", "MEMORY_BUDGET");
	const doc = createDocument({
		width,
		height,
		name: p.name,
		palette: p.palette?.length ? p.palette : DEFAULT_PALETTE
	});
	doc.layers = (p.layers?.length ? p.layers : [{
		id: 1,
		name: "Layer 1"
	}]).map((l, i) => ({
		...l,
		id: `layer-${l.id ?? i + 1}`,
		name: l.name ?? `Layer ${i + 1}`,
		type: "image",
		parentId: null,
		visible: l.visible !== false,
		locked: !!l.locked,
		opacity: (l.opacity ?? 100) / 100,
		blendMode: "normal"
	}));
	doc.images = {};
	const used = /* @__PURE__ */ new Set();
	doc.frames = p.frames.map((f, i) => {
		let fid = `frame-${f.id ?? i + 1}`;
		if (used.has(fid)) fid = `frame-migrated-${i}`;
		used.add(fid);
		const cels = {};
		const source = Array.isArray(f.cels) ? f.cels : [{
			layerId: p.layers?.[0]?.id ?? 1,
			pixels: f.pixels,
			data: f.data
		}];
		for (const [j, c] of source.entries()) {
			let pix;
			if (Array.isArray(c.pixels)) pix = c.pixels.map((v) => v == null ? null : normalizeColor(v));
			else if (c.data !== void 0) pix = decodeLegacyPixels(c.data, c.bytesPerIndex ?? f.bytesPerIndex ?? p.bytesPerIndex, p.colors ?? [], total);
			else continue;
			if (pix.length !== total) fail$2("Legacy pixel count mismatch");
			const imageId = `image-migrated-${i}-${j}`;
			doc.images[imageId] = {
				width,
				height,
				pixels: pix
			};
			cels[`layer-${c.layerId ?? 1}`] = {
				imageId,
				x: 0,
				y: 0,
				opacity: 1
			};
		}
		return {
			id: fid,
			durationMs: f.durationMs ?? 125,
			cels
		};
	});
	const oldFrameMap = new Map(p.frames.map((f, i) => [String(f.id ?? i + 1), doc.frames[i].id]));
	doc.clips = p.clips?.length ? p.clips.map((c, i) => ({
		id: `clip-${c.id ?? i + 1}`,
		name: c.name ?? `Clip ${i + 1}`,
		frameIds: c.frameIds.map((fid) => oldFrameMap.get(String(fid))),
		direction: c.direction ?? "forward",
		loop: c.loop !== false
	})) : [{
		id: "clip-1",
		name: "default",
		frameIds: doc.frames.map((f) => f.id),
		direction: "forward",
		loop: true
	}];
	doc.slices = (p.slices ?? []).map((s, i) => ({
		...s,
		id: `slice-${s.id ?? i + 1}`
	}));
	doc.metadata = {
		migratedFrom: p.version ?? "runtime",
		legacy: {
			pivot: jsonCopy(p.pivot),
			tile: jsonCopy(p.tile),
			tilemap: jsonCopy(p.tilemap),
			projector: jsonCopy(p.projector),
			editor: jsonCopy(input.editor ?? p.editor)
		}
	};
	return normalizeDocument(doc);
}
function validateTilemap(doc, map) {
	const ts = doc.tilesets.find((t) => t.id === map.tilesetId);
	if (!ts) fail$2("Tilemap tileset missing");
	integer$4(map.columns, "Tilemap columns", 1, 2048);
	integer$4(map.rows, "Tilemap rows", 1, 2048);
	integer$4(map.x ?? 0, "Tilemap x", -65535, 65535);
	integer$4(map.y ?? 0, "Tilemap y", -65535, 65535);
	finite(map.opacity ?? 1, "Tilemap opacity", 0, 1);
	if (map.columns * map.rows > 1048576 || !Array.isArray(map.cells) || map.cells.length !== map.columns * map.rows) fail$2("Invalid tilemap dimensions");
	const ids = new Set((ts.tiles ?? []).map((t) => t.id));
	for (const c of map.cells) if (c !== null && (!record$2(c) || !ids.has(c.tileId) || ![
		0,
		90,
		180,
		270
	].includes(c.rotate ?? 0))) fail$2("Tilemap tile is invalid");
}
function rgbHsl(rgb) {
	const r = rgb[0] / 255, g = rgb[1] / 255, b = rgb[2] / 255, max = Math.max(r, g, b), min = Math.min(r, g, b), d = max - min, l = (max + min) / 2;
	let h = 0, s = 0;
	if (d) {
		s = d / (1 - Math.abs(2 * l - 1));
		h = max === r ? (g - b) / d % 6 : max === g ? (b - r) / d + 2 : (r - g) / d + 4;
		h = (h / 6 % 1 + 1) % 1;
	}
	return [
		h,
		s,
		l
	];
}
function hslRgb([h, s, l]) {
	h = (h % 1 + 1) % 1;
	s = clamp(s);
	l = clamp(l);
	const a = s * Math.min(l, 1 - l);
	return [
		0,
		8,
		4
	].map((n) => {
		const k = (n + h * 12) % 12;
		return 255 * (l - a * Math.max(-1, Math.min(k - 3, 9 - k, 1)));
	});
}
function blendChannel(b, s, mode) {
	switch (mode) {
		case "multiply": return b * s;
		case "screen": return b + s - b * s;
		case "overlay": return b < .5 ? 2 * b * s : 1 - 2 * (1 - b) * (1 - s);
		case "darken": return Math.min(b, s);
		case "lighten": return Math.max(b, s);
		case "color-dodge": return s >= 1 ? 1 : Math.min(1, b / (1 - s));
		case "color-burn": return s <= 0 ? 0 : 1 - Math.min(1, (1 - b) / s);
		case "hard-light": return s < .5 ? 2 * b * s : 1 - 2 * (1 - b) * (1 - s);
		case "soft-light": return s <= .5 ? b - (1 - 2 * s) * b * (1 - b) : b + (2 * s - 1) * ((b <= .25 ? ((16 * b - 12) * b + 4) * b : Math.sqrt(b)) - b);
		case "difference": return Math.abs(b - s);
		case "exclusion": return b + s - 2 * b * s;
		case "addition": return Math.min(1, b + s);
		case "subtract": return Math.max(0, b - s);
		case "divide": return s === 0 ? 1 : Math.min(1, b / s);
		default: return s;
	}
}
function colorMultiplyAdd(a, b, c) {
	const split = 134217729, as = split * a, bs = split * b, ah = as - (as - a), al = a - ah, bh = bs - (bs - b), bl = b - bh, product = a * b, error = ah * bh - product + ah * bl + al * bh + al * bl, sum = product + c, z = sum - product;
	return sum + (error + (product - (sum - z) + (c - z)));
}
const luminosity = (c) => colorMultiplyAdd(.11, c[2], .3 * c[0] + .59 * c[1]), saturation = (c) => Math.max(...c) - Math.min(...c);
function setLuminosity(c, l) {
	const delta = l - luminosity(c);
	let result = c.map((v) => v + delta);
	const mid = luminosity(result), min = Math.min(...result), max = Math.max(...result);
	if (min < 0) result = result.map((v) => mid + (v - mid) * mid / (mid - min));
	if (max > 1) result = result.map((v) => mid + (v - mid) * (1 - mid) / (max - mid));
	return result;
}
function setSaturation(c, s) {
	const order = [
		0,
		1,
		2
	].sort((a, b) => c[a] - c[b]), result = [
		0,
		0,
		0
	], [lo, mid, hi] = order;
	if (c[hi] > c[lo]) {
		result[mid] = (c[mid] - c[lo]) * s / (c[hi] - c[lo]);
		result[hi] = s;
	}
	return result;
}
function coverageProduct(a, b) {
	const value = a * b + 128;
	return value + (value >> 8) >> 8;
}
function blendAt(out, index, source, opacity = 1, mode = "normal") {
	const sourceAlpha = coverageProduct(source[3], Math.round(opacity * 255));
	if (sourceAlpha <= 0) return;
	const backdropAlpha = out[index + 3], alpha = sourceAlpha + backdropAlpha - coverageProduct(sourceAlpha, backdropAlpha);
	if (mode === "normal" || !backdropAlpha) {
		for (let k = 0; k < 3; k++) out[index + k] = backdropAlpha ? out[index + k] + Math.trunc((source[k] - out[index + k]) * sourceAlpha / alpha) : source[k];
		out[index + 3] = alpha;
		return;
	}
	const backdrop = Array.from(out.subarray(index, index + 3)), foreground = Array.from(source).slice(0, 3);
	const over = (color) => backdrop.map((value, k) => value + Math.trunc((color[k] - value) * sourceAlpha / alpha));
	const normal = backdropAlpha ? over(foreground) : foreground;
	let result = normal;
	if (mode !== "normal" && backdropAlpha) {
		const b = backdrop.map((v) => v / 255), s = foreground.map((v) => v / 255);
		let color;
		if ([
			"hue",
			"saturation",
			"color",
			"luminosity"
		].includes(mode)) color = mode === "hue" ? setLuminosity(setSaturation(s, saturation(b)), luminosity(b)) : mode === "saturation" ? setLuminosity(setSaturation(b, saturation(s)), luminosity(b)) : mode === "color" ? setLuminosity(s, luminosity(b)) : setLuminosity(b, luminosity(s));
		else if (mode === "exclusion") color = backdrop.map((v, k) => (v + foreground[k] - 2 * coverageProduct(v, foreground[k])) / 255);
		else if (mode === "color-dodge") color = backdrop.map((v, k) => v === 0 ? 0 : foreground[k] === 255 ? 1 : Math.min(255, Math.floor((v * 255 + (255 - foreground[k]) / 2) / (255 - foreground[k]))) / 255);
		else if (mode === "color-burn") color = backdrop.map((v, k) => v === 255 ? 1 : foreground[k] === 0 ? 0 : 1 - Math.min(255, Math.floor(((255 - v) * 255 + foreground[k] / 2) / foreground[k])) / 255);
		else if (mode === "divide") color = backdrop.map((v, k) => v === 0 ? 0 : foreground[k] === 0 ? 1 : Math.min(255, Math.floor((v * 255 + foreground[k] / 2) / foreground[k])) / 255);
		else color = b.map((value, k) => blendChannel(value, s[k], mode));
		const blended = over(color.map((v) => [
			"hue",
			"saturation",
			"color",
			"luminosity"
		].includes(mode) ? Math.floor(clamp(v) * 255) : Math.round(clamp(v) * 255))), intersection = coverageProduct(backdropAlpha, sourceAlpha);
		result = normal.map((value, k) => {
			const mixed = value + coverageProduct(blended[k] - value, backdropAlpha);
			return mixed + coverageProduct(blended[k] - mixed, intersection);
		});
	}
	for (let k = 0; k < 3; k++) out[index + k] = result[k];
	out[index + 3] = alpha;
}
function renderImage(doc, out, image, cel, opacity, mode) {
	if (!image || image.tilemap) return;
	if (cel.preciseBounds?.flags & 1) {
		const b = cel.preciseBounds;
		if (![
			b.x,
			b.y,
			b.width,
			b.height
		].every(Number.isFinite) || b.width <= 0 || b.height <= 0) return;
		for (let y = Math.max(0, Math.ceil(b.y - .5)); y < Math.min(doc.height, Math.ceil(b.y + b.height - .5)); y++) for (let x = Math.max(0, Math.ceil(b.x - .5)); x < Math.min(doc.width, Math.ceil(b.x + b.width - .5)); x++) {
			const ix = clamp(Math.floor((x + .5 - b.x) / b.width * image.width), 0, image.width - 1), iy = clamp(Math.floor((y + .5 - b.y) / b.height * image.height), 0, image.height - 1), p = image.pixels[iy * image.width + ix];
			if (p !== null) blendAt(out, (y * doc.width + x) * 4, pixelRGBA(doc, p), opacity, mode);
		}
		return;
	}
	const x0 = Math.max(0, cel.x), y0 = Math.max(0, cel.y), x1 = Math.min(doc.width, cel.x + image.width), y1 = Math.min(doc.height, cel.y + image.height);
	for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x++) {
		const p = image.pixels[(y - cel.y) * image.width + x - cel.x];
		if (p !== null) blendAt(out, (y * doc.width + x) * 4, pixelRGBA(doc, p), opacity, mode);
	}
}
function renderTile(doc, out, image, sx, sy, sw, sh, dx, dy, dw, dh, flipX, flipY, rotate, opacity, mode) {
	let fx = !!flipX, fy = !!flipY, diagonal = false;
	if (rotate === 90) {
		diagonal = true;
		[fx, fy] = [!fy, fx];
	} else if (rotate === 180) {
		fx = !fx;
		fy = !fy;
	} else if (rotate === 270) {
		diagonal = true;
		[fx, fy] = [fy, !fx];
	}
	for (let y = Math.max(0, dy); y < Math.min(doc.height, dy + dh); y++) for (let x = Math.max(0, dx); x < Math.min(doc.width, dx + dw); x++) {
		let u = fx ? dw - 1 - (x - dx) : x - dx, v = fy ? dh - 1 - (y - dy) : y - dy;
		if (diagonal) [u, v] = [v, u];
		if (u < 0 || v < 0 || u >= dw || v >= dh) {
			out.fill(0, (y * doc.width + x) * 4, (y * doc.width + x) * 4 + 4);
			continue;
		}
		const ix = sx + Math.min(sw - 1, Math.floor((u + .5) * sw / dw)), iy = sy + Math.min(sh - 1, Math.floor((v + .5) * sh / dh));
		if (ix < 0 || iy < 0 || ix >= image.width || iy >= image.height) continue;
		if (image[TILE_BACKDROP_CLEAR]?.[iy * image.width + ix]) {
			out.fill(0, (y * doc.width + x) * 4, (y * doc.width + x) * 4 + 4);
			continue;
		}
		const p = image.pixels[iy * image.width + ix];
		if (p != null) blendAt(out, (y * doc.width + x) * 4, pixelRGBA(doc, p), opacity, mode);
	}
}
function renderTilemap(doc, out, layer, frame, opacity, mode) {
	const map = layer.tilemaps?.[frame.id];
	if (map) {
		const ts = doc.tilesets.find((t) => t.id === map.tilesetId);
		if (!ts) return;
		const tiles = new Map((ts.tiles ?? []).map((t) => [t.id, t]));
		for (let i = 0; i < map.cells.length; i++) {
			const cell = map.cells[i];
			if (!cell) continue;
			const tile = tiles.get(cell.tileId), image = doc.images[tile?.imageId], rect = tile?.sourceRect;
			if (image) renderTile(doc, out, image, rect?.x ?? 0, rect?.y ?? 0, rect?.width ?? image.width, rect?.height ?? image.height, (map.x ?? 0) + i % map.columns * ts.tileWidth, (map.y ?? 0) + Math.floor(i / map.columns) * ts.tileHeight, ts.tileWidth, ts.tileHeight, cell.flipX, cell.flipY, cell.rotate ?? 0, opacity * (map.opacity ?? 1), mode);
		}
		return;
	}
	const cel = frame.cels[layer.id], image = doc.images[cel?.imageId], tilemap = image?.tilemap, ts = doc.tilesets.find((t) => t.id === layer.tilesetId), atlas = doc.images[ts?.imageId];
	if (!tilemap || !ts || !atlas) return;
	const tw = ts.tileWidth, th = ts.tileHeight, cols = Math.floor(atlas.width / tw);
	if (cols < 1) return;
	for (let i = 0; i < tilemap.tiles.length; i++) {
		const value = tilemap.tiles[i] >>> 0, index = (value & (tilemap.idMask ?? 536870911)) >>> 0;
		if (ts.flags & 4 ? index === 0 : value === 4294967295) continue;
		if (index >= (ts.tileCount ?? Math.floor(atlas.height / th) * cols)) continue;
		const diagonal = !!(value & (tilemap.diagonalFlipMask ?? 536870912)), flipX = !!(value & (tilemap.xFlipMask ?? 2147483648)), flipY = !!(value & (tilemap.yFlipMask ?? 1073741824));
		renderTile(doc, out, atlas, index % cols * tw, Math.floor(index / cols) * th, tw, th, cel.x + i % image.width * tw, cel.y + Math.floor(i / image.width) * th, tw, th, diagonal ? flipY : flipX, diagonal ? !flipX : flipY, diagonal ? 90 : 0, opacity * cel.opacity, mode);
	}
}
/** Layers are ordered bottom-to-top. Groups composite their children in isolation. */
function renderFrame(doc, frameId = doc.frames[0]?.id) {
	if (!Number.isSafeInteger(doc.width) || !Number.isSafeInteger(doc.height) || doc.width < 1 || doc.height < 1 || doc.width > LIMITS.edge || doc.height > LIMITS.edge || doc.width * doc.height > LIMITS.canvasPixels) fail$2("Invalid canvas dimensions or pixel budget", "MEMORY_BUDGET");
	const frame = doc.frames.find((f) => f.id === frameId);
	if (!frame) fail$2("Frame not found");
	let palette = doc.palette;
	for (const f of doc.frames) {
		if (f.palette) palette = f.palette;
		if (f.id === frame.id) break;
	}
	const working = palette === doc.palette ? doc : {
		...doc,
		palette
	};
	const children = /* @__PURE__ */ new Map(), positions = new Map(doc.layers.map((l, i) => [l.id, i]));
	for (const l of doc.layers) {
		const key = l.parentId ?? null;
		if (!children.has(key)) children.set(key, []);
		children.get(key).push(l);
	}
	for (const list of children.values()) list.sort((a, b) => {
		const za = frame.cels[a.id]?.zIndex ?? 0, zb = frame.cels[b.id]?.zIndex ?? 0;
		return positions.get(a.id) + za - positions.get(b.id) - zb || za - zb || positions.get(a.id) - positions.get(b.id);
	});
	function renderGroup(parent, depth) {
		if (depth > 24) fail$2("Layer nesting exceeds rendering limit");
		const out = new Uint8ClampedArray(doc.width * doc.height * 4);
		for (const layer of children.get(parent) ?? []) {
			if (!layer.visible || layer.opacity === 0 && layer.type !== "tilemap") continue;
			let display = working;
			const transparent = doc.metadata?.aseprite?.transparentIndex;
			if (doc.colorMode === "indexed" && Number.isInteger(transparent) && !(layer.asepriteFlags & 8)) {
				display = {
					...working,
					palette: [...working.palette]
				};
				if (transparent < display.palette.length) display.palette[transparent] = "#00000000";
			}
			if (layer.type === "group") {
				const sub = renderGroup(layer.id, depth + 1);
				for (let i = 0; i < sub.length; i += 4) if (sub[i + 3]) blendAt(out, i, sub.subarray(i, i + 4), layer.opacity, layer.blendMode);
			} else if (layer.type === "tilemap") renderTilemap(display, out, layer, frame, layer.opacity, layer.blendMode);
			else {
				const cel = frame.cels[layer.id];
				if (cel) renderImage(display, out, doc.images[cel.imageId], cel, layer.opacity * cel.opacity, layer.blendMode);
			}
		}
		return out;
	}
	return renderGroup(null, 0);
}
function shallowDocument(doc) {
	return {
		...doc,
		palette: [...doc.palette],
		layers: doc.layers.map((l) => ({ ...l })),
		frames: doc.frames.map((f) => ({
			...f,
			cels: Object.fromEntries(Object.entries(f.cels).map(([k, c]) => [k, { ...c }]))
		})),
		images: { ...doc.images },
		clips: doc.clips.map((c) => ({
			...c,
			frameIds: [...c.frameIds]
		})),
		slices: doc.slices.map((s) => ({
			...s,
			...s.bounds ? { bounds: { ...s.bounds } } : {}
		})),
		tilesets: doc.tilesets.map((t) => ({
			...t,
			...t.tiles ? { tiles: t.tiles.map((a) => ({ ...a })) } : {}
		})),
		metadata: { ...doc.metadata }
	};
}
function fresh(doc, prefix) {
	const keys = new Set([
		doc.id,
		...doc.layers.map((l) => l.id),
		...doc.frames.map((f) => f.id),
		...Object.keys(doc.images),
		...doc.clips.map((c) => c.id),
		...doc.slices.map((s) => s.id),
		...doc.tilesets.map((t) => t.id)
	]);
	let n = 1;
	while (keys.has(`${prefix}-${n}`)) n++;
	return `${prefix}-${n}`;
}
function frameFor(doc, fid) {
	const f = doc.frames.find((f) => f.id === (fid ?? doc.frames[0].id));
	if (!f) fail$2("Frame not found");
	return f;
}
function layerFor(doc, lid, write = false) {
	const l = doc.layers.find((l) => l.id === (lid ?? doc.layers.find((l) => l.type === "image")?.id));
	if (!l) fail$2("Layer not found");
	if (write) {
		let a = l;
		while (a) {
			if (a.locked) fail$2("Layer is locked", "LOCKED_LAYER");
			a = a.parentId ? doc.layers.find((l) => l.id === a.parentId) : null;
		}
	}
	return l;
}
function targetFrames(doc, c) {
	const ids = c.frameIds ?? (c.frameId ? [c.frameId] : [doc.frames[0].id]);
	if (!Array.isArray(ids) || !ids.length || new Set(ids).size !== ids.length) fail$2("Frame range must be a nonempty list of unique ids");
	return ids.map((fid) => frameFor(doc, fid));
}
function reserve(doc, count, replacing) {
	if (Object.values(doc.images).reduce((s, i) => s + i.width * i.height, 0) - (replacing ? doc.images[replacing].width * doc.images[replacing].height : 0) + count > LIMITS.pixels) fail$2("Document exceeds the stored pixel budget", "MEMORY_BUDGET");
}
function writable(doc, c, changed) {
	const layer = layerFor(doc, c.layerId, true);
	if (!["image", "reference"].includes(layer.type)) fail$2("Drawing requires an image or reference layer");
	const frame = frameFor(doc, c.frameId);
	let cel = frame.cels[layer.id];
	if (!cel) {
		reserve(doc, doc.width * doc.height);
		const imageId = fresh(doc, "image");
		doc.images[imageId] = {
			width: doc.width,
			height: doc.height,
			pixels: Array(doc.width * doc.height).fill(null)
		};
		cel = frame.cels[layer.id] = {
			imageId,
			x: 0,
			y: 0,
			opacity: 1
		};
		changed.add(imageId);
	}
	let image = doc.images[cel.imageId];
	if (image.tilemap) fail$2("Raster drawing cannot edit tile indices");
	if (cel.preciseBounds?.flags & 1) {
		const b = cel.preciseBounds, x = integer$4(Math.floor(b.x), "Rasterized cel x", -65535, 65535), y = integer$4(Math.floor(b.y), "Rasterized cel y", -65535, 65535), width = integer$4(Math.ceil(b.x + b.width) - x, "Rasterized width", 1, LIMITS.imageEdge), height = integer$4(Math.ceil(b.y + b.height) - y, "Rasterized height", 1, LIMITS.imageEdge), source = image, imageId = fresh(doc, "image");
		delete frame.cels[layer.id];
		gcImages(doc);
		reserve(doc, width * height);
		const pixels = Array(width * height).fill(null);
		for (let py = 0; py < height; py++) for (let px = 0; px < width; px++) {
			const wx = x + px + .5, wy = y + py + .5;
			if (wx < b.x || wy < b.y || wx >= b.x + b.width || wy >= b.y + b.height) continue;
			const ix = clamp(Math.floor((wx - b.x) / b.width * source.width), 0, source.width - 1), iy = clamp(Math.floor((wy - b.y) / b.height * source.height), 0, source.height - 1);
			pixels[py * width + px] = source.pixels[iy * source.width + ix];
		}
		image = doc.images[imageId] = {
			width,
			height,
			pixels
		};
		cel = frame.cels[layer.id] = {
			...cel,
			imageId,
			x,
			y,
			preciseBounds: {
				...b,
				flags: b.flags & -2
			}
		};
		changed.add(imageId);
	}
	if (!changed.has(cel.imageId)) {
		image = doc.images[cel.imageId] = {
			...image,
			pixels: [...image.pixels]
		};
		changed.add(cel.imageId);
	}
	const x0 = Math.min(cel.x, 0), y0 = Math.min(cel.y, 0), w = Math.max(cel.x + image.width, doc.width) - x0, h = Math.max(cel.y + image.height, doc.height) - y0;
	if (w !== image.width || h !== image.height) {
		if (w > LIMITS.imageEdge || h > LIMITS.imageEdge) fail$2("Image expansion exceeds bounds");
		reserve(doc, w * h, cel.imageId);
		const pixels = Array(w * h).fill(null), ox = cel.x - x0, oy = cel.y - y0;
		for (let y = 0; y < image.height; y++) for (let x = 0; x < image.width; x++) pixels[(y + oy) * w + x + ox] = image.pixels[y * image.width + x];
		image = doc.images[cel.imageId] = {
			...image,
			width: w,
			height: h,
			pixels
		};
		for (const f of doc.frames) for (const linked of Object.values(f.cels)) if (linked.imageId === cel.imageId) {
			linked.x -= ox;
			linked.y -= oy;
		}
	}
	return {
		frame,
		layer,
		cel,
		image
	};
}
function selectionMask(doc, mask) {
	if (mask === void 0 || mask === null) return null;
	if (!Array.isArray(mask) && !(mask instanceof Uint8Array) || mask.length !== doc.width * doc.height) fail$2("Selection must match canvas dimensions");
	for (const x of mask) if (x !== 0 && x !== 1 && x !== false && x !== true) fail$2("Selection values must be 0 or 1");
	return mask;
}
function point(p, label = "Point") {
	if (!record$2(p)) fail$2(`${label} is missing`);
	return {
		x: Math.round(finite(p.x, `${label} x`, -65535, 65535)),
		y: Math.round(finite(p.y, `${label} y`, -65535, 65535)),
		...p.pressure === void 0 ? {} : { pressure: finite(p.pressure, "Pressure", 0, 1) }
	};
}
function points(ps, min = 1, max = 65536) {
	if (!Array.isArray(ps) || ps.length < min || ps.length > max) fail$2(`Expected ${min}–${max} points`);
	return ps.map((p) => point(p));
}
function context(doc, c, changed) {
	const t = writable(doc, c, changed), mask = selectionMask(doc, c.selection), wrap = c.wrap === true ? "both" : c.wrap ?? "none";
	if (![
		"none",
		"x",
		"y",
		"both"
	].includes(wrap)) fail$2("Invalid drawing wrap mode");
	let ops = 0;
	return {
		...t,
		doc: colorContext(doc, t.frame.id, t.layer.id),
		command: c,
		mask,
		put(x, y, color) {
			if (++ops > LIMITS.operations) fail$2("Drawing operation exceeds work budget");
			x = Math.round(x);
			y = Math.round(y);
			if (wrap === "x" || wrap === "both") x = (x % doc.width + doc.width) % doc.width;
			if (wrap === "y" || wrap === "both") y = (y % doc.height + doc.height) % doc.height;
			if (x < 0 || y < 0 || x >= doc.width || y >= doc.height || mask && !mask[y * doc.width + x]) return;
			const ix = x - t.cel.x, iy = y - t.cel.y;
			if (ix >= 0 && iy >= 0 && ix < t.image.width && iy < t.image.height) t.image.pixels[iy * t.image.width + ix] = color;
		},
		get(x, y) {
			if (wrap === "x" || wrap === "both") x = (x % doc.width + doc.width) % doc.width;
			if (wrap === "y" || wrap === "both") y = (y % doc.height + doc.height) % doc.height;
			x = Math.round(x) - t.cel.x;
			y = Math.round(y) - t.cel.y;
			return x < 0 || y < 0 || x >= t.image.width || y >= t.image.height ? null : t.image.pixels[y * t.image.width + x];
		}
	};
}
function clippedLine(a, b, width, height, pad = 0) {
	let lo = 0, hi = 1;
	const dx = b.x - a.x, dy = b.y - a.y;
	for (const [p, q] of [
		[-dx, a.x + pad],
		[dx, width - 1 + pad - a.x],
		[-dy, a.y + pad],
		[dy, height - 1 + pad - a.y]
	]) if (p === 0) {
		if (q < 0) return null;
	} else {
		const r = q / p;
		if (p < 0) lo = Math.max(lo, r);
		else hi = Math.min(hi, r);
		if (lo > hi) return null;
	}
	return [{
		x: Math.round(a.x + lo * dx),
		y: Math.round(a.y + lo * dy)
	}, {
		x: Math.round(a.x + hi * dx),
		y: Math.round(a.y + hi * dy)
	}];
}
function linePoints(a, b, width, height, pad = 0) {
	const clip = clippedLine(a, b, width, height, pad);
	if (!clip) return [];
	let [{ x: x0, y: y0 }, { x: x1, y: y1 }] = clip;
	const out = [], dx = Math.abs(x1 - x0), sx = x0 < x1 ? 1 : -1, dy = -Math.abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
	let e = dx + dy;
	for (;;) {
		out.push({
			x: x0,
			y: y0
		});
		if (x0 === x1 && y0 === y1) break;
		const e2 = 2 * e;
		if (e2 >= dy) {
			e += dy;
			x0 += sx;
		}
		if (e2 <= dx) {
			e += dx;
			y0 += sy;
		}
	}
	return out;
}
function brush(c, doc) {
	const size = integer$4(c.size ?? 1, "Brush size", 1, 256);
	let mask = null;
	if (c.mask) {
		const m = c.mask;
		integer$4(m.width, "Mask width", 1, 256);
		integer$4(m.height, "Mask height", 1, 256);
		if (!Array.isArray(m.pixels) || m.pixels.length !== m.width * m.height) fail$2("Brush mask dimensions mismatch");
		if (m.colors && (!Array.isArray(m.colors) || m.colors.length !== m.pixels.length)) fail$2("Brush colors dimensions mismatch");
		mask = {
			...m,
			colors: m.colors?.map((p) => encodeColor(doc, p))
		};
	}
	const symmetry = c.symmetry ?? "none";
	if (![
		"none",
		"x",
		"y",
		"both"
	].includes(symmetry)) fail$2("Invalid symmetry");
	if (![
		"paint",
		"lighten",
		"darken",
		"shading"
	].includes(c.ink ?? "paint")) fail$2("Unsupported ink");
	let shading = null;
	if (c.ink === "shading") {
		const entries = c.ramp ?? doc.palette.map((_color, index) => index);
		if (!Array.isArray(entries) || !entries.length || entries.length > LIMITS.palette) fail$2("Shading ramp must contain palette indices or colors");
		const ramp = entries.map((color) => encodeColor(doc, color)), step = integer$4(c.shadeStep ?? -1, "Shading step", -65535, 65535);
		shading = /* @__PURE__ */ new Map();
		ramp.forEach((color, index) => {
			if (!shading.has(color)) shading.set(color, ramp[clamp(index + step, 0, ramp.length - 1)]);
		});
	}
	return {
		size,
		mask,
		symmetry,
		shading,
		round: c.brush === "circle",
		color: c.erase ? null : encodeColor(doc, c.color === void 0 ? doc.palette[0] : c.color)
	};
}
function stamp(ctx, p, b) {
	if (p.pressure === 0) return;
	const pressure = p.pressure ?? 1, size = Math.max(1, Math.round(b.size * pressure)), w = b.mask ? b.mask.width : size, h = b.mask ? b.mask.height : size;
	const xs = b.symmetry === "x" || b.symmetry === "both" ? [p.x, ctx.doc.width - 1 - p.x] : [p.x], ys = b.symmetry === "y" || b.symmetry === "both" ? [p.y, ctx.doc.height - 1 - p.y] : [p.y];
	for (const cx of new Set(xs)) for (const cy of new Set(ys)) for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
		if (b.mask && !b.mask.pixels[y * w + x]) continue;
		if (!b.mask && b.round && (x - (w - 1) / 2) ** 2 + (y - (h - 1) / 2) ** 2 > (size / 2) ** 2) continue;
		const dx = cx + x - Math.floor(w / 2), dy = cy + y - Math.floor(h / 2);
		let color = b.mask?.colors ? b.mask.colors[y * w + x] : b.color;
		if (b.shading) {
			const old = ctx.get(dx, dy);
			if (!pixelRGBA(ctx.doc, old)[3] || !b.shading.has(old)) continue;
			const wrap = ctx.command.wrap === true ? "both" : ctx.command.wrap, px = wrap === "x" || wrap === "both" ? (dx % ctx.doc.width + ctx.doc.width) % ctx.doc.width : dx;
			const key = (wrap === "y" || wrap === "both" ? (dy % ctx.doc.height + ctx.doc.height) % ctx.doc.height : dy) * ctx.doc.width + px;
			ctx.shaded ??= /* @__PURE__ */ new Set();
			if (ctx.shaded.has(key)) continue;
			ctx.shaded.add(key);
			color = b.shading.get(old);
		} else if (ctx.command.ink === "lighten" || ctx.command.ink === "darken") {
			const old = pixelRGBA(ctx.doc, ctx.get(dx, dy)), delta = 255 * finite(ctx.command.amount ?? .12, "Shade amount", 0, 1) * (ctx.command.ink === "lighten" ? 1 : -1);
			color = old[3] ? encodeColor(ctx.doc, hex$2([
				old[0] + delta,
				old[1] + delta,
				old[2] + delta,
				old[3]
			])) : null;
		}
		ctx.put(dx, dy, color);
	}
}
function drawStroke(ctx, ps, c) {
	if (c.pressure === false) ps = ps.map((p) => ({
		...p,
		pressure: 1
	}));
	const b = brush(c, ctx.doc), path = [];
	for (let i = 0; i < ps.length; i++) {
		if (i === 0) {
			path.push(ps[i]);
			continue;
		}
		const segment = c.wrap && c.wrap !== "none" ? linePoints({
			x: ps[i - 1].x + 65535,
			y: ps[i - 1].y + 65535
		}, {
			x: ps[i].x + 65535,
			y: ps[i].y + 65535
		}, 131071, 131071).map((p) => ({
			x: p.x - 65535,
			y: p.y - 65535
		})) : linePoints(ps[i - 1], ps[i], ctx.doc.width, ctx.doc.height, Math.max(b.size, b.mask?.width ?? 0, b.mask?.height ?? 0));
		for (let j = 0; j < segment.length; j++) {
			if (path.at(-1)?.x === segment[j].x && path.at(-1)?.y === segment[j].y) continue;
			path.push({
				...segment[j],
				pressure: (ps[i - 1].pressure ?? 1) + ((ps[i].pressure ?? 1) - (ps[i - 1].pressure ?? 1)) * j / Math.max(1, segment.length - 1)
			});
			if (path.length > 1048576) fail$2("Stroke exceeds work budget");
		}
	}
	const filtered = [];
	for (const p of path) {
		const a = filtered.at(-2), b0 = filtered.at(-1);
		if (c.pixelPerfect && b.size === 1 && !b.mask && a && b0 && Math.abs(a.x - p.x) === 1 && Math.abs(a.y - p.y) === 1 && Math.abs(a.x - b0.x) + Math.abs(a.y - b0.y) === 1 && Math.abs(p.x - b0.x) + Math.abs(p.y - b0.y) === 1) filtered.pop();
		filtered.push(p);
	}
	for (const p of filtered) stamp(ctx, p, b);
}
function bounds$1(c) {
	return {
		x: integer$4(c.x, "X", -65535, 65535),
		y: integer$4(c.y, "Y", -65535, 65535),
		width: integer$4(c.width, "Shape width", 1, 65535),
		height: integer$4(c.height, "Shape height", 1, 65535)
	};
}
function drawShape(ctx, c, ellipse = false) {
	const b = bounds$1(c), color = encodeColor(ctx.doc, c.color === void 0 ? ctx.doc.palette[0] : c.color), thickness = integer$4(c.size ?? 1, "Outline size", 1, 256);
	const x1 = Math.max(0, b.x), y1 = Math.max(0, b.y), x2 = Math.min(ctx.doc.width, b.x + b.width), y2 = Math.min(ctx.doc.height, b.y + b.height);
	for (let y = y1; y < y2; y++) for (let x = x1; x < x2; x++) {
		const dx = x - b.x + .5 - b.width / 2, dy = y - b.y + .5 - b.height / 2;
		const outer = ellipse ? (dx / (b.width / 2)) ** 2 + (dy / (b.height / 2)) ** 2 <= 1 : true;
		const iw = b.width / 2 - thickness, ih = b.height / 2 - thickness;
		const inner = ellipse ? iw > 0 && ih > 0 && (dx / iw) ** 2 + (dy / ih) ** 2 < 1 : x >= b.x + thickness && y >= b.y + thickness && x < b.x + b.width - thickness && y < b.y + b.height - thickness;
		if (outer && (c.filled || !inner)) ctx.put(x, y, color);
	}
}
function floodMask(doc, get, c) {
	const seed = point(c), mask = Array(doc.width * doc.height).fill(0);
	if (seed.x < 0 || seed.y < 0 || seed.x >= doc.width || seed.y >= doc.height) return mask;
	const target = pixelRGBA(doc, get(seed.x, seed.y)), tolerance = finite(c.tolerance ?? 0, "Tolerance", 0, 255);
	const matches = (x, y) => {
		const p = pixelRGBA(doc, get(x, y));
		return Math.max(...p.map((v, k) => Math.abs(v - target[k]))) <= tolerance;
	};
	if (c.contiguous === false) {
		for (let y = 0; y < doc.height; y++) for (let x = 0; x < doc.width; x++) if (matches(x, y)) mask[y * doc.width + x] = 1;
		return mask;
	}
	const queue = new Int32Array(doc.width * doc.height);
	let read = 0, write = 0;
	const enqueue = (x, y) => {
		if (x < 0 || y < 0 || x >= doc.width || y >= doc.height) return;
		const i = y * doc.width + x;
		if (mask[i] !== 0) return;
		mask[i] = 2;
		if (matches(x, y)) {
			mask[i] = 1;
			queue[write++] = i;
		}
	};
	enqueue(seed.x, seed.y);
	while (read < write) {
		const i = queue[read++], x = i % doc.width, y = Math.floor(i / doc.width);
		enqueue(x - 1, y);
		enqueue(x + 1, y);
		enqueue(x, y - 1);
		enqueue(x, y + 1);
	}
	return mask.map((v) => v === 1 ? 1 : 0);
}
const BITMAP_FONT = Object.freeze({
	width: 5,
	height: 7,
	glyphs: Object.freeze(Object.fromEntries(Object.entries({
		"A": [
			"01110",
			"10001",
			"10001",
			"11111",
			"10001",
			"10001",
			"10001"
		],
		"B": [
			"11110",
			"10001",
			"10001",
			"11110",
			"10001",
			"10001",
			"11110"
		],
		"C": [
			"01111",
			"10000",
			"10000",
			"10000",
			"10000",
			"10000",
			"01111"
		],
		"D": [
			"11110",
			"10001",
			"10001",
			"10001",
			"10001",
			"10001",
			"11110"
		],
		"E": [
			"11111",
			"10000",
			"10000",
			"11110",
			"10000",
			"10000",
			"11111"
		],
		"F": [
			"11111",
			"10000",
			"10000",
			"11110",
			"10000",
			"10000",
			"10000"
		],
		"G": [
			"01111",
			"10000",
			"10000",
			"10111",
			"10001",
			"10001",
			"01111"
		],
		"H": [
			"10001",
			"10001",
			"10001",
			"11111",
			"10001",
			"10001",
			"10001"
		],
		"I": [
			"11111",
			"00100",
			"00100",
			"00100",
			"00100",
			"00100",
			"11111"
		],
		"J": [
			"00111",
			"00010",
			"00010",
			"00010",
			"10010",
			"10010",
			"01100"
		],
		"K": [
			"10001",
			"10010",
			"10100",
			"11000",
			"10100",
			"10010",
			"10001"
		],
		"L": [
			"10000",
			"10000",
			"10000",
			"10000",
			"10000",
			"10000",
			"11111"
		],
		"M": [
			"10001",
			"11011",
			"10101",
			"10101",
			"10001",
			"10001",
			"10001"
		],
		"N": [
			"10001",
			"11001",
			"10101",
			"10011",
			"10001",
			"10001",
			"10001"
		],
		"O": [
			"01110",
			"10001",
			"10001",
			"10001",
			"10001",
			"10001",
			"01110"
		],
		"P": [
			"11110",
			"10001",
			"10001",
			"11110",
			"10000",
			"10000",
			"10000"
		],
		"Q": [
			"01110",
			"10001",
			"10001",
			"10001",
			"10101",
			"10010",
			"01101"
		],
		"R": [
			"11110",
			"10001",
			"10001",
			"11110",
			"10100",
			"10010",
			"10001"
		],
		"S": [
			"01111",
			"10000",
			"10000",
			"01110",
			"00001",
			"00001",
			"11110"
		],
		"T": [
			"11111",
			"00100",
			"00100",
			"00100",
			"00100",
			"00100",
			"00100"
		],
		"U": [
			"10001",
			"10001",
			"10001",
			"10001",
			"10001",
			"10001",
			"01110"
		],
		"V": [
			"10001",
			"10001",
			"10001",
			"10001",
			"10001",
			"01010",
			"00100"
		],
		"W": [
			"10001",
			"10001",
			"10001",
			"10101",
			"10101",
			"10101",
			"01010"
		],
		"X": [
			"10001",
			"10001",
			"01010",
			"00100",
			"01010",
			"10001",
			"10001"
		],
		"Y": [
			"10001",
			"10001",
			"01010",
			"00100",
			"00100",
			"00100",
			"00100"
		],
		"Z": [
			"11111",
			"00001",
			"00010",
			"00100",
			"01000",
			"10000",
			"11111"
		],
		"0": [
			"01110",
			"10001",
			"10011",
			"10101",
			"11001",
			"10001",
			"01110"
		],
		"1": [
			"00100",
			"01100",
			"00100",
			"00100",
			"00100",
			"00100",
			"01110"
		],
		"2": [
			"01110",
			"10001",
			"00001",
			"00010",
			"00100",
			"01000",
			"11111"
		],
		"3": [
			"11110",
			"00001",
			"00001",
			"01110",
			"00001",
			"00001",
			"11110"
		],
		"4": [
			"00010",
			"00110",
			"01010",
			"10010",
			"11111",
			"00010",
			"00010"
		],
		"5": [
			"11111",
			"10000",
			"10000",
			"11110",
			"00001",
			"00001",
			"11110"
		],
		"6": [
			"01110",
			"10000",
			"10000",
			"11110",
			"10001",
			"10001",
			"01110"
		],
		"7": [
			"11111",
			"00001",
			"00010",
			"00100",
			"01000",
			"01000",
			"01000"
		],
		"8": [
			"01110",
			"10001",
			"10001",
			"01110",
			"10001",
			"10001",
			"01110"
		],
		"9": [
			"01110",
			"10001",
			"10001",
			"01111",
			"00001",
			"00001",
			"01110"
		],
		"?": [
			"01110",
			"10001",
			"00010",
			"00100",
			"00100",
			"00000",
			"00100"
		],
		"!": [
			"00100",
			"00100",
			"00100",
			"00100",
			"00100",
			"00000",
			"00100"
		],
		".": [
			"00000",
			"00000",
			"00000",
			"00000",
			"00000",
			"00110",
			"00110"
		],
		",": [
			"00000",
			"00000",
			"00000",
			"00000",
			"00110",
			"00110",
			"00100"
		],
		":": [
			"00000",
			"00110",
			"00110",
			"00000",
			"00110",
			"00110",
			"00000"
		],
		";": [
			"00000",
			"00110",
			"00110",
			"00000",
			"00110",
			"00110",
			"00100"
		],
		"-": [
			"00000",
			"00000",
			"00000",
			"11111",
			"00000",
			"00000",
			"00000"
		],
		"_": [
			"00000",
			"00000",
			"00000",
			"00000",
			"00000",
			"00000",
			"11111"
		],
		"+": [
			"00000",
			"00100",
			"00100",
			"11111",
			"00100",
			"00100",
			"00000"
		],
		"=": [
			"00000",
			"00000",
			"11111",
			"00000",
			"11111",
			"00000",
			"00000"
		],
		"/": [
			"00001",
			"00010",
			"00010",
			"00100",
			"01000",
			"01000",
			"10000"
		],
		"\\": [
			"10000",
			"01000",
			"01000",
			"00100",
			"00010",
			"00010",
			"00001"
		],
		"(": [
			"00010",
			"00100",
			"01000",
			"01000",
			"01000",
			"00100",
			"00010"
		],
		")": [
			"01000",
			"00100",
			"00010",
			"00010",
			"00010",
			"00100",
			"01000"
		],
		"[": [
			"01110",
			"01000",
			"01000",
			"01000",
			"01000",
			"01000",
			"01110"
		],
		"]": [
			"01110",
			"00010",
			"00010",
			"00010",
			"00010",
			"00010",
			"01110"
		],
		"<": [
			"00010",
			"00100",
			"01000",
			"10000",
			"01000",
			"00100",
			"00010"
		],
		">": [
			"01000",
			"00100",
			"00010",
			"00001",
			"00010",
			"00100",
			"01000"
		],
		"#": [
			"01010",
			"01010",
			"11111",
			"01010",
			"11111",
			"01010",
			"01010"
		],
		"*": [
			"00000",
			"10101",
			"01110",
			"11111",
			"01110",
			"10101",
			"00000"
		],
		"\"": [
			"01010",
			"01010",
			"00000",
			"00000",
			"00000",
			"00000",
			"00000"
		],
		"'": [
			"00100",
			"00100",
			"00000",
			"00000",
			"00000",
			"00000",
			"00000"
		],
		" ": [
			"00000",
			"00000",
			"00000",
			"00000",
			"00000",
			"00000",
			"00000"
		]
	}).map(([k, v]) => [k, Object.freeze(v.join("").split("").map(Number))])))
});
function drawText(ctx, c) {
	const pos = point(c), scale = integer$4(c.scale ?? 1, "Text scale", 1, 64), font = c.font ?? BITMAP_FONT, w = integer$4(font.width, "Glyph width", 1, 64), h = integer$4(font.height, "Glyph height", 1, 64);
	if (typeof c.text !== "string" || c.text.length > 4096) fail$2("Text must contain at most 4096 characters");
	const spacing = integer$4(c.spacing ?? 1, "Text spacing", 0, 64), lineHeight = integer$4(c.lineHeight ?? h + 1, "Line height", 1, 128), color = encodeColor(ctx.doc, c.color === void 0 ? ctx.doc.palette[0] : c.color);
	let x = pos.x, y = pos.y;
	for (const ch of c.text) {
		if (ch === "\n") {
			x = pos.x;
			y += lineHeight * scale;
			continue;
		}
		const glyph = font.glyphs[ch] ?? font.glyphs[ch.toUpperCase()] ?? font.glyphs["?"];
		if (!Array.isArray(glyph) || glyph.length !== w * h) fail$2(`Missing or invalid glyph: ${ch}`);
		for (let gy = 0; gy < h; gy++) for (let gx = 0; gx < w; gx++) if (glyph[gy * w + gx]) for (let py = 0; py < scale; py++) for (let px = 0; px < scale; px++) ctx.put(x + gx * scale + px, y + gy * scale + py, color);
		x += (w + spacing) * scale;
	}
}
function gradient(ctx, c) {
	const a = point(c.from, "Gradient start"), b = point(c.to, "Gradient end"), ac = pixelRGBA(ctx.doc, encodeColor(ctx.doc, c.color === void 0 ? ctx.doc.palette[0] : c.color)), bc = pixelRGBA(ctx.doc, encodeColor(ctx.doc, c.endColor === void 0 ? ctx.doc.palette.at(-1) : c.endColor)), dx = b.x - a.x, dy = b.y - a.y, den = dx * dx + dy * dy;
	if (!den) fail$2("Gradient endpoints must differ");
	const bayer = [
		0,
		8,
		2,
		10,
		12,
		4,
		14,
		6,
		3,
		11,
		1,
		9,
		15,
		7,
		13,
		5
	];
	for (let y = 0; y < ctx.doc.height; y++) for (let x = 0; x < ctx.doc.width; x++) {
		let t = clamp(((x - a.x) * dx + (y - a.y) * dy) / den);
		if (c.dither) {
			const threshold = (bayer[y % 4 * 4 + x % 4] + .5) / 16;
			ctx.put(x, y, encodeColor(ctx.doc, hex$2(t >= threshold ? bc : ac)));
		} else ctx.put(x, y, encodeColor(ctx.doc, hex$2(ac.map((v, k) => v + (bc[k] - v) * t))));
	}
}
function drawCurve(ctx, c) {
	const ps = points(c.points, 3, 4);
	if (ps.length !== 3 && ps.length !== 4) fail$2("Curve requires 3 or 4 control points");
	const length = ps.slice(1).reduce((s, p, i) => s + Math.hypot(p.x - ps[i].x, p.y - ps[i].y), 0), steps = Math.max(4, Math.min(16384, Math.ceil(length * 2))), path = [];
	for (let i = 0; i <= steps; i++) {
		const t = i / steps, u = 1 - t;
		path.push(ps.length === 3 ? {
			x: Math.round(u * u * ps[0].x + 2 * u * t * ps[1].x + t * t * ps[2].x),
			y: Math.round(u * u * ps[0].y + 2 * u * t * ps[1].y + t * t * ps[2].y)
		} : {
			x: Math.round(u ** 3 * ps[0].x + 3 * u * u * t * ps[1].x + 3 * u * t * t * ps[2].x + t ** 3 * ps[3].x),
			y: Math.round(u ** 3 * ps[0].y + 3 * u * u * t * ps[1].y + 3 * u * t * t * ps[2].y + t ** 3 * ps[3].y)
		});
	}
	drawStroke(ctx, path, c);
}
function drawPolygon(ctx, c) {
	const ps = points(c.points, c.filled ? 3 : 2, 4096), color = encodeColor(ctx.doc, c.color === void 0 ? ctx.doc.palette[0] : c.color);
	if (c.filled) {
		const minY = Math.max(0, Math.min(...ps.map((p) => p.y))), maxY = Math.min(ctx.doc.height - 1, Math.max(...ps.map((p) => p.y)));
		for (let y = minY; y <= maxY; y++) {
			const scan = y + .5, intersections = [];
			for (let i = 0, j = ps.length - 1; i < ps.length; j = i++) {
				const a = ps[i], b = ps[j];
				if (a.y > scan !== b.y > scan) intersections.push(a.x + (scan - a.y) * (b.x - a.x) / (b.y - a.y));
			}
			intersections.sort((a, b) => a - b);
			for (let i = 0; i + 1 < intersections.length; i += 2) for (let x = Math.max(0, Math.ceil(intersections[i] - .5)); x < Math.min(ctx.doc.width, Math.ceil(intersections[i + 1] - .5)); x++) ctx.put(x, y, color);
		}
	}
	drawStroke(ctx, [...ps, ps[0]], c);
}
function maskBounds(mask, width, height) {
	let x = width, y = height, x2 = -1, y2 = -1;
	for (let i = 0; i < mask.length; i++) if (mask[i]) {
		const px = i % width, py = Math.floor(i / width);
		x = Math.min(x, px);
		y = Math.min(y, py);
		x2 = Math.max(x2, px);
		y2 = Math.max(y2, py);
	}
	return x2 < 0 ? null : {
		x,
		y,
		width: x2 - x + 1,
		height: y2 - y + 1
	};
}
function selectionTransform(doc, c, changed) {
	const mask = selectionMask(doc, c.selection);
	if (!mask) fail$2("Transform requires a selection");
	const b = maskBounds(mask, doc.width, doc.height);
	if (!b) return;
	const ctx = context(doc, {
		...c,
		selection: null
	}, changed), snapshot = [...ctx.image.pixels], get = (x, y) => {
		const ix = x - ctx.cel.x, iy = y - ctx.cel.y;
		return ix < 0 || iy < 0 || ix >= ctx.image.width || iy >= ctx.image.height ? null : snapshot[iy * ctx.image.width + ix];
	}, op = c.operation ?? "move", method = c.method ?? "nearest";
	if (![
		"move",
		"scale",
		"rotate",
		"flipX",
		"flipY"
	].includes(op)) fail$2("Unsupported selection transform");
	if (![
		"nearest",
		"pixel-safe",
		"fast",
		"rotsprite"
	].includes(method)) fail$2("Unsupported transform sampling method");
	if (method !== "nearest" && op !== "rotate") fail$2("Fast and RotSprite sampling are only used for rotation");
	const dx = finite(c.dx ?? 0, "Move x", -65535, 65535), dy = finite(c.dy ?? 0, "Move y", -65535, 65535), sx = op === "scale" ? finite(c.scaleX ?? 1, "Scale x", .01, 64) : op === "flipX" ? -1 : 1, sy = op === "scale" ? finite(c.scaleY ?? c.scaleX ?? 1, "Scale y", .01, 64) : op === "flipY" ? -1 : 1, angle = op === "rotate" ? finite(c.angle ?? 0, "Angle", -36e3, 36e3) * Math.PI / 180 : 0, cos = Math.cos(angle), sin = Math.sin(angle), cx = c.pivot?.x ?? b.x + b.width / 2, cy = c.pivot?.y ?? b.y + b.height / 2;
	finite(cx, "Pivot x", -65535, 65535);
	finite(cy, "Pivot y", -65535, 65535);
	if (op === "rotate") {
		const corner = (x, y) => [Math.round((x - cx) * cos - (y - cy) * sin + cx + dx), Math.round((x - cx) * sin + (y - cy) * cos + cy + dy)], q0 = corner(b.x, b.y), q1 = corner(b.x + b.width, b.y), q3 = corner(b.x, b.y + b.height), corners = [
			q0,
			q1,
			[q1[0] + q3[0] - q0[0], q1[1] + q3[1] - q0[1]],
			q3
		];
		const left = Math.min(...corners.map((p) => p[0])), top = Math.min(...corners.map((p) => p[1])), width = Math.max(...corners.map((p) => p[0])) - left, height = Math.max(...corners.map((p) => p[1])) - top;
		let transformed = null;
		if (width && height && left < doc.width && top < doc.height && left + width > 0 && top + height > 0) {
			const pixels = new Uint32Array(b.width * b.height), selection = new Uint8Array(pixels.length), indexed = doc.colorMode === "indexed", gray = doc.colorMode === "grayscale";
			for (let y = 0; y < b.height; y++) for (let x = 0; x < b.width; x++) {
				const at = y * b.width + x;
				if (!mask[(y + b.y) * doc.width + x + b.x]) continue;
				selection[at] = 1;
				const raw = get(x + b.x, y + b.y), rgba = pixelRGBA(ctx.doc, raw);
				pixels[at] = indexed ? raw == null || !rgba[3] ? 0 : raw + 1 : gray ? rgba[0] | rgba[3] << 8 : (rgba[0] | rgba[1] << 8 | rgba[2] << 16 | rgba[3] << 24) >>> 0;
			}
			transformed = rasterizeRotation({
				pixels,
				width: b.width,
				height: b.height,
				destinationWidth: width,
				destinationHeight: height,
				corners: corners.map(([x, y]) => [x - left, y - top]),
				method: ["pixel-safe", "rotsprite"].includes(method) ? "rotsprite" : "fast",
				pixelFormat: indexed ? "values" : gray ? "grayscale" : "rgba",
				mask: selection
			});
		}
		if (!c.copy) {
			for (let y = b.y; y < b.y + b.height; y++) for (let x = b.x; x < b.x + b.width; x++) if (mask[y * doc.width + x]) ctx.put(x, y, null);
		}
		if (transformed) {
			const back = new Uint8ClampedArray(4);
			for (let y = Math.max(0, -top); y < Math.min(height, doc.height - top); y++) for (let x = Math.max(0, -left); x < Math.min(width, doc.width - left); x++) {
				const at = y * width + x;
				if (!transformed.coverage[at]) continue;
				const value = transformed.pixels[at];
				if (doc.colorMode === "indexed") {
					if (value) ctx.put(x + left, y + top, value - 1);
					continue;
				}
				const rgba = doc.colorMode === "grayscale" ? [
					value & 255,
					value & 255,
					value & 255,
					value >>> 8 & 255
				] : [
					value & 255,
					value >>> 8 & 255,
					value >>> 16 & 255,
					value >>> 24
				];
				if (!rgba[3]) continue;
				back.set(pixelRGBA(ctx.doc, ctx.get(x + left, y + top)));
				blendAt(back, 0, rgba, 1, "normal");
				ctx.put(x + left, y + top, encodeColor(ctx.doc, hex$2([...back])));
			}
		}
		return;
	}
	if (!c.copy) {
		for (let y = b.y; y < b.y + b.height; y++) for (let x = b.x; x < b.x + b.width; x++) if (mask[y * doc.width + x]) ctx.put(x, y, null);
	}
	for (let y = 0; y < doc.height; y++) for (let x = 0; x < doc.width; x++) {
		const tx = x + .5 - cx - dx, ty = y + .5 - cy - dy, sourceX = Math.floor((tx * cos + ty * sin) / sx + cx + 1e-9), sourceY = Math.floor((-tx * sin + ty * cos) / sy + cy + 1e-9);
		if (sourceX >= 0 && sourceY >= 0 && sourceX < doc.width && sourceY < doc.height && mask[sourceY * doc.width + sourceX]) ctx.put(x, y, get(sourceX, sourceY));
	}
}
function separateEffectContexts(doc, c) {
	const selected = targetFrames(doc, c);
	if (doc.colorMode !== "indexed" || selected.length < 2) return;
	const layer = layerFor(doc, c.layerId, true), selectedImages = new Set(selected.map((frame) => frame.cels[layer.id]?.imageId).filter(Boolean)), groups = /* @__PURE__ */ new Map();
	for (const frame of doc.frames) {
		const cel = frame.cels[layer.id];
		if (!cel || !selectedImages.has(cel.imageId)) continue;
		const originalId = cel.imageId, key = JSON.stringify(getFramePalette(doc, frame.id, layer.id));
		let contexts = groups.get(originalId);
		if (!contexts) {
			contexts = /* @__PURE__ */ new Map();
			groups.set(originalId, contexts);
		}
		if (!contexts.has(key)) if (!contexts.size) contexts.set(key, originalId);
		else {
			const image = doc.images[originalId];
			reserve(doc, image.width * image.height);
			const imageId = fresh(doc, "image");
			doc.images[imageId] = {
				...image,
				pixels: [...image.pixels]
			};
			contexts.set(key, imageId);
		}
		cel.imageId = contexts.get(key);
	}
}
function applyEffect(doc, c, changed) {
	separateEffectContexts(doc, c);
	const effect = c.effect;
	if (![
		"replace",
		"outline",
		"brightness",
		"contrast",
		"hue",
		"saturation",
		"convolution",
		"despeckle"
	].includes(effect)) fail$2("Unsupported effect");
	const handled = /* @__PURE__ */ new Set();
	for (const frame of targetFrames(doc, c)) {
		const cel0 = frame.cels[c.layerId ?? doc.layers.find((l) => l.type === "image")?.id];
		if (cel0 && handled.has(cel0.imageId)) continue;
		const ctx = context(doc, {
			...c,
			frameId: frame.id
		}, changed);
		handled.add(ctx.cel.imageId);
		const source = [...ctx.image.pixels], sample = (x, y) => {
			x = clamp(x, 0, doc.width - 1) - ctx.cel.x;
			y = clamp(y, 0, doc.height - 1) - ctx.cel.y;
			return x < 0 || y < 0 || x >= ctx.image.width || y >= ctx.image.height ? null : source[y * ctx.image.width + x];
		};
		const color = ["replace", "outline"].includes(effect) ? encodeColor(ctx.doc, c.toColor === void 0 ? c.color === void 0 ? doc.palette[0] : c.color : c.toColor) : null, from = effect === "replace" && c.fromColor !== void 0 ? encodeColor(ctx.doc, c.fromColor) : void 0, amount = [
			"brightness",
			"contrast",
			"hue",
			"saturation"
		].includes(effect) ? finite(c.amount ?? (effect === "hue" ? 30 : .1), "Effect amount", effect === "hue" ? -360 : effect === "contrast" ? -.99 : -1, effect === "hue" ? 360 : effect === "contrast" ? .99 : 1) : 0, radius = effect === "outline" ? integer$4(c.radius ?? 1, "Outline radius", 1, 64) : 1;
		let kernel, size, divisor;
		if (effect === "convolution") {
			kernel = c.kernel;
			if (!Array.isArray(kernel) || kernel.length < 1 || kernel.length > 225 || !Number.isInteger(Math.sqrt(kernel.length)) || Math.sqrt(kernel.length) % 2 !== 1) fail$2("Convolution requires an odd square kernel up to 15×15");
			for (const n of kernel) finite(n, "Kernel coefficient", -1e3, 1e3);
			size = Math.sqrt(kernel.length);
			divisor = finite(c.divisor ?? (kernel.reduce((a, b) => a + b, 0) || 1), "Kernel divisor", -1e6, 1e6);
			if (divisor === 0) fail$2("Kernel divisor cannot be zero");
			finite(c.bias ?? 0, "Kernel bias", -255, 255);
		}
		if ((ctx.mask ? ctx.mask.reduce((sum, v) => sum + (v ? 1 : 0), 0) : doc.width * doc.height) * (effect === "outline" ? (radius * 2 + 1) ** 2 : effect === "convolution" ? kernel.length : effect === "despeckle" ? 9 : 1) > LIMITS.operations) fail$2("Effect exceeds work budget; use a smaller canvas or radius");
		for (let y = 0; y < doc.height; y++) for (let x = 0; x < doc.width; x++) {
			if (ctx.mask && !ctx.mask[y * doc.width + x]) continue;
			const p = sample(x, y), v = pixelRGBA(ctx.doc, p);
			let result = p;
			if (effect === "replace") {
				if (from === void 0 ? p !== null : hex$2(pixelRGBA(ctx.doc, from)) === hex$2(v)) result = color;
			} else if (effect === "outline") {
				if (v[3] === 0) {
					let hit = false;
					for (let oy = -radius; oy <= radius && !hit; oy++) for (let ox = -radius; ox <= radius; ox++) {
						if (c.diagonal === false && Math.abs(ox) + Math.abs(oy) > radius) continue;
						if (x + ox < 0 || y + oy < 0 || x + ox >= doc.width || y + oy >= doc.height) continue;
						if (pixelRGBA(ctx.doc, sample(x + ox, y + oy))[3]) {
							hit = true;
							break;
						}
					}
					if (hit) result = color;
				}
			} else if (effect === "convolution") {
				const sum = [
					0,
					0,
					0,
					0
				];
				for (let ky = 0; ky < size; ky++) for (let kx = 0; kx < size; kx++) {
					const q = pixelRGBA(ctx.doc, sample(x + kx - (size - 1) / 2, y + ky - (size - 1) / 2)), weight = kernel[ky * size + kx];
					for (let k = 0; k < 4; k++) sum[k] += q[k] * weight;
				}
				result = encodeColor(ctx.doc, hex$2(sum.map((n, k) => k === 3 && !c.affectAlpha ? v[3] : n / divisor + (k === 3 ? 0 : c.bias ?? 0))));
			} else if (effect === "despeckle") {
				const samples = [];
				for (let oy = -1; oy <= 1; oy++) for (let ox = -1; ox <= 1; ox++) samples.push(pixelRGBA(ctx.doc, sample(x + ox, y + oy)));
				result = encodeColor(ctx.doc, hex$2([
					0,
					1,
					2,
					3
				].map((k) => samples.map((p) => p[k]).sort((a, b) => a - b)[4])));
			} else if (v[3]) {
				if (effect === "brightness") for (let k = 0; k < 3; k++) v[k] += amount * 255;
				else if (effect === "contrast") {
					const factor = (1 + amount) / (1 - amount);
					for (let k = 0; k < 3; k++) v[k] = (v[k] - 127.5) * factor + 127.5;
				} else {
					const hsl = rgbHsl(v);
					if (effect === "hue") hsl[0] += amount / 360;
					else hsl[1] = clamp(hsl[1] + amount);
					v.splice(0, 3, ...hslRgb(hsl));
				}
				result = encodeColor(ctx.doc, hex$2(v));
			}
			ctx.put(x, y, result);
		}
	}
}
function gcImages(doc) {
	const used = new Set(doc.frames.flatMap((f) => Object.values(f.cels).map((c) => c.imageId)));
	for (const ts of doc.tilesets) {
		if (ts.imageId) used.add(ts.imageId);
		for (const t of ts.tiles ?? []) used.add(t.imageId);
	}
	for (const key of Object.keys(doc.images)) if (!used.has(key)) delete doc.images[key];
}
function resizeImage(image, width, height) {
	const pixels = Array(width * height).fill(null);
	for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) pixels[y * width + x] = image.pixels[Math.min(image.height - 1, Math.floor(y * image.height / height)) * image.width + Math.min(image.width - 1, Math.floor(x * image.width / width))];
	return {
		...image,
		width,
		height,
		pixels
	};
}
function resizeDocument(doc, c) {
	const width = integer$4(c.width, "Width", 1, LIMITS.edge), height = integer$4(c.height, "Height", 1, LIMITS.edge), mode = c.mode ?? "canvas";
	if (width * height > LIMITS.canvasPixels) fail$2("Canvas exceeds the 4,194,304 pixel budget", "MEMORY_BUDGET");
	if (!["canvas", "scale"].includes(mode)) fail$2("Invalid resize mode");
	const sx = width / doc.width, sy = height / doc.height, dx = c.anchor === "center" ? Math.floor((width - doc.width) / 2) : 0, dy = c.anchor === "center" ? Math.floor((height - doc.height) / 2) : 0;
	if (mode === "scale") {
		const referenced = new Set(doc.frames.flatMap((f) => Object.values(f.cels).map((c) => c.imageId))), plans = [];
		let pixels = 0;
		for (const [key, image] of Object.entries(doc.images)) if (referenced.has(key) && !image.tilemap) {
			const w = Math.max(1, Math.round(image.width * sx)), h = Math.max(1, Math.round(image.height * sy));
			integer$4(w, "Scaled image width", 1, LIMITS.imageEdge);
			integer$4(h, "Scaled image height", 1, LIMITS.imageEdge);
			pixels += w * h;
			plans.push([
				key,
				w,
				h
			]);
		} else pixels += image.width * image.height;
		if (pixels > LIMITS.pixels) fail$2("Scaled document exceeds pixel budget");
		for (const [key, w, h] of plans) doc.images[key] = resizeImage(doc.images[key], w, h);
		for (const frame of doc.frames) for (const cel of Object.values(frame.cels)) {
			cel.x = Math.round(cel.x * sx);
			cel.y = Math.round(cel.y * sy);
		}
	} else for (const frame of doc.frames) for (const cel of Object.values(frame.cels)) {
		cel.x += dx;
		cel.y += dy;
	}
	doc.slices = doc.slices.map((s) => {
		if (!s.bounds) return {
			...s,
			keys: s.keys.map((k) => ({
				...k,
				x: Math.round(mode === "scale" ? k.x * sx : k.x + dx),
				y: Math.round(mode === "scale" ? k.y * sy : k.y + dy),
				width: Math.round(k.width * (mode === "scale" ? sx : 1)),
				height: Math.round(k.height * (mode === "scale" ? sy : 1))
			}))
		};
		const x = clamp(Math.round(mode === "scale" ? s.bounds.x * sx : s.bounds.x + dx), 0, width - 1), y = clamp(Math.round(mode === "scale" ? s.bounds.y * sy : s.bounds.y + dy), 0, height - 1);
		return {
			...s,
			bounds: {
				x,
				y,
				width: clamp(Math.round(s.bounds.width * (mode === "scale" ? sx : 1)), 1, width - x),
				height: clamp(Math.round(s.bounds.height * (mode === "scale" ? sy : 1)), 1, height - y)
			}
		};
	});
	doc.width = width;
	doc.height = height;
}
function easing(t, name = "linear") {
	t = clamp(t);
	switch (name) {
		case "linear": return t;
		case "easeIn": return t * t;
		case "easeOut": return 1 - (1 - t) ** 2;
		case "easeInOut": return t < .5 ? 2 * t * t : 1 - (-2 * t + 2) ** 2 / 2;
		case "bounce": {
			const n = 7.5625, d = 2.75;
			if (t < 1 / d) return n * t * t;
			if (t < 2 / d) return n * (t -= 1.5 / d) * t + .75;
			if (t < 2.5 / d) return n * (t -= 2.25 / d) * t + .9375;
			return n * (t -= 2.625 / d) * t + .984375;
		}
		default: fail$2("Unsupported easing");
	}
}
function tween(doc, c) {
	const layer = layerFor(doc, c.layerId, true);
	if (layer.type === "group" || layer.type === "tilemap") fail$2("Tween requires a raster layer");
	const frames = targetFrames(doc, c), source = frameFor(doc, c.sourceFrameId ?? frames[0].id).cels[layer.id];
	if (!source) fail$2("Tween source cel is empty");
	const from = c.from ?? {}, to = c.to ?? {}, start = {
		x: finite(from.x ?? source.x, "Start x", -65535, 65535),
		y: finite(from.y ?? source.y, "Start y", -65535, 65535),
		opacity: finite(from.opacity ?? source.opacity, "Start opacity", 0, 1)
	}, end = {
		x: finite(to.x ?? start.x, "End x", -65535, 65535),
		y: finite(to.y ?? start.y, "End y", -65535, 65535),
		opacity: finite(to.opacity ?? start.opacity, "End opacity", 0, 1)
	};
	frames.forEach((f, i) => {
		const t = easing(frames.length === 1 ? 0 : i / (frames.length - 1), c.easing ?? "linear");
		const cel = {
			...source,
			x: Math.round(start.x + (end.x - start.x) * t),
			y: Math.round(start.y + (end.y - start.y) * t),
			opacity: start.opacity + (end.opacity - start.opacity) * t
		};
		if (c.bake !== false) {
			const image = doc.images[source.imageId];
			reserve(doc, image.width * image.height);
			const key = fresh(doc, "image");
			doc.images[key] = {
				...image,
				pixels: [...image.pixels]
			};
			cel.imageId = key;
		}
		f.cels[layer.id] = cel;
	});
	doc.metadata.motion = {
		...doc.metadata.motion ?? {},
		[c.id ?? "last-tween"]: {
			type: "tween",
			layerId: layer.id,
			frameIds: frames.map((f) => f.id),
			from: start,
			to: end,
			easing: c.easing ?? "linear",
			bake: c.bake !== false
		}
	};
}
function seededRandom(seed) {
	let n = seed >>> 0;
	return () => {
		n += 1831565813;
		let t = n;
		t = Math.imul(t ^ t >>> 15, t | 1);
		t ^= t + Math.imul(t ^ t >>> 7, t | 61);
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
function particles(doc, c, changed) {
	const layer = layerFor(doc, c.layerId, true);
	if (layer.type !== "image") fail$2("Particles require an image layer");
	const frames = targetFrames(doc, c), seed = integer$4(c.seed ?? 1, "Seed", 0, 4294967295), count = integer$4(c.count ?? 32, "Particle count", 1, 4096), x = finite(c.x ?? doc.width / 2, "Emitter x", -65535, 65535), y = finite(c.y ?? doc.height / 2, "Emitter y", -65535, 65535), speed = finite(c.speed ?? 20, "Speed", 0, 4096), spread = finite(c.spread ?? 360, "Spread", 0, 360), angle = finite(c.angle ?? -90, "Direction", -36e3, 36e3), gravity = finite(c.gravity ?? 12, "Gravity", -4096, 4096), lifetime = finite(c.lifetime ?? 2, "Lifetime seconds", .01, 3600), size = integer$4(c.size ?? 1, "Particle size", 1, 64), random = seededRandom(seed), emission = finite(c.emission ?? 0, "Emission seconds", 0, 3600), color = c.color === void 0 ? doc.palette[0] : c.color;
	const ps = Array.from({ length: count }, () => {
		const a = (angle + (random() - .5) * spread) * Math.PI / 180, v = speed * (.5 + random() * .5);
		return {
			vx: Math.cos(a) * v,
			vy: Math.sin(a) * v,
			birth: random() * emission,
			life: lifetime * (.7 + .3 * random())
		};
	});
	let time = 0;
	for (const frame of frames) {
		if (c.clear !== false) {
			delete frame.cels[layer.id];
			gcImages(doc);
		}
		const ctx = context(doc, {
			...c,
			frameId: frame.id
		}, changed), b = brush({
			size,
			color,
			brush: c.brush ?? "square"
		}, ctx.doc);
		for (const p of ps) {
			const t = time - p.birth;
			if (t < 0 || t > p.life) continue;
			const a = c.fade === false ? 1 : 1 - t / p.life, base = pixelRGBA(ctx.doc, b.color);
			stamp(ctx, {
				x: Math.round(x + p.vx * t),
				y: Math.round(y + p.vy * t + .5 * gravity * t * t)
			}, {
				...b,
				color: encodeColor(ctx.doc, hex$2([
					base[0],
					base[1],
					base[2],
					base[3] * a
				]))
			});
		}
		time += frame.durationMs / 1e3;
	}
	doc.metadata.motion = {
		...doc.metadata.motion ?? {},
		[c.id ?? "last-particles"]: {
			type: "particles",
			layerId: layer.id,
			frameIds: frames.map((f) => f.id),
			seed,
			count,
			x,
			y,
			speed,
			spread,
			angle,
			gravity,
			lifetime,
			size,
			emission,
			color,
			fade: c.fade !== false
		}
	};
}
function setCel(doc, c) {
	const frame = frameFor(doc, c.frameId), layer = layerFor(doc, c.layerId, true);
	if (!["image", "reference"].includes(layer.type)) fail$2("Set cel requires a raster layer");
	const width = integer$4(c.width ?? doc.width, "Image width", 1, LIMITS.imageEdge), height = integer$4(c.height ?? doc.height, "Image height", 1, LIMITS.imageEdge);
	if (width * height > LIMITS.pixels || !Array.isArray(c.pixels) || c.pixels.length !== width * height) fail$2("Imported image dimensions mismatch");
	const working = colorContext(doc, frame.id, layer.id), pixels = c.pixels.map((v) => encodeColor(working, v));
	const existing = frame.cels[layer.id], key = c.editLinked && existing ? existing.imageId : fresh(doc, "image");
	if (existing && !c.editLinked) delete frame.cels[layer.id];
	gcImages(doc);
	reserve(doc, width * height, own$1(doc.images, key) ? key : void 0);
	doc.images[key] = {
		width,
		height,
		pixels
	};
	frame.cels[layer.id] = {
		...existing?.userData ? { userData: jsonCopy(existing.userData) } : {},
		...existing?.zIndex !== void 0 ? { zIndex: existing.zIndex } : {},
		imageId: key,
		x: integer$4(c.x ?? 0, "Cel x", -65535, 65535),
		y: integer$4(c.y ?? 0, "Cel y", -65535, 65535),
		opacity: finite(c.opacity ?? 1, "Cel opacity", 0, 1)
	};
}
/** Convert each image in its actual frame/layer color context. Tile variants stay in
* the same tileset, so palette animation remains exportable as a native tilemap. */
function convertColorMode(doc, colorMode, options = {}) {
	if (![
		"rgba",
		"indexed",
		"grayscale"
	].includes(colorMode)) fail$2("Unsupported color mode");
	if (colorMode === doc.colorMode && !options.remap && !options.indexedOptions) return;
	const source = shallowDocument(doc), images = {}, variants = /* @__PURE__ */ new Map(), tilesetVariants = /* @__PURE__ */ new Map();
	const usedIds = new Set(Object.keys(source.images));
	let nextImage = 1, storedPixels = 0;
	const framePalettes = /* @__PURE__ */ new Map(), contexts = /* @__PURE__ */ new WeakMap();
	let palette = source.palette, workPixels = 0;
	const indexedOptions = options.indexedOptions, indexedBudget = { remaining: LIMITS.operations };
	const nativeMapping = indexedOptions && indexedOptions.rgbmap !== "pixelwall", nativeGeneration = indexedOptions?.paletteMode === "generate" && indexedOptions.quantization !== "median-cut";
	const backgroundOnly = source.layers.length === 1 && !!(source.layers[0].asepriteFlags & 8);
	let destinationTransparent = indexedOptions ? source.metadata?.aseprite?.transparentIndex ?? 0 : source.metadata?.aseprite?.transparentIndex;
	if (nativeMapping && source.colorMode !== "indexed") destinationTransparent = Math.max(0, source.palette.indexOf("#00000000"));
	let generatedPalette;
	for (const frame of source.frames) {
		if (frame.palette) palette = frame.palette;
		framePalettes.set(frame.id, palette);
	}
	if (indexedOptions?.paletteMode === "generate") {
		function* samples() {
			const seen = /* @__PURE__ */ new Set(), usedTilesets = /* @__PURE__ */ new Set();
			function* imageSamples(imageId, frameId, layerId) {
				const image = source.images[imageId];
				if (!image || image.tilemap) return;
				const effective = getFramePalette(source, frameId, layerId), key = JSON.stringify([imageId, source.colorMode === "indexed" ? effective : null]);
				if (seen.has(key)) return;
				seen.add(key);
				const working = {
					...source,
					palette: effective
				};
				for (const pixel of image.pixels) yield pixel == null ? null : hex$2(pixelRGBA(working, pixel));
			}
			function* tileSamples(tilesetId, frameId, layerId) {
				const ts = source.tilesets.find((value) => value.id === tilesetId);
				if (!ts) return;
				usedTilesets.add(ts.id);
				if (!ts.tiles?.length && ts.externalFileId != null) fail$2("Embed external tileset pixels before converting color mode");
				for (const imageId of new Set([ts.imageId, ...(ts.tiles ?? []).map((tile) => tile.imageId)].filter(Boolean))) yield* imageSamples(imageId, frameId, layerId);
			}
			for (const frame of source.frames) for (const layer of source.layers) {
				const cel = frame.cels[layer.id];
				if (cel) yield* imageSamples(cel.imageId, frame.id, layer.id);
				if (layer.type === "tilemap") yield* tileSamples(layer.tilemaps?.[frame.id]?.tilesetId ?? layer.tilesetId, frame.id, layer.id);
			}
			for (const ts of source.tilesets) if (!usedTilesets.has(ts.id)) yield* tileSamples(ts.id, source.frames[0].id);
		}
		function* renderedSamples() {
			for (const frame of source.frames) {
				const cost = source.width * source.height * Math.max(1, source.layers.length);
				indexedBudget.remaining -= cost;
				if (indexedBudget.remaining < 0) fail$2("Native indexed palette sampling exceeds the work budget");
				const rendered = renderFrame(source, frame.id);
				for (let at = 0; at < rendered.length; at += 4) yield hex$2([...rendered.subarray(at, at + 4)]);
			}
		}
		generatedPalette = quantizePalette(nativeGeneration ? renderedSamples() : samples(), {
			...indexedOptions,
			transparentIndex: nativeGeneration ? backgroundOnly ? null : source.colorMode === "indexed" ? destinationTransparent : 0 : destinationTransparent,
			budget: indexedBudget
		});
		if (nativeGeneration) destinationTransparent = Math.max(0, generatedPalette.indexOf("#00000000"));
	}
	function contextFor(frameId, layerId) {
		const palette = framePalettes.get(frameId), layer = layerId == null ? null : source.layers.find((item) => item.id === layerId);
		const transparent = source.metadata?.aseprite?.transparentIndex, maskTransparent = (!layer || !(layer.asepriteFlags & 8)) && Number.isInteger(transparent), selected = options.selected?.has(frameId) ?? false;
		const targetTransparent = (!layer || !(layer.asepriteFlags & 8)) && Number.isInteger(destinationTransparent) ? destinationTransparent : null;
		const contextKey = `${maskTransparent}:${targetTransparent}:${selected}`;
		let byTransparency = contexts.get(palette);
		if (!byTransparency) {
			byTransparency = /* @__PURE__ */ new Map();
			contexts.set(palette, byTransparency);
		}
		if (!byTransparency.has(contextKey)) {
			const effective = (mode, entries, index) => {
				if (mode !== "indexed" || index == null || index >= entries.length) return entries;
				const copy = [...entries];
				copy[index] = "#00000000";
				return copy;
			};
			const from = {
				...source,
				palette: effective(source.colorMode, palette, maskTransparent ? transparent : null)
			}, to = {
				...source,
				colorMode,
				palette: effective(colorMode, generatedPalette ?? (selected ? options.palette : palette), nativeMapping ? null : targetTransparent)
			};
			const signature = JSON.stringify([
				source.colorMode === "indexed" || options.remap ? from.palette : null,
				colorMode === "indexed" || options.remap ? to.palette : null,
				selected
			]);
			byTransparency.set(contextKey, {
				from,
				to,
				signature,
				selected,
				originalPalette: palette,
				transparent: maskTransparent ? transparent : null,
				targetTransparent
			});
		}
		return byTransparency.get(contextKey);
	}
	function addImage(imageId, image) {
		storedPixels += image.width * image.height;
		if (storedPixels > LIMITS.pixels) fail$2("Color conversion exceeds the stored pixel budget", "MEMORY_BUDGET");
		images[imageId] = image;
		return imageId;
	}
	function convertImage(imageId, context) {
		const image = source.images[imageId];
		if (!image) fail$2("Color conversion references a missing image");
		if (image.tilemap) {
			if (!images[imageId]) addImage(imageId, image);
			return imageId;
		}
		let byContext = variants.get(imageId);
		if (!byContext) {
			byContext = /* @__PURE__ */ new Map();
			variants.set(imageId, byContext);
		}
		if (byContext.has(context.signature)) return byContext.get(context.signature);
		let convertedId;
		workPixels += image.pixels.length;
		if (workPixels > LIMITS.operations) fail$2("Color conversion exceeds the work budget", "MEMORY_BUDGET");
		const pixels = indexedOptions ? mapIndexedImage({
			...image,
			pixels: image.pixels.map((pixel) => pixel == null ? null : hex$2(pixelRGBA(context.from, pixel)))
		}, context.to.palette, {
			...indexedOptions,
			transparentIndex: context.targetTransparent,
			sourceColorMode: source.colorMode,
			budget: indexedBudget,
			...context.tileGrid ?? {}
		}) : image.pixels.map((pixel) => {
			if (pixel == null) return null;
			if (!options.remap) return encodeColor(context.to, hex$2(pixelRGBA(context.from, pixel)));
			if (!context.selected) return pixel;
			if (source.colorMode === "indexed") {
				if (pixel === context.transparent) return null;
				return options.mapping ? options.mapping[pixel] : encodeColor(context.to, hex$2(pixelRGBA(context.from, pixel)));
			}
			const oldIndex = context.originalPalette.indexOf(pixel);
			const mapped = options.mapping && oldIndex >= 0 ? options.mapping[oldIndex] : nearest(context.to.palette, rgba(pixel));
			return mapped == null ? null : encodeColor(context.to, context.to.palette[mapped]);
		});
		if (pixels.every((pixel, i) => pixel === image.pixels[i])) {
			convertedId = imageId;
			if (!images[convertedId]) addImage(convertedId, image);
			else if (!images[convertedId].pixels.every((pixel, i) => pixel === pixels[i])) convertedId = null;
		} else convertedId = null;
		if (convertedId == null) {
			for (const candidate of new Set(byContext.values())) if (images[candidate].pixels.every((pixel, i) => pixel === pixels[i])) {
				convertedId = candidate;
				break;
			}
			if (convertedId == null) {
				convertedId = imageId;
				if (images[convertedId]) {
					while (usedIds.has(`image-color-${nextImage}`)) nextImage++;
					convertedId = `image-color-${nextImage++}`;
					usedIds.add(convertedId);
				}
				addImage(convertedId, {
					...image,
					pixels
				});
			}
		}
		byContext.set(context.signature, convertedId);
		return convertedId;
	}
	function convertTileset(tilesetId, context) {
		const original = source.tilesets.find((ts) => ts.id === tilesetId);
		if (!original) fail$2("Tileset missing");
		if (!original.tiles?.length && original.externalFileId != null) fail$2("Embed external tileset pixels before converting color mode");
		let state = tilesetVariants.get(tilesetId);
		if (!state) {
			state = {
				tileset: {
					...original,
					tiles: []
				},
				contexts: /* @__PURE__ */ new Map(),
				usedIds: new Set((original.tiles ?? []).map((t) => t.id)),
				next: 1
			};
			tilesetVariants.set(tilesetId, state);
		}
		if (state.contexts.has(context.signature)) return state.contexts.get(context.signature);
		const first = state.contexts.size === 0, ids = /* @__PURE__ */ new Map();
		const atlasContext = indexedOptions && original.imageId ? {
			...context,
			tileGrid: {
				tileWidth: original.tileWidth,
				tileHeight: original.tileHeight
			},
			signature: context.signature + JSON.stringify([original.tileWidth, original.tileHeight])
		} : context;
		if (first && original.imageId) state.tileset.imageId = convertImage(original.imageId, atlasContext);
		for (const tile of original.tiles ?? []) {
			let tileId = tile.id;
			if (!first) {
				while (state.usedIds.has(`tile-color-${state.next}`)) state.next++;
				tileId = `tile-color-${state.next++}`;
				state.usedIds.add(tileId);
			}
			const converted = {
				...tile,
				id: tileId,
				imageId: convertImage(tile.imageId, tile.imageId === original.imageId ? atlasContext : context)
			};
			if (!first) delete converted.asepriteTileId;
			state.tileset.tiles.push(converted);
			ids.set(tile.id, tileId);
			if (state.tileset.tiles.length > 65536) fail$2("Color conversion exceeds the tileset limit", "MEMORY_BUDGET");
		}
		state.contexts.set(context.signature, ids);
		return ids;
	}
	for (const frame of doc.frames) {
		const originalFrame = frameFor(source, frame.id);
		for (const layer of doc.layers) {
			const cel = originalFrame.cels[layer.id];
			if (layer.type === "tilemap") {
				const originalLayer = source.layers.find((item) => item.id === layer.id), originalMap = originalLayer.tilemaps?.[frame.id];
				const tilesetId = originalMap?.tilesetId ?? originalLayer.tilesetId, ts = source.tilesets.find((item) => item.id === tilesetId);
				const map = originalMap ?? (ts ? nativeMap(source, originalLayer, originalFrame, ts) : null);
				if (map) {
					const ids = convertTileset(tilesetId, contextFor(frame.id, layer.id));
					if (!(nativeMapping && !originalMap && map.cells.every((cell) => !cell || ids.get(cell.tileId) === cell.tileId))) layer.tilemaps = {
						...layer.tilemaps ?? {},
						[frame.id]: {
							...map,
							cells: map.cells.map((cell) => cell ? {
								...cell,
								tileId: ids.get(cell.tileId)
							} : null)
						}
					};
				}
			}
			if (cel) frame.cels[layer.id] = {
				...cel,
				imageId: convertImage(cel.imageId, contextFor(frame.id, layer.id))
			};
		}
	}
	for (const tileset of source.tilesets) if (!tilesetVariants.has(tileset.id)) convertTileset(tileset.id, contextFor(source.frames[0].id));
	doc.images = images;
	doc.tilesets = source.tilesets.map((ts) => tilesetVariants.get(ts.id).tileset);
	doc.colorMode = colorMode;
	if (generatedPalette) {
		doc.palette = [...generatedPalette];
		for (const frame of doc.frames) frame.palette = [...generatedPalette];
	}
	if (indexedOptions) doc.metadata = {
		...doc.metadata,
		aseprite: {
			...doc.metadata?.aseprite,
			transparentIndex: destinationTransparent
		}
	};
}
function paletteEdit(doc, c, remap) {
	if (!Array.isArray(c.palette) || !c.palette.length || c.palette.length > LIMITS.palette) fail$2("Invalid palette");
	const palette = c.palette.map(normalizeColor), scope = c.scope ?? (c.frameIds ? "range" : c.frameId ? "frame" : "all");
	if (![
		"all",
		"frame",
		"range"
	].includes(scope)) fail$2("Palette scope must be all, frame, or range");
	if (scope === "range" && (!Array.isArray(c.frameIds) || !c.frameIds.length)) fail$2("Palette range requires frameIds");
	const selected = new Set((scope === "all" ? doc.frames : targetFrames(doc, scope === "frame" ? { frameId: c.frameId ?? doc.frames[0].id } : { frameIds: c.frameIds })).map((frame) => frame.id));
	const palettes = /* @__PURE__ */ new Map();
	let previous = doc.palette;
	for (const frame of doc.frames) {
		if (frame.palette) previous = frame.palette;
		palettes.set(frame.id, [...previous]);
	}
	let mapping = c.mapping;
	if (remap && mapping) {
		if (!Array.isArray(mapping)) fail$2("Palette mapping must include every old index");
		for (const frameId of selected) if (mapping.length !== palettes.get(frameId).length) fail$2("Palette mapping must include every old index in each selected frame");
		mapping = mapping.map((index) => index == null ? null : integer$4(index, "Remapped index", 0, palette.length - 1));
	}
	if (remap) convertColorMode(doc, doc.colorMode, {
		remap: true,
		selected,
		palette,
		mapping
	});
	else if (doc.colorMode === "indexed") {
		const checked = /* @__PURE__ */ new Set();
		function checkImage(imageId) {
			if (checked.has(imageId)) return;
			checked.add(imageId);
			const image = doc.images[imageId];
			if (!image || image.tilemap) return;
			for (const pixel of image.pixels) if (pixel != null && pixel >= palette.length) fail$2("Removing used palette entries requires remapping");
		}
		for (const frame of doc.frames) if (selected.has(frame.id)) {
			for (const cel of Object.values(frame.cels)) checkImage(cel.imageId);
			for (const layer of doc.layers) if (layer.type === "tilemap") {
				const tilesetId = layer.tilemaps?.[frame.id]?.tilesetId ?? layer.tilesetId, tileset = doc.tilesets.find((item) => item.id === tilesetId);
				if (tileset?.imageId) checkImage(tileset.imageId);
				for (const tile of tileset?.tiles ?? []) checkImage(tile.imageId);
			}
		}
		if (scope === "all") for (const tileset of doc.tilesets) {
			if (tileset.imageId) checkImage(tileset.imageId);
			for (const tile of tileset.tiles ?? []) checkImage(tile.imageId);
		}
	}
	for (const frame of doc.frames) frame.palette = selected.has(frame.id) ? [...palette] : palettes.get(frame.id);
	doc.palette = [...doc.frames[0].palette];
	const capacity = Math.max(...doc.frames.map((frame) => frame.palette.length));
	while (doc.palette.length < capacity) doc.palette.push("#00000000");
}
function addTileset(doc, c) {
	const input = c.tileset, working = colorContext(doc, c.frameId, c.layerId);
	if (!record$2(input)) fail$2("Tileset is missing");
	const ts = {
		...jsonCopy(input),
		id: input.id ?? fresh(doc, "tileset"),
		name: input.name ?? "Tileset",
		tileWidth: integer$4(input.tileWidth, "Tile width", 1, LIMITS.edge),
		tileHeight: integer$4(input.tileHeight, "Tile height", 1, LIMITS.edge),
		tiles: []
	};
	if (doc.tilesets.some((t) => t.id === ts.id)) fail$2("Tileset id exists");
	if (!Array.isArray(input.tiles) || input.tiles.length > 65536) fail$2("Tileset requires a tile list");
	for (const [i, t] of input.tiles.entries()) {
		let imageId = t.imageId;
		if (t.pixels) {
			if (!Array.isArray(t.pixels) || t.pixels.length !== ts.tileWidth * ts.tileHeight) fail$2("Tile pixels size mismatch");
			reserve(doc, t.pixels.length);
			imageId = fresh(doc, "image");
			doc.images[imageId] = {
				width: ts.tileWidth,
				height: ts.tileHeight,
				pixels: t.pixels.map((p) => encodeColor(working, p))
			};
		}
		if (!own$1(doc.images, imageId)) fail$2("Tile image missing");
		ts.tiles.push({
			id: t.id ?? `tile-${i + 1}`,
			imageId
		});
	}
	doc.tilesets.push(ts);
}
function nativeMap(doc, layer, frame, ts) {
	const cel = frame.cels[layer.id], image = doc.images[cel?.imageId], raw = image?.tilemap;
	if (!raw) return null;
	const ids = new Map((ts.tiles ?? []).filter((t) => Number.isInteger(t.asepriteTileId)).map((t) => [t.asepriteTileId, t.id]));
	const cells = raw.tiles.map((rawValue) => {
		const value = rawValue >>> 0, index = (value & (raw.idMask ?? 536870911)) >>> 0;
		if (ts.flags & 4 ? index === 0 : value === 4294967295) return null;
		const tileId = ids.get(index);
		if (!tileId) return null;
		const diagonal = !!(value & (raw.diagonalFlipMask ?? 536870912)), flipY = !!(value & (raw.yFlipMask ?? 1073741824)), flipX = !!(value & (raw.xFlipMask ?? 2147483648));
		return {
			tileId,
			flipX: diagonal ? flipY : flipX,
			flipY: diagonal ? !flipX : flipY,
			rotate: diagonal ? 90 : 0
		};
	});
	return {
		tilesetId: ts.id,
		columns: image.width,
		rows: image.height,
		cells,
		x: cel.x,
		y: cel.y,
		opacity: cel.opacity,
		sourceImageId: cel.imageId
	};
}
function getTile(doc, tilesetId, tileId) {
	const ts = doc.tilesets.find((t) => t.id === tilesetId), tile = ts?.tiles?.find((t) => t.id === tileId);
	if (!tile) fail$2("Tile not found");
	const image = doc.images[tile.imageId], r = tile.sourceRect ?? {
		x: 0,
		y: 0,
		width: image.width,
		height: image.height
	}, pixels = Array(ts.tileWidth * ts.tileHeight);
	for (let y = 0; y < ts.tileHeight; y++) for (let x = 0; x < ts.tileWidth; x++) pixels[y * ts.tileWidth + x] = image.pixels[(r.y + Math.min(r.height - 1, Math.floor(y * r.height / ts.tileHeight))) * image.width + r.x + Math.min(r.width - 1, Math.floor(x * r.width / ts.tileWidth))];
	return {
		width: ts.tileWidth,
		height: ts.tileHeight,
		pixels
	};
}
function replaceTilesetImage(doc, c) {
	const ts = doc.tilesets.find((t) => t.id === c.tilesetId);
	if (!ts) fail$2("Tileset missing");
	assertTilesetEditable(doc, ts.id);
	const slots = tilesetSlots(doc, ts), index = integer$4(c.tileIndex, "Tile index", 0, slots.count - 1), tile = slots.entries.get(index);
	if (!tile) fail$2(ts.flags & 1 ? "External tileset artwork must be embedded before editing" : "Virtual or missing tile artwork cannot be edited");
	if (c.width !== ts.tileWidth || c.height !== ts.tileHeight) fail$2("Tile image dimensions must match the tileset grid");
	const capacity = Math.max(doc.palette.length, ...doc.frames.map((f) => f.palette?.length ?? 0)), pixels = validatePixels({
		width: c.width,
		height: c.height,
		pixels: c.pixels
	}, {
		...doc,
		palette: { length: capacity }
	}, "Tile image");
	if (ts.imageId && Number.isInteger(tile.asepriteTileId)) {
		const original = doc.images[ts.imageId];
		if (!original || original.tilemap) fail$2("Tileset atlas is missing");
		const columns = Math.floor(original.width / ts.tileWidth), x = index % columns * ts.tileWidth, y = Math.floor(index / columns) * ts.tileHeight;
		if (columns < 1 || y + ts.tileHeight > original.height) fail$2("Native tile index exceeds its atlas");
		const oldId = ts.imageId, shared = doc.tilesets.some((other) => other.id !== ts.id && (other.imageId === oldId || other.tiles?.some((t) => t.imageId === oldId))) || doc.frames.some((f) => Object.values(f.cels).some((c) => c.imageId === oldId));
		let imageId = oldId;
		if (shared) {
			reserve(doc, original.pixels.length);
			imageId = fresh(doc, "image");
			ts.imageId = imageId;
			for (const t of ts.tiles) if (t.imageId === oldId) t.imageId = imageId;
		}
		const atlas = {
			...original,
			pixels: [...original.pixels]
		};
		for (let yy = 0; yy < ts.tileHeight; yy++) for (let xx = 0; xx < ts.tileWidth; xx++) atlas.pixels[(y + yy) * atlas.width + x + xx] = pixels[yy * ts.tileWidth + xx];
		doc.images[imageId] = atlas;
		tile.imageId = imageId;
		tile.sourceRect = {
			x,
			y,
			width: ts.tileWidth,
			height: ts.tileHeight
		};
	} else {
		const shared = doc.tilesets.some((other) => other.tiles?.some((t) => t !== tile && t.imageId === tile.imageId)) || doc.frames.some((f) => Object.values(f.cels).some((c) => c.imageId === tile.imageId));
		const imageId = shared ? fresh(doc, "image") : tile.imageId;
		if (shared) reserve(doc, pixels.length);
		doc.images[imageId] = {
			width: ts.tileWidth,
			height: ts.tileHeight,
			pixels
		};
		tile.imageId = imageId;
		delete tile.sourceRect;
	}
}
function paintTilemap(doc, c) {
	const layer = layerFor(doc, c.layerId, true);
	if (layer.type !== "tilemap") fail$2("Tile painting requires a tilemap layer");
	const frame = frameFor(doc, c.frameId), ts = doc.tilesets.find((t) => t.id === (c.tilesetId ?? layer.tilemaps?.[frame.id]?.tilesetId ?? layer.tilesetId));
	if (!ts) fail$2("Tileset missing");
	const previous = layer.tilemaps?.[frame.id] ?? nativeMap(doc, layer, frame, ts), columns = integer$4(c.columns ?? previous?.columns ?? Math.ceil(doc.width / ts.tileWidth), "Tile columns", 1, 2048), rows = integer$4(c.rows ?? previous?.rows ?? Math.ceil(doc.height / ts.tileHeight), "Tile rows", 1, 2048);
	if (columns * rows > 1048576) fail$2("Tilemap too large");
	const cells = Array(columns * rows).fill(null);
	if (previous) for (let y = 0; y < Math.min(rows, previous.rows); y++) for (let x = 0; x < Math.min(columns, previous.columns); x++) cells[y * columns + x] = previous.cells[y * previous.columns + x];
	if (!Array.isArray(c.points) || c.points.length > 65536) fail$2("Invalid tile paint points");
	for (const p of c.points) {
		const x = integer$4(p.x, "Tile x", 0, columns - 1), y = integer$4(p.y, "Tile y", 0, rows - 1);
		cells[y * columns + x] = p.tileId == null ? null : {
			tileId: id(p.tileId),
			flipX: !!p.flipX,
			flipY: !!p.flipY,
			rotate: p.rotate ?? 0
		};
	}
	const map = {
		...previous ?? {},
		tilesetId: ts.id,
		columns,
		rows,
		cells
	};
	validateTilemap(doc, map);
	layer.tilemaps = {
		...layer.tilemaps ?? {},
		[frame.id]: map
	};
	layer.tilesetId = ts.id;
}
function stampImage(doc, c, changed) {
	const width = integer$4(c.width, "Stamp width", 1, LIMITS.imageEdge), height = integer$4(c.height, "Stamp height", 1, LIMITS.imageEdge);
	if (width * height > LIMITS.pixels || !Array.isArray(c.pixels) || c.pixels.length !== width * height) fail$2("Stamp pixels size mismatch");
	const x0 = integer$4(c.x ?? 0, "Stamp x", -65535, 65535), y0 = integer$4(c.y ?? 0, "Stamp y", -65535, 65535), opacity = finite(c.opacity ?? 1, "Stamp opacity", 0, 1), transparent = c.transparent ?? "skip";
	if (!["skip", "replace"].includes(transparent)) fail$2("Invalid transparent-pixel mode");
	const ctx = context(doc, c, changed), pixels = c.pixels.map((p) => encodeColor(ctx.doc, p));
	for (let y = Math.max(0, -y0); y < Math.min(height, doc.height - y0); y++) for (let x = Math.max(0, -x0); x < Math.min(width, doc.width - x0); x++) {
		const source = pixels[y * width + x];
		if (source === null) {
			if (transparent === "replace") ctx.put(x + x0, y + y0, null);
			continue;
		}
		if (c.blend === false && opacity === 1) ctx.put(x + x0, y + y0, source);
		else {
			const out = new Uint8ClampedArray(pixelRGBA(ctx.doc, ctx.get(x + x0, y + y0)));
			blendAt(out, 0, pixelRGBA(ctx.doc, source), opacity, "normal");
			ctx.put(x + x0, y + y0, encodeColor(ctx.doc, hex$2([...out])));
		}
	}
}
function removeUnusedTile(doc, tileset, tileId) {
	if (!tileId) return;
	const used = /* @__PURE__ */ new Set();
	for (const layer of doc.layers) if (layer.type === "tilemap") for (const frame of doc.frames) {
		const map = layer.tilemaps?.[frame.id] ?? (layer.tilesetId === tileset.id ? nativeMap(doc, layer, frame, tileset) : null);
		if (map?.tilesetId === tileset.id) {
			for (const cell of map.cells) if (cell) used.add(cell.tileId);
		}
	}
	if (used.has(tileId)) return;
	if (!tileset.tiles.find((tile) => tile.id === tileId)) return;
	if (!(!!tileset.imageId && Number.isInteger(tileset.asepriteId))) {
		tileset.tiles = tileset.tiles.filter((tile) => tile.id !== tileId);
		gcImages(doc);
		return;
	}
	for (const layer of doc.layers) if (layer.type === "tilemap" && layer.tilesetId === tileset.id) for (const frame of doc.frames) {
		if (layer.tilemaps?.[frame.id]) continue;
		const map = nativeMap(doc, layer, frame, tileset);
		if (map) layer.tilemaps = {
			...layer.tilemaps ?? {},
			[frame.id]: map
		};
	}
	const remaining = tileset.tiles.filter((tile) => tile.id !== tileId && !(tileset.flags & 4 && tile.asepriteTileId === 0 && !used.has(tile.id)));
	const plans = remaining.map((tile) => ({
		tile,
		pixels: getTile(doc, tileset.id, tile.id).pixels
	}));
	const tileUserData = tileset.tileUserData;
	tileset.tiles = [];
	delete tileset.imageId;
	delete tileset.tileCount;
	delete tileset.externalFileId;
	delete tileset.externalTilesetId;
	tileset.flags = ((tileset.flags ?? 0) | 6) & -2;
	if (tileUserData) tileset.tileUserData = [null, ...remaining.map((tile) => tileUserData[tile.asepriteTileId] ?? null)];
	gcImages(doc);
	for (const { tile, pixels } of plans) {
		reserve(doc, pixels.length);
		const imageId = fresh(doc, "image");
		doc.images[imageId] = {
			width: tileset.tileWidth,
			height: tileset.tileHeight,
			pixels
		};
		const copy = {
			...tile,
			imageId
		};
		delete copy.sourceRect;
		delete copy.asepriteTileId;
		tileset.tiles.push(copy);
	}
}
function editTilemap(doc, c) {
	const layer = layerFor(doc, c.layerId, true);
	if (layer.type !== "tilemap") fail$2("Tile editing requires a tilemap layer");
	const frame = frameFor(doc, c.frameId), ts = doc.tilesets.find((t) => t.id === (layer.tilemaps?.[frame.id]?.tilesetId ?? layer.tilesetId));
	if (!ts) fail$2("Tileset missing");
	const map = layer.tilemaps?.[frame.id] ?? nativeMap(doc, layer, frame, ts);
	if (!map) fail$2("Paint an initial tilemap cell before editing tiles");
	const x = integer$4(c.x, "Tile x", 0, map.columns - 1), y = integer$4(c.y, "Tile y", 0, map.rows - 1), mode = c.mode ?? "auto";
	if (![
		"manual",
		"auto",
		"stack"
	].includes(mode)) fail$2("Tile edit mode must be manual, auto, or stack");
	if (!Array.isArray(c.pixels) || c.pixels.length !== ts.tileWidth * ts.tileHeight) fail$2("Tile pixel dimensions mismatch");
	const working = colorContext(doc, frame.id, layer.id), pixels = c.pixels.map((p) => encodeColor(working, p)), previous = map.cells[y * map.columns + x];
	let tile;
	if (mode === "manual") {
		tile = ts.tiles.find((t) => t.id === previous?.tileId);
		if (!tile) fail$2("Manual editing requires a nonempty tile");
		const source = doc.images[tile.imageId];
		if (tile.sourceRect) {
			const r = tile.sourceRect, updated = [...source.pixels];
			for (let y = 0; y < r.height; y++) for (let x = 0; x < r.width; x++) updated[(r.y + y) * source.width + r.x + x] = pixels[Math.min(ts.tileHeight - 1, Math.floor(y * ts.tileHeight / r.height)) * ts.tileWidth + Math.min(ts.tileWidth - 1, Math.floor(x * ts.tileWidth / r.width))];
			doc.images[tile.imageId] = {
				...source,
				pixels: updated
			};
		} else {
			reserve(doc, pixels.length, tile.imageId);
			doc.images[tile.imageId] = {
				...source,
				width: ts.tileWidth,
				height: ts.tileHeight,
				pixels
			};
		}
		return;
	}
	if (!(mode === "auto" && pixels.every((pixel) => pixelRGBA(working, pixel)[3] === 0))) {
		if (mode === "auto") tile = ts.tiles.find((t) => getTile(doc, ts.id, t.id).pixels.every((p, i) => p === pixels[i]));
		if (!tile) {
			if (mode === "auto" && previous?.tileId) {
				const cleared = [...map.cells];
				cleared[y * map.columns + x] = null;
				layer.tilemaps = {
					...layer.tilemaps ?? {},
					[frame.id]: {
						...map,
						cells: cleared
					}
				};
				removeUnusedTile(doc, ts, previous.tileId);
			}
			if (ts.tiles.length >= 65536) fail$2("Tileset limit reached");
			reserve(doc, pixels.length);
			const imageId = fresh(doc, "image");
			doc.images[imageId] = {
				width: ts.tileWidth,
				height: ts.tileHeight,
				pixels
			};
			let n = 1;
			while (ts.tiles.some((t) => t.id === `tile-${n}`)) n++;
			tile = {
				id: `tile-${n}`,
				imageId
			};
			ts.tiles.push(tile);
		}
	}
	const cells = [...map.cells];
	cells[y * map.columns + x] = tile ? {
		tileId: tile.id,
		flipX: previous?.flipX ?? false,
		flipY: previous?.flipY ?? false,
		rotate: previous?.rotate ?? 0
	} : null;
	layer.tilemaps = {
		...layer.tilemaps ?? {},
		[frame.id]: {
			...map,
			cells
		}
	};
	if (mode === "auto" && previous?.tileId !== tile?.id) removeUnusedTile(doc, ts, previous?.tileId);
}
function duplicateLayer(doc, c) {
	const source = layerFor(doc, c.layerId), ids = new Set([source.id]);
	let again = true;
	while (again) {
		again = false;
		for (const l of doc.layers) if (ids.has(l.parentId) && !ids.has(l.id)) {
			ids.add(l.id);
			again = true;
		}
	}
	const originals = doc.layers.filter((l) => ids.has(l.id));
	if (doc.layers.length + originals.length > LIMITS.layers) fail$2("Layer limit reached");
	const copies = [], idMap = /* @__PURE__ */ new Map(), imageMap = /* @__PURE__ */ new Map();
	for (const l of originals) {
		const copy = {
			...jsonCopy(l),
			id: fresh(doc, "layer"),
			name: l.id === source.id ? name(c.name, `${l.name} copy`) : l.name
		};
		idMap.set(l.id, copy.id);
		doc.layers.push(copy);
		copies.push(copy);
	}
	for (const copy of copies) if (idMap.has(copy.parentId)) copy.parentId = idMap.get(copy.parentId);
	doc.layers = doc.layers.filter((l) => !copies.includes(l));
	const at = doc.layers.indexOf(originals.at(-1)) + 1;
	doc.layers.splice(at, 0, ...copies);
	for (const frame of doc.frames) for (const original of originals) {
		const cel = frame.cels[original.id];
		if (!cel) continue;
		let imageId = cel.imageId;
		if (!c.linked) if (imageMap.has(imageId)) imageId = imageMap.get(imageId);
		else {
			const image = doc.images[imageId], key = fresh(doc, "image");
			reserve(doc, image.width * image.height);
			doc.images[key] = {
				...image,
				pixels: [...image.pixels],
				...image.tilemap ? { tilemap: jsonCopy(image.tilemap) } : {}
			};
			imageMap.set(imageId, key);
			imageId = key;
		}
		frame.cels[idMap.get(original.id)] = {
			...cel,
			imageId
		};
	}
}
function descendantIds(doc, rootIds) {
	const ids = new Set(rootIds);
	let added = true;
	while (added) {
		added = false;
		for (const layer of doc.layers) if (ids.has(layer.parentId) && !ids.has(layer.id)) {
			ids.add(layer.id);
			added = true;
		}
	}
	return ids;
}
function rasterLayer(source, patch = {}) {
	const layer = {
		...source,
		...patch,
		type: "image"
	};
	delete layer.tilemaps;
	delete layer.tilesetId;
	delete layer.asepriteTilesetIndex;
	delete layer.reference;
	if (layer.asepriteFlags !== void 0) layer.asepriteFlags &= -65;
	return layer;
}
/** Bake selected whole layer subtrees, preserving off-canvas artwork and frame links.
* Root blend/opacity can stay on the replacement, or be baked against transparency.
* Non-normal blends that depend on unselected backdrop layers cannot be reproduced
* by an isolated normal layer; Merge Down matches that native editor convention. */
function bakeLayerTrees(doc, rootIds, replacement, { forceRootsVisible = false, preserveRootStyle = false } = {}) {
	const included = descendantIds(doc, rootIds), rootSet = new Set(rootIds), source = shallowDocument(doc);
	for (const layerId of included) layerFor(doc, layerId, true);
	const sourceLayers = source.layers.filter((layer) => included.has(layer.id));
	const renderLayers = sourceLayers.map((layer) => rootSet.has(layer.id) ? {
		...layer,
		parentId: null,
		visible: forceRootsVisible || layer.visible,
		...preserveRootStyle ? {
			opacity: 1,
			blendMode: "normal"
		} : {}
	} : layer);
	const byId = new Map(renderLayers.map((layer) => [layer.id, layer]));
	function visible(layer) {
		for (let item = layer; item; item = item.parentId ? byId.get(item.parentId) : null) if (!item.visible || item.opacity === 0) return false;
		return true;
	}
	const visibleLayers = renderLayers.filter(visible), cache = /* @__PURE__ */ new Map(), linkCache = /* @__PURE__ */ new Map();
	let work = 0;
	const insertion = source.layers.findIndex((layer) => layer.id === replacement.id);
	if (insertion < 0) fail$2("Flatten replacement layer is missing");
	doc.layers = source.layers.filter((layer) => !included.has(layer.id));
	doc.layers.splice(source.layers.slice(0, insertion).filter((layer) => !included.has(layer.id)).length, 0, replacement);
	for (const frame of doc.frames) for (const layerId of included) delete frame.cels[layerId];
	gcImages(doc);
	for (const frame of doc.frames) {
		const originalFrame = frameFor(source, frame.id), palette = getFramePalette(source, frame.id);
		const sourceLinks = sourceLayers.map((layer) => [
			layer.id,
			originalFrame.cels[layer.id] ?? null,
			layer.tilemaps?.[frame.id] ?? null
		]), linkSignature = JSON.stringify(sourceLinks);
		const signature = JSON.stringify([source.colorMode === "indexed" ? palette : null, sourceLinks]);
		if (cache.has(signature)) {
			const cel = cache.get(signature);
			if (cel) frame.cels[replacement.id] = { ...cel };
			continue;
		}
		let left = Infinity, top = Infinity, right = -Infinity, bottom = -Infinity;
		function addBounds(x, y, width, height) {
			if (width <= 0 || height <= 0) return;
			left = Math.min(left, Math.floor(x));
			top = Math.min(top, Math.floor(y));
			right = Math.max(right, Math.ceil(x + width));
			bottom = Math.max(bottom, Math.ceil(y + height));
		}
		for (const layer of visibleLayers) {
			if (layer.type === "group") continue;
			const cel = originalFrame.cels[layer.id], image = source.images[cel?.imageId];
			if (layer.type === "tilemap") {
				const map = layer.tilemaps?.[frame.id], tileset = source.tilesets.find((ts) => ts.id === (map?.tilesetId ?? layer.tilesetId));
				if (!tileset) fail$2("Cannot flatten a tilemap with a missing tileset");
				if (!tileset.tiles?.length && !tileset.imageId && tileset.externalFileId != null) fail$2("Embed external tileset pixels before flattening");
				if (map) addBounds(map.x ?? 0, map.y ?? 0, map.columns * tileset.tileWidth, map.rows * tileset.tileHeight);
				else if (image) addBounds(cel.x, cel.y, image.width * tileset.tileWidth, image.height * tileset.tileHeight);
			} else if (image) {
				const bounds = cel.preciseBounds;
				if (bounds?.flags & 1) addBounds(bounds.x, bounds.y, bounds.width, bounds.height);
				else addBounds(cel.x, cel.y, image.width, image.height);
			}
		}
		if (left === Infinity) {
			cache.set(signature, null);
			continue;
		}
		const width = right - left, height = bottom - top;
		integer$4(width, "Flattened image width", 1, LIMITS.imageEdge);
		integer$4(height, "Flattened image height", 1, LIMITS.imageEdge);
		if (width * height > LIMITS.pixels) fail$2("Flattened layer exceeds the pixel budget", "MEMORY_BUDGET");
		work += width * height * Math.max(1, visibleLayers.filter((layer) => layer.type !== "group").length);
		if (work > LIMITS.operations) fail$2("Flatten operation exceeds the work budget", "MEMORY_BUDGET");
		const cels = {};
		for (const layer of sourceLayers) {
			const cel = originalFrame.cels[layer.id];
			if (cel) cels[layer.id] = {
				...cel,
				x: cel.x - left,
				y: cel.y - top,
				...cel.preciseBounds ? { preciseBounds: {
					...cel.preciseBounds,
					x: cel.preciseBounds.x - left,
					y: cel.preciseBounds.y - top
				} } : {}
			};
		}
		const shiftedLayers = renderLayers.map((layer) => {
			const map = layer.tilemaps?.[frame.id];
			return map ? {
				...layer,
				tilemaps: { [frame.id]: {
					...map,
					x: (map.x ?? 0) - left,
					y: (map.y ?? 0) - top
				} }
			} : layer;
		});
		const rgbaPixels = renderFrame({
			...source,
			width,
			height,
			palette,
			layers: shiftedLayers,
			frames: [{
				...originalFrame,
				palette,
				cels
			}]
		}, frame.id);
		let minX = width, minY = height, maxX = -1, maxY = -1;
		for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) if (rgbaPixels[(y * width + x) * 4 + 3]) {
			minX = Math.min(minX, x);
			minY = Math.min(minY, y);
			maxX = Math.max(maxX, x);
			maxY = Math.max(maxY, y);
		}
		if (maxX < 0) {
			cache.set(signature, null);
			continue;
		}
		const outputWidth = maxX - minX + 1, outputHeight = maxY - minY + 1, pixels = Array(outputWidth * outputHeight), working = colorContext({
			...source,
			layers: source.layers.map((layer) => layer.id === replacement.id ? replacement : layer)
		}, frame.id, replacement.id);
		for (let y = 0; y < outputHeight; y++) for (let x = 0; x < outputWidth; x++) {
			const offset = ((y + minY) * width + x + minX) * 4;
			pixels[y * outputWidth + x] = rgbaPixels[offset + 3] ? encodeColor(working, hex$2([...rgbaPixels.subarray(offset, offset + 4)])) : null;
		}
		const x = integer$4(left + minX, "Flattened cel x", -65535, 65535), y = integer$4(top + minY, "Flattened cel y", -65535, 65535);
		const linked = linkCache.get(linkSignature) ?? [];
		let imageId = linked.find((candidate) => candidate.x === x && candidate.y === y && candidate.width === outputWidth && candidate.height === outputHeight && candidate.pixels.every((pixel, index) => pixel === pixels[index]))?.imageId;
		if (!imageId) {
			reserve(doc, pixels.length);
			imageId = fresh(doc, "image");
			doc.images[imageId] = {
				width: outputWidth,
				height: outputHeight,
				pixels
			};
			linked.push({
				imageId,
				x,
				y,
				width: outputWidth,
				height: outputHeight,
				pixels
			});
			linkCache.set(linkSignature, linked);
		}
		const previous = originalFrame.cels[replacement.id], cel = {
			...previous?.userData ? { userData: jsonCopy(previous.userData) } : {},
			imageId,
			x,
			y,
			opacity: 1
		};
		frame.cels[replacement.id] = cel;
		cache.set(signature, cel);
	}
}
function mergeDown(doc, c) {
	if (c.visibleOnly !== void 0 && typeof c.visibleOnly !== "boolean") fail$2("visibleOnly must be a boolean");
	const upper = layerFor(doc, c.layerId, true), at = doc.layers.indexOf(upper), lower = [...doc.layers.slice(0, at)].reverse().find((layer) => layer.parentId === upper.parentId);
	if (!lower) fail$2("No lower sibling layer to merge");
	const visibleOnly = c.visibleOnly === true, replacement = rasterLayer(lower, {
		name: name(c.name, lower.name),
		opacity: 1,
		blendMode: "normal",
		visible: visibleOnly ? lower.visible || upper.visible : lower.visible
	});
	bakeLayerTrees(doc, [lower.id, upper.id], replacement, { forceRootsVisible: !visibleOnly });
}
function flattenLayer(doc, c) {
	const layer = layerFor(doc, c.layerId, true), replacement = rasterLayer(layer, { name: name(c.name, layer.name) });
	bakeLayerTrees(doc, [layer.id], replacement, {
		forceRootsVisible: true,
		preserveRootStyle: true
	});
}
function flattenDocument(doc, c) {
	if (c.visibleOnly !== void 0 && typeof c.visibleOnly !== "boolean") fail$2("visibleOnly must be a boolean");
	const visibleOnly = c.visibleOnly !== false, roots = doc.layers.filter((layer) => layer.parentId === null && (!visibleOnly || layer.visible));
	if (!roots.length) return;
	const first = roots[0], replacement = rasterLayer(first, {
		name: name(c.name, "Flattened"),
		visible: true,
		opacity: 1,
		blendMode: "normal"
	});
	if (replacement.asepriteFlags !== void 0) replacement.asepriteFlags &= -9;
	bakeLayerTrees(doc, roots.map((layer) => layer.id), replacement);
}
/** A failed command never changes its input. Untouched image objects retain identity. */
function applyCommand(input, command) {
	if (!record$2(command) || typeof command.type !== "string") fail$2("Command type is missing", "INVALID_COMMAND");
	if (input?.format !== "pixelwall-document" || input.version !== 4) fail$2("Normalize the document before editing");
	const doc = shallowDocument(input), c = command, changed = /* @__PURE__ */ new Set();
	switch (c.type) {
		case "batch": {
			if (!Array.isArray(c.commands) || c.commands.length > 1024) fail$2("Invalid command batch");
			let result = input;
			for (const command of c.commands) result = applyCommand(result, command);
			return result;
		}
		case "object.userData": {
			let target;
			if (c.target === "sprite") target = doc;
			else if (c.target === "layer") target = layerFor(doc, c.layerId, true);
			else if (c.target === "cel") {
				const layer = layerFor(doc, c.layerId, true);
				target = frameFor(doc, c.frameId).cels[layer.id];
			} else if (c.target === "tileset" || c.target === "tile") {
				const ts = doc.tilesets.find((t) => t.id === c.tilesetId);
				if (!ts) fail$2("Tileset missing");
				assertTilesetEditable(doc, ts.id);
				if (c.target === "tileset") target = ts;
				else {
					const slots = tilesetSlots(doc, ts), index = integer$4(c.tileIndex, "Tile index", 0, slots.count - 1);
					ts.tileUserData = [...ts.tileUserData ?? []];
					const userData = validateAsepriteUserData(c.userData);
					ts.tileUserData[index] = userData;
					target = slots.entries.get(index);
					if (target) target.userData = userData;
					break;
				}
			} else if (c.target === "tag") target = doc.clips.find((v) => v.id === c.clipId);
			else if (c.target === "slice") target = doc.slices.find((v) => v.id === c.sliceId);
			else fail$2("Unsupported user-data target");
			if (!target) fail$2("User-data target missing");
			target.userData = validateAsepriteUserData(c.userData);
			break;
		}
		case "document.update":
			if (!record$2(c.patch)) fail$2("Document patch missing");
			for (const key of Object.keys(c.patch)) if (!["name", "metadata"].includes(key)) fail$2(`Document field ${key} cannot be patched`);
			if (c.patch.name !== void 0) doc.name = name(c.patch.name, "Untitled Sprite");
			if (c.patch.metadata !== void 0) doc.metadata = jsonCopy(c.patch.metadata);
			break;
		case "document.colorProfile":
			applyColorProfileCommand(doc, c);
			break;
		case "document.resize":
			resizeDocument(doc, c);
			break;
		case "document.nativeColorMode":
			convertNativeColorMode(doc, c, {
				limits: LIMITS,
				getFramePalette
			});
			break;
		case "palette.nativeSet":
			setNativePalette(doc, c, { normalizeColor });
			break;
		case "palette.nativeGenerate":
			generateNativePalette(doc, c, {
				limits: LIMITS,
				normalizeColor,
				renderFrame
			});
			break;
		case "document.colorMode": {
			const configured = [
				"paletteMode",
				"maxColors",
				"quantization",
				"withAlpha",
				"dithering",
				"ditherMatrix",
				"ditherStrength",
				"rgbmap",
				"fitCriteria"
			].some((key) => own$1(c, key));
			if (configured && c.colorMode !== "indexed") fail$2("Palette generation and dithering require indexed color mode");
			convertColorMode(doc, c.colorMode, configured ? { indexedOptions: indexedConversionOptions(c) } : {});
			break;
		}
		case "layer.add": {
			const v = c.layer ?? {};
			const layer = {
				id: v.id ?? fresh(doc, "layer"),
				name: v.name ?? `Layer ${doc.layers.length + 1}`,
				type: v.type ?? "image",
				parentId: v.parentId ?? null,
				visible: v.visible !== false,
				locked: !!v.locked,
				opacity: v.opacity ?? 1,
				blendMode: v.blendMode ?? "normal",
				...jsonCopy(v)
			};
			if (layer.parentId) layerFor(doc, layer.parentId, true);
			if (doc.layers.some((l) => l.id === layer.id)) fail$2("Layer id exists");
			const index = integer$4(c.index ?? doc.layers.length, "Layer index", 0, doc.layers.length);
			doc.layers.splice(index, 0, layer);
			break;
		}
		case "layer.update": {
			const layer = layerFor(doc, c.layerId);
			if (!record$2(c.patch)) fail$2("Layer patch missing");
			for (const key of Object.keys(c.patch)) if (![
				"name",
				"parentId",
				"visible",
				"locked",
				"opacity",
				"blendMode",
				"reference",
				"tilesetId"
			].includes(key)) fail$2(`Layer field ${key} cannot be patched`);
			Object.assign(layer, jsonCopy(c.patch));
			break;
		}
		case "layer.reorder": {
			const layer = layerFor(doc, c.layerId, true), index = integer$4(c.index, "Layer index", 0, doc.layers.length - 1);
			doc.layers.splice(doc.layers.indexOf(layer), 1);
			doc.layers.splice(index, 0, layer);
			break;
		}
		case "layer.duplicate":
			duplicateLayer(doc, c);
			break;
		case "layer.mergeDown":
			mergeDown(doc, c);
			break;
		case "layer.flatten":
			flattenLayer(doc, c);
			break;
		case "document.flatten":
			flattenDocument(doc, c);
			break;
		case "layer.remove": {
			const layer = layerFor(doc, c.layerId, true), remove = new Set([layer.id]);
			let again = true;
			while (again) {
				again = false;
				for (const l of doc.layers) if (remove.has(l.parentId) && !remove.has(l.id)) {
					remove.add(l.id);
					again = true;
				}
			}
			if (remove.size === doc.layers.length) fail$2("Document must retain a layer");
			doc.layers = doc.layers.filter((l) => !remove.has(l.id));
			for (const f of doc.frames) for (const key of remove) delete f.cels[key];
			break;
		}
		case "frame.add": {
			if (doc.frames.length >= LIMITS.frames) fail$2("Frame limit reached");
			const after = c.afterFrameId ? doc.frames.indexOf(frameFor(doc, c.afterFrameId)) : doc.frames.length - 1, newId = c.id ?? fresh(doc, "frame");
			if (doc.frames.some((f) => f.id === newId)) fail$2("Frame id exists");
			doc.frames.splice(after + 1, 0, {
				id: newId,
				durationMs: integer$4(c.durationMs ?? 125, "Duration", 1, 65535),
				cels: {}
			});
			if (c.clipId) {
				const clip = doc.clips.find((clip) => clip.id === c.clipId);
				if (!clip) fail$2("Clip missing");
				const pos = clip.frameIds.indexOf(c.afterFrameId);
				clip.frameIds.splice(pos < 0 ? clip.frameIds.length : pos + 1, 0, newId);
			}
			break;
		}
		case "frame.duplicate": {
			const frames = targetFrames(doc, c);
			if (doc.frames.length + frames.length > LIMITS.frames) fail$2("Frame limit reached");
			let at = c.afterFrameId ? doc.frames.indexOf(frameFor(doc, c.afterFrameId)) : doc.frames.indexOf(frames.at(-1));
			for (const f of frames) {
				const fid = fresh(doc, "frame"), cels = {};
				for (const [lid, cel] of Object.entries(f.cels)) if (c.linked) cels[lid] = { ...cel };
				else {
					const source = doc.images[cel.imageId];
					reserve(doc, source.width * source.height);
					const imageId = fresh(doc, "image");
					doc.images[imageId] = {
						...source,
						pixels: [...source.pixels],
						...source.tilemap ? { tilemap: jsonCopy(source.tilemap) } : {}
					};
					cels[lid] = {
						...cel,
						imageId
					};
				}
				doc.frames.splice(++at, 0, {
					...f,
					id: fid,
					cels
				});
				for (const layer of doc.layers) if (layer.tilemaps?.[f.id]) layer.tilemaps = {
					...layer.tilemaps,
					[fid]: jsonCopy(layer.tilemaps[f.id])
				};
				if (c.clipId) {
					const clip = doc.clips.find((v) => v.id === c.clipId);
					if (!clip) fail$2("Clip missing");
					clip.frameIds.push(fid);
				}
			}
			break;
		}
		case "frame.update":
			if (!record$2(c.patch) || Object.keys(c.patch).some((k) => ![
				"durationMs",
				"name",
				"pivot"
			].includes(k))) fail$2("Invalid frame patch");
			for (const f of targetFrames(doc, c)) Object.assign(f, jsonCopy(c.patch));
			break;
		case "frame.reorder": {
			const frames = targetFrames(doc, c), selected = new Set(frames.map((f) => f.id)), others = doc.frames.filter((f) => !selected.has(f.id)), index = integer$4(c.index, "Frame insertion index", 0, others.length);
			others.splice(index, 0, ...frames);
			doc.frames = others;
			break;
		}
		case "frame.reverse": {
			const frames = targetFrames(doc, c), ids = new Set(frames.map((f) => f.id)), reverse = [...frames].reverse();
			let i = 0;
			doc.frames = doc.frames.map((f) => ids.has(f.id) ? reverse[i++] : f);
			break;
		}
		case "frame.remove": {
			const ids = new Set(targetFrames(doc, c).map((f) => f.id));
			if (ids.size === doc.frames.length) fail$2("Document must retain a frame");
			doc.frames = doc.frames.filter((f) => !ids.has(f.id));
			doc.slices = doc.slices.map((s) => s.keys ? {
				...s,
				keys: s.keys.filter((k) => !ids.has(k.frameId))
			} : s);
			doc.clips = doc.clips.map((clip) => ({
				...clip,
				frameIds: clip.frameIds.filter((fid) => !ids.has(fid))
			})).filter((clip) => clip.frameIds.length);
			for (const layer of doc.layers) if (layer.tilemaps) {
				layer.tilemaps = { ...layer.tilemaps };
				for (const fid of ids) delete layer.tilemaps[fid];
			}
			break;
		}
		case "cel.set":
			setCel(doc, c);
			break;
		case "image.stamp":
			stampImage(doc, c, changed);
			break;
		case "cel.link": {
			const layer = layerFor(doc, c.layerId, true), source = frameFor(doc, c.sourceFrameId).cels[layer.id];
			if (!source) fail$2("Source cel is empty");
			for (const f of targetFrames(doc, c)) f.cels[layer.id] = { ...source };
			break;
		}
		case "cel.unlink": {
			const layer = layerFor(doc, c.layerId, true);
			for (const f of targetFrames(doc, c)) {
				const cel = f.cels[layer.id];
				if (!cel) continue;
				const source = doc.images[cel.imageId];
				reserve(doc, source.width * source.height);
				const key = fresh(doc, "image");
				doc.images[key] = {
					...source,
					pixels: [...source.pixels],
					...source.tilemap ? { tilemap: jsonCopy(source.tilemap) } : {}
				};
				cel.imageId = key;
			}
			break;
		}
		case "cel.move": {
			const layer = layerFor(doc, c.layerId, true);
			for (const f of targetFrames(doc, c)) {
				const cel = f.cels[layer.id];
				if (!cel) continue;
				cel.x = integer$4(c.x ?? cel.x, "Cel x", -65535, 65535);
				cel.y = integer$4(c.y ?? cel.y, "Cel y", -65535, 65535);
				if (c.opacity !== void 0) cel.opacity = finite(c.opacity, "Cel opacity", 0, 1);
				if (c.zIndex !== void 0) cel.zIndex = integer$4(c.zIndex, "Cel z-index", -2147483648, 2147483647);
			}
			break;
		}
		case "cel.clear": {
			const layer = layerFor(doc, c.layerId, true);
			for (const f of targetFrames(doc, c)) delete f.cels[layer.id];
			break;
		}
		case "draw.stroke":
			drawStroke(context(doc, c, changed), points(c.points), c);
			break;
		case "draw.line":
			drawStroke(context(doc, c, changed), [point(c.from), point(c.to)], c);
			break;
		case "draw.rect":
			drawShape(context(doc, c, changed), c, false);
			break;
		case "draw.ellipse":
			drawShape(context(doc, c, changed), c, true);
			break;
		case "draw.polygon":
			drawPolygon(context(doc, c, changed), c);
			break;
		case "draw.curve":
			drawCurve(context(doc, c, changed), c);
			break;
		case "draw.fill": {
			const ctx = context(doc, c, changed), mask = floodMask(ctx.doc, ctx.get, c), color = encodeColor(ctx.doc, c.color === void 0 ? ctx.doc.palette[0] : c.color);
			for (let i = 0; i < mask.length; i++) if (mask[i]) ctx.put(i % doc.width, Math.floor(i / doc.width), color);
			break;
		}
		case "draw.gradient":
			gradient(context(doc, c, changed), c);
			break;
		case "draw.text":
			drawText(context(doc, c, changed), c);
			break;
		case "selection.transform":
			selectionTransform(doc, c, changed);
			break;
		case "selection.clear": {
			const ctx = context(doc, c, changed);
			if (!ctx.mask) fail$2("Clear selection requires a selection mask");
			for (let y = 0; y < doc.height; y++) for (let x = 0; x < doc.width; x++) ctx.put(x, y, null);
			break;
		}
		case "palette.update":
			paletteEdit(doc, c, false);
			break;
		case "palette.remap":
			paletteEdit(doc, c, true);
			break;
		case "effect.apply":
			applyEffect(doc, c, changed);
			break;
		case "animation.tween":
			tween(doc, c);
			break;
		case "animation.particles":
			particles(doc, c, changed);
			break;
		case "tileset.add":
			addTileset(doc, c);
			break;
		case "tileset.create":
			createNativeTileset(doc, c, {
				fresh,
				reserve,
				limits: LIMITS
			});
			break;
		case "tileset.tileInsert":
		case "tileset.tileRemove":
			changeTilesetSlots(doc, c, {
				fresh,
				reserve,
				limits: LIMITS
			});
			break;
		case "layer.tileset":
			assignLayerTileset(doc, c, {
				fresh,
				reserve,
				limits: LIMITS,
				layerFor
			});
			break;
		case "tileset.tileImage":
			replaceTilesetImage(doc, c);
			break;
		case "tileset.update": {
			const ts = doc.tilesets.find((t) => t.id === c.tilesetId);
			if (!ts) fail$2("Tileset missing");
			assertTilesetEditable(doc, ts.id);
			if (c.patch?.baseIndex !== void 0) integer$4(c.patch.baseIndex, "Tileset base index", -32768, 32767);
			if (!record$2(c.patch) || Object.keys(c.patch).some((k) => ![
				"name",
				"tileWidth",
				"tileHeight",
				"tiles",
				"imageId",
				"baseIndex"
			].includes(k))) fail$2("Invalid tileset patch");
			Object.assign(ts, jsonCopy(c.patch));
			break;
		}
		case "tileset.remove":
			if (doc.layers.some((l) => l.tilesetId === c.tilesetId || Object.values(l.tilemaps ?? {}).some((m) => m.tilesetId === c.tilesetId))) fail$2("Cannot remove a tileset used by a layer");
			if (!doc.tilesets.some((t) => t.id === c.tilesetId)) fail$2("Tileset missing");
			doc.tilesets = doc.tilesets.filter((t) => t.id !== c.tilesetId);
			break;
		case "tilemap.paint":
			paintTilemap(doc, c);
			break;
		case "tilemap.edit":
			editTilemap(doc, c);
			break;
		case "clip.add": {
			const v = c.clip ?? {};
			doc.clips.push({
				id: v.id ?? fresh(doc, "clip"),
				name: v.name ?? "Animation",
				frameIds: v.frameIds ?? doc.frames.map((f) => f.id),
				direction: v.direction ?? "forward",
				loop: v.loop !== false
			});
			break;
		}
		case "clip.update": {
			const clip = doc.clips.find((v) => v.id === c.clipId);
			if (!clip) fail$2("Clip missing");
			if (!record$2(c.patch) || Object.keys(c.patch).some((k) => ![
				"name",
				"frameIds",
				"direction",
				"loop",
				"repeat",
				"color"
			].includes(k))) fail$2("Invalid clip patch");
			Object.assign(clip, jsonCopy(c.patch));
			break;
		}
		case "clip.remove":
			if (!doc.clips.some((v) => v.id === c.clipId)) fail$2("Clip missing");
			doc.clips = doc.clips.filter((v) => v.id !== c.clipId);
			break;
		case "slice.add": {
			const v = c.slice ?? {};
			doc.slices.push({
				...jsonCopy(v),
				id: v.id ?? fresh(doc, "slice"),
				name: v.name ?? "Slice"
			});
			break;
		}
		case "slice.update": {
			const s = doc.slices.find((v) => v.id === c.sliceId);
			if (!s) fail$2("Slice missing");
			if (!record$2(c.patch) || Object.keys(c.patch).some((k) => ![
				"name",
				"bounds",
				"pivot",
				"ninePatch",
				"keys"
			].includes(k))) fail$2("Invalid slice patch");
			Object.assign(s, jsonCopy(c.patch));
			if (c.patch.keys !== void 0) delete s.bounds;
			break;
		}
		case "slice.remove":
			if (!doc.slices.some((v) => v.id === c.sliceId)) fail$2("Slice missing");
			doc.slices = doc.slices.filter((v) => v.id !== c.sliceId);
			break;
		default: fail$2(`Unknown command: ${c.type}`, "UNKNOWN_COMMAND");
	}
	gcImages(doc);
	return normalizeDocument(doc, { shareImages: true });
}
const TARGET = {
	frameId: "Optional frame id; defaults to first frame.",
	layerId: "Optional raster layer id; defaults to first image layer."
};
const RANGE = { frameIds: "Nonempty list of unique frame ids; or pass frameId for one frame." };
const DRAW = {
	...TARGET,
	color: "Hex RGB/RGBA string, palette index, or null (transparent).",
	selection: "Optional canvas-size array of 0/1; restricts affected pixels."
};
const STROKE = {
	...DRAW,
	size: "Integer 1–256 (default 1).",
	brush: "square | circle",
	mask: "Optional {width,height,pixels:[0|1],colors?:[RGBA|null]}; maximum 256×256.",
	symmetry: "none | x | y | both",
	wrap: "none | x | y | both; true is both. Wraps brush pixels and line paths for seamless tiles.",
	pressure: "false ignores point pressures; true or omitted uses supplied point pressures.",
	pixelPerfect: "Boolean; removes 1px orthogonal corners along the sampled path.",
	erase: "Boolean; stamps transparency.",
	ink: "paint | lighten | darken | shading",
	amount: "Lighten/darken amount 0–1 (default .12).",
	ramp: "Shading ink: ordered palette-index or color array; defaults to the active frame palette.",
	shadeStep: "Shading ink: signed steps along ramp; default -1. Endpoints clamp; unlisted colors are unchanged."
};
Object.freeze([
	[
		"batch",
		"Apply an ordered command list atomically.",
		{ commands: "Array of up to 1024 command objects." }
	],
	[
		"object.userData",
		"Replace native user data on a sprite, layer, cel, tag, slice, tileset or tile.",
		{
			target: "sprite | layer | cel | tag | slice | tileset | tile",
			tilesetId: "Tileset/tile target ID",
			tileIndex: "Zero-based native tile index",
			layerId: "Layer target ID",
			frameId: "Cel frame ID",
			clipId: "Tag target ID",
			sliceId: "Slice target ID",
			userData: "{text?,color?:#rrggbbaa,propertiesBytes?:native property block}"
		}
	],
	[
		"document.update",
		"Rename the document or replace metadata.",
		{ patch: "{name?:string,metadata?:object}" }
	],
	[
		"document.colorProfile",
		"Assign a working profile or apply a bounded precomputed color conversion.",
		{
			profile: "{type:0|1|2,flags?:0|1,gamma?:number,icc?:byte[],name?:string}",
			replacements: "Optional validated images/palette/framePalettes; preserves dimensions, IDs, links, layers and color mode."
		}
	],
	[
		"document.resize",
		"Resize canvas or nearest-neighbor artwork.",
		{
			width: "Integer 1–65535; width × height ≤ 4194304",
			height: "Integer 1–65535; width × height ≤ 4194304",
			mode: "canvas | scale",
			anchor: "top-left | center (canvas mode)"
		}
	],
	[
		"document.nativeColorMode",
		"Convert native pixel format with first-exposure image links, indexed cel-opacity reset and grayscale palette reset.",
		{
			colorMode: "rgba | grayscale | indexed",
			rgbmap: "octree (default) | rgb5a3",
			fitCriteria: "default | rgb | linearizedRGB | ciexyz | cielab",
			dithering: "none | aseprite-ordered | aseprite-old | aseprite-error-diffusion",
			ditherMatrix: "bayer2x2 | bayer4x4 | bayer8x8",
			toGray: "luma | hsv | hsl"
		}
	],
	[
		"palette.nativeSet",
		"Replace one existing effective palette key without remapping pixels.",
		{
			frameId: "Frame using the palette key; defaults first",
			paletteFrameIds: "Optional ordered existing key frames",
			palette: "1–256 RGBA colors"
		}
	],
	[
		"palette.nativeGenerate",
		"Generate a palette from all visible frames and replace the active palette key without remapping pixels.",
		{
			frameId: "Active frame",
			paletteFrameIds: "Optional ordered existing key frames",
			algorithm: "octree (default) | rgb5a3",
			maxColors: "2–256, default 256",
			withAlpha: "Boolean, default true",
			colors: "Optional sorted selected palette entries; empty means no-op"
		}
	],
	[
		"document.colorMode",
		"Convert pixel storage between working color modes.",
		{
			colorMode: "rgba | indexed | grayscale",
			paletteMode: "existing (default) | generate; supplying indexed options enables explicit indexed remapping.",
			maxColors: "Generated palette limit 2–256, including transparent slot; default 256.",
			quantization: "median-cut (default, stored artwork) | octree | rgb5a3 (native algorithms sampling visible composited frames).",
			rgbmap: "pixelwall (legacy default) | octree | rgb5a3; native quantization/dithering defaults to octree.",
			fitCriteria: "default | rgb | linearizedRGB | ciexyz | cielab; non-default fitting requires a native RGB map.",
			withAlpha: "Generated palette retains partial alpha unless false; transparent pixels remain transparent.",
			dithering: "none | ordered | floyd-steinberg | aseprite-ordered | aseprite-old | aseprite-error-diffusion; legacy/native modes require matching RGB map.",
			ditherMatrix: "bayer2x2 | bayer4x4 (default) | bayer8x8",
			ditherStrength: "0–1, default 1; native ordered/old require 1; native diffusion uses integer percentage strength."
		}
	],
	[
		"layer.add",
		"Insert image, group, reference, or tilemap layer.",
		{
			layer: "{id?,name?,type?,parentId?,visible?,locked?,opacity?,blendMode?}",
			index: "Optional bottom-to-top insertion index."
		}
	],
	[
		"layer.update",
		"Update layer properties.",
		{
			layerId: "Layer id",
			patch: "{name?,parentId?,visible?,locked?,opacity?,blendMode?,reference?,tilesetId?}"
		}
	],
	[
		"layer.reorder",
		"Move a layer within bottom-to-top order.",
		{
			layerId: "Layer id",
			index: "Zero-based destination index."
		}
	],
	[
		"layer.duplicate",
		"Duplicate a layer or group hierarchy with independent image copies.",
		{
			layerId: "Layer id",
			name: "Optional duplicate name",
			linked: "True shares original image objects; false preserves linking only within the copied hierarchy."
		}
	],
	[
		"layer.mergeDown",
		"Bake two adjacent sibling subtrees into the lower raster layer across all frames.",
		{
			layerId: "Upper image/group/reference/tilemap layer id.",
			visibleOnly: "Default false includes both root layers regardless of visibility and retains lower visibility, matching native Merge Down. True uses current root visibility.",
			name: "Optional result name. Root blend modes/opacity bake against transparency, so blends depending on an outside backdrop may change appearance; use document.flatten for the whole visible composite."
		}
	],
	[
		"layer.flatten",
		"Rasterize one layer or group across all frames, retaining root visibility, opacity and blend mode.",
		{
			layerId: "Image/group/reference/tilemap root. Visible descendants are baked; hidden descendants are removed with the flattened subtree.",
			name: "Optional result name. Off-canvas pixels and equal-source frame links are retained within document budgets."
		}
	],
	[
		"document.flatten",
		"Bake the visible document composite into one normal raster layer across all frames.",
		{
			visibleOnly: "Default true retains hidden root layers separately. False removes hidden root layers as well, without adding their hidden pixels to the result.",
			name: "Optional result name; default Flattened."
		}
	],
	[
		"layer.remove",
		"Remove a layer and all descendants.",
		{ layerId: "Layer id; at least one layer must remain." }
	],
	[
		"frame.add",
		"Insert an empty animation frame.",
		{
			id: "Optional new id",
			afterFrameId: "Optional preceding frame id",
			durationMs: "1–65535; default125",
			clipId: "Optional clip receiving the frame."
		}
	],
	[
		"frame.duplicate",
		"Duplicate a frame range with independent or shared images.",
		{
			...RANGE,
			frameId: "Single frame id",
			afterFrameId: "Optional insertion anchor",
			linked: "Boolean; default false",
			clipId: "Optional clip to append duplicates to."
		}
	],
	[
		"frame.update",
		"Change duration or metadata for a frame range.",
		{
			...RANGE,
			frameId: "Single frame id",
			patch: "{durationMs?:1–65535,name?:string,pivot?:object}"
		}
	],
	[
		"frame.reorder",
		"Move a frame range to an insertion index.",
		{
			...RANGE,
			index: "Index among unselected frames."
		}
	],
	[
		"frame.reverse",
		"Reverse the selected animation frames.",
		RANGE
	],
	[
		"frame.remove",
		"Remove frames and repair clips/tilemaps.",
		RANGE
	],
	[
		"cel.set",
		"Import or replace a cel with decoded pixels.",
		{
			...TARGET,
			width: "Image width",
			height: "Image height",
			pixels: "Flat RGBA|null|palette-index array, width×height",
			x: "Optional integer offset",
			y: "Optional integer offset",
			opacity: "0–1",
			editLinked: "False by default; true replaces the shared image."
		}
	],
	[
		"image.stamp",
		"Paste image pixels into an existing cel.",
		{
			...DRAW,
			width: "Stamp width",
			height: "Stamp height",
			pixels: "Flat decoded RGBA|null|palette-index array.",
			x: "Destination left; default0",
			y: "Destination top; default0",
			transparent: "skip (default) | replace",
			blend: "true (default) composites source-over; false replaces pixels.",
			opacity: "0–1; default1"
		}
	],
	[
		"cel.link",
		"Reference one cel image from multiple frames.",
		{
			...RANGE,
			layerId: "Layer id",
			sourceFrameId: "Frame containing the source cel."
		}
	],
	[
		"cel.unlink",
		"Give selected cels independent images.",
		{
			...RANGE,
			layerId: "Layer id"
		}
	],
	[
		"cel.move",
		"Change cel offsets, opacity or drawing order across frames.",
		{
			...RANGE,
			layerId: "Layer id",
			x: "Integer -65535…65535",
			y: "Integer -65535…65535",
			opacity: "Optional 0–1",
			zIndex: "Optional signed 32-bit integer; portable sprite files require -32768…32767"
		}
	],
	[
		"cel.clear",
		"Remove cels from selected frames.",
		{
			...RANGE,
			layerId: "Layer id"
		}
	],
	[
		"draw.stroke",
		"Paint a pressure-aware freehand path with custom brush and symmetry.",
		{
			...STROKE,
			points: "Array of {x,y,pressure?:0–1}."
		}
	],
	[
		"draw.line",
		"Draw a straight pixel line.",
		{
			...STROKE,
			from: "{x,y}",
			to: "{x,y}"
		}
	],
	[
		"draw.rect",
		"Draw a rectangle.",
		{
			...DRAW,
			x: "Integer left",
			y: "Integer top",
			width: "Positive width",
			height: "Positive height",
			filled: "Boolean",
			size: "Outline thickness1–256"
		}
	],
	[
		"draw.ellipse",
		"Draw an ellipse.",
		{
			...DRAW,
			x: "Integer left",
			y: "Integer top",
			width: "Positive width",
			height: "Positive height",
			filled: "Boolean",
			size: "Outline thickness1–256"
		}
	],
	[
		"draw.polygon",
		"Draw a closed polygon or its filled interior.",
		{
			...STROKE,
			points: "2–4096 vertices {x,y}; at least3 for fill.",
			filled: "Boolean"
		}
	],
	[
		"draw.curve",
		"Rasterize quadratic or cubic Bézier curve.",
		{
			...STROKE,
			points: "[start,control,end] or [start,control1,control2,end]."
		}
	],
	[
		"draw.fill",
		"Flood fill matching connected pixels or all matching colors.",
		{
			...DRAW,
			x: "Seed x",
			y: "Seed y",
			tolerance: "Channel tolerance0–255",
			contiguous: "Boolean; default true"
		}
	],
	[
		"draw.gradient",
		"Paint an RGBA gradient or ordered two-color Bayer dither.",
		{
			...DRAW,
			from: "{x,y}",
			to: "{x,y}",
			endColor: "Ending color",
			dither: "Boolean; default false"
		}
	],
	[
		"draw.text",
		"Rasterize text with included 5×7 bitmap font or custom glyphs.",
		{
			...DRAW,
			x: "Text x",
			y: "Text y",
			text: "Up to4096 characters",
			scale: "Integer1–64",
			spacing: "Glyph spacing0–64",
			lineHeight: "Line advance1–128",
			font: "Optional {width,height,glyphs:{character:[0|1]}}."
		}
	],
	[
		"selection.transform",
		"Move, scale, rotate, flip, or copy a masked raster region.",
		{
			...TARGET,
			selection: "Canvas-size array of0/1; required.",
			operation: "move | scale | rotate | flipX | flipY",
			dx: "Translation pixels",
			dy: "Translation pixels",
			scaleX: "Scale .01–64",
			scaleY: "Scale .01–64",
			angle: "Clockwise degrees",
			method: "nearest (default; Fast rotation alias) | fast | rotsprite | pixel-safe (RotSprite alias). Fast/RotSprite are rotation-only; RotSprite uses the MIT native8× algorithm. Temporary owned buffers limited to64MiB. Corner coordinates are rounded to the pixel grid.",
			pivot: "Optional {x,y}; defaults to selection center.",
			copy: "False moves/cuts, true copies."
		}
	],
	[
		"selection.clear",
		"Erase pixels under a mask.",
		{
			...TARGET,
			selection: "Canvas-size array of0/1; required."
		}
	],
	[
		"palette.update",
		"Edit scoped palette entries; indexed pixels retain their indices.",
		{
			palette: "1–65536 RGBA hex colors. Cannot remove used indexed entries.",
			scope: "all (default with no selectors) | frame | range",
			frameId: "Frame for frame scope; defaults to the first frame. A frameId without scope infers frame.",
			frameIds: "Nonempty unique frame IDs for range scope. frameIds without scope infers range."
		}
	],
	[
		"palette.remap",
		"Replace scoped palettes and remap pixels in their effective color context.",
		{
			palette: "New RGBA palette.",
			mapping: "Optional old-index→new-index array; null clears that entry. Must cover every selected old palette. Omit to find nearest colors.",
			scope: "all (default with no selectors) | frame | range",
			frameId: "Frame for frame scope; defaults first. Inferred when provided without scope.",
			frameIds: "Nonempty unique frame IDs for range scope; inferred when provided without scope."
		}
	],
	[
		"effect.apply",
		"Apply destructive raster effect to selected unique images.",
		{
			...DRAW,
			...RANGE,
			effect: "replace | outline | brightness | contrast | hue | saturation | convolution | despeckle",
			fromColor: "Replace source color; omit to replace all opaque pixels.",
			toColor: "Replacement color.",
			amount: "Brightness/saturation -1…1; contrast -.99….99; hue degrees-360…360.",
			radius: "Outline radius1–64",
			diagonal: "Boolean, default true.",
			kernel: "Odd square numeric array, up to15×15.",
			divisor: "Optional nonzero convolution divisor.",
			bias: "Optional convolution RGB bias-255…255.",
			affectAlpha: "Convolve alpha as well."
		}
	],
	[
		"animation.tween",
		"Bake or link reusable deterministic 2D position/opacity tween.",
		{
			...RANGE,
			layerId: "Raster layer id",
			sourceFrameId: "Optional source cel frame.",
			from: "{x?,y?,opacity?}",
			to: "{x?,y?,opacity?}",
			easing: "linear | easeIn | easeOut | easeInOut | bounce",
			bake: "Default true creates independent images; false links images.",
			id: "Optional reusable preset key in metadata.motion."
		}
	],
	[
		"animation.particles",
		"Bake deterministic 2D particle simulation into cels.",
		{
			...RANGE,
			layerId: "Image layer id",
			seed: "Unsigned32-bit integer",
			count: "1–4096",
			x: "Emitter x",
			y: "Emitter y",
			speed: "Pixels/second0–4096",
			angle: "Emission direction degrees (default -90)",
			spread: "Cone width0–360 degrees",
			gravity: "Pixels/second²",
			lifetime: "Seconds.01–3600",
			emission: "Emission interval in seconds",
			color: "RGBA or palette index",
			size: "1–64",
			fade: "Boolean; default true",
			clear: "Replace target cels unless false.",
			id: "Optional reusable preset key in metadata.motion."
		}
	],
	[
		"tileset.add",
		"Create an independent tileset from images or tile pixels.",
		{
			frameId: "Optional frame palette used to encode tile colors.",
			layerId: "Optional layer for transparent-index semantics.",
			tileset: "{id?,name?,tileWidth,tileHeight,tiles:[{id?,imageId}|{id?,pixels}]}"
		}
	],
	[
		"tileset.create",
		"Create an embedded native tileset, optionally copying a same-document resource.",
		{
			tilesetId: "Optional ID",
			tileWidth: "Positive tile width",
			tileHeight: "Positive tile height",
			tileCount: "Count including tile zero; default 1",
			copyTilesetId: "Optional source tileset",
			gridOrigin: "Optional in-memory {x,y} origin"
		}
	],
	[
		"tileset.tileInsert",
		"Insert tile artwork at an index; native Lua leaves map numbers unchanged.",
		{
			tilesetId: "Tileset ID",
			tileIndex: "Index 1 through count; default append"
		}
	],
	[
		"tileset.tileRemove",
		"Delete tile artwork at an index; native Lua leaves map numbers unchanged.",
		{
			tilesetId: "Tileset ID",
			tileIndex: "Index 1 through count minus one"
		}
	],
	[
		"layer.tileset",
		"Assign a tileset to one layer, retaining map numbers, flags and positions.",
		{
			layerId: "Tilemap layer ID",
			tilesetId: "Destination tileset ID"
		}
	],
	[
		"tileset.tileImage",
		"Replace a tile image while retaining native tile IDs, placements and linked maps.",
		{
			tilesetId: "Tileset id",
			tileIndex: "Zero-based native tile index",
			width: "Exact tile grid width",
			height: "Exact tile grid height",
			pixels: "Exact native-mode raster pixels"
		}
	],
	[
		"tileset.update",
		"Update independent tileset properties and references.",
		{
			tilesetId: "Tileset id",
			patch: "{name?,tileWidth?,tileHeight?,tiles?,imageId?,baseIndex?}"
		}
	],
	[
		"tileset.remove",
		"Remove a tileset unused by layers.",
		{ tilesetId: "Tileset id" }
	],
	[
		"tilemap.paint",
		"Paint independently referenced tiles into a frame tilemap.",
		{
			...TARGET,
			tilesetId: "Tileset id; defaults to existing map.",
			columns: "Optional tile grid width",
			rows: "Optional tile grid height",
			points: "[{x,y,tileId:string|null,flipX?,flipY?,rotate?:0|90|180|270}]"
		}
	],
	[
		"tilemap.edit",
		"Edit intrinsic tile pixels in manual, automatic reuse, or stack mode.",
		{
			...TARGET,
			x: "Tile column",
			y: "Tile row",
			pixels: "Complete tileWidth×tileHeight decoded color array.",
			mode: "manual edits the shared tile; auto reuses/adds tiles and removes the replaced tile when no frame/layer uses it; stack retains prior tiles. Auto transparent pixels clear the cell. Cell transforms are preserved."
		}
	],
	[
		"clip.add",
		"Create an animation tag/clip.",
		{ clip: "{id?,name?,frameIds?,direction?:forward|reverse|pingpong|pingpong_reverse,loop?}" }
	],
	[
		"clip.update",
		"Update an animation tag/clip.",
		{
			clipId: "Clip id",
			patch: "{name?,frameIds?,direction?,loop?,repeat?:0–65535,color?}"
		}
	],
	[
		"clip.remove",
		"Remove an animation tag/clip.",
		{ clipId: "Clip id" }
	],
	[
		"slice.add",
		"Create an export slice with optional pivot and nine-patch.",
		{ slice: "{id?,name?,bounds:{x,y,width,height},pivot?,ninePatch?}" }
	],
	[
		"slice.update",
		"Update a slice.",
		{
			sliceId: "Slice id",
			patch: "{name?,bounds?,pivot?,ninePatch?,keys?}"
		}
	],
	[
		"slice.remove",
		"Remove a slice.",
		{ sliceId: "Slice id" }
	]
].map(([type, description, parameters]) => Object.freeze({
	type,
	description,
	parameters: Object.freeze(parameters)
})));
//#endregion
//#region app/color-management.mjs
/** ICC color transforms. Pixel data stays in the document's working profile;
* canvas/export callers explicitly request sRGB. LittleCMS owns the conversion. */
const MAX_PROFILE_BYTES = 4 * 1024 * 1024;
const SRGB = Object.freeze({
	type: 1,
	flags: 0,
	gamma: 0
});
const bytesOf = (value) => {
	if (!(value instanceof Uint8Array) && !Array.isArray(value)) throw Error("Choose an ICC profile file.");
	if (value.length < 132 || value.length > MAX_PROFILE_BYTES) throw Error("ICC profile must contain 132 bytes to 4 MB.");
	if (Array.isArray(value) && value.some((v) => !Number.isInteger(v) || v < 0 || v > 255)) throw Error("Invalid ICC profile bytes.");
	const bytes = Uint8Array.from(value), view = new DataView(bytes.buffer);
	if (String.fromCharCode(...bytes.subarray(36, 40)) !== "acsp" || view.getUint32(0) !== bytes.length) throw Error("Invalid ICC profile header or length.");
	const count = view.getUint32(128);
	if (count > 4096 || 132 + count * 12 > bytes.length) throw Error("Invalid ICC tag table.");
	for (let i = 0; i < count; i++) {
		const offset = view.getUint32(136 + i * 12), length = view.getUint32(140 + i * 12);
		if (offset < 128 || offset + length > bytes.length) throw Error("ICC tag extends beyond the profile.");
	}
	return bytes;
};
function documentProfile(doc) {
	return doc.metadata?.aseprite?.colorProfile ?? SRGB;
}
function isSRGB(profile) {
	return !profile || profile === "sRGB" || profile.type !== 2 && !(profile.flags & 1);
}
/** Matrix/TRC profile with sRGB primaries and a fixed transfer exponent.
* ICC v2 XYZ/curve tags, D50-adapted colorants; useful for Aseprite fixed gamma. */
function createGammaProfile(gamma = 1) {
	if (!Number.isFinite(gamma) || gamma < .1 || gamma > 10) throw Error("Gamma must be between 0.1 and 10.");
	const enc = new TextEncoder(), tags = [], tag = (sig, data) => tags.push({
		sig,
		data
	});
	const xyz = (values) => {
		const b = new Uint8Array(20), v = new DataView(b.buffer);
		b.set(enc.encode("XYZ "));
		values.forEach((n, i) => v.setInt32(8 + i * 4, Math.round(n * 65536)));
		return b;
	};
	const curve = new Uint8Array(16), cv = new DataView(curve.buffer);
	curve.set(enc.encode("curv"));
	cv.setUint32(8, 1);
	cv.setUint16(12, Math.round(gamma * 256));
	const label = enc.encode(`PixelWall sRGB primaries gamma ${gamma}\0`), description = new Uint8Array(12 + label.length + 78), dv = new DataView(description.buffer);
	description.set(enc.encode("desc"));
	dv.setUint32(8, label.length);
	description.set(label, 12);
	tag("desc", description);
	tag("wtpt", xyz([
		.9642,
		1,
		.8249
	]));
	tag("rXYZ", xyz([
		.4360747,
		.2225045,
		.0139322
	]));
	tag("gXYZ", xyz([
		.3850649,
		.7168786,
		.0971045
	]));
	tag("bXYZ", xyz([
		.1430804,
		.0606169,
		.7141733
	]));
	for (const sig of [
		"rTRC",
		"gTRC",
		"bTRC"
	]) tag(sig, curve);
	tag("cprt", enc.encode("text\0\0\0\0PixelWall generated profile. CC0.\0"));
	let offset = 132 + tags.length * 12;
	for (const t of tags) {
		t.offset = offset;
		offset += Math.ceil(t.data.length / 4) * 4;
	}
	const bytes = new Uint8Array(offset), view = new DataView(bytes.buffer);
	view.setUint32(0, offset);
	view.setUint32(8, 34603008);
	for (const [at, s] of [
		[12, "mntr"],
		[16, "RGB "],
		[20, "XYZ "],
		[36, "acsp"],
		[40, "APPL"],
		[80, "PWAL"]
	]) bytes.set(enc.encode(s), at);
	[
		2026,
		1,
		1,
		0,
		0,
		0
	].forEach((n, i) => view.setUint16(24 + i * 2, n));
	[
		.9642,
		1,
		.8249
	].forEach((n, i) => view.setInt32(68 + i * 4, Math.round(n * 65536)));
	view.setUint32(128, tags.length);
	tags.forEach((t, i) => {
		const at = 132 + i * 12;
		bytes.set(enc.encode(t.sig), at);
		view.setUint32(at + 4, t.offset);
		view.setUint32(at + 8, t.data.length);
		bytes.set(t.data, t.offset);
	});
	return bytes;
}
function createColorManager(lcms, constants) {
	const profiles = /* @__PURE__ */ new Map(), transforms = /* @__PURE__ */ new Map();
	let disposed = false, profileSequence = 0;
	function clearTransforms() {
		for (const handle of transforms.values()) lcms.cmsDeleteTransform(handle);
		transforms.clear();
	}
	function profileInfo(profile = SRGB) {
		if (disposed) throw Error("Color manager has been closed.");
		if (profile === "sRGB") profile = SRGB;
		let key = "sRGB", bytes;
		if (profile?.type === 2) {
			bytes = bytesOf(profile.icc);
			const chunks = [];
			for (let at = 0; at < bytes.length; at += 16384) chunks.push(String.fromCharCode(...bytes.subarray(at, at + 16384)));
			key = chunks.join("");
		} else if (profile?.flags & 1) {
			bytes = createGammaProfile(profile.gamma);
			key = `gamma:${profile.gamma}`;
		}
		if (profiles.has(key)) {
			const info = profiles.get(key);
			profiles.delete(key);
			profiles.set(key, info);
			return info;
		}
		const handle = bytes ? lcms.cmsOpenProfileFromMem(bytes, bytes.length) : lcms.cmsCreate_sRGBProfile();
		if (!handle) throw Error("LittleCMS could not read this ICC profile.");
		const space = lcms.cmsGetColorSpaceASCII(handle);
		if (!["RGB", "GRAY"].includes(space)) {
			lcms.cmsCloseProfile(handle);
			throw Error(`A ${space || "non-RGB"} profile cannot be used with this sprite.`);
		}
		const info = {
			key,
			token: ++profileSequence,
			handle,
			space,
			name: bytes ? lcms.cmsGetProfileInfoASCII(handle, constants.cmsInfoDescription, "en", "US") || "Embedded ICC profile" : "sRGB"
		};
		if (profiles.size >= 8) {
			clearTransforms();
			const oldest = profiles.keys().next().value;
			lcms.cmsCloseProfile(profiles.get(oldest).handle);
			profiles.delete(oldest);
		}
		profiles.set(key, info);
		return info;
	}
	function transformRGBA(input, source = SRGB, destination = SRGB, { intent = 1, blackPointCompensation = true } = {}) {
		if (!ArrayBuffer.isView(input) || input.length % 4) throw Error("Color conversion expects RGBA bytes.");
		if (!Number.isInteger(intent) || intent < 0 || intent > 3) throw Error("Choose a valid rendering intent.");
		const src = profileInfo(source), dst = profileInfo(destination);
		if (src.key === dst.key) return Uint8ClampedArray.from(input);
		const key = `${src.token}>${dst.token}:${intent}:${blackPointCompensation}`;
		let handle = transforms.get(key);
		if (!handle) {
			if (transforms.size >= 128) clearTransforms();
			handle = lcms.cmsCreateTransform(src.handle, src.space === "GRAY" ? constants.TYPE_GRAY_8 : constants.TYPE_RGB_8, dst.handle, dst.space === "GRAY" ? constants.TYPE_GRAY_8 : constants.TYPE_RGB_8, intent, blackPointCompensation ? constants.cmsFLAGS_BLACKPOINTCOMPENSATION : 0);
			if (!handle) throw Error("This ICC profile does not support the requested conversion.");
			transforms.set(key, handle);
		}
		const channels = src.space === "GRAY" ? 1 : 3, count = input.length / 4, packed = new Uint8Array(count * channels);
		for (let i = 0; i < count; i++) for (let c = 0; c < channels; c++) packed[i * channels + c] = input[i * 4 + c];
		const converted = lcms.cmsDoTransform(handle, packed, count), out = new Uint8ClampedArray(input.length), outChannels = dst.space === "GRAY" ? 1 : 3;
		for (let i = 0; i < count; i++) {
			for (let c = 0; c < 3; c++) out[i * 4 + c] = converted[i * outChannels + (outChannels === 1 ? 0 : c)];
			out[i * 4 + 3] = input[i * 4 + 3];
		}
		return out;
	}
	function transformColors(colors, source, destination, options) {
		const packed = new Uint8Array(colors.length * 4);
		colors.forEach((color, i) => {
			const s = normalizeColor(color);
			for (let c = 0; c < 4; c++) packed[i * 4 + c] = parseInt(s.slice(1 + c * 2, 3 + c * 2), 16);
		});
		const converted = transformRGBA(packed, source, destination, options);
		return colors.map((_, i) => "#" + Array.from(converted.subarray(i * 4, i * 4 + 4), (c) => c.toString(16).padStart(2, "0")).join(""));
	}
	function assignProfile(input, profile = SRGB) {
		const doc = normalizeDocument(input);
		if (profileInfo(profile).space === "GRAY" && doc.colorMode !== "grayscale") throw Error("A gray profile requires a grayscale document.");
		const cp = profile === "sRGB" ? SRGB : profile;
		doc.metadata.aseprite = {
			...doc.metadata.aseprite,
			colorProfile: structuredClone(cp)
		};
		return doc;
	}
	function convertDocument(input, profile = SRGB, options) {
		const source = documentProfile(input), destination = profileInfo(profile), doc = assignProfile(input, profile);
		if (destination.space === "RGB" && doc.colorMode === "grayscale" && !isSRGB(profile)) doc.colorMode = "rgba";
		doc.palette = transformColors(doc.palette, source, profile, options);
		for (const frame of doc.frames) if (frame.palette) frame.palette = transformColors(frame.palette, source, profile, options);
		if (doc.colorMode !== "indexed") {
			for (const image of Object.values(doc.images)) if (!image.tilemap) {
				const palette = [...new Set(image.pixels.filter((p) => p !== null))], converted = transformColors(palette, source, profile, options), lookup = new Map(palette.map((p, i) => [p, converted[i]]));
				image.pixels = image.pixels.map((p) => p === null ? null : lookup.get(p));
			}
		}
		if (doc.colorMode === "grayscale" && Object.values(doc.images).some((image) => !image.tilemap && image.pixels.some((p) => p !== null && (p.slice(1, 3) !== p.slice(3, 5) || p.slice(3, 5) !== p.slice(5, 7))))) doc.colorMode = "rgba";
		return normalizeDocument(doc);
	}
	return Object.freeze({
		profileInfo: (profile) => {
			const { space, name } = profileInfo(profile);
			return {
				space,
				name
			};
		},
		readProfile(bytes) {
			const profile = {
				type: 2,
				flags: 0,
				gamma: 0,
				icc: Array.from(bytesOf(bytes))
			};
			profileInfo(profile);
			return profile;
		},
		transformRGBA,
		transformColors,
		assignProfile,
		convertDocument,
		displayFrame: (doc, frameId) => transformRGBA(renderFrame(doc, frameId), documentProfile(doc)),
		displayColor: (doc, color) => transformColors([color], documentProfile(doc), SRGB)[0],
		workingColor: (doc, color) => transformColors([color], SRGB, documentProfile(doc))[0],
		close() {
			if (disposed) return;
			for (const handle of transforms.values()) lcms.cmsDeleteTransform(handle);
			for (const { handle } of profiles.values()) lcms.cmsCloseProfile(handle);
			transforms.clear();
			profiles.clear();
			disposed = true;
		}
	});
}
//#endregion
//#region app/color-runtime-node.mjs
let pending;
function loadNodeColorManager() {
	pending ??= (async () => {
		const distributed = new URL("./runtimes/lcms.wasm", import.meta.url);
		return createColorManager(await instantiate({ wasmBinary: await readFile(existsSync(distributed) ? distributed : new URL("../node_modules/lcms-wasm/dist/lcms.wasm", import.meta.url)) }), lcms_exports);
	})().catch((error) => {
		pending = void 0;
		throw error;
	});
	return pending;
}
//#endregion
//#region app/lua-plugin-session.mjs
/** Worker-local package state. Preferences are returned as staged data only. */
function createLuaPluginSession(options, requestCommand) {
	if (options == null) return null;
	const plugin = validatePluginOptions(options);
	if (typeof requestCommand !== "function") throw Error("Package commands require an explicit interactive host.");
	let catalog, selected, result, requests = 0;
	const parse = (json, limit = LUA_PLUGIN_LIMITS.bytes) => {
		if (typeof json !== "string" || new TextEncoder().encode(json).length > limit) throw Error("Lua package data exceeds its byte limit.");
		return JSON.parse(json);
	};
	return {
		configuration: JSON.stringify(plugin),
		async choose(json) {
			try {
				if (++requests !== 1) throw Error("Only one command choice is allowed per package session.");
				catalog = validatePluginCatalog(parse(json), plugin);
				const choice = validatePluginChoice(await requestCommand(catalog), catalog);
				if (choice.action === "cancel") throw Error("Package command session cancelled. No edits were committed.");
				selected = choice.commandId;
				return JSON.stringify({
					ok: true,
					value: choice
				});
			} catch (error) {
				return JSON.stringify({
					ok: false,
					error: String(error?.message ?? error).slice(0, 4096)
				});
			}
		},
		complete(json) {
			if (!selected || result) throw Error("Invalid package command completion.");
			result = validatePluginResult(parse(json, LUA_PLUGIN_LIMITS.bytes + 1024), plugin, selected);
			return true;
		},
		finish() {
			if (requests !== 1 || !selected || !result) throw Error("The package command did not complete.");
			return structuredClone(result);
		}
	};
}
//#endregion
//#region app/lua-dialog-schema.mjs
var import_dist = (/* @__PURE__ */ __commonJSMin(((exports, module) => {
	(function(global, factory) {
		typeof exports === "object" && typeof module !== "undefined" ? factory(exports) : typeof define === "function" && define.amd ? define(["exports"], factory) : (global = typeof globalThis !== "undefined" ? globalThis : global || self, factory(global.wasmoon = {}));
	})(exports, (function(exports$1) {
		"use strict";
		var _documentCurrentScript = typeof document !== "undefined" ? document.currentScript : null;
		exports$1.LuaReturn = void 0;
		(function(LuaReturn) {
			LuaReturn[LuaReturn["Ok"] = 0] = "Ok";
			LuaReturn[LuaReturn["Yield"] = 1] = "Yield";
			LuaReturn[LuaReturn["ErrorRun"] = 2] = "ErrorRun";
			LuaReturn[LuaReturn["ErrorSyntax"] = 3] = "ErrorSyntax";
			LuaReturn[LuaReturn["ErrorMem"] = 4] = "ErrorMem";
			LuaReturn[LuaReturn["ErrorErr"] = 5] = "ErrorErr";
			LuaReturn[LuaReturn["ErrorFile"] = 6] = "ErrorFile";
		})(exports$1.LuaReturn || (exports$1.LuaReturn = {}));
		const PointerSize = 4;
		const LUA_MULTRET = -1;
		const LUAI_MAXSTACK = 1e6;
		const LUA_REGISTRYINDEX = -LUAI_MAXSTACK - 1e3;
		exports$1.LuaType = void 0;
		(function(LuaType) {
			LuaType[LuaType["None"] = -1] = "None";
			LuaType[LuaType["Nil"] = 0] = "Nil";
			LuaType[LuaType["Boolean"] = 1] = "Boolean";
			LuaType[LuaType["LightUserdata"] = 2] = "LightUserdata";
			LuaType[LuaType["Number"] = 3] = "Number";
			LuaType[LuaType["String"] = 4] = "String";
			LuaType[LuaType["Table"] = 5] = "Table";
			LuaType[LuaType["Function"] = 6] = "Function";
			LuaType[LuaType["Userdata"] = 7] = "Userdata";
			LuaType[LuaType["Thread"] = 8] = "Thread";
		})(exports$1.LuaType || (exports$1.LuaType = {}));
		exports$1.LuaEventCodes = void 0;
		(function(LuaEventCodes) {
			LuaEventCodes[LuaEventCodes["Call"] = 0] = "Call";
			LuaEventCodes[LuaEventCodes["Ret"] = 1] = "Ret";
			LuaEventCodes[LuaEventCodes["Line"] = 2] = "Line";
			LuaEventCodes[LuaEventCodes["Count"] = 3] = "Count";
			LuaEventCodes[LuaEventCodes["TailCall"] = 4] = "TailCall";
		})(exports$1.LuaEventCodes || (exports$1.LuaEventCodes = {}));
		exports$1.LuaEventMasks = void 0;
		(function(LuaEventMasks) {
			LuaEventMasks[LuaEventMasks["Call"] = 1] = "Call";
			LuaEventMasks[LuaEventMasks["Ret"] = 2] = "Ret";
			LuaEventMasks[LuaEventMasks["Line"] = 4] = "Line";
			LuaEventMasks[LuaEventMasks["Count"] = 8] = "Count";
		})(exports$1.LuaEventMasks || (exports$1.LuaEventMasks = {}));
		exports$1.LuaLibraries = void 0;
		(function(LuaLibraries) {
			LuaLibraries["Base"] = "_G";
			LuaLibraries["Coroutine"] = "coroutine";
			LuaLibraries["Table"] = "table";
			LuaLibraries["IO"] = "io";
			LuaLibraries["OS"] = "os";
			LuaLibraries["String"] = "string";
			LuaLibraries["UTF8"] = "utf8";
			LuaLibraries["Math"] = "math";
			LuaLibraries["Debug"] = "debug";
			LuaLibraries["Package"] = "package";
		})(exports$1.LuaLibraries || (exports$1.LuaLibraries = {}));
		class LuaTimeoutError extends Error {}
		class Decoration {
			constructor(target, options) {
				this.target = target;
				this.options = options;
			}
		}
		function decorate(target, options) {
			return new Decoration(target, options);
		}
		class Pointer extends Number {}
		class MultiReturn extends Array {}
		const INSTRUCTION_HOOK_COUNT = 1e3;
		class Thread {
			constructor(lua, typeExtensions, address, parent) {
				this.closed = false;
				this.lua = lua;
				this.typeExtensions = typeExtensions;
				this.address = address;
				this.parent = parent;
			}
			newThread() {
				const address = this.lua.lua_newthread(this.address);
				if (!address) throw new Error("lua_newthread returned a null pointer");
				return new Thread(this.lua, this.typeExtensions, address, this.parent || this);
			}
			resetThread() {
				this.assertOk(this.lua.lua_resetthread(this.address));
			}
			loadString(luaCode, name) {
				const size = this.lua.module.lengthBytesUTF8(luaCode);
				const pointerSize = size + 1;
				const bufferPointer = this.lua.module._malloc(pointerSize);
				try {
					this.lua.module.stringToUTF8(luaCode, bufferPointer, pointerSize);
					this.assertOk(this.lua.luaL_loadbufferx(this.address, bufferPointer, size, name !== null && name !== void 0 ? name : bufferPointer, null));
				} finally {
					this.lua.module._free(bufferPointer);
				}
			}
			loadFile(filename) {
				this.assertOk(this.lua.luaL_loadfilex(this.address, filename, null));
			}
			resume(argCount = 0) {
				const dataPointer = this.lua.module._malloc(PointerSize);
				try {
					this.lua.module.setValue(dataPointer, 0, "i32");
					return {
						result: this.lua.lua_resume(this.address, null, argCount, dataPointer),
						resultCount: this.lua.module.getValue(dataPointer, "i32")
					};
				} finally {
					this.lua.module._free(dataPointer);
				}
			}
			getTop() {
				return this.lua.lua_gettop(this.address);
			}
			setTop(index) {
				this.lua.lua_settop(this.address, index);
			}
			remove(index) {
				return this.lua.lua_remove(this.address, index);
			}
			setField(index, name, value) {
				index = this.lua.lua_absindex(this.address, index);
				this.pushValue(value);
				this.lua.lua_setfield(this.address, index, name);
			}
			async run(argCount = 0, options) {
				const originalTimeout = this.timeout;
				try {
					if ((options === null || options === void 0 ? void 0 : options.timeout) !== void 0) this.setTimeout(Date.now() + options.timeout);
					let resumeResult = this.resume(argCount);
					while (resumeResult.result === exports$1.LuaReturn.Yield) {
						if (this.timeout && Date.now() > this.timeout) {
							if (resumeResult.resultCount > 0) this.pop(resumeResult.resultCount);
							throw new LuaTimeoutError(`thread timeout exceeded`);
						}
						if (resumeResult.resultCount > 0) {
							const lastValue = this.getValue(-1);
							this.pop(resumeResult.resultCount);
							if (lastValue === Promise.resolve(lastValue)) await lastValue;
							else await new Promise((resolve) => setImmediate(resolve));
						} else await new Promise((resolve) => setImmediate(resolve));
						resumeResult = this.resume(0);
					}
					this.assertOk(resumeResult.result);
					return this.getStackValues();
				} finally {
					if ((options === null || options === void 0 ? void 0 : options.timeout) !== void 0) this.setTimeout(originalTimeout);
				}
			}
			runSync(argCount = 0) {
				const base = this.getTop() - argCount - 1;
				this.assertOk(this.lua.lua_pcallk(this.address, argCount, LUA_MULTRET, 0, 0, null));
				return this.getStackValues(base);
			}
			pop(count = 1) {
				this.lua.lua_pop(this.address, count);
			}
			call(name, ...args) {
				const type = this.lua.lua_getglobal(this.address, name);
				if (type !== exports$1.LuaType.Function) throw new Error(`A function of type '${type}' was pushed, expected is ${exports$1.LuaType.Function}`);
				for (const arg of args) this.pushValue(arg);
				const base = this.getTop() - args.length - 1;
				this.lua.lua_callk(this.address, args.length, LUA_MULTRET, 0, null);
				return this.getStackValues(base);
			}
			getStackValues(start = 0) {
				const returns = this.getTop() - start;
				const returnValues = new MultiReturn(returns);
				for (let i = 0; i < returns; i++) returnValues[i] = this.getValue(start + i + 1);
				return returnValues;
			}
			stateToThread(L) {
				var _a;
				return L === ((_a = this.parent) === null || _a === void 0 ? void 0 : _a.address) ? this.parent : new Thread(this.lua, this.typeExtensions, L, this.parent || this);
			}
			pushValue(rawValue, userdata) {
				const decoratedValue = this.getValueDecorations(rawValue);
				const target = decoratedValue.target;
				if (target instanceof Thread) {
					if (!(this.lua.lua_pushthread(target.address) === 1)) this.lua.lua_xmove(target.address, this.address, 1);
					return;
				}
				const startTop = this.getTop();
				switch (typeof target) {
					case "undefined":
						this.lua.lua_pushnil(this.address);
						break;
					case "number":
						if (Number.isInteger(target)) this.lua.lua_pushinteger(this.address, BigInt(target));
						else this.lua.lua_pushnumber(this.address, target);
						break;
					case "string":
						this.lua.lua_pushstring(this.address, target);
						break;
					case "boolean":
						this.lua.lua_pushboolean(this.address, target ? 1 : 0);
						break;
					default: if (!this.typeExtensions.find((wrapper) => wrapper.extension.pushValue(this, decoratedValue, userdata))) throw new Error(`The type '${typeof target}' is not supported by Lua`);
				}
				if (decoratedValue.options.metatable) this.setMetatable(-1, decoratedValue.options.metatable);
				if (this.getTop() !== startTop + 1) throw new Error(`pushValue expected stack size ${startTop + 1}, got ${this.getTop()}`);
			}
			setMetatable(index, metatable) {
				index = this.lua.lua_absindex(this.address, index);
				if (this.lua.lua_getmetatable(this.address, index)) {
					this.pop(1);
					const name = this.getMetatableName(index);
					throw new Error(`data already has associated metatable: ${name || "unknown name"}`);
				}
				this.pushValue(metatable);
				this.lua.lua_setmetatable(this.address, index);
			}
			getMetatableName(index) {
				const metatableNameType = this.lua.luaL_getmetafield(this.address, index, "__name");
				if (metatableNameType === exports$1.LuaType.Nil) return;
				if (metatableNameType !== exports$1.LuaType.String) {
					this.pop(1);
					return;
				}
				const name = this.lua.lua_tolstring(this.address, -1, null);
				this.pop(1);
				return name;
			}
			getValue(index, inputType, userdata) {
				index = this.lua.lua_absindex(this.address, index);
				const type = inputType !== null && inputType !== void 0 ? inputType : this.lua.lua_type(this.address, index);
				switch (type) {
					case exports$1.LuaType.None: return;
					case exports$1.LuaType.Nil: return null;
					case exports$1.LuaType.Number: return this.lua.lua_tonumberx(this.address, index, null);
					case exports$1.LuaType.String: return this.lua.lua_tolstring(this.address, index, null);
					case exports$1.LuaType.Boolean: return Boolean(this.lua.lua_toboolean(this.address, index));
					case exports$1.LuaType.Thread: return this.stateToThread(this.lua.lua_tothread(this.address, index));
					default: {
						let metatableName;
						if (type === exports$1.LuaType.Table || type === exports$1.LuaType.Userdata) metatableName = this.getMetatableName(index);
						const typeExtensionWrapper = this.typeExtensions.find((wrapper) => wrapper.extension.isType(this, index, type, metatableName));
						if (typeExtensionWrapper) return typeExtensionWrapper.extension.getValue(this, index, userdata);
						console.warn(`The type '${this.lua.lua_typename(this.address, type)}' returned is not supported on JS`);
						return new Pointer(this.lua.lua_topointer(this.address, index));
					}
				}
			}
			close() {
				if (this.isClosed()) return;
				if (this.hookFunctionPointer) this.lua.module.removeFunction(this.hookFunctionPointer);
				this.closed = true;
			}
			setTimeout(timeout) {
				if (timeout && timeout > 0) {
					if (!this.hookFunctionPointer) this.hookFunctionPointer = this.lua.module.addFunction(() => {
						if (Date.now() > timeout) {
							this.pushValue(new LuaTimeoutError(`thread timeout exceeded`));
							this.lua.lua_error(this.address);
						}
					}, "vii");
					this.lua.lua_sethook(this.address, this.hookFunctionPointer, exports$1.LuaEventMasks.Count, INSTRUCTION_HOOK_COUNT);
					this.timeout = timeout;
				} else if (this.hookFunctionPointer) {
					this.hookFunctionPointer = void 0;
					this.timeout = void 0;
					this.lua.lua_sethook(this.address, null, 0, 0);
				}
			}
			getTimeout() {
				return this.timeout;
			}
			getPointer(index) {
				return new Pointer(this.lua.lua_topointer(this.address, index));
			}
			isClosed() {
				var _a;
				return !this.address || this.closed || Boolean((_a = this.parent) === null || _a === void 0 ? void 0 : _a.isClosed());
			}
			indexToString(index) {
				const str = this.lua.luaL_tolstring(this.address, index, null);
				this.pop();
				return str;
			}
			dumpStack(log = console.log) {
				const top = this.getTop();
				for (let i = 1; i <= top; i++) {
					const type = this.lua.lua_type(this.address, i);
					const typename = this.lua.lua_typename(this.address, type);
					const pointer = this.getPointer(i);
					const name = this.indexToString(i);
					const value = this.getValue(i, type);
					log(i, typename, pointer, name, value);
				}
			}
			assertOk(result) {
				if (result !== exports$1.LuaReturn.Ok && result !== exports$1.LuaReturn.Yield) {
					const resultString = exports$1.LuaReturn[result];
					const error = /* @__PURE__ */ new Error(`Lua Error(${resultString}/${result})`);
					if (this.getTop() > 0) if (result === exports$1.LuaReturn.ErrorMem) error.message = this.lua.lua_tolstring(this.address, -1, null);
					else {
						const luaError = this.getValue(-1);
						if (luaError instanceof Error) error.stack = luaError.stack;
						error.message = this.indexToString(-1);
					}
					if (result !== exports$1.LuaReturn.ErrorMem) try {
						this.lua.luaL_traceback(this.address, this.address, null, 1);
						const traceback = this.lua.lua_tolstring(this.address, -1, null);
						if (traceback.trim() !== "stack traceback:") error.message = `${error.message}\n${traceback}`;
						this.pop(1);
					} catch (err) {
						console.warn("Failed to generate stack trace", err);
					}
					throw error;
				}
			}
			getValueDecorations(value) {
				return value instanceof Decoration ? value : new Decoration(value, {});
			}
		}
		class Global extends Thread {
			constructor(cmodule, shouldTraceAllocations) {
				if (shouldTraceAllocations) {
					const memoryStats = { memoryUsed: 0 };
					const allocatorFunctionPointer = cmodule.module.addFunction((_userData, pointer, oldSize, newSize) => {
						if (newSize === 0) {
							if (pointer) {
								memoryStats.memoryUsed -= oldSize;
								cmodule.module._free(pointer);
							}
							return 0;
						}
						const endMemoryDelta = pointer ? newSize - oldSize : newSize;
						const endMemory = memoryStats.memoryUsed + endMemoryDelta;
						if (newSize > oldSize && memoryStats.memoryMax && endMemory > memoryStats.memoryMax) return 0;
						const reallocated = cmodule.module._realloc(pointer, newSize);
						if (reallocated) memoryStats.memoryUsed = endMemory;
						return reallocated;
					}, "iiiii");
					const address = cmodule.lua_newstate(allocatorFunctionPointer, null);
					if (!address) {
						cmodule.module.removeFunction(allocatorFunctionPointer);
						throw new Error("lua_newstate returned a null pointer");
					}
					super(cmodule, [], address);
					this.memoryStats = memoryStats;
					this.allocatorFunctionPointer = allocatorFunctionPointer;
				} else super(cmodule, [], cmodule.luaL_newstate());
				if (this.isClosed()) throw new Error("Global state could not be created (probably due to lack of memory)");
			}
			close() {
				if (this.isClosed()) return;
				super.close();
				this.lua.lua_close(this.address);
				if (this.allocatorFunctionPointer) this.lua.module.removeFunction(this.allocatorFunctionPointer);
				for (const wrapper of this.typeExtensions) wrapper.extension.close();
			}
			registerTypeExtension(priority, extension) {
				this.typeExtensions.push({
					extension,
					priority
				});
				this.typeExtensions.sort((a, b) => b.priority - a.priority);
			}
			loadLibrary(library) {
				switch (library) {
					case exports$1.LuaLibraries.Base:
						this.lua.luaopen_base(this.address);
						break;
					case exports$1.LuaLibraries.Coroutine:
						this.lua.luaopen_coroutine(this.address);
						break;
					case exports$1.LuaLibraries.Table:
						this.lua.luaopen_table(this.address);
						break;
					case exports$1.LuaLibraries.IO:
						this.lua.luaopen_io(this.address);
						break;
					case exports$1.LuaLibraries.OS:
						this.lua.luaopen_os(this.address);
						break;
					case exports$1.LuaLibraries.String:
						this.lua.luaopen_string(this.address);
						break;
					case exports$1.LuaLibraries.UTF8:
						this.lua.luaopen_string(this.address);
						break;
					case exports$1.LuaLibraries.Math:
						this.lua.luaopen_math(this.address);
						break;
					case exports$1.LuaLibraries.Debug:
						this.lua.luaopen_debug(this.address);
						break;
					case exports$1.LuaLibraries.Package:
						this.lua.luaopen_package(this.address);
						break;
				}
				this.lua.lua_setglobal(this.address, library);
			}
			get(name) {
				const type = this.lua.lua_getglobal(this.address, name);
				const value = this.getValue(-1, type);
				this.pop();
				return value;
			}
			set(name, value) {
				this.pushValue(value);
				this.lua.lua_setglobal(this.address, name);
			}
			getTable(name, callback) {
				const startStackTop = this.getTop();
				const type = this.lua.lua_getglobal(this.address, name);
				try {
					if (type !== exports$1.LuaType.Table) throw new TypeError(`Unexpected type in ${name}. Expected ${exports$1.LuaType[exports$1.LuaType.Table]}. Got ${exports$1.LuaType[type]}.`);
					callback(startStackTop + 1);
				} finally {
					if (this.getTop() !== startStackTop + 1) console.warn(`getTable: expected stack size ${startStackTop} got ${this.getTop()}`);
					this.setTop(startStackTop);
				}
			}
			getMemoryUsed() {
				return this.getMemoryStatsRef().memoryUsed;
			}
			getMemoryMax() {
				return this.getMemoryStatsRef().memoryMax;
			}
			setMemoryMax(max) {
				this.getMemoryStatsRef().memoryMax = max;
			}
			getMemoryStatsRef() {
				if (!this.memoryStats) throw new Error("Memory allocations is not being traced, please build engine with { traceAllocations: true }");
				return this.memoryStats;
			}
		}
		class LuaTypeExtension {
			constructor(thread, name) {
				this.thread = thread;
				this.name = name;
			}
			isType(_thread, _index, type, name) {
				return type === exports$1.LuaType.Userdata && name === this.name;
			}
			getValue(thread, index, _userdata) {
				const refUserdata = thread.lua.luaL_testudata(thread.address, index, this.name);
				if (!refUserdata) throw new Error(`data does not have the expected metatable: ${this.name}`);
				const referencePointer = thread.lua.module.getValue(refUserdata, "*");
				return thread.lua.getRef(referencePointer);
			}
			pushValue(thread, decoratedValue, _userdata) {
				const { target } = decoratedValue;
				const pointer = thread.lua.ref(target);
				const userDataPointer = thread.lua.lua_newuserdatauv(thread.address, PointerSize, 0);
				thread.lua.module.setValue(userDataPointer, pointer, "*");
				if (exports$1.LuaType.Nil === thread.lua.luaL_getmetatable(thread.address, this.name)) {
					thread.pop(2);
					throw new Error(`metatable not found: ${this.name}`);
				}
				thread.lua.lua_setmetatable(thread.address, -2);
				return true;
			}
		}
		class ErrorTypeExtension extends LuaTypeExtension {
			constructor(thread, injectObject) {
				super(thread, "js_error");
				this.gcPointer = thread.lua.module.addFunction((functionStateAddress) => {
					const userDataPointer = thread.lua.luaL_checkudata(functionStateAddress, 1, this.name);
					const referencePointer = thread.lua.module.getValue(userDataPointer, "*");
					thread.lua.unref(referencePointer);
					return exports$1.LuaReturn.Ok;
				}, "ii");
				if (thread.lua.luaL_newmetatable(thread.address, this.name)) {
					const metatableIndex = thread.lua.lua_gettop(thread.address);
					thread.lua.lua_pushstring(thread.address, "protected metatable");
					thread.lua.lua_setfield(thread.address, metatableIndex, "__metatable");
					thread.lua.lua_pushcclosure(thread.address, this.gcPointer, 0);
					thread.lua.lua_setfield(thread.address, metatableIndex, "__gc");
					thread.pushValue((jsRefError, key) => {
						if (key === "message") return jsRefError.message;
						return null;
					});
					thread.lua.lua_setfield(thread.address, metatableIndex, "__index");
					thread.pushValue((jsRefError) => {
						return jsRefError.message;
					});
					thread.lua.lua_setfield(thread.address, metatableIndex, "__tostring");
				}
				thread.lua.lua_pop(thread.address, 1);
				if (injectObject) thread.set("Error", { create: (message) => {
					if (message && typeof message !== "string") throw new Error("message must be a string");
					return new Error(message);
				} });
			}
			pushValue(thread, decoration) {
				if (!(decoration.target instanceof Error)) return false;
				return super.pushValue(thread, decoration);
			}
			close() {
				this.thread.lua.module.removeFunction(this.gcPointer);
			}
		}
		function createTypeExtension$6(thread, injectObject) {
			return new ErrorTypeExtension(thread, injectObject);
		}
		class RawResult {
			constructor(count) {
				this.count = count;
			}
		}
		function decorateFunction(target, options) {
			return new Decoration(target, options);
		}
		class FunctionTypeExtension extends LuaTypeExtension {
			constructor(thread, options) {
				super(thread, "js_function");
				this.functionRegistry = typeof FinalizationRegistry !== "undefined" ? new FinalizationRegistry((func) => {
					if (!this.thread.isClosed()) this.thread.lua.luaL_unref(this.thread.address, LUA_REGISTRYINDEX, func);
				}) : void 0;
				this.options = options;
				this.callbackContext = thread.newThread();
				this.callbackContextIndex = this.thread.lua.luaL_ref(thread.address, LUA_REGISTRYINDEX);
				if (!this.functionRegistry) console.warn("FunctionTypeExtension: FinalizationRegistry not found. Memory leaks likely.");
				this.gcPointer = thread.lua.module.addFunction((calledL) => {
					thread.lua.luaL_checkudata(calledL, 1, this.name);
					const userDataPointer = thread.lua.luaL_checkudata(calledL, 1, this.name);
					const referencePointer = thread.lua.module.getValue(userDataPointer, "*");
					thread.lua.unref(referencePointer);
					return exports$1.LuaReturn.Ok;
				}, "ii");
				if (thread.lua.luaL_newmetatable(thread.address, this.name)) {
					thread.lua.lua_pushstring(thread.address, "__gc");
					thread.lua.lua_pushcclosure(thread.address, this.gcPointer, 0);
					thread.lua.lua_settable(thread.address, -3);
					thread.lua.lua_pushstring(thread.address, "__metatable");
					thread.lua.lua_pushstring(thread.address, "protected metatable");
					thread.lua.lua_settable(thread.address, -3);
				}
				thread.lua.lua_pop(thread.address, 1);
				this.functionWrapper = thread.lua.module.addFunction((calledL) => {
					const calledThread = thread.stateToThread(calledL);
					const refUserdata = thread.lua.luaL_checkudata(calledL, thread.lua.lua_upvalueindex(1), this.name);
					const refPointer = thread.lua.module.getValue(refUserdata, "*");
					const { target, options } = thread.lua.getRef(refPointer);
					const argsQuantity = calledThread.getTop();
					const args = [];
					if (options.receiveThread) args.push(calledThread);
					if (options.receiveArgsQuantity) args.push(argsQuantity);
					else for (let i = 1; i <= argsQuantity; i++) {
						const value = calledThread.getValue(i);
						if (i !== 1 || !(options === null || options === void 0 ? void 0 : options.self) || value !== options.self) args.push(value);
					}
					try {
						const result = target.apply(options === null || options === void 0 ? void 0 : options.self, args);
						if (result === void 0) return 0;
						else if (result instanceof RawResult) return result.count;
						else if (result instanceof MultiReturn) {
							for (const item of result) calledThread.pushValue(item);
							return result.length;
						} else {
							calledThread.pushValue(result);
							return 1;
						}
					} catch (err) {
						if (err === Infinity) throw err;
						calledThread.pushValue(err);
						return calledThread.lua.lua_error(calledThread.address);
					}
				}, "ii");
			}
			close() {
				this.thread.lua.module.removeFunction(this.gcPointer);
				this.thread.lua.module.removeFunction(this.functionWrapper);
				this.callbackContext.close();
				this.callbackContext.lua.luaL_unref(this.callbackContext.address, LUA_REGISTRYINDEX, this.callbackContextIndex);
			}
			isType(_thread, _index, type) {
				return type === exports$1.LuaType.Function;
			}
			pushValue(thread, decoration) {
				if (typeof decoration.target !== "function") return false;
				const pointer = thread.lua.ref(decoration);
				const userDataPointer = thread.lua.lua_newuserdatauv(thread.address, PointerSize, 0);
				thread.lua.module.setValue(userDataPointer, pointer, "*");
				if (exports$1.LuaType.Nil === thread.lua.luaL_getmetatable(thread.address, this.name)) {
					thread.pop(1);
					thread.lua.unref(pointer);
					throw new Error(`metatable not found: ${this.name}`);
				}
				thread.lua.lua_setmetatable(thread.address, -2);
				thread.lua.lua_pushcclosure(thread.address, this.functionWrapper, 1);
				return true;
			}
			getValue(thread, index) {
				var _a;
				thread.lua.lua_pushvalue(thread.address, index);
				const func = thread.lua.luaL_ref(thread.address, LUA_REGISTRYINDEX);
				const jsFunc = (...args) => {
					var _a;
					if (this.callbackContext.isClosed()) {
						console.warn("Tried to call a function after closing lua state");
						return;
					}
					const callThread = this.callbackContext.newThread();
					try {
						const internalType = callThread.lua.lua_rawgeti(callThread.address, LUA_REGISTRYINDEX, BigInt(func));
						if (internalType !== exports$1.LuaType.Function) {
							const callMetafieldType = callThread.lua.luaL_getmetafield(callThread.address, -1, "__call");
							callThread.pop();
							if (callMetafieldType !== exports$1.LuaType.Function) throw new Error(`A value of type '${internalType}' was pushed but it is not callable`);
						}
						for (const arg of args) callThread.pushValue(arg);
						if ((_a = this.options) === null || _a === void 0 ? void 0 : _a.functionTimeout) callThread.setTimeout(Date.now() + this.options.functionTimeout);
						const status = callThread.lua.lua_pcallk(callThread.address, args.length, 1, 0, 0, null);
						if (status === exports$1.LuaReturn.Yield) throw new Error("cannot yield in callbacks from javascript");
						callThread.assertOk(status);
						if (callThread.getTop() > 0) return callThread.getValue(-1);
						return;
					} finally {
						callThread.close();
						this.callbackContext.pop();
					}
				};
				(_a = this.functionRegistry) === null || _a === void 0 || _a.register(jsFunc, func);
				return jsFunc;
			}
		}
		function createTypeExtension$5(thread, options) {
			return new FunctionTypeExtension(thread, options);
		}
		class NullTypeExtension extends LuaTypeExtension {
			constructor(thread) {
				super(thread, "js_null");
				this.gcPointer = thread.lua.module.addFunction((functionStateAddress) => {
					const userDataPointer = thread.lua.luaL_checkudata(functionStateAddress, 1, this.name);
					const referencePointer = thread.lua.module.getValue(userDataPointer, "*");
					thread.lua.unref(referencePointer);
					return exports$1.LuaReturn.Ok;
				}, "ii");
				if (thread.lua.luaL_newmetatable(thread.address, this.name)) {
					const metatableIndex = thread.lua.lua_gettop(thread.address);
					thread.lua.lua_pushstring(thread.address, "protected metatable");
					thread.lua.lua_setfield(thread.address, metatableIndex, "__metatable");
					thread.lua.lua_pushcclosure(thread.address, this.gcPointer, 0);
					thread.lua.lua_setfield(thread.address, metatableIndex, "__gc");
					thread.pushValue(() => null);
					thread.lua.lua_setfield(thread.address, metatableIndex, "__index");
					thread.pushValue(() => "null");
					thread.lua.lua_setfield(thread.address, metatableIndex, "__tostring");
					thread.pushValue((self, other) => self === other);
					thread.lua.lua_setfield(thread.address, metatableIndex, "__eq");
				}
				thread.lua.lua_pop(thread.address, 1);
				super.pushValue(thread, new Decoration({}, {}));
				thread.lua.lua_setglobal(thread.address, "null");
			}
			getValue(thread, index) {
				if (!thread.lua.luaL_testudata(thread.address, index, this.name)) throw new Error(`data does not have the expected metatable: ${this.name}`);
				return null;
			}
			pushValue(thread, decoration) {
				if ((decoration === null || decoration === void 0 ? void 0 : decoration.target) !== null) return false;
				thread.lua.lua_getglobal(thread.address, "null");
				return true;
			}
			close() {
				this.thread.lua.module.removeFunction(this.gcPointer);
			}
		}
		function createTypeExtension$4(thread) {
			return new NullTypeExtension(thread);
		}
		class PromiseTypeExtension extends LuaTypeExtension {
			constructor(thread, injectObject) {
				super(thread, "js_promise");
				this.gcPointer = thread.lua.module.addFunction((functionStateAddress) => {
					const userDataPointer = thread.lua.luaL_checkudata(functionStateAddress, 1, this.name);
					const referencePointer = thread.lua.module.getValue(userDataPointer, "*");
					thread.lua.unref(referencePointer);
					return exports$1.LuaReturn.Ok;
				}, "ii");
				if (thread.lua.luaL_newmetatable(thread.address, this.name)) {
					const metatableIndex = thread.lua.lua_gettop(thread.address);
					thread.lua.lua_pushstring(thread.address, "protected metatable");
					thread.lua.lua_setfield(thread.address, metatableIndex, "__metatable");
					thread.lua.lua_pushcclosure(thread.address, this.gcPointer, 0);
					thread.lua.lua_setfield(thread.address, metatableIndex, "__gc");
					const checkSelf = (self) => {
						if (Promise.resolve(self) !== self && typeof self.then !== "function") throw new Error("promise method called without self instance");
						return true;
					};
					thread.pushValue({
						next: (self, ...args) => checkSelf(self) && self.then(...args),
						catch: (self, ...args) => checkSelf(self) && self.catch(...args),
						finally: (self, ...args) => checkSelf(self) && self.finally(...args),
						await: decorateFunction((functionThread, self) => {
							checkSelf(self);
							if (functionThread.address === thread.address) throw new Error("cannot await in the main thread");
							let promiseResult = void 0;
							const awaitPromise = self.then((res) => {
								promiseResult = {
									status: "fulfilled",
									value: res
								};
							}).catch((err) => {
								promiseResult = {
									status: "rejected",
									value: err
								};
							});
							const continuance = this.thread.lua.module.addFunction((continuanceState) => {
								if (!promiseResult) return thread.lua.lua_yieldk(functionThread.address, 0, 0, continuance);
								this.thread.lua.module.removeFunction(continuance);
								const continuanceThread = thread.stateToThread(continuanceState);
								if (promiseResult.status === "rejected") {
									continuanceThread.pushValue(promiseResult.value || /* @__PURE__ */ new Error("promise rejected with no error"));
									return this.thread.lua.lua_error(continuanceState);
								}
								if (promiseResult.value instanceof RawResult) return promiseResult.value.count;
								else if (promiseResult.value instanceof MultiReturn) {
									for (const arg of promiseResult.value) continuanceThread.pushValue(arg);
									return promiseResult.value.length;
								} else {
									continuanceThread.pushValue(promiseResult.value);
									return 1;
								}
							}, "iiii");
							functionThread.pushValue(awaitPromise);
							return new RawResult(thread.lua.lua_yieldk(functionThread.address, 1, 0, continuance));
						}, { receiveThread: true })
					});
					thread.lua.lua_setfield(thread.address, metatableIndex, "__index");
					thread.pushValue((self, other) => self === other);
					thread.lua.lua_setfield(thread.address, metatableIndex, "__eq");
				}
				thread.lua.lua_pop(thread.address, 1);
				if (injectObject) thread.set("Promise", {
					create: (callback) => new Promise(callback),
					all: (promiseArray) => {
						if (!Array.isArray(promiseArray)) throw new Error("argument must be an array of promises");
						return Promise.all(promiseArray.map((potentialPromise) => Promise.resolve(potentialPromise)));
					},
					resolve: (value) => Promise.resolve(value)
				});
			}
			close() {
				this.thread.lua.module.removeFunction(this.gcPointer);
			}
			pushValue(thread, decoration) {
				if (Promise.resolve(decoration.target) !== decoration.target && typeof decoration.target.then !== "function") return false;
				return super.pushValue(thread, decoration);
			}
		}
		function createTypeExtension$3(thread, injectObject) {
			return new PromiseTypeExtension(thread, injectObject);
		}
		function decorateProxy(target, options) {
			return new Decoration(target, options || {});
		}
		class ProxyTypeExtension extends LuaTypeExtension {
			constructor(thread) {
				super(thread, "js_proxy");
				this.gcPointer = thread.lua.module.addFunction((functionStateAddress) => {
					const userDataPointer = thread.lua.luaL_checkudata(functionStateAddress, 1, this.name);
					const referencePointer = thread.lua.module.getValue(userDataPointer, "*");
					thread.lua.unref(referencePointer);
					return exports$1.LuaReturn.Ok;
				}, "ii");
				if (thread.lua.luaL_newmetatable(thread.address, this.name)) {
					const metatableIndex = thread.lua.lua_gettop(thread.address);
					thread.lua.lua_pushstring(thread.address, "protected metatable");
					thread.lua.lua_setfield(thread.address, metatableIndex, "__metatable");
					thread.lua.lua_pushcclosure(thread.address, this.gcPointer, 0);
					thread.lua.lua_setfield(thread.address, metatableIndex, "__gc");
					thread.pushValue((self, key) => {
						switch (typeof key) {
							case "number": key = key - 1;
							case "string": break;
							default: throw new Error("Only strings or numbers can index js objects");
						}
						const value = self[key];
						if (typeof value === "function") return decorateFunction(value, { self });
						return value;
					});
					thread.lua.lua_setfield(thread.address, metatableIndex, "__index");
					thread.pushValue((self, key, value) => {
						switch (typeof key) {
							case "number": key = key - 1;
							case "string": break;
							default: throw new Error("Only strings or numbers can index js objects");
						}
						self[key] = value;
					});
					thread.lua.lua_setfield(thread.address, metatableIndex, "__newindex");
					thread.pushValue((self) => {
						var _a, _b;
						return (_b = (_a = self.toString) === null || _a === void 0 ? void 0 : _a.call(self)) !== null && _b !== void 0 ? _b : typeof self;
					});
					thread.lua.lua_setfield(thread.address, metatableIndex, "__tostring");
					thread.pushValue((self) => {
						return self.length || 0;
					});
					thread.lua.lua_setfield(thread.address, metatableIndex, "__len");
					thread.pushValue((self) => {
						const keys = Object.getOwnPropertyNames(self);
						let i = 0;
						return MultiReturn.of(() => {
							const ret = MultiReturn.of(keys[i], self[keys[i]]);
							i++;
							return ret;
						}, self, null);
					});
					thread.lua.lua_setfield(thread.address, metatableIndex, "__pairs");
					thread.pushValue((self, other) => {
						return self === other;
					});
					thread.lua.lua_setfield(thread.address, metatableIndex, "__eq");
					thread.pushValue((self, ...args) => {
						if (args[0] === self) args.shift();
						return self(...args);
					});
					thread.lua.lua_setfield(thread.address, metatableIndex, "__call");
				}
				thread.lua.lua_pop(thread.address, 1);
			}
			isType(_thread, _index, type, name) {
				return type === exports$1.LuaType.Userdata && name === this.name;
			}
			getValue(thread, index) {
				const refUserdata = thread.lua.lua_touserdata(thread.address, index);
				const referencePointer = thread.lua.module.getValue(refUserdata, "*");
				return thread.lua.getRef(referencePointer);
			}
			pushValue(thread, decoratedValue) {
				var _a;
				const { target, options } = decoratedValue;
				if (options.proxy === void 0) {
					if (target === null || target === void 0) return false;
					if (typeof target !== "object") {
						if (!(typeof target === "function" && ((_a = target.prototype) === null || _a === void 0 ? void 0 : _a.constructor) === target && target.toString().startsWith("class "))) return false;
					}
					if (Promise.resolve(target) === target || typeof target.then === "function") return false;
				} else if (options.proxy === false) return false;
				if (options.metatable && !(options.metatable instanceof Decoration)) {
					decoratedValue.options.metatable = decorateProxy(options.metatable, { proxy: false });
					return false;
				}
				return super.pushValue(thread, decoratedValue);
			}
			close() {
				this.thread.lua.module.removeFunction(this.gcPointer);
			}
		}
		function createTypeExtension$2(thread) {
			return new ProxyTypeExtension(thread);
		}
		class TableTypeExtension extends LuaTypeExtension {
			constructor(thread) {
				super(thread, "js_table");
			}
			close() {}
			isType(_thread, _index, type) {
				return type === exports$1.LuaType.Table;
			}
			getValue(thread, index, userdata) {
				const seenMap = userdata || /* @__PURE__ */ new Map();
				const pointer = thread.lua.lua_topointer(thread.address, index);
				let table = seenMap.get(pointer);
				if (!table) {
					const keys = this.readTableKeys(thread, index);
					table = keys.length > 0 && keys.every((key, index) => key === String(index + 1)) ? [] : {};
					seenMap.set(pointer, table);
					this.readTableValues(thread, index, seenMap, table);
				}
				return table;
			}
			pushValue(thread, { target }, userdata) {
				if (typeof target !== "object" || target === null) return false;
				const seenMap = userdata || /* @__PURE__ */ new Map();
				const existingReference = seenMap.get(target);
				if (existingReference !== void 0) {
					thread.lua.lua_rawgeti(thread.address, LUA_REGISTRYINDEX, BigInt(existingReference));
					return true;
				}
				try {
					const tableIndex = thread.getTop() + 1;
					const createTable = (arrayCount, keyCount) => {
						thread.lua.lua_createtable(thread.address, arrayCount, keyCount);
						const ref = thread.lua.luaL_ref(thread.address, LUA_REGISTRYINDEX);
						seenMap.set(target, ref);
						thread.lua.lua_rawgeti(thread.address, LUA_REGISTRYINDEX, BigInt(ref));
					};
					if (Array.isArray(target)) {
						createTable(target.length, 0);
						for (let i = 0; i < target.length; i++) {
							thread.pushValue(i + 1, seenMap);
							thread.pushValue(target[i], seenMap);
							thread.lua.lua_settable(thread.address, tableIndex);
						}
					} else {
						createTable(0, Object.getOwnPropertyNames(target).length);
						for (const key in target) {
							thread.pushValue(key, seenMap);
							thread.pushValue(target[key], seenMap);
							thread.lua.lua_settable(thread.address, tableIndex);
						}
					}
				} finally {
					if (userdata === void 0) for (const reference of seenMap.values()) thread.lua.luaL_unref(thread.address, LUA_REGISTRYINDEX, reference);
				}
				return true;
			}
			readTableKeys(thread, index) {
				const keys = [];
				thread.lua.lua_pushnil(thread.address);
				while (thread.lua.lua_next(thread.address, index)) {
					const key = thread.indexToString(-2);
					keys.push(key);
					thread.pop();
				}
				return keys;
			}
			readTableValues(thread, index, seenMap, table) {
				const isArray = Array.isArray(table);
				thread.lua.lua_pushnil(thread.address);
				while (thread.lua.lua_next(thread.address, index)) {
					const key = thread.indexToString(-2);
					const value = thread.getValue(-1, void 0, seenMap);
					if (isArray) table.push(value);
					else table[key] = value;
					thread.pop();
				}
			}
		}
		function createTypeExtension$1(thread) {
			return new TableTypeExtension(thread);
		}
		function decorateUserdata(target) {
			return new Decoration(target, { reference: true });
		}
		class UserdataTypeExtension extends LuaTypeExtension {
			constructor(thread) {
				super(thread, "js_userdata");
				this.gcPointer = thread.lua.module.addFunction((functionStateAddress) => {
					const userDataPointer = thread.lua.luaL_checkudata(functionStateAddress, 1, this.name);
					const referencePointer = thread.lua.module.getValue(userDataPointer, "*");
					thread.lua.unref(referencePointer);
					return exports$1.LuaReturn.Ok;
				}, "ii");
				if (thread.lua.luaL_newmetatable(thread.address, this.name)) {
					const metatableIndex = thread.lua.lua_gettop(thread.address);
					thread.lua.lua_pushstring(thread.address, "protected metatable");
					thread.lua.lua_setfield(thread.address, metatableIndex, "__metatable");
					thread.lua.lua_pushcclosure(thread.address, this.gcPointer, 0);
					thread.lua.lua_setfield(thread.address, metatableIndex, "__gc");
				}
				thread.lua.lua_pop(thread.address, 1);
			}
			isType(_thread, _index, type, name) {
				return type === exports$1.LuaType.Userdata && name === this.name;
			}
			getValue(thread, index) {
				const refUserdata = thread.lua.lua_touserdata(thread.address, index);
				const referencePointer = thread.lua.module.getValue(refUserdata, "*");
				return thread.lua.getRef(referencePointer);
			}
			pushValue(thread, decoratedValue) {
				if (!decoratedValue.options.reference) return false;
				return super.pushValue(thread, decoratedValue);
			}
			close() {
				this.thread.lua.module.removeFunction(this.gcPointer);
			}
		}
		function createTypeExtension(thread) {
			return new UserdataTypeExtension(thread);
		}
		class LuaEngine {
			constructor(cmodule, { openStandardLibs = true, injectObjects = false, enableProxy = true, traceAllocations = false, functionTimeout = void 0 } = {}) {
				this.cmodule = cmodule;
				this.global = new Global(this.cmodule, traceAllocations);
				this.global.registerTypeExtension(0, createTypeExtension$1(this.global));
				this.global.registerTypeExtension(0, createTypeExtension$5(this.global, { functionTimeout }));
				this.global.registerTypeExtension(1, createTypeExtension$3(this.global, injectObjects));
				if (injectObjects) this.global.registerTypeExtension(5, createTypeExtension$4(this.global));
				if (enableProxy) this.global.registerTypeExtension(3, createTypeExtension$2(this.global));
				else this.global.registerTypeExtension(1, createTypeExtension$6(this.global, injectObjects));
				this.global.registerTypeExtension(4, createTypeExtension(this.global));
				if (openStandardLibs) this.cmodule.luaL_openlibs(this.global.address);
			}
			doString(script) {
				return this.callByteCode((thread) => thread.loadString(script));
			}
			doFile(filename) {
				return this.callByteCode((thread) => thread.loadFile(filename));
			}
			doStringSync(script) {
				this.global.loadString(script);
				return this.global.runSync()[0];
			}
			doFileSync(filename) {
				this.global.loadFile(filename);
				return this.global.runSync()[0];
			}
			async callByteCode(loader) {
				const thread = this.global.newThread();
				const threadIndex = this.global.getTop();
				try {
					loader(thread);
					const result = await thread.run(0);
					if (result.length > 0) {
						this.cmodule.lua_xmove(thread.address, this.global.address, result.length);
						return this.global.getValue(this.global.getTop() - result.length + 1);
					}
					return;
				} finally {
					this.global.remove(threadIndex);
				}
			}
		}
		var initWasmModule = (() => {
			var _scriptDir = typeof document === "undefined" && typeof location === "undefined" ? __require("url").pathToFileURL(__filename).href : typeof document === "undefined" ? location.href : _documentCurrentScript && _documentCurrentScript.src || new URL("index.js", document.baseURI).href;
			return (async function(moduleArg = {}) {
				var e = moduleArg, aa, ba;
				e.ready = new Promise((a, b) => {
					aa = a;
					ba = b;
				});
				"_malloc _free _realloc _luaL_checkversion_ _luaL_getmetafield _luaL_callmeta _luaL_tolstring _luaL_argerror _luaL_typeerror _luaL_checklstring _luaL_optlstring _luaL_checknumber _luaL_optnumber _luaL_checkinteger _luaL_optinteger _luaL_checkstack _luaL_checktype _luaL_checkany _luaL_newmetatable _luaL_setmetatable _luaL_testudata _luaL_checkudata _luaL_where _luaL_fileresult _luaL_execresult _luaL_ref _luaL_unref _luaL_loadfilex _luaL_loadbufferx _luaL_loadstring _luaL_newstate _luaL_len _luaL_addgsub _luaL_gsub _luaL_setfuncs _luaL_getsubtable _luaL_traceback _luaL_requiref _luaL_buffinit _luaL_prepbuffsize _luaL_addlstring _luaL_addstring _luaL_addvalue _luaL_pushresult _luaL_pushresultsize _luaL_buffinitsize _lua_newstate _lua_close _lua_newthread _lua_resetthread _lua_atpanic _lua_version _lua_absindex _lua_gettop _lua_settop _lua_pushvalue _lua_rotate _lua_copy _lua_checkstack _lua_xmove _lua_isnumber _lua_isstring _lua_iscfunction _lua_isinteger _lua_isuserdata _lua_type _lua_typename _lua_tonumberx _lua_tointegerx _lua_toboolean _lua_tolstring _lua_rawlen _lua_tocfunction _lua_touserdata _lua_tothread _lua_topointer _lua_arith _lua_rawequal _lua_compare _lua_pushnil _lua_pushnumber _lua_pushinteger _lua_pushlstring _lua_pushstring _lua_pushcclosure _lua_pushboolean _lua_pushlightuserdata _lua_pushthread _lua_getglobal _lua_gettable _lua_getfield _lua_geti _lua_rawget _lua_rawgeti _lua_rawgetp _lua_createtable _lua_newuserdatauv _lua_getmetatable _lua_getiuservalue _lua_setglobal _lua_settable _lua_setfield _lua_seti _lua_rawset _lua_rawseti _lua_rawsetp _lua_setmetatable _lua_setiuservalue _lua_callk _lua_pcallk _lua_load _lua_dump _lua_yieldk _lua_resume _lua_status _lua_isyieldable _lua_setwarnf _lua_warning _lua_error _lua_next _lua_concat _lua_len _lua_stringtonumber _lua_getallocf _lua_setallocf _lua_toclose _lua_closeslot _lua_getstack _lua_getinfo _lua_getlocal _lua_setlocal _lua_getupvalue _lua_setupvalue _lua_upvalueid _lua_upvaluejoin _lua_sethook _lua_gethook _lua_gethookmask _lua_gethookcount _lua_setcstacklimit _luaopen_base _luaopen_coroutine _luaopen_table _luaopen_io _luaopen_os _luaopen_string _luaopen_utf8 _luaopen_math _luaopen_debug _luaopen_package _luaL_openlibs _memory ___indirect_function_table _fflush onRuntimeInitialized".split(" ").forEach((a) => {
					Object.getOwnPropertyDescriptor(e.ready, a) || Object.defineProperty(e.ready, a, {
						get: () => g("You are getting " + a + " on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js"),
						set: () => g("You are setting " + a + " on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js")
					});
				});
				var ca = Object.assign({}, e), da = "./this.program", ea = (a, b) => {
					throw b;
				}, fa = "object" == typeof window, k = "function" == typeof importScripts, n = "object" == typeof process && "object" == typeof process.versions && "string" == typeof process.versions.node, ha = !fa && !n && !k;
				if (e.ENVIRONMENT) throw Error("Module.ENVIRONMENT has been deprecated. To force the environment, use the ENVIRONMENT compile-time option (for example, -sENVIRONMENT=web or -sENVIRONMENT=node)");
				var r = "", ia, ja, ka;
				if (n) {
					if ("undefined" == typeof process || !process.release || "node" !== process.release.name) throw Error("not compiled for this environment (did you build to HTML and try to run it not on the web, or set ENVIRONMENT to something - like node - and run it someplace else - like on the web?)");
					var la = process.versions.node, ma = la.split(".").slice(0, 3);
					ma = 1e4 * ma[0] + 100 * ma[1] + 1 * ma[2].split("-")[0];
					if (16e4 > ma) throw Error("This emscripten-generated code requires node v16.0.0 (detected v" + la + ")");
					const { createRequire: a } = await import("module");
					var require$1 = a(typeof document === "undefined" && typeof location === "undefined" ? __require("url").pathToFileURL(__filename).href : typeof document === "undefined" ? location.href : _documentCurrentScript && _documentCurrentScript.src || new URL("index.js", document.baseURI).href), fs = require$1("fs"), na = require$1("path");
					k ? r = na.dirname(r) + "/" : r = require$1("url").fileURLToPath(new URL("./", typeof document === "undefined" && typeof location === "undefined" ? __require("url").pathToFileURL(__filename).href : typeof document === "undefined" ? location.href : _documentCurrentScript && _documentCurrentScript.src || new URL("index.js", document.baseURI).href));
					ia = (b, c) => {
						b = oa(b) ? new URL(b) : na.normalize(b);
						return fs.readFileSync(b, c ? void 0 : "utf8");
					};
					ka = (b) => {
						b = ia(b, !0);
						b.buffer || (b = new Uint8Array(b));
						u(b.buffer);
						return b;
					};
					ja = (b, c, d, f = !0) => {
						b = oa(b) ? new URL(b) : na.normalize(b);
						fs.readFile(b, f ? void 0 : "utf8", (h, m) => {
							h ? d(h) : c(f ? m.buffer : m);
						});
					};
					!e.thisProgram && 1 < process.argv.length && (da = process.argv[1].replace(/\\/g, "/"));
					process.argv.slice(2);
					ea = (b, c) => {
						process.exitCode = b;
						throw c;
					};
					e.inspect = () => "[Emscripten Module object]";
				} else if (ha) {
					if ("object" == typeof process && "function" === typeof require$1 || "object" == typeof window || "function" == typeof importScripts) throw Error("not compiled for this environment (did you build to HTML and try to run it not on the web, or set ENVIRONMENT to something - like node - and run it someplace else - like on the web?)");
					"undefined" != typeof read && (ia = read);
					ka = (a) => {
						if ("function" == typeof readbuffer) return new Uint8Array(readbuffer(a));
						a = read(a, "binary");
						u("object" == typeof a);
						return a;
					};
					ja = (a, b) => {
						setTimeout(() => b(ka(a)));
					};
					"undefined" == typeof clearTimeout && (globalThis.clearTimeout = () => {});
					"undefined" == typeof setTimeout && (globalThis.setTimeout = (a) => "function" == typeof a ? a() : g());
					"function" == typeof quit && (ea = (a, b) => {
						setTimeout(() => {
							if (!(b instanceof pa)) {
								let c = b;
								b && "object" == typeof b && b.stack && (c = [b, b.stack]);
								z(`exiting due to exception: ${c}`);
							}
							quit(a);
						});
						throw b;
					});
					"undefined" != typeof print && ("undefined" == typeof console && (console = {}), console.log = print, console.warn = console.error = "undefined" != typeof printErr ? printErr : print);
				} else if (fa || k) {
					k ? r = self.location.href : "undefined" != typeof document && document.currentScript && (r = document.currentScript.src);
					_scriptDir && (r = _scriptDir);
					0 !== r.indexOf("blob:") ? r = r.substr(0, r.replace(/[?#].*/, "").lastIndexOf("/") + 1) : r = "";
					if ("object" != typeof window && "function" != typeof importScripts) throw Error("not compiled for this environment (did you build to HTML and try to run it not on the web, or set ENVIRONMENT to something - like node - and run it someplace else - like on the web?)");
					ia = (a) => {
						var b = new XMLHttpRequest();
						b.open("GET", a, !1);
						b.send(null);
						return b.responseText;
					};
					k && (ka = (a) => {
						var b = new XMLHttpRequest();
						b.open("GET", a, !1);
						b.responseType = "arraybuffer";
						b.send(null);
						return new Uint8Array(b.response);
					});
					ja = (a, b, c) => {
						var d = new XMLHttpRequest();
						d.open("GET", a, !0);
						d.responseType = "arraybuffer";
						d.onload = () => {
							200 == d.status || 0 == d.status && d.response ? b(d.response) : c();
						};
						d.onerror = c;
						d.send(null);
					};
				} else throw Error("environment detection error");
				var qa = console.log.bind(console), z = console.error.bind(console);
				Object.assign(e, ca);
				ca = null;
				C("ENVIRONMENT");
				C("GL_MAX_TEXTURE_IMAGE_UNITS");
				C("SDL_canPlayWithWebAudio");
				C("SDL_numSimultaneouslyQueuedBuffers");
				C("INITIAL_MEMORY");
				C("wasmMemory");
				C("arguments");
				C("buffer");
				C("canvas");
				C("doNotCaptureKeyboard");
				C("dynamicLibraries");
				C("elementPointerLock");
				C("extraStackTrace");
				C("forcedAspectRatio");
				C("instantiateWasm");
				C("keyboardListeningElement");
				C("freePreloadedMediaOnUse");
				C("loadSplitModule");
				C("logReadFiles");
				C("mainScriptUrlOrBlob");
				C("mem");
				C("monitorRunDependencies");
				C("noExitRuntime");
				C("noInitialRun");
				C("onAbort");
				C("onCustomMessage");
				C("onExit");
				C("onFree");
				C("onFullScreen");
				C("onMalloc");
				C("onRealloc");
				C("onRuntimeInitialized");
				C("postMainLoop");
				C("postRun");
				C("preInit");
				C("preMainLoop");
				C("preinitializedWebGLContext");
				C("memoryInitializerRequest");
				C("preloadPlugins");
				C("print");
				C("printErr");
				C("quit");
				C("setStatus");
				C("statusMessage");
				C("stderr");
				C("stdin");
				C("stdout");
				C("thisProgram");
				C("wasm");
				C("wasmBinary");
				C("websocket");
				C("fetchSettings");
				D("arguments", "arguments_");
				D("thisProgram", "thisProgram");
				D("quit", "quit_");
				u("undefined" == typeof e.memoryInitializerPrefixURL, "Module.memoryInitializerPrefixURL option was removed, use Module.locateFile instead");
				u("undefined" == typeof e.pthreadMainPrefixURL, "Module.pthreadMainPrefixURL option was removed, use Module.locateFile instead");
				u("undefined" == typeof e.cdInitializerPrefixURL, "Module.cdInitializerPrefixURL option was removed, use Module.locateFile instead");
				u("undefined" == typeof e.filePackagePrefixURL, "Module.filePackagePrefixURL option was removed, use Module.locateFile instead");
				u("undefined" == typeof e.read, "Module.read option was removed (modify read_ in JS)");
				u("undefined" == typeof e.readAsync, "Module.readAsync option was removed (modify readAsync in JS)");
				u("undefined" == typeof e.readBinary, "Module.readBinary option was removed (modify readBinary in JS)");
				u("undefined" == typeof e.setWindowTitle, "Module.setWindowTitle option was removed (modify emscripten_set_window_title in JS)");
				u("undefined" == typeof e.TOTAL_MEMORY, "Module.TOTAL_MEMORY has been renamed Module.INITIAL_MEMORY");
				D("asm", "wasmExports");
				D("read", "read_");
				D("readAsync", "readAsync");
				D("readBinary", "readBinary");
				D("setWindowTitle", "setWindowTitle");
				u(!ha, "shell environment detected but not enabled at build time.  Add 'shell' to `-sENVIRONMENT` to enable.");
				D("wasmBinary", "wasmBinary");
				"object" != typeof WebAssembly && g("no native wasm support detected");
				var ra, sa = !1;
				function u(a, b) {
					a || g("Assertion failed" + (b ? ": " + b : ""));
				}
				var E, ta, ua, F, G, va, wa, xa;
				function ya() {
					var a = ra.buffer;
					e.HEAP8 = E = new Int8Array(a);
					e.HEAP16 = ua = new Int16Array(a);
					e.HEAPU8 = ta = new Uint8Array(a);
					e.HEAPU16 = new Uint16Array(a);
					e.HEAP32 = F = new Int32Array(a);
					e.HEAPU32 = G = new Uint32Array(a);
					e.HEAPF32 = va = new Float32Array(a);
					e.HEAPF64 = xa = new Float64Array(a);
					e.HEAP64 = wa = new BigInt64Array(a);
					e.HEAPU64 = new BigUint64Array(a);
				}
				u(!e.STACK_SIZE, "STACK_SIZE can no longer be set at runtime.  Use -sSTACK_SIZE at link time");
				u("undefined" != typeof Int32Array && "undefined" !== typeof Float64Array && void 0 != Int32Array.prototype.subarray && void 0 != Int32Array.prototype.set, "JS engine does not provide full typed array support");
				u(!e.wasmMemory, "Use of `wasmMemory` detected.  Use -sIMPORTED_MEMORY to define wasmMemory externally");
				u(!e.INITIAL_MEMORY, "Detected runtime INITIAL_MEMORY setting.  Use -sIMPORTED_MEMORY to define wasmMemory dynamically");
				function za() {
					if (!sa) {
						var a = Aa();
						0 == a && (a += 4);
						var b = G[a >> 2], c = G[a + 4 >> 2];
						34821223 == b && 2310721022 == c || g(`Stack overflow! Stack cookie has been overwritten at ${Ba(a)}, expected hex dwords 0x89BACDFE and 0x2135467, but received ${Ba(c)} ${Ba(b)}`);
						1668509029 != G[0] && g("Runtime error: The application has corrupted its heap memory area (address zero)!");
					}
				}
				var Ca = new Int16Array(1), Da = new Int8Array(Ca.buffer);
				Ca[0] = 25459;
				if (115 !== Da[0] || 99 !== Da[1]) throw "Runtime error: expected the system to be little-endian! (Run with -sSUPPORT_BIG_ENDIAN to bypass)";
				var Ea = [], Fa = [], Ga = [], Ha = !1;
				u(Math.imul, "This browser does not support Math.imul(), build with LEGACY_VM_SUPPORT or POLYFILL_OLD_MATH_FUNCTIONS to add in a polyfill");
				u(Math.fround, "This browser does not support Math.fround(), build with LEGACY_VM_SUPPORT or POLYFILL_OLD_MATH_FUNCTIONS to add in a polyfill");
				u(Math.clz32, "This browser does not support Math.clz32(), build with LEGACY_VM_SUPPORT or POLYFILL_OLD_MATH_FUNCTIONS to add in a polyfill");
				u(Math.trunc, "This browser does not support Math.trunc(), build with LEGACY_VM_SUPPORT or POLYFILL_OLD_MATH_FUNCTIONS to add in a polyfill");
				var Ia = 0, I = null, Ja = null, Ka = {};
				function La(a) {
					for (var b = a;;) {
						if (!Ka[a]) return a;
						a = b + Math.random();
					}
				}
				function Ma(a) {
					Ia++;
					a ? (u(!Ka[a]), Ka[a] = 1, null === I && "undefined" != typeof setInterval && (I = setInterval(() => {
						if (sa) clearInterval(I), I = null;
						else {
							var b = !1, c;
							for (c in Ka) b || (b = !0, z("still waiting on run dependencies:")), z(`dependency: ${c}`);
							b && z("(end of list)");
						}
					}, 1e4))) : z("warning: run dependency added without ID");
				}
				function Na(a) {
					Ia--;
					a ? (u(Ka[a]), delete Ka[a]) : z("warning: run dependency removed without ID");
					0 == Ia && (null !== I && (clearInterval(I), I = null), Ja && (a = Ja, Ja = null, a()));
				}
				function g(a) {
					a = "Aborted(" + a + ")";
					z(a);
					sa = !0;
					a = new WebAssembly.RuntimeError(a);
					ba(a);
					throw a;
				}
				var Oa = (a) => a.startsWith("data:application/octet-stream;base64,"), oa = (a) => a.startsWith("file://");
				function J(a) {
					return function() {
						u(Ha, `native function \`${a}\` called before runtime initialization`);
						var b = L[a];
						u(b, `exported native function \`${a}\` not found`);
						return b.apply(null, arguments);
					};
				}
				var M;
				if (e.locateFile) {
					if (M = "glue.wasm", !Oa(M)) {
						var Pa = M;
						M = e.locateFile ? e.locateFile(Pa, r) : r + Pa;
					}
				} else M = new URL("glue.wasm", typeof document === "undefined" && typeof location === "undefined" ? __require("url").pathToFileURL(__filename).href : typeof document === "undefined" ? location.href : _documentCurrentScript && _documentCurrentScript.src || new URL("index.js", document.baseURI).href).href;
				function Qa(a) {
					if (ka) return ka(a);
					throw "both async and sync fetching of the wasm failed";
				}
				function Ra(a) {
					if (fa || k) {
						if ("function" == typeof fetch && !oa(a)) return fetch(a, { credentials: "same-origin" }).then((b) => {
							if (!b.ok) throw "failed to load wasm binary file at '" + a + "'";
							return b.arrayBuffer();
						}).catch(() => Qa(a));
						if (ja) return new Promise((b, c) => {
							ja(a, (d) => b(new Uint8Array(d)), c);
						});
					}
					return Promise.resolve().then(() => Qa(a));
				}
				function Sa(a, b, c) {
					return Ra(a).then((d) => WebAssembly.instantiate(d, b)).then((d) => d).then(c, (d) => {
						z(`failed to asynchronously prepare wasm: ${d}`);
						oa(M) && z(`warning: Loading from a file URI (${M}) is not supported in most browsers. See https://emscripten.org/docs/getting_started/FAQ.html#how-do-i-run-a-local-webserver-for-testing-why-does-my-program-stall-in-downloading-or-preparing`);
						g(d);
					});
				}
				function Ta(a, b) {
					var c = M;
					return "function" != typeof WebAssembly.instantiateStreaming || Oa(c) || oa(c) || n || "function" != typeof fetch ? Sa(c, a, b) : fetch(c, { credentials: "same-origin" }).then((d) => WebAssembly.instantiateStreaming(d, a).then(b, function(f) {
						z(`wasm streaming compile failed: ${f}`);
						z("falling back to ArrayBuffer instantiation");
						return Sa(c, a, b);
					}));
				}
				function D(a, b) {
					Object.getOwnPropertyDescriptor(e, a) || Object.defineProperty(e, a, {
						configurable: !0,
						get() {
							g(`\`Module.${a}\` has been replaced by \`${b}\` (the initial value can be provided on Module, but after startup the value is only looked for on a local variable of that name)`);
						}
					});
				}
				function C(a) {
					Object.getOwnPropertyDescriptor(e, a) && g(`\`Module.${a}\` was supplied but \`${a}\` not included in INCOMING_MODULE_JS_API`);
				}
				function Ua(a) {
					return "FS_createPath" === a || "FS_createDataFile" === a || "FS_createPreloadedFile" === a || "FS_unlink" === a || "addRunDependency" === a || "FS_createLazyFile" === a || "FS_createDevice" === a || "removeRunDependency" === a;
				}
				function Va(a, b) {
					"undefined" !== typeof globalThis && Object.defineProperty(globalThis, a, {
						configurable: !0,
						get() {
							Wa(`\`${a}\` is not longer defined by emscripten. ${b}`);
						}
					});
				}
				Va("buffer", "Please use HEAP8.buffer or wasmMemory.buffer");
				Va("asm", "Please use wasmExports instead");
				function Xa(a) {
					Object.getOwnPropertyDescriptor(e, a) || Object.defineProperty(e, a, {
						configurable: !0,
						get() {
							var b = `'${a}' was not exported. add it to EXPORTED_RUNTIME_METHODS (see the Emscripten FAQ)`;
							Ua(a) && (b += ". Alternatively, forcing filesystem support (-sFORCE_FILESYSTEM) can export this for you");
							g(b);
						}
					});
				}
				function pa(a) {
					this.name = "ExitStatus";
					this.message = `Program terminated with exit(${a})`;
					this.status = a;
				}
				var Ba = (a) => {
					u("number" === typeof a);
					return "0x" + (a >>> 0).toString(16).padStart(8, "0");
				}, Wa = (a) => {
					Ya ||= {};
					Ya[a] || (Ya[a] = 1, n && (a = "warning: " + a), z(a));
				}, Ya, Za = (a, b) => {
					for (var c = 0, d = a.length - 1; 0 <= d; d--) {
						var f = a[d];
						"." === f ? a.splice(d, 1) : ".." === f ? (a.splice(d, 1), c++) : c && (a.splice(d, 1), c--);
					}
					if (b) for (; c; c--) a.unshift("..");
					return a;
				}, P = (a) => {
					var b = "/" === a.charAt(0), c = "/" === a.substr(-1);
					(a = Za(a.split("/").filter((d) => !!d), !b).join("/")) || b || (a = ".");
					a && c && (a += "/");
					return (b ? "/" : "") + a;
				}, $a = (a) => {
					var b = /^(\/?|)([\s\S]*?)((?:\.{1,2}|[^\/]+?|)(\.[^.\/]*|))(?:[\/]*)$/.exec(a).slice(1);
					a = b[0];
					b = b[1];
					if (!a && !b) return ".";
					b &&= b.substr(0, b.length - 1);
					return a + b;
				}, Q = (a) => {
					if ("/" === a) return "/";
					a = P(a);
					a = a.replace(/\/$/, "");
					var b = a.lastIndexOf("/");
					return -1 === b ? a : a.substr(b + 1);
				}, ab = (a, b) => P(a + "/" + b), bb = () => {
					if ("object" == typeof crypto && "function" == typeof crypto.getRandomValues) return (c) => crypto.getRandomValues(c);
					if (n) try {
						var a = require$1("crypto");
						if (a.randomFillSync) return (c) => a.randomFillSync(c);
						var b = a.randomBytes;
						return (c) => (c.set(b(c.byteLength)), c);
					} catch (c) {}
					g("no cryptographic support found for randomDevice. consider polyfilling it if you want to use something insecure like Math.random(), e.g. put this in a --pre-js: var crypto = { getRandomValues: (array) => { for (var i = 0; i < array.length; i++) array[i] = (Math.random()*256)|0 } };");
				}, cb = (a) => (cb = bb())(a);
				function db() {
					for (var a = "", b = !1, c = arguments.length - 1; -1 <= c && !b; c--) {
						b = 0 <= c ? arguments[c] : R.cwd();
						if ("string" != typeof b) throw new TypeError("Arguments to path.resolve must be strings");
						if (!b) return "";
						a = b + "/" + a;
						b = "/" === b.charAt(0);
					}
					a = Za(a.split("/").filter((d) => !!d), !b).join("/");
					return (b ? "/" : "") + a || ".";
				}
				var eb = (a, b) => {
					function c(m) {
						for (var p = 0; p < m.length && "" === m[p]; p++);
						for (var y = m.length - 1; 0 <= y && "" === m[y]; y--);
						return p > y ? [] : m.slice(p, y - p + 1);
					}
					a = db(a).substr(1);
					b = db(b).substr(1);
					a = c(a.split("/"));
					b = c(b.split("/"));
					for (var d = Math.min(a.length, b.length), f = d, h = 0; h < d; h++) if (a[h] !== b[h]) {
						f = h;
						break;
					}
					d = [];
					for (h = f; h < a.length; h++) d.push("..");
					d = d.concat(b.slice(f));
					return d.join("/");
				}, gb = "undefined" != typeof TextDecoder ? new TextDecoder("utf8") : void 0, hb = (a, b) => {
					for (var c = b + NaN, d = b; a[d] && !(d >= c);) ++d;
					if (16 < d - b && a.buffer && gb) return gb.decode(a.subarray(b, d));
					for (c = ""; b < d;) {
						var f = a[b++];
						if (f & 128) {
							var h = a[b++] & 63;
							if (192 == (f & 224)) c += String.fromCharCode((f & 31) << 6 | h);
							else {
								var m = a[b++] & 63;
								224 == (f & 240) ? f = (f & 15) << 12 | h << 6 | m : (240 != (f & 248) && Wa("Invalid UTF-8 leading byte " + Ba(f) + " encountered when deserializing a UTF-8 string in wasm memory to a JS string!"), f = (f & 7) << 18 | h << 12 | m << 6 | a[b++] & 63);
								65536 > f ? c += String.fromCharCode(f) : (f -= 65536, c += String.fromCharCode(55296 | f >> 10, 56320 | f & 1023));
							}
						} else c += String.fromCharCode(f);
					}
					return c;
				}, ib = [], jb = (a) => {
					for (var b = 0, c = 0; c < a.length; ++c) {
						var d = a.charCodeAt(c);
						127 >= d ? b++ : 2047 >= d ? b += 2 : 55296 <= d && 57343 >= d ? (b += 4, ++c) : b += 3;
					}
					return b;
				}, kb = (a, b, c, d) => {
					u("string" === typeof a, `stringToUTF8Array expects a string (got ${typeof a})`);
					if (!(0 < d)) return 0;
					var f = c;
					d = c + d - 1;
					for (var h = 0; h < a.length; ++h) {
						var m = a.charCodeAt(h);
						if (55296 <= m && 57343 >= m) {
							var p = a.charCodeAt(++h);
							m = 65536 + ((m & 1023) << 10) | p & 1023;
						}
						if (127 >= m) {
							if (c >= d) break;
							b[c++] = m;
						} else {
							if (2047 >= m) {
								if (c + 1 >= d) break;
								b[c++] = 192 | m >> 6;
							} else {
								if (65535 >= m) {
									if (c + 2 >= d) break;
									b[c++] = 224 | m >> 12;
								} else {
									if (c + 3 >= d) break;
									1114111 < m && Wa("Invalid Unicode code point " + Ba(m) + " encountered when serializing a JS string to a UTF-8 string in wasm memory! (Valid unicode code points should be in range 0-0x10FFFF).");
									b[c++] = 240 | m >> 18;
									b[c++] = 128 | m >> 12 & 63;
								}
								b[c++] = 128 | m >> 6 & 63;
							}
							b[c++] = 128 | m & 63;
						}
					}
					b[c] = 0;
					return c - f;
				};
				function lb(a, b) {
					var c = Array(jb(a) + 1);
					a = kb(a, c, 0, c.length);
					b && (c.length = a);
					return c;
				}
				var mb = [];
				function nb(a, b) {
					mb[a] = {
						input: [],
						output: [],
						K: b
					};
					ob(a, pb);
				}
				var pb = {
					open(a) {
						var b = mb[a.node.rdev];
						if (!b) throw new R.g(43);
						a.tty = b;
						a.seekable = !1;
					},
					close(a) {
						a.tty.K.fsync(a.tty);
					},
					fsync(a) {
						a.tty.K.fsync(a.tty);
					},
					read(a, b, c, d) {
						if (!a.tty || !a.tty.K.ra) throw new R.g(60);
						for (var f = 0, h = 0; h < d; h++) {
							try {
								var m = a.tty.K.ra(a.tty);
							} catch (p) {
								throw new R.g(29);
							}
							if (void 0 === m && 0 === f) throw new R.g(6);
							if (null === m || void 0 === m) break;
							f++;
							b[c + h] = m;
						}
						f && (a.node.timestamp = Date.now());
						return f;
					},
					write(a, b, c, d) {
						if (!a.tty || !a.tty.K.ia) throw new R.g(60);
						try {
							for (var f = 0; f < d; f++) a.tty.K.ia(a.tty, b[c + f]);
						} catch (h) {
							throw new R.g(29);
						}
						d && (a.node.timestamp = Date.now());
						return f;
					}
				}, qb = {
					ra() {
						a: {
							if (!ib.length) {
								var a = null;
								if (n) {
									var b = Buffer.alloc(256), c = 0, d = process.stdin.fd;
									try {
										c = fs.readSync(d, b);
									} catch (f) {
										if (f.toString().includes("EOF")) c = 0;
										else throw f;
									}
									0 < c ? a = b.slice(0, c).toString("utf-8") : a = null;
								} else "undefined" != typeof window && "function" == typeof window.prompt ? (a = window.prompt("Input: "), null !== a && (a += "\n")) : "function" == typeof readline && (a = readline(), null !== a && (a += "\n"));
								if (!a) {
									a = null;
									break a;
								}
								ib = lb(a, !0);
							}
							a = ib.shift();
						}
						return a;
					},
					ia(a, b) {
						null === b || 10 === b ? (qa(hb(a.output, 0)), a.output = []) : 0 != b && a.output.push(b);
					},
					fsync(a) {
						a.output && 0 < a.output.length && (qa(hb(a.output, 0)), a.output = []);
					},
					Ia() {
						return {
							ab: 25856,
							cb: 5,
							$a: 191,
							bb: 35387,
							Za: [
								3,
								28,
								127,
								21,
								4,
								0,
								1,
								0,
								17,
								19,
								26,
								0,
								18,
								15,
								23,
								22,
								0,
								0,
								0,
								0,
								0,
								0,
								0,
								0,
								0,
								0,
								0,
								0,
								0,
								0,
								0,
								0
							]
						};
					},
					Ja() {
						return 0;
					},
					Ka() {
						return [24, 80];
					}
				}, rb = {
					ia(a, b) {
						null === b || 10 === b ? (z(hb(a.output, 0)), a.output = []) : 0 != b && a.output.push(b);
					},
					fsync(a) {
						a.output && 0 < a.output.length && (z(hb(a.output, 0)), a.output = []);
					}
				}, sb = () => {
					g("internal error: mmapAlloc called but `emscripten_builtin_memalign` native symbol not exported");
				};
				function tb(a, b) {
					var c = a.m ? a.m.length : 0;
					c >= b || (b = Math.max(b, c * (1048576 > c ? 2 : 1.125) >>> 0), 0 != c && (b = Math.max(b, 256)), c = a.m, a.m = new Uint8Array(b), 0 < a.o && a.m.set(c.subarray(0, a.o), 0));
				}
				var S = {
					G: null,
					s() {
						return S.createNode(null, "/", 16895, 0);
					},
					createNode(a, b, c, d) {
						if (24576 === (c & 61440) || R.isFIFO(c)) throw new R.g(63);
						S.G || (S.G = {
							dir: {
								node: {
									C: S.h.C,
									v: S.h.v,
									lookup: S.h.lookup,
									J: S.h.J,
									rename: S.h.rename,
									unlink: S.h.unlink,
									rmdir: S.h.rmdir,
									readdir: S.h.readdir,
									symlink: S.h.symlink
								},
								stream: { D: S.l.D }
							},
							file: {
								node: {
									C: S.h.C,
									v: S.h.v
								},
								stream: {
									D: S.l.D,
									read: S.l.read,
									write: S.l.write,
									T: S.l.T,
									S: S.l.S,
									V: S.l.V
								}
							},
							link: {
								node: {
									C: S.h.C,
									v: S.h.v,
									readlink: S.h.readlink
								},
								stream: {}
							},
							na: {
								node: {
									C: S.h.C,
									v: S.h.v
								},
								stream: R.Da
							}
						});
						c = R.createNode(a, b, c, d);
						T(c.mode) ? (c.h = S.G.dir.node, c.l = S.G.dir.stream, c.m = {}) : R.isFile(c.mode) ? (c.h = S.G.file.node, c.l = S.G.file.stream, c.o = 0, c.m = null) : 40960 === (c.mode & 61440) ? (c.h = S.G.link.node, c.l = S.G.link.stream) : 8192 === (c.mode & 61440) && (c.h = S.G.na.node, c.l = S.G.na.stream);
						c.timestamp = Date.now();
						a && (a.m[b] = c, a.timestamp = c.timestamp);
						return c;
					},
					lb(a) {
						return a.m ? a.m.subarray ? a.m.subarray(0, a.o) : new Uint8Array(a.m) : new Uint8Array(0);
					},
					h: {
						C(a) {
							var b = {};
							b.dev = 8192 === (a.mode & 61440) ? a.id : 1;
							b.ino = a.id;
							b.mode = a.mode;
							b.nlink = 1;
							b.uid = 0;
							b.gid = 0;
							b.rdev = a.rdev;
							T(a.mode) ? b.size = 4096 : R.isFile(a.mode) ? b.size = a.o : 40960 === (a.mode & 61440) ? b.size = a.link.length : b.size = 0;
							b.atime = new Date(a.timestamp);
							b.mtime = new Date(a.timestamp);
							b.ctime = new Date(a.timestamp);
							b.Ba = 4096;
							b.blocks = Math.ceil(b.size / b.Ba);
							return b;
						},
						v(a, b) {
							void 0 !== b.mode && (a.mode = b.mode);
							void 0 !== b.timestamp && (a.timestamp = b.timestamp);
							if (void 0 !== b.size && (b = b.size, a.o != b)) if (0 == b) a.m = null, a.o = 0;
							else {
								var c = a.m;
								a.m = new Uint8Array(b);
								c && a.m.set(c.subarray(0, Math.min(b, a.o)));
								a.o = b;
							}
						},
						lookup() {
							throw R.da[44];
						},
						J(a, b, c, d) {
							return S.createNode(a, b, c, d);
						},
						rename(a, b, c) {
							if (T(a.mode)) {
								try {
									var d = U(b, c);
								} catch (h) {}
								if (d) for (var f in d.m) throw new R.g(55);
							}
							delete a.parent.m[a.name];
							a.parent.timestamp = Date.now();
							a.name = c;
							b.m[c] = a;
							b.timestamp = a.parent.timestamp;
							a.parent = b;
						},
						unlink(a, b) {
							delete a.m[b];
							a.timestamp = Date.now();
						},
						rmdir(a, b) {
							var c = U(a, b), d;
							for (d in c.m) throw new R.g(55);
							delete a.m[b];
							a.timestamp = Date.now();
						},
						readdir(a) {
							var b = [".", ".."], c;
							for (c in a.m) a.m.hasOwnProperty(c) && b.push(c);
							return b;
						},
						symlink(a, b, c) {
							a = S.createNode(a, b, 41471, 0);
							a.link = c;
							return a;
						},
						readlink(a) {
							if (40960 !== (a.mode & 61440)) throw new R.g(28);
							return a.link;
						}
					},
					l: {
						read(a, b, c, d, f) {
							var h = a.node.m;
							if (f >= a.node.o) return 0;
							a = Math.min(a.node.o - f, d);
							u(0 <= a);
							if (8 < a && h.subarray) b.set(h.subarray(f, f + a), c);
							else for (d = 0; d < a; d++) b[c + d] = h[f + d];
							return a;
						},
						write(a, b, c, d, f, h) {
							u(!(b instanceof ArrayBuffer));
							b.buffer === E.buffer && (h = !1);
							if (!d) return 0;
							a = a.node;
							a.timestamp = Date.now();
							if (b.subarray && (!a.m || a.m.subarray)) {
								if (h) return u(0 === f, "canOwn must imply no weird position inside the file"), a.m = b.subarray(c, c + d), a.o = d;
								if (0 === a.o && 0 === f) return a.m = b.slice(c, c + d), a.o = d;
								if (f + d <= a.o) return a.m.set(b.subarray(c, c + d), f), d;
							}
							tb(a, f + d);
							if (a.m.subarray && b.subarray) a.m.set(b.subarray(c, c + d), f);
							else for (h = 0; h < d; h++) a.m[f + h] = b[c + h];
							a.o = Math.max(a.o, f + d);
							return d;
						},
						D(a, b, c) {
							1 === c ? b += a.position : 2 === c && R.isFile(a.node.mode) && (b += a.node.o);
							if (0 > b) throw new R.g(28);
							return b;
						},
						T(a, b, c) {
							tb(a.node, b + c);
							a.node.o = Math.max(a.node.o, b + c);
						},
						S(a, b, c, d, f) {
							if (!R.isFile(a.node.mode)) throw new R.g(43);
							a = a.node.m;
							if (f & 2 || a.buffer !== E.buffer) {
								if (0 < c || c + b < a.length) a.subarray ? a = a.subarray(c, c + b) : a = Array.prototype.slice.call(a, c, c + b);
								c = !0;
								b = sb();
								if (!b) throw new R.g(48);
								E.set(a, b);
							} else c = !1, b = a.byteOffset;
							return {
								Ra: b,
								Aa: c
							};
						},
						V(a, b, c, d) {
							S.l.write(a, b, 0, d, c, !1);
							return 0;
						}
					}
				}, ub = (a, b, c) => {
					var d = La(`al ${a}`);
					ja(a, (f) => {
						u(f, `Loading data file "${a}" failed (no arrayBuffer).`);
						b(new Uint8Array(f));
						d && Na(d);
					}, () => {
						if (c) c();
						else throw `Loading data file "${a}" failed.`;
					});
					d && Ma(d);
				}, vb = [], wb = (a, b, c, d) => {
					"undefined" != typeof Browser && Browser.R();
					var f = !1;
					vb.forEach((h) => {
						!f && h.canHandle(b) && (h.handle(a, b, c, d), f = !0);
					});
					return f;
				}, xb = (a, b) => {
					var c = 0;
					a && (c |= 365);
					b && (c |= 146);
					return c;
				}, yb = {
					0: "Success",
					1: "Arg list too long",
					2: "Permission denied",
					3: "Address already in use",
					4: "Address not available",
					5: "Address family not supported by protocol family",
					6: "No more processes",
					7: "Socket already connected",
					8: "Bad file number",
					9: "Trying to read unreadable message",
					10: "Mount device busy",
					11: "Operation canceled",
					12: "No children",
					13: "Connection aborted",
					14: "Connection refused",
					15: "Connection reset by peer",
					16: "File locking deadlock error",
					17: "Destination address required",
					18: "Math arg out of domain of func",
					19: "Quota exceeded",
					20: "File exists",
					21: "Bad address",
					22: "File too large",
					23: "Host is unreachable",
					24: "Identifier removed",
					25: "Illegal byte sequence",
					26: "Connection already in progress",
					27: "Interrupted system call",
					28: "Invalid argument",
					29: "I/O error",
					30: "Socket is already connected",
					31: "Is a directory",
					32: "Too many symbolic links",
					33: "Too many open files",
					34: "Too many links",
					35: "Message too long",
					36: "Multihop attempted",
					37: "File or path name too long",
					38: "Network interface is not configured",
					39: "Connection reset by network",
					40: "Network is unreachable",
					41: "Too many open files in system",
					42: "No buffer space available",
					43: "No such device",
					44: "No such file or directory",
					45: "Exec format error",
					46: "No record locks available",
					47: "The link has been severed",
					48: "Not enough core",
					49: "No message of desired type",
					50: "Protocol not available",
					51: "No space left on device",
					52: "Function not implemented",
					53: "Socket is not connected",
					54: "Not a directory",
					55: "Directory not empty",
					56: "State not recoverable",
					57: "Socket operation on non-socket",
					59: "Not a typewriter",
					60: "No such device or address",
					61: "Value too large for defined data type",
					62: "Previous owner died",
					63: "Not super-user",
					64: "Broken pipe",
					65: "Protocol error",
					66: "Unknown protocol",
					67: "Protocol wrong type for socket",
					68: "Math result not representable",
					69: "Read only file system",
					70: "Illegal seek",
					71: "No such process",
					72: "Stale file handle",
					73: "Connection timed out",
					74: "Text file busy",
					75: "Cross-device link",
					100: "Device not a stream",
					101: "Bad font file fmt",
					102: "Invalid slot",
					103: "Invalid request code",
					104: "No anode",
					105: "Block device required",
					106: "Channel number out of range",
					107: "Level 3 halted",
					108: "Level 3 reset",
					109: "Link number out of range",
					110: "Protocol driver not attached",
					111: "No CSI structure available",
					112: "Level 2 halted",
					113: "Invalid exchange",
					114: "Invalid request descriptor",
					115: "Exchange full",
					116: "No data (for no delay io)",
					117: "Timer expired",
					118: "Out of streams resources",
					119: "Machine is not on the network",
					120: "Package not installed",
					121: "The object is remote",
					122: "Advertise error",
					123: "Srmount error",
					124: "Communication error on send",
					125: "Cross mount point (not really error)",
					126: "Given log. name not unique",
					127: "f.d. invalid for this operation",
					128: "Remote address changed",
					129: "Can   access a needed shared lib",
					130: "Accessing a corrupted shared lib",
					131: ".lib section in a.out corrupted",
					132: "Attempting to link in too many libs",
					133: "Attempting to exec a shared library",
					135: "Streams pipe error",
					136: "Too many users",
					137: "Socket type not supported",
					138: "Not supported",
					139: "Protocol family not supported",
					140: "Can't send after socket shutdown",
					141: "Too many references",
					142: "Host is down",
					148: "No medium (in tape drive)",
					156: "Level 2 not synchronized"
				}, zb = {
					EPERM: 63,
					ENOENT: 44,
					ESRCH: 71,
					EINTR: 27,
					EIO: 29,
					ENXIO: 60,
					E2BIG: 1,
					ENOEXEC: 45,
					EBADF: 8,
					ECHILD: 12,
					EAGAIN: 6,
					EWOULDBLOCK: 6,
					ENOMEM: 48,
					EACCES: 2,
					EFAULT: 21,
					ENOTBLK: 105,
					EBUSY: 10,
					EEXIST: 20,
					EXDEV: 75,
					ENODEV: 43,
					ENOTDIR: 54,
					EISDIR: 31,
					EINVAL: 28,
					ENFILE: 41,
					EMFILE: 33,
					ENOTTY: 59,
					ETXTBSY: 74,
					EFBIG: 22,
					ENOSPC: 51,
					ESPIPE: 70,
					EROFS: 69,
					EMLINK: 34,
					EPIPE: 64,
					EDOM: 18,
					ERANGE: 68,
					ENOMSG: 49,
					EIDRM: 24,
					ECHRNG: 106,
					EL2NSYNC: 156,
					EL3HLT: 107,
					EL3RST: 108,
					ELNRNG: 109,
					EUNATCH: 110,
					ENOCSI: 111,
					EL2HLT: 112,
					EDEADLK: 16,
					ENOLCK: 46,
					EBADE: 113,
					EBADR: 114,
					EXFULL: 115,
					ENOANO: 104,
					EBADRQC: 103,
					EBADSLT: 102,
					EDEADLOCK: 16,
					EBFONT: 101,
					ENOSTR: 100,
					ENODATA: 116,
					ETIME: 117,
					ENOSR: 118,
					ENONET: 119,
					ENOPKG: 120,
					EREMOTE: 121,
					ENOLINK: 47,
					EADV: 122,
					ESRMNT: 123,
					ECOMM: 124,
					EPROTO: 65,
					EMULTIHOP: 36,
					EDOTDOT: 125,
					EBADMSG: 9,
					ENOTUNIQ: 126,
					EBADFD: 127,
					EREMCHG: 128,
					ELIBACC: 129,
					ELIBBAD: 130,
					ELIBSCN: 131,
					ELIBMAX: 132,
					ELIBEXEC: 133,
					ENOSYS: 52,
					ENOTEMPTY: 55,
					ENAMETOOLONG: 37,
					ELOOP: 32,
					EOPNOTSUPP: 138,
					EPFNOSUPPORT: 139,
					ECONNRESET: 15,
					ENOBUFS: 42,
					EAFNOSUPPORT: 5,
					EPROTOTYPE: 67,
					ENOTSOCK: 57,
					ENOPROTOOPT: 50,
					ESHUTDOWN: 140,
					ECONNREFUSED: 14,
					EADDRINUSE: 3,
					ECONNABORTED: 13,
					ENETUNREACH: 40,
					ENETDOWN: 38,
					ETIMEDOUT: 73,
					EHOSTDOWN: 142,
					EHOSTUNREACH: 23,
					EINPROGRESS: 26,
					EALREADY: 7,
					EDESTADDRREQ: 17,
					EMSGSIZE: 35,
					EPROTONOSUPPORT: 66,
					ESOCKTNOSUPPORT: 137,
					EADDRNOTAVAIL: 4,
					ENETRESET: 39,
					EISCONN: 30,
					ENOTCONN: 53,
					ETOOMANYREFS: 141,
					EUSERS: 136,
					EDQUOT: 19,
					ESTALE: 72,
					ENOTSUP: 138,
					ENOMEDIUM: 148,
					EILSEQ: 25,
					EOVERFLOW: 61,
					ECANCELED: 11,
					ENOTRECOVERABLE: 56,
					EOWNERDEAD: 62,
					ESTRPIPE: 135
				}, Ab = (a) => a.replace(/\b_Z[\w\d_]+/g, function(b) {
					Wa("warning: build with -sDEMANGLE_SUPPORT to link in libcxxabi demangling");
					return b === b ? b : b + " [" + b + "]";
				});
				function ob(a, b) {
					R.pa[a] = { l: b };
				}
				function T(a) {
					return 16384 === (a & 61440);
				}
				function U(a, b) {
					var c;
					if (c = (c = Bb(a, "x")) ? c : a.h.lookup ? 0 : 2) throw new R.g(c, a);
					for (c = R.F[Cb(a.id, b)]; c; c = c.N) {
						var d = c.name;
						if (c.parent.id === a.id && d === b) return c;
					}
					return R.lookup(a, b);
				}
				function V(a, b = {}) {
					a = db(a);
					if (!a) return {
						path: "",
						node: null
					};
					b = Object.assign({
						ba: !0,
						ka: 0
					}, b);
					if (8 < b.ka) throw new R.g(32);
					a = a.split("/").filter((m) => !!m);
					for (var c = R.root, d = "/", f = 0; f < a.length; f++) {
						var h = f === a.length - 1;
						if (h && b.parent) break;
						c = U(c, a[f]);
						d = P(d + "/" + a[f]);
						c.A && (!h || h && b.ba) && (c = c.A.root);
						if (!h || b.B) {
							for (h = 0; 40960 === (c.mode & 61440);) if (c = R.readlink(d), d = db($a(d), c), c = V(d, { ka: b.ka + 1 }).node, 40 < h++) throw new R.g(32);
						}
					}
					return {
						path: d,
						node: c
					};
				}
				function Db(a) {
					for (var b;;) {
						if (R.Z(a)) return a = a.s.ua, b ? "/" !== a[a.length - 1] ? `${a}/${b}` : a + b : a;
						b = b ? `${a.name}/${b}` : a.name;
						a = a.parent;
					}
				}
				function Cb(a, b) {
					for (var c = 0, d = 0; d < b.length; d++) c = (c << 5) - c + b.charCodeAt(d) | 0;
					return (a + c >>> 0) % R.F.length;
				}
				function Eb(a) {
					var b = Cb(a.parent.id, a.name);
					a.N = R.F[b];
					R.F[b] = a;
				}
				function Fb(a) {
					var b = Cb(a.parent.id, a.name);
					if (R.F[b] === a) R.F[b] = a.N;
					else for (b = R.F[b]; b;) {
						if (b.N === a) {
							b.N = a.N;
							break;
						}
						b = b.N;
					}
				}
				function Gb(a) {
					var b = [
						"r",
						"w",
						"rw"
					][a & 3];
					a & 512 && (b += "w");
					return b;
				}
				function Bb(a, b) {
					if (R.ta) return 0;
					if (!b.includes("r") || a.mode & 292) {
						if (b.includes("w") && !(a.mode & 146) || b.includes("x") && !(a.mode & 73)) return 2;
					} else return 2;
					return 0;
				}
				function Hb(a, b) {
					try {
						return U(a, b), 20;
					} catch (c) {}
					return Bb(a, "wx");
				}
				function Ib(a, b, c) {
					try {
						var d = U(a, b);
					} catch (f) {
						return f.u;
					}
					if (a = Bb(a, "wx")) return a;
					if (c) {
						if (!T(d.mode)) return 54;
						if (R.Z(d) || Db(d) === R.cwd()) return 10;
					} else if (T(d.mode)) return 31;
					return 0;
				}
				function Jb() {
					for (var a = 0; a <= R.xa; a++) if (!R.streams[a]) return a;
					throw new R.g(33);
				}
				function W(a) {
					a = R.qa(a);
					if (!a) throw new R.g(8);
					return a;
				}
				function Kb(a, b = -1) {
					R.X || (R.X = function() {
						this.I = {};
					}, R.X.prototype = {}, Object.defineProperties(R.X.prototype, {
						object: {
							get() {
								return this.node;
							},
							set(c) {
								this.node = c;
							}
						},
						flags: {
							get() {
								return this.I.flags;
							},
							set(c) {
								this.I.flags = c;
							}
						},
						position: {
							get() {
								return this.I.position;
							},
							set(c) {
								this.I.position = c;
							}
						}
					}));
					a = Object.assign(new R.X(), a);
					-1 == b && (b = Jb());
					a.fd = b;
					return R.streams[b] = a;
				}
				function Lb(a) {
					var b = [];
					for (a = [a]; a.length;) {
						var c = a.pop();
						b.push(c);
						a.push.apply(a, c.U);
					}
					return b;
				}
				function Mb(a, b, c) {
					"undefined" == typeof c && (c = b, b = 438);
					return R.J(a, b | 8192, c);
				}
				function Nb() {
					R.g || (R.g = function(a, b) {
						this.name = "ErrnoError";
						this.node = b;
						this.Sa = function(c) {
							this.u = c;
							for (var d in zb) if (zb[d] === c) {
								this.code = d;
								break;
							}
						};
						this.Sa(a);
						this.message = yb[a];
						this.stack && (Object.defineProperty(this, "stack", {
							value: Error().stack,
							writable: !0
						}), this.stack = Ab(this.stack));
					}, R.g.prototype = Error(), R.g.prototype.constructor = R.g, [44].forEach((a) => {
						R.da[a] = new R.g(a);
						R.da[a].stack = "<generic error, no stack>";
					}));
				}
				function Ob(a, b) {
					try {
						var c = V(a, { B: !b });
						a = c.path;
					} catch (f) {}
					var d = {
						Z: !1,
						exists: !1,
						error: 0,
						name: null,
						path: null,
						object: null,
						Oa: !1,
						Qa: null,
						Pa: null
					};
					try {
						c = V(a, { parent: !0 }), d.Oa = !0, d.Qa = c.path, d.Pa = c.node, d.name = Q(a), c = V(a, { B: !b }), d.exists = !0, d.path = c.path, d.object = c.node, d.name = c.node.name, d.Z = "/" === c.path;
					} catch (f) {
						d.error = f.u;
					}
					return d;
				}
				function Pb(a, b, c, d) {
					a = "string" == typeof a ? a : Db(a);
					b = P(a + "/" + b);
					return R.create(b, xb(c, d));
				}
				function Qb(a) {
					if (!(a.La || a.Ma || a.link || a.m)) {
						if ("undefined" != typeof XMLHttpRequest) throw Error("Lazy loading should have been performed (contents set) in createLazyFile, but it was not. Lazy loading only works in web workers. Use --embed-file or --preload-file in emcc on the main thread.");
						if (ia) try {
							a.m = lb(ia(a.url), !0), a.o = a.m.length;
						} catch (b) {
							throw new R.g(29);
						}
						else throw Error("Cannot load without read() or XMLHttpRequest.");
					}
				}
				var R = {
					root: null,
					U: [],
					pa: {},
					streams: [],
					Na: 1,
					F: null,
					oa: "/",
					Y: !1,
					ta: !0,
					g: null,
					da: {},
					Fa: null,
					W: 0,
					createNode(a, b, c, d) {
						u("object" == typeof a);
						a = new R.wa(a, b, c, d);
						Eb(a);
						return a;
					},
					Z(a) {
						return a === a.parent;
					},
					isFile(a) {
						return 32768 === (a & 61440);
					},
					isFIFO(a) {
						return 4096 === (a & 61440);
					},
					isSocket(a) {
						return 49152 === (a & 49152);
					},
					xa: 4096,
					qa: (a) => R.streams[a],
					Da: {
						open(a) {
							a.l = R.Ga(a.node.rdev).l;
							a.l.open && a.l.open(a);
						},
						D() {
							throw new R.g(70);
						}
					},
					ha: (a) => a >> 8,
					nb: (a) => a & 255,
					M: (a, b) => a << 8 | b,
					Ga: (a) => R.pa[a],
					va(a, b) {
						function c(m) {
							u(0 < R.W);
							R.W--;
							return b(m);
						}
						function d(m) {
							if (m) {
								if (!d.Ea) return d.Ea = !0, c(m);
							} else ++h >= f.length && c(null);
						}
						"function" == typeof a && (b = a, a = !1);
						R.W++;
						1 < R.W && z(`warning: ${R.W} FS.syncfs operations in flight at once, probably just doing extra work`);
						var f = Lb(R.root.s), h = 0;
						f.forEach((m) => {
							if (!m.type.va) return d(null);
							m.type.va(m, a, d);
						});
					},
					s(a, b, c) {
						if ("string" == typeof a) throw a;
						var d = "/" === c, f = !c;
						if (d && R.root) throw new R.g(10);
						if (!d && !f) {
							var h = V(c, { ba: !1 });
							c = h.path;
							h = h.node;
							if (h.A) throw new R.g(10);
							if (!T(h.mode)) throw new R.g(54);
						}
						b = {
							type: a,
							rb: b,
							ua: c,
							U: []
						};
						a = a.s(b);
						a.s = b;
						b.root = a;
						d ? R.root = a : h && (h.A = b, h.s && h.s.U.push(b));
						return a;
					},
					xb(a) {
						a = V(a, { ba: !1 });
						if (!a.node.A) throw new R.g(28);
						a = a.node;
						var b = a.A, c = Lb(b);
						Object.keys(R.F).forEach((d) => {
							for (d = R.F[d]; d;) {
								var f = d.N;
								c.includes(d.s) && Fb(d);
								d = f;
							}
						});
						a.A = null;
						b = a.s.U.indexOf(b);
						u(-1 !== b);
						a.s.U.splice(b, 1);
					},
					lookup(a, b) {
						return a.h.lookup(a, b);
					},
					J(a, b, c) {
						var d = V(a, { parent: !0 }).node;
						a = Q(a);
						if (!a || "." === a || ".." === a) throw new R.g(28);
						var f = Hb(d, a);
						if (f) throw new R.g(f);
						if (!d.h.J) throw new R.g(63);
						return d.h.J(d, a, b, c);
					},
					create(a, b) {
						return R.J(a, (void 0 !== b ? b : 438) & 4095 | 32768, 0);
					},
					mkdir(a, b) {
						return R.J(a, (void 0 !== b ? b : 511) & 1023 | 16384, 0);
					},
					ob(a, b) {
						a = a.split("/");
						for (var c = "", d = 0; d < a.length; ++d) if (a[d]) {
							c += "/" + a[d];
							try {
								R.mkdir(c, b);
							} catch (f) {
								if (20 != f.u) throw f;
							}
						}
					},
					symlink(a, b) {
						if (!db(a)) throw new R.g(44);
						var c = V(b, { parent: !0 }).node;
						if (!c) throw new R.g(44);
						b = Q(b);
						var d = Hb(c, b);
						if (d) throw new R.g(d);
						if (!c.h.symlink) throw new R.g(63);
						return c.h.symlink(c, b, a);
					},
					rename(a, b) {
						var c = $a(a), d = $a(b), f = Q(a), h = Q(b);
						var m = V(a, { parent: !0 });
						var p = m.node;
						m = V(b, { parent: !0 });
						m = m.node;
						if (!p || !m) throw new R.g(44);
						if (p.s !== m.s) throw new R.g(75);
						var y = U(p, f);
						a = eb(a, d);
						if ("." !== a.charAt(0)) throw new R.g(28);
						a = eb(b, c);
						if ("." !== a.charAt(0)) throw new R.g(55);
						try {
							var q = U(m, h);
						} catch (x) {}
						if (y !== q) {
							b = T(y.mode);
							if (f = Ib(p, f, b)) throw new R.g(f);
							if (f = q ? Ib(m, h, b) : Hb(m, h)) throw new R.g(f);
							if (!p.h.rename) throw new R.g(63);
							if (y.A || q && q.A) throw new R.g(10);
							if (m !== p && (f = Bb(p, "w"))) throw new R.g(f);
							Fb(y);
							try {
								p.h.rename(y, m, h);
							} catch (x) {
								throw x;
							} finally {
								Eb(y);
							}
						}
					},
					rmdir(a) {
						var b = V(a, { parent: !0 }).node;
						a = Q(a);
						var c = U(b, a), d = Ib(b, a, !0);
						if (d) throw new R.g(d);
						if (!b.h.rmdir) throw new R.g(63);
						if (c.A) throw new R.g(10);
						b.h.rmdir(b, a);
						Fb(c);
					},
					readdir(a) {
						a = V(a, { B: !0 }).node;
						if (!a.h.readdir) throw new R.g(54);
						return a.h.readdir(a);
					},
					unlink(a) {
						var b = V(a, { parent: !0 }).node;
						if (!b) throw new R.g(44);
						a = Q(a);
						var c = U(b, a), d = Ib(b, a, !1);
						if (d) throw new R.g(d);
						if (!b.h.unlink) throw new R.g(63);
						if (c.A) throw new R.g(10);
						b.h.unlink(b, a);
						Fb(c);
					},
					readlink(a) {
						a = V(a).node;
						if (!a) throw new R.g(44);
						if (!a.h.readlink) throw new R.g(28);
						return db(Db(a.parent), a.h.readlink(a));
					},
					stat(a, b) {
						a = V(a, { B: !b }).node;
						if (!a) throw new R.g(44);
						if (!a.h.C) throw new R.g(63);
						return a.h.C(a);
					},
					lstat(a) {
						return R.stat(a, !0);
					},
					chmod(a, b, c) {
						a = "string" == typeof a ? V(a, { B: !c }).node : a;
						if (!a.h.v) throw new R.g(63);
						a.h.v(a, {
							mode: b & 4095 | a.mode & -4096,
							timestamp: Date.now()
						});
					},
					lchmod(a, b) {
						R.chmod(a, b, !0);
					},
					fchmod(a, b) {
						a = W(a);
						R.chmod(a.node, b);
					},
					chown(a, b, c, d) {
						a = "string" == typeof a ? V(a, { B: !d }).node : a;
						if (!a.h.v) throw new R.g(63);
						a.h.v(a, { timestamp: Date.now() });
					},
					lchown(a, b, c) {
						R.chown(a, b, c, !0);
					},
					fchown(a, b, c) {
						a = W(a);
						R.chown(a.node, b, c);
					},
					truncate(a, b) {
						if (0 > b) throw new R.g(28);
						a = "string" == typeof a ? V(a, { B: !0 }).node : a;
						if (!a.h.v) throw new R.g(63);
						if (T(a.mode)) throw new R.g(31);
						if (!R.isFile(a.mode)) throw new R.g(28);
						var c = Bb(a, "w");
						if (c) throw new R.g(c);
						a.h.v(a, {
							size: b,
							timestamp: Date.now()
						});
					},
					kb(a, b) {
						a = W(a);
						if (0 === (a.flags & 2097155)) throw new R.g(28);
						R.truncate(a.node, b);
					},
					yb(a, b, c) {
						a = V(a, { B: !0 }).node;
						a.h.v(a, { timestamp: Math.max(b, c) });
					},
					open(a, b, c) {
						if ("" === a) throw new R.g(44);
						if ("string" == typeof b) {
							var d = {
								r: 0,
								"r+": 2,
								w: 577,
								"w+": 578,
								a: 1089,
								"a+": 1090
							}[b];
							if ("undefined" == typeof d) throw Error(`Unknown file open mode: ${b}`);
							b = d;
						}
						c = b & 64 ? ("undefined" == typeof c ? 438 : c) & 4095 | 32768 : 0;
						if ("object" == typeof a) var f = a;
						else {
							a = P(a);
							try {
								f = V(a, { B: !(b & 131072) }).node;
							} catch (h) {}
						}
						d = !1;
						if (b & 64) if (f) {
							if (b & 128) throw new R.g(20);
						} else f = R.J(a, c, 0), d = !0;
						if (!f) throw new R.g(44);
						8192 === (f.mode & 61440) && (b &= -513);
						if (b & 65536 && !T(f.mode)) throw new R.g(54);
						if (!d && (c = f ? 40960 === (f.mode & 61440) ? 32 : T(f.mode) && ("r" !== Gb(b) || b & 512) ? 31 : Bb(f, Gb(b)) : 44)) throw new R.g(c);
						b & 512 && !d && R.truncate(f, 0);
						b &= -131713;
						f = Kb({
							node: f,
							path: Db(f),
							flags: b,
							seekable: !0,
							position: 0,
							l: f.l,
							Xa: [],
							error: !1
						});
						f.l.open && f.l.open(f);
						!e.logReadFiles || b & 1 || (R.ja || (R.ja = {}), a in R.ja || (R.ja[a] = 1));
						return f;
					},
					close(a) {
						if (null === a.fd) throw new R.g(8);
						a.ea && (a.ea = null);
						try {
							a.l.close && a.l.close(a);
						} catch (b) {
							throw b;
						} finally {
							R.streams[a.fd] = null;
						}
						a.fd = null;
					},
					D(a, b, c) {
						if (null === a.fd) throw new R.g(8);
						if (!a.seekable || !a.l.D) throw new R.g(70);
						if (0 != c && 1 != c && 2 != c) throw new R.g(28);
						a.position = a.l.D(a, b, c);
						a.Xa = [];
						return a.position;
					},
					read(a, b, c, d, f) {
						u(0 <= c);
						if (0 > d || 0 > f) throw new R.g(28);
						if (null === a.fd) throw new R.g(8);
						if (1 === (a.flags & 2097155)) throw new R.g(8);
						if (T(a.node.mode)) throw new R.g(31);
						if (!a.l.read) throw new R.g(28);
						var h = "undefined" != typeof f;
						if (!h) f = a.position;
						else if (!a.seekable) throw new R.g(70);
						b = a.l.read(a, b, c, d, f);
						h || (a.position += b);
						return b;
					},
					write(a, b, c, d, f, h) {
						u(0 <= c);
						if (0 > d || 0 > f) throw new R.g(28);
						if (null === a.fd) throw new R.g(8);
						if (0 === (a.flags & 2097155)) throw new R.g(8);
						if (T(a.node.mode)) throw new R.g(31);
						if (!a.l.write) throw new R.g(28);
						a.seekable && a.flags & 1024 && R.D(a, 0, 2);
						var m = "undefined" != typeof f;
						if (!m) f = a.position;
						else if (!a.seekable) throw new R.g(70);
						b = a.l.write(a, b, c, d, f, h);
						m || (a.position += b);
						return b;
					},
					T(a, b, c) {
						if (null === a.fd) throw new R.g(8);
						if (0 > b || 0 >= c) throw new R.g(28);
						if (0 === (a.flags & 2097155)) throw new R.g(8);
						if (!R.isFile(a.node.mode) && !T(a.node.mode)) throw new R.g(43);
						if (!a.l.T) throw new R.g(138);
						a.l.T(a, b, c);
					},
					S(a, b, c, d, f) {
						if (0 !== (d & 2) && 0 === (f & 2) && 2 !== (a.flags & 2097155)) throw new R.g(2);
						if (1 === (a.flags & 2097155)) throw new R.g(2);
						if (!a.l.S) throw new R.g(43);
						return a.l.S(a, b, c, d, f);
					},
					V(a, b, c, d, f) {
						u(0 <= c);
						return a.l.V ? a.l.V(a, b, c, d, f) : 0;
					},
					qb: () => 0,
					fa(a, b, c) {
						if (!a.l.fa) throw new R.g(59);
						return a.l.fa(a, b, c);
					},
					readFile(a, b = {}) {
						b.flags = b.flags || 0;
						b.encoding = b.encoding || "binary";
						if ("utf8" !== b.encoding && "binary" !== b.encoding) throw Error(`Invalid encoding type "${b.encoding}"`);
						var c, d = R.open(a, b.flags);
						a = R.stat(a).size;
						var f = new Uint8Array(a);
						R.read(d, f, 0, a, 0);
						"utf8" === b.encoding ? c = hb(f, 0) : "binary" === b.encoding && (c = f);
						R.close(d);
						return c;
					},
					writeFile(a, b, c = {}) {
						c.flags = c.flags || 577;
						a = R.open(a, c.flags, c.mode);
						if ("string" == typeof b) {
							var d = new Uint8Array(jb(b) + 1);
							b = kb(b, d, 0, d.length);
							R.write(a, d, 0, b, void 0, c.Ca);
						} else if (ArrayBuffer.isView(b)) R.write(a, b, 0, b.byteLength, void 0, c.Ca);
						else throw Error("Unsupported data type");
						R.close(a);
					},
					cwd: () => R.oa,
					chdir(a) {
						a = V(a, { B: !0 });
						if (null === a.node) throw new R.g(44);
						if (!T(a.node.mode)) throw new R.g(54);
						var b = Bb(a.node, "x");
						if (b) throw new R.g(b);
						R.oa = a.path;
					},
					R(a, b, c) {
						u(!R.R.Y, "FS.init was previously called. If you want to initialize later with custom parameters, remove any earlier calls (note that one is automatically added to the generated code)");
						R.R.Y = !0;
						Nb();
						e.stdin = a || e.stdin;
						e.stdout = b || e.stdout;
						e.stderr = c || e.stderr;
						e.stdin ? R.L("/dev", "stdin", e.stdin) : R.symlink("/dev/tty", "/dev/stdin");
						e.stdout ? R.L("/dev", "stdout", null, e.stdout) : R.symlink("/dev/tty", "/dev/stdout");
						e.stderr ? R.L("/dev", "stderr", null, e.stderr) : R.symlink("/dev/tty1", "/dev/stderr");
						a = R.open("/dev/stdin", 0);
						b = R.open("/dev/stdout", 1);
						c = R.open("/dev/stderr", 1);
						u(0 === a.fd, `invalid handle for stdin (${a.fd})`);
						u(1 === b.fd, `invalid handle for stdout (${b.fd})`);
						u(2 === c.fd, `invalid handle for stderr (${c.fd})`);
					},
					sb() {
						R.R.Y = !1;
						Rb(0);
						for (var a = 0; a < R.streams.length; a++) {
							var b = R.streams[a];
							b && R.close(b);
						}
					},
					jb(a, b) {
						a = Ob(a, b);
						return a.exists ? a.object : null;
					},
					hb(a, b) {
						a = "string" == typeof a ? a : Db(a);
						for (b = b.split("/").reverse(); b.length;) {
							var c = b.pop();
							if (c) {
								var d = P(a + "/" + c);
								try {
									R.mkdir(d);
								} catch (f) {}
								a = d;
							}
						}
						return d;
					},
					L(a, b, c, d) {
						a = ab("string" == typeof a ? a : Db(a), b);
						b = xb(!!c, !!d);
						R.L.ha || (R.L.ha = 64);
						var f = R.M(R.L.ha++, 0);
						ob(f, {
							open(h) {
								h.seekable = !1;
							},
							close() {
								d && d.buffer && d.buffer.length && d(10);
							},
							read(h, m, p, y) {
								for (var q = 0, x = 0; x < y; x++) {
									try {
										var t = c();
									} catch (B) {
										throw new R.g(29);
									}
									if (void 0 === t && 0 === q) throw new R.g(6);
									if (null === t || void 0 === t) break;
									q++;
									m[p + x] = t;
								}
								q && (h.node.timestamp = Date.now());
								return q;
							},
							write(h, m, p, y) {
								for (var q = 0; q < y; q++) try {
									d(m[p + q]);
								} catch (x) {
									throw new R.g(29);
								}
								y && (h.node.timestamp = Date.now());
								return q;
							}
						});
						return Mb(a, b, f);
					},
					fb(a, b, c, d, f) {
						function h() {
							this.ga = !1;
							this.I = [];
						}
						function m(t, B, l, w, v) {
							t = t.node.m;
							if (v >= t.length) return 0;
							w = Math.min(t.length - v, w);
							u(0 <= w);
							if (t.slice) for (var A = 0; A < w; A++) B[l + A] = t[v + A];
							else for (A = 0; A < w; A++) B[l + A] = t.get(v + A);
							return w;
						}
						h.prototype.get = function(t) {
							if (!(t > this.length - 1 || 0 > t)) {
								var B = t % this.chunkSize;
								return this.sa(t / this.chunkSize | 0)[B];
							}
						};
						h.prototype.Ha = function(t) {
							this.sa = t;
						};
						h.prototype.ma = function() {
							var t = new XMLHttpRequest();
							t.open("HEAD", c, !1);
							t.send(null);
							if (!(200 <= t.status && 300 > t.status || 304 === t.status)) throw Error("Couldn't load " + c + ". Status: " + t.status);
							var B = Number(t.getResponseHeader("Content-length")), l, w = (l = t.getResponseHeader("Accept-Ranges")) && "bytes" === l;
							t = (l = t.getResponseHeader("Content-Encoding")) && "gzip" === l;
							var v = 1048576;
							w || (v = B);
							var A = this;
							A.Ha((H) => {
								var N = H * v, O = (H + 1) * v - 1;
								O = Math.min(O, B - 1);
								if ("undefined" == typeof A.I[H]) {
									var fb = A.I;
									if (N > O) throw Error("invalid range (" + N + ", " + O + ") or no bytes requested!");
									if (O > B - 1) throw Error("only " + B + " bytes available! programmer error!");
									var K = new XMLHttpRequest();
									K.open("GET", c, !1);
									B !== v && K.setRequestHeader("Range", "bytes=" + N + "-" + O);
									K.responseType = "arraybuffer";
									K.overrideMimeType && K.overrideMimeType("text/plain; charset=x-user-defined");
									K.send(null);
									if (!(200 <= K.status && 300 > K.status || 304 === K.status)) throw Error("Couldn't load " + c + ". Status: " + K.status);
									N = void 0 !== K.response ? new Uint8Array(K.response || []) : lb(K.responseText || "", !0);
									fb[H] = N;
								}
								if ("undefined" == typeof A.I[H]) throw Error("doXHR failed!");
								return A.I[H];
							});
							if (t || !B) v = B = 1, v = B = this.sa(0).length, qa("LazyFiles on gzip forces download of the whole file when length is accessed");
							this.za = B;
							this.ya = v;
							this.ga = !0;
						};
						if ("undefined" != typeof XMLHttpRequest) {
							if (!k) throw "Cannot do synchronous binary XHRs outside webworkers in modern browsers. Use --embed-file or --preload-file in emcc";
							var p = new h();
							Object.defineProperties(p, {
								length: { get: function() {
									this.ga || this.ma();
									return this.za;
								} },
								chunkSize: { get: function() {
									this.ga || this.ma();
									return this.ya;
								} }
							});
							var y = void 0;
						} else y = c, p = void 0;
						var q = Pb(a, b, d, f);
						p ? q.m = p : y && (q.m = null, q.url = y);
						Object.defineProperties(q, { o: { get: function() {
							return this.m.length;
						} } });
						var x = {};
						Object.keys(q.l).forEach((t) => {
							var B = q.l[t];
							x[t] = function() {
								Qb(q);
								return B.apply(null, arguments);
							};
						});
						x.read = (t, B, l, w, v) => {
							Qb(q);
							return m(t, B, l, w, v);
						};
						x.S = (t, B, l) => {
							Qb(q);
							var w = sb();
							if (!w) throw new R.g(48);
							m(t, E, w, B, l);
							return {
								Ra: w,
								Aa: !0
							};
						};
						q.l = x;
						return q;
					},
					Ya() {
						g("FS.absolutePath has been removed; use PATH_FS.resolve instead");
					},
					eb() {
						g("FS.createFolder has been removed; use FS.mkdir instead");
					},
					gb() {
						g("FS.createLink has been removed; use FS.symlink instead");
					},
					mb() {
						g("FS.joinPath has been removed; use PATH.join instead");
					},
					pb() {
						g("FS.mmapAlloc has been replaced by the top level function mmapAlloc");
					},
					vb() {
						g("FS.standardizePath has been removed; use PATH.normalize instead");
					}
				}, X = (a) => {
					u("number" == typeof a, `UTF8ToString expects a number (got ${typeof a})`);
					return a ? hb(ta, a) : "";
				};
				function Sb(a, b) {
					if ("/" === b.charAt(0)) return b;
					a = -100 === a ? R.cwd() : W(a).path;
					if (0 == b.length) throw new R.g(44);
					return P(a + "/" + b);
				}
				var Tb = void 0;
				function Y() {
					u(void 0 != Tb);
					var a = F[+Tb >> 2];
					Tb += 4;
					return a;
				}
				var Ub = (a, b, c) => {
					u("number" == typeof c, "stringToUTF8(str, outPtr, maxBytesToWrite) is missing the third parameter that specifies the length of the output buffer!");
					return kb(a, ta, b, c);
				}, Vb = (a) => 0 === a % 4 && (0 !== a % 100 || 0 === a % 400), Wb = [
					0,
					31,
					60,
					91,
					121,
					152,
					182,
					213,
					244,
					274,
					305,
					335
				], Xb = [
					0,
					31,
					59,
					90,
					120,
					151,
					181,
					212,
					243,
					273,
					304,
					334
				], Zb = (a) => {
					var b = jb(a) + 1, c = Yb(b);
					c && Ub(a, c, b);
					return c;
				}, $b = {}, bc = () => {
					if (!ac) {
						var a = {
							USER: "web_user",
							LOGNAME: "web_user",
							PATH: "/",
							PWD: "/",
							HOME: "/home/web_user",
							LANG: ("object" == typeof navigator && navigator.languages && navigator.languages[0] || "C").replace("-", "_") + ".UTF-8",
							_: da || "./this.program"
						}, b;
						for (b in $b) void 0 === $b[b] ? delete a[b] : a[b] = $b[b];
						var c = [];
						for (b in a) c.push(`${b}=${a[b]}`);
						ac = c;
					}
					return ac;
				}, ac, cc = [
					31,
					29,
					31,
					30,
					31,
					30,
					31,
					31,
					30,
					31,
					30,
					31
				], dc = [
					31,
					28,
					31,
					30,
					31,
					30,
					31,
					31,
					30,
					31,
					30,
					31
				], ec = (a, b) => {
					u(0 <= a.length, "writeArrayToMemory array must have a length (should be an array or typed array)");
					E.set(a, b);
				}, fc = [], Z, gc = (a) => {
					var b = fc[a];
					b || (a >= fc.length && (fc.length = a + 1), fc[a] = b = Z.get(a));
					u(Z.get(a) == b, "JavaScript-side Wasm function table mirror is out of date!");
					return b;
				}, hc = (a) => {
					var b = e["_" + a];
					u(b, "Cannot call unknown function " + a + ", make sure it is exported");
					return b;
				}, ic, jc = [];
				function kc(a, b, c, d) {
					a ||= this;
					this.parent = a;
					this.s = a.s;
					this.A = null;
					this.id = R.Na++;
					this.name = b;
					this.mode = c;
					this.h = {};
					this.l = {};
					this.rdev = d;
				}
				Object.defineProperties(kc.prototype, {
					read: {
						get: function() {
							return 365 === (this.mode & 365);
						},
						set: function(a) {
							a ? this.mode |= 365 : this.mode &= -366;
						}
					},
					write: {
						get: function() {
							return 146 === (this.mode & 146);
						},
						set: function(a) {
							a ? this.mode |= 146 : this.mode &= -147;
						}
					},
					Ma: { get: function() {
						return T(this.mode);
					} },
					La: { get: function() {
						return 8192 === (this.mode & 61440);
					} }
				});
				R.wa = kc;
				R.ib = (a, b, c, d, f, h, m, p, y, q) => {
					function x(l) {
						function w(v) {
							q && q();
							if (!p) {
								var A = a, H = b;
								A && (A = "string" == typeof A ? A : Db(A), H = b ? P(A + "/" + b) : A);
								A = xb(d, f);
								H = R.create(H, A);
								if (v) {
									if ("string" == typeof v) {
										for (var N = Array(v.length), O = 0, fb = v.length; O < fb; ++O) N[O] = v.charCodeAt(O);
										v = N;
									}
									R.chmod(H, A | 146);
									N = R.open(H, 577);
									R.write(N, v, 0, v.length, 0, y);
									R.close(N);
									R.chmod(H, A);
								}
							}
							h && h();
							Na(B);
						}
						wb(l, t, w, () => {
							m && m();
							Na(B);
						}) || w(l);
					}
					var t = b ? db(P(a + "/" + b)) : a, B = La(`cp ${t}`);
					Ma(B);
					"string" == typeof c ? ub(c, (l) => x(l), m) : x(c);
				};
				Nb();
				R.F = Array(4096);
				R.s(S, {}, "/");
				R.mkdir("/tmp");
				R.mkdir("/home");
				R.mkdir("/home/web_user");
				(function() {
					R.mkdir("/dev");
					ob(R.M(1, 3), {
						read: () => 0,
						write: (d, f, h, m) => m
					});
					Mb("/dev/null", R.M(1, 3));
					nb(R.M(5, 0), qb);
					nb(R.M(6, 0), rb);
					Mb("/dev/tty", R.M(5, 0));
					Mb("/dev/tty1", R.M(6, 0));
					var a = new Uint8Array(1024), b = 0, c = () => {
						0 === b && (b = cb(a).byteLength);
						return a[--b];
					};
					R.L("/dev", "random", c);
					R.L("/dev", "urandom", c);
					R.mkdir("/dev/shm");
					R.mkdir("/dev/shm/tmp");
				})();
				(function() {
					R.mkdir("/proc");
					var a = R.mkdir("/proc/self");
					R.mkdir("/proc/self/fd");
					R.s({ s() {
						var b = R.createNode(a, "fd", 16895, 73);
						b.h = { lookup(c, d) {
							var f = W(+d);
							c = {
								parent: null,
								s: { ua: "fake" },
								h: { readlink: () => f.path }
							};
							return c.parent = c;
						} };
						return b;
					} }, {}, "/proc/self/fd");
				})();
				R.Fa = { MEMFS: S };
				var oc = {
					__syscall_dup3: function(a, b, c) {
						try {
							var d = W(a);
							u(!c);
							if (d.fd === b) return -28;
							var f = R.qa(b);
							f && R.close(f);
							return Kb(d, b).fd;
						} catch (h) {
							if ("undefined" == typeof R || "ErrnoError" !== h.name) throw h;
							return -h.u;
						}
					},
					__syscall_fcntl64: function(a, b, c) {
						Tb = c;
						try {
							var d = W(a);
							switch (b) {
								case 0:
									var f = Y();
									if (0 > f) return -28;
									for (; R.streams[f];) f++;
									return Kb(d, f).fd;
								case 1:
								case 2: return 0;
								case 3: return d.flags;
								case 4: return f = Y(), d.flags |= f, 0;
								case 5: return f = Y(), ua[f + 0 >> 1] = 2, 0;
								case 6:
								case 7: return 0;
								case 16:
								case 8: return -28;
								case 9: return F[lc() >> 2] = 28, -1;
								default: return -28;
							}
						} catch (h) {
							if ("undefined" == typeof R || "ErrnoError" !== h.name) throw h;
							return -h.u;
						}
					},
					__syscall_ioctl: function(a, b, c) {
						Tb = c;
						try {
							var d = W(a);
							switch (b) {
								case 21509: return d.tty ? 0 : -59;
								case 21505:
									if (!d.tty) return -59;
									if (d.tty.K.Ia) {
										a = [
											3,
											28,
											127,
											21,
											4,
											0,
											1,
											0,
											17,
											19,
											26,
											0,
											18,
											15,
											23,
											22,
											0,
											0,
											0,
											0,
											0,
											0,
											0,
											0,
											0,
											0,
											0,
											0,
											0,
											0,
											0,
											0
										];
										var f = Y();
										F[f >> 2] = 25856;
										F[f + 4 >> 2] = 5;
										F[f + 8 >> 2] = 191;
										F[f + 12 >> 2] = 35387;
										for (var h = 0; 32 > h; h++) E[f + h + 17 >> 0] = a[h] || 0;
									}
									return 0;
								case 21510:
								case 21511:
								case 21512: return d.tty ? 0 : -59;
								case 21506:
								case 21507:
								case 21508:
									if (!d.tty) return -59;
									if (d.tty.K.Ja) for (f = Y(), a = [], h = 0; 32 > h; h++) a.push(E[f + h + 17 >> 0]);
									return 0;
								case 21519:
									if (!d.tty) return -59;
									f = Y();
									return F[f >> 2] = 0;
								case 21520: return d.tty ? -28 : -59;
								case 21531: return f = Y(), R.fa(d, b, f);
								case 21523:
									if (!d.tty) return -59;
									d.tty.K.Ka && (h = [24, 80], f = Y(), ua[f >> 1] = h[0], ua[f + 2 >> 1] = h[1]);
									return 0;
								case 21524: return d.tty ? 0 : -59;
								case 21515: return d.tty ? 0 : -59;
								default: return -28;
							}
						} catch (m) {
							if ("undefined" == typeof R || "ErrnoError" !== m.name) throw m;
							return -m.u;
						}
					},
					__syscall_openat: function(a, b, c, d) {
						Tb = d;
						try {
							b = X(b);
							b = Sb(a, b);
							var f = d ? Y() : 0;
							return R.open(b, c, f).fd;
						} catch (h) {
							if ("undefined" == typeof R || "ErrnoError" !== h.name) throw h;
							return -h.u;
						}
					},
					__syscall_readlinkat: function(a, b, c, d) {
						try {
							b = X(b);
							b = Sb(a, b);
							if (0 >= d) return -28;
							var f = R.readlink(b), h = Math.min(d, jb(f)), m = E[c + h];
							Ub(f, c, d + 1);
							E[c + h] = m;
							return h;
						} catch (p) {
							if ("undefined" == typeof R || "ErrnoError" !== p.name) throw p;
							return -p.u;
						}
					},
					__syscall_renameat: function(a, b, c, d) {
						try {
							return b = X(b), d = X(d), b = Sb(a, b), d = Sb(c, d), R.rename(b, d), 0;
						} catch (f) {
							if ("undefined" == typeof R || "ErrnoError" !== f.name) throw f;
							return -f.u;
						}
					},
					__syscall_rmdir: function(a) {
						try {
							return a = X(a), R.rmdir(a), 0;
						} catch (b) {
							if ("undefined" == typeof R || "ErrnoError" !== b.name) throw b;
							return -b.u;
						}
					},
					__syscall_unlinkat: function(a, b, c) {
						try {
							return b = X(b), b = Sb(a, b), 0 === c ? R.unlink(b) : 512 === c ? R.rmdir(b) : g("Invalid flags passed to unlinkat"), 0;
						} catch (d) {
							if ("undefined" == typeof R || "ErrnoError" !== d.name) throw d;
							return -d.u;
						}
					},
					_emscripten_get_now_is_monotonic: () => 1,
					_emscripten_throw_longjmp: () => {
						throw Infinity;
					},
					_gmtime_js: function(a, b) {
						a = -9007199254740992 > a || 9007199254740992 < a ? NaN : Number(a);
						a = /* @__PURE__ */ new Date(1e3 * a);
						F[b >> 2] = a.getUTCSeconds();
						F[b + 4 >> 2] = a.getUTCMinutes();
						F[b + 8 >> 2] = a.getUTCHours();
						F[b + 12 >> 2] = a.getUTCDate();
						F[b + 16 >> 2] = a.getUTCMonth();
						F[b + 20 >> 2] = a.getUTCFullYear() - 1900;
						F[b + 24 >> 2] = a.getUTCDay();
						F[b + 28 >> 2] = (a.getTime() - Date.UTC(a.getUTCFullYear(), 0, 1, 0, 0, 0, 0)) / 864e5 | 0;
					},
					_localtime_js: function(a, b) {
						a = -9007199254740992 > a || 9007199254740992 < a ? NaN : Number(a);
						a = /* @__PURE__ */ new Date(1e3 * a);
						F[b >> 2] = a.getSeconds();
						F[b + 4 >> 2] = a.getMinutes();
						F[b + 8 >> 2] = a.getHours();
						F[b + 12 >> 2] = a.getDate();
						F[b + 16 >> 2] = a.getMonth();
						F[b + 20 >> 2] = a.getFullYear() - 1900;
						F[b + 24 >> 2] = a.getDay();
						F[b + 28 >> 2] = (Vb(a.getFullYear()) ? Wb : Xb)[a.getMonth()] + a.getDate() - 1 | 0;
						F[b + 36 >> 2] = -(60 * a.getTimezoneOffset());
						var c = new Date(a.getFullYear(), 6, 1).getTimezoneOffset(), d = new Date(a.getFullYear(), 0, 1).getTimezoneOffset();
						F[b + 32 >> 2] = (c != d && a.getTimezoneOffset() == Math.min(d, c)) | 0;
					},
					_mktime_js: function(a) {
						var b = new Date(F[a + 20 >> 2] + 1900, F[a + 16 >> 2], F[a + 12 >> 2], F[a + 8 >> 2], F[a + 4 >> 2], F[a >> 2], 0), c = F[a + 32 >> 2], d = b.getTimezoneOffset(), f = new Date(b.getFullYear(), 6, 1).getTimezoneOffset(), h = new Date(b.getFullYear(), 0, 1).getTimezoneOffset(), m = Math.min(h, f);
						0 > c ? F[a + 32 >> 2] = Number(f != h && m == d) : 0 < c != (m == d) && (f = Math.max(h, f), b.setTime(b.getTime() + 6e4 * ((0 < c ? m : f) - d)));
						F[a + 24 >> 2] = b.getDay();
						F[a + 28 >> 2] = (Vb(b.getFullYear()) ? Wb : Xb)[b.getMonth()] + b.getDate() - 1 | 0;
						F[a >> 2] = b.getSeconds();
						F[a + 4 >> 2] = b.getMinutes();
						F[a + 8 >> 2] = b.getHours();
						F[a + 12 >> 2] = b.getDate();
						F[a + 16 >> 2] = b.getMonth();
						F[a + 20 >> 2] = b.getYear();
						a = b.getTime();
						isNaN(a) ? (F[lc() >> 2] = 61, a = -1) : a /= 1e3;
						return BigInt(a);
					},
					_tzset_js: (a, b, c) => {
						function d(y) {
							return (y = y.toTimeString().match(/\(([A-Za-z ]+)\)$/)) ? y[1] : "GMT";
						}
						var f = (/* @__PURE__ */ new Date()).getFullYear(), h = new Date(f, 0, 1), m = new Date(f, 6, 1);
						f = h.getTimezoneOffset();
						var p = m.getTimezoneOffset();
						G[a >> 2] = 60 * Math.max(f, p);
						F[b >> 2] = Number(f != p);
						a = d(h);
						b = d(m);
						a = Zb(a);
						b = Zb(b);
						p < f ? (G[c >> 2] = a, G[c + 4 >> 2] = b) : (G[c >> 2] = b, G[c + 4 >> 2] = a);
					},
					abort: () => {
						g("native code called abort()");
					},
					emscripten_date_now: () => Date.now(),
					emscripten_get_now: () => performance.now(),
					emscripten_resize_heap: (a) => {
						var b = ta.length;
						a >>>= 0;
						u(a > b);
						if (2147483648 < a) return z(`Cannot enlarge memory, requested ${a} bytes, but the limit is 2147483648 bytes!`), !1;
						for (var c = 1; 4 >= c; c *= 2) {
							var d = b * (1 + .2 / c);
							d = Math.min(d, a + 100663296);
							var f = Math;
							d = Math.max(a, d);
							f = f.min.call(f, 2147483648, d + (65536 - d % 65536) % 65536);
							a: {
								d = f;
								var h = ra.buffer, m = (d - h.byteLength + 65535) / 65536;
								try {
									ra.grow(m);
									ya();
									var p = 1;
									break a;
								} catch (y) {
									z(`growMemory: Attempted to grow heap from ${h.byteLength} bytes to ${d} bytes, but got error: ${y}`);
								}
								p = void 0;
							}
							if (p) return !0;
						}
						z(`Failed to grow the heap from ${b} bytes to ${f} bytes, not enough memory!`);
						return !1;
					},
					environ_get: (a, b) => {
						var c = 0;
						bc().forEach((d, f) => {
							var h = b + c;
							f = G[a + 4 * f >> 2] = h;
							for (h = 0; h < d.length; ++h) u(d.charCodeAt(h) === (d.charCodeAt(h) & 255)), E[f++ >> 0] = d.charCodeAt(h);
							E[f >> 0] = 0;
							c += d.length + 1;
						});
						return 0;
					},
					environ_sizes_get: (a, b) => {
						var c = bc();
						G[a >> 2] = c.length;
						var d = 0;
						c.forEach((f) => d += f.length + 1);
						G[b >> 2] = d;
						return 0;
					},
					exit: (a) => {
						mc();
						sa = !0;
						ea(a, new pa(a));
					},
					fd_close: function(a) {
						try {
							var b = W(a);
							R.close(b);
							return 0;
						} catch (c) {
							if ("undefined" == typeof R || "ErrnoError" !== c.name) throw c;
							return c.u;
						}
					},
					fd_read: function(a, b, c, d) {
						try {
							a: {
								var f = W(a);
								a = b;
								for (var h, m = b = 0; m < c; m++) {
									var p = G[a >> 2], y = G[a + 4 >> 2];
									a += 8;
									var q = R.read(f, E, p, y, h);
									if (0 > q) {
										var x = -1;
										break a;
									}
									b += q;
									if (q < y) break;
									"undefined" !== typeof h && (h += q);
								}
								x = b;
							}
							G[d >> 2] = x;
							return 0;
						} catch (t) {
							if ("undefined" == typeof R || "ErrnoError" !== t.name) throw t;
							return t.u;
						}
					},
					fd_seek: function(a, b, c, d) {
						b = -9007199254740992 > b || 9007199254740992 < b ? NaN : Number(b);
						try {
							if (isNaN(b)) return 61;
							var f = W(a);
							R.D(f, b, c);
							wa[d >> 3] = BigInt(f.position);
							f.ea && 0 === b && 0 === c && (f.ea = null);
							return 0;
						} catch (h) {
							if ("undefined" == typeof R || "ErrnoError" !== h.name) throw h;
							return h.u;
						}
					},
					fd_write: function(a, b, c, d) {
						try {
							a: {
								var f = W(a);
								a = b;
								for (var h, m = b = 0; m < c; m++) {
									var p = G[a >> 2], y = G[a + 4 >> 2];
									a += 8;
									var q = R.write(f, E, p, y, h);
									if (0 > q) {
										var x = -1;
										break a;
									}
									b += q;
									"undefined" !== typeof h && (h += q);
								}
								x = b;
							}
							G[d >> 2] = x;
							return 0;
						} catch (t) {
							if ("undefined" == typeof R || "ErrnoError" !== t.name) throw t;
							return t.u;
						}
					},
					invoke_vii: nc,
					strftime: (a, b, c, d) => {
						function f(l, w, v) {
							for (l = "number" == typeof l ? l.toString() : l || ""; l.length < w;) l = v[0] + l;
							return l;
						}
						function h(l, w) {
							return f(l, w, "0");
						}
						function m(l, w) {
							function v(H) {
								return 0 > H ? -1 : 0 < H ? 1 : 0;
							}
							var A;
							0 === (A = v(l.getFullYear() - w.getFullYear())) && 0 === (A = v(l.getMonth() - w.getMonth())) && (A = v(l.getDate() - w.getDate()));
							return A;
						}
						function p(l) {
							switch (l.getDay()) {
								case 0: return new Date(l.getFullYear() - 1, 11, 29);
								case 1: return l;
								case 2: return new Date(l.getFullYear(), 0, 3);
								case 3: return new Date(l.getFullYear(), 0, 2);
								case 4: return new Date(l.getFullYear(), 0, 1);
								case 5: return new Date(l.getFullYear() - 1, 11, 31);
								case 6: return new Date(l.getFullYear() - 1, 11, 30);
							}
						}
						function y(l) {
							var w = l.O;
							for (l = new Date(new Date(l.P + 1900, 0, 1).getTime()); 0 < w;) {
								var v = l.getMonth(), A = (Vb(l.getFullYear()) ? cc : dc)[v];
								if (w > A - l.getDate()) w -= A - l.getDate() + 1, l.setDate(1), 11 > v ? l.setMonth(v + 1) : (l.setMonth(0), l.setFullYear(l.getFullYear() + 1));
								else {
									l.setDate(l.getDate() + w);
									break;
								}
							}
							v = new Date(l.getFullYear() + 1, 0, 4);
							w = p(new Date(l.getFullYear(), 0, 4));
							v = p(v);
							return 0 >= m(w, l) ? 0 >= m(v, l) ? l.getFullYear() + 1 : l.getFullYear() : l.getFullYear() - 1;
						}
						var q = G[d + 40 >> 2];
						d = {
							Va: F[d >> 2],
							Ua: F[d + 4 >> 2],
							$: F[d + 8 >> 2],
							la: F[d + 12 >> 2],
							aa: F[d + 16 >> 2],
							P: F[d + 20 >> 2],
							H: F[d + 24 >> 2],
							O: F[d + 28 >> 2],
							wb: F[d + 32 >> 2],
							Ta: F[d + 36 >> 2],
							Wa: q ? X(q) : ""
						};
						c = X(c);
						q = {
							"%c": "%a %b %d %H:%M:%S %Y",
							"%D": "%m/%d/%y",
							"%F": "%Y-%m-%d",
							"%h": "%b",
							"%r": "%I:%M:%S %p",
							"%R": "%H:%M",
							"%T": "%H:%M:%S",
							"%x": "%m/%d/%y",
							"%X": "%H:%M:%S",
							"%Ec": "%c",
							"%EC": "%C",
							"%Ex": "%m/%d/%y",
							"%EX": "%H:%M:%S",
							"%Ey": "%y",
							"%EY": "%Y",
							"%Od": "%d",
							"%Oe": "%e",
							"%OH": "%H",
							"%OI": "%I",
							"%Om": "%m",
							"%OM": "%M",
							"%OS": "%S",
							"%Ou": "%u",
							"%OU": "%U",
							"%OV": "%V",
							"%Ow": "%w",
							"%OW": "%W",
							"%Oy": "%y"
						};
						for (var x in q) c = c.replace(new RegExp(x, "g"), q[x]);
						var t = "Sunday Monday Tuesday Wednesday Thursday Friday Saturday".split(" "), B = "January February March April May June July August September October November December".split(" ");
						q = {
							"%a": (l) => t[l.H].substring(0, 3),
							"%A": (l) => t[l.H],
							"%b": (l) => B[l.aa].substring(0, 3),
							"%B": (l) => B[l.aa],
							"%C": (l) => h((l.P + 1900) / 100 | 0, 2),
							"%d": (l) => h(l.la, 2),
							"%e": (l) => f(l.la, 2, " "),
							"%g": (l) => y(l).toString().substring(2),
							"%G": (l) => y(l),
							"%H": (l) => h(l.$, 2),
							"%I": (l) => {
								l = l.$;
								0 == l ? l = 12 : 12 < l && (l -= 12);
								return h(l, 2);
							},
							"%j": (l) => {
								for (var w = 0, v = 0; v <= l.aa - 1; w += (Vb(l.P + 1900) ? cc : dc)[v++]);
								return h(l.la + w, 3);
							},
							"%m": (l) => h(l.aa + 1, 2),
							"%M": (l) => h(l.Ua, 2),
							"%n": () => "\n",
							"%p": (l) => 0 <= l.$ && 12 > l.$ ? "AM" : "PM",
							"%S": (l) => h(l.Va, 2),
							"%t": () => "	",
							"%u": (l) => l.H || 7,
							"%U": (l) => h(Math.floor((l.O + 7 - l.H) / 7), 2),
							"%V": (l) => {
								var w = Math.floor((l.O + 7 - (l.H + 6) % 7) / 7);
								2 >= (l.H + 371 - l.O - 2) % 7 && w++;
								if (w) 53 == w && (v = (l.H + 371 - l.O) % 7, 4 == v || 3 == v && Vb(l.P) || (w = 1));
								else {
									w = 52;
									var v = (l.H + 7 - l.O - 1) % 7;
									(4 == v || 5 == v && Vb(l.P % 400 - 1)) && w++;
								}
								return h(w, 2);
							},
							"%w": (l) => l.H,
							"%W": (l) => h(Math.floor((l.O + 7 - (l.H + 6) % 7) / 7), 2),
							"%y": (l) => (l.P + 1900).toString().substring(2),
							"%Y": (l) => l.P + 1900,
							"%z": (l) => {
								l = l.Ta;
								var w = 0 <= l;
								l = Math.abs(l) / 60;
								return (w ? "+" : "-") + String("0000" + (l / 60 * 100 + l % 60)).slice(-4);
							},
							"%Z": (l) => l.Wa,
							"%%": () => "%"
						};
						c = c.replace(/%%/g, "\0\0");
						for (x in q) c.includes(x) && (c = c.replace(new RegExp(x, "g"), q[x](d)));
						c = c.replace(/\0\0/g, "%");
						x = lb(c, !1);
						if (x.length > b) return 0;
						ec(x, a);
						return x.length - 1;
					},
					system: (a) => {
						if (n) {
							if (!a) return 1;
							a = X(a);
							if (!a.length) return 0;
							a = require$1("child_process").ub(a, [], {
								tb: !0,
								stdio: "inherit"
							});
							var b = (c, d) => c << 8 | d;
							return null === a.status ? b(0, ((c) => {
								switch (c) {
									case "SIGHUP": return 1;
									case "SIGQUIT": return 3;
									case "SIGFPE": return 8;
									case "SIGKILL": return 9;
									case "SIGALRM": return 14;
									case "SIGTERM": return 15;
								}
								return 2;
							})(a.signal)) : a.status << 8 | 0;
						}
						if (!a) return 0;
						F[lc() >> 2] = 52;
						return -1;
					}
				}, L = function() {
					var a = {
						env: oc,
						wasi_snapshot_preview1: oc
					};
					Ma("wasm-instantiate");
					var b = e;
					Ta(a, function(c) {
						u(e === b, "the Module object should not be replaced during async compilation - perhaps the order of HTML elements is wrong?");
						b = null;
						L = c.instance.exports;
						ra = L.memory;
						u(ra, "memory not found in wasm exports");
						ya();
						Z = L.__indirect_function_table;
						u(Z, "table not found in wasm exports");
						Fa.unshift(L.__wasm_call_ctors);
						Na("wasm-instantiate");
					}).catch(ba);
					return {};
				}();
				e._lua_checkstack = J("lua_checkstack");
				e._lua_xmove = J("lua_xmove");
				e._lua_atpanic = J("lua_atpanic");
				e._lua_version = J("lua_version");
				e._lua_absindex = J("lua_absindex");
				e._lua_gettop = J("lua_gettop");
				e._lua_settop = J("lua_settop");
				e._lua_closeslot = J("lua_closeslot");
				e._lua_rotate = J("lua_rotate");
				e._lua_copy = J("lua_copy");
				e._lua_pushvalue = J("lua_pushvalue");
				e._lua_type = J("lua_type");
				e._lua_typename = J("lua_typename");
				e._lua_iscfunction = J("lua_iscfunction");
				e._lua_isinteger = J("lua_isinteger");
				e._lua_isnumber = J("lua_isnumber");
				e._lua_isstring = J("lua_isstring");
				e._lua_isuserdata = J("lua_isuserdata");
				e._lua_rawequal = J("lua_rawequal");
				e._lua_arith = J("lua_arith");
				e._lua_compare = J("lua_compare");
				e._lua_stringtonumber = J("lua_stringtonumber");
				e._lua_tonumberx = J("lua_tonumberx");
				e._lua_tointegerx = J("lua_tointegerx");
				e._lua_toboolean = J("lua_toboolean");
				e._lua_tolstring = J("lua_tolstring");
				e._lua_rawlen = J("lua_rawlen");
				e._lua_tocfunction = J("lua_tocfunction");
				e._lua_touserdata = J("lua_touserdata");
				e._lua_tothread = J("lua_tothread");
				e._lua_topointer = J("lua_topointer");
				e._lua_pushnil = J("lua_pushnil");
				e._lua_pushnumber = J("lua_pushnumber");
				e._lua_pushinteger = J("lua_pushinteger");
				e._lua_pushlstring = J("lua_pushlstring");
				e._lua_pushstring = J("lua_pushstring");
				e._lua_pushcclosure = J("lua_pushcclosure");
				e._lua_pushboolean = J("lua_pushboolean");
				e._lua_pushlightuserdata = J("lua_pushlightuserdata");
				e._lua_pushthread = J("lua_pushthread");
				e._lua_getglobal = J("lua_getglobal");
				e._lua_gettable = J("lua_gettable");
				e._lua_getfield = J("lua_getfield");
				e._lua_geti = J("lua_geti");
				e._lua_rawget = J("lua_rawget");
				e._lua_rawgeti = J("lua_rawgeti");
				e._lua_rawgetp = J("lua_rawgetp");
				e._lua_createtable = J("lua_createtable");
				e._lua_getmetatable = J("lua_getmetatable");
				e._lua_getiuservalue = J("lua_getiuservalue");
				e._lua_setglobal = J("lua_setglobal");
				e._lua_settable = J("lua_settable");
				e._lua_setfield = J("lua_setfield");
				e._lua_seti = J("lua_seti");
				e._lua_rawset = J("lua_rawset");
				e._lua_rawsetp = J("lua_rawsetp");
				e._lua_rawseti = J("lua_rawseti");
				e._lua_setmetatable = J("lua_setmetatable");
				e._lua_setiuservalue = J("lua_setiuservalue");
				e._lua_callk = J("lua_callk");
				e._lua_pcallk = J("lua_pcallk");
				e._lua_load = J("lua_load");
				e._lua_dump = J("lua_dump");
				e._lua_status = J("lua_status");
				e._lua_error = J("lua_error");
				e._lua_next = J("lua_next");
				e._lua_toclose = J("lua_toclose");
				e._lua_concat = J("lua_concat");
				e._lua_len = J("lua_len");
				e._lua_getallocf = J("lua_getallocf");
				e._lua_setallocf = J("lua_setallocf");
				e._lua_setwarnf = J("lua_setwarnf");
				e._lua_warning = J("lua_warning");
				e._lua_newuserdatauv = J("lua_newuserdatauv");
				e._lua_getupvalue = J("lua_getupvalue");
				e._lua_setupvalue = J("lua_setupvalue");
				e._lua_upvalueid = J("lua_upvalueid");
				e._lua_upvaluejoin = J("lua_upvaluejoin");
				e._luaL_traceback = J("luaL_traceback");
				e._lua_getstack = J("lua_getstack");
				e._lua_getinfo = J("lua_getinfo");
				e._luaL_buffinit = J("luaL_buffinit");
				e._luaL_addstring = J("luaL_addstring");
				e._luaL_prepbuffsize = J("luaL_prepbuffsize");
				e._luaL_addvalue = J("luaL_addvalue");
				e._luaL_pushresult = J("luaL_pushresult");
				e._luaL_argerror = J("luaL_argerror");
				e._luaL_typeerror = J("luaL_typeerror");
				e._luaL_getmetafield = J("luaL_getmetafield");
				e._luaL_where = J("luaL_where");
				e._luaL_fileresult = J("luaL_fileresult");
				var lc = J("__errno_location");
				e._luaL_execresult = J("luaL_execresult");
				e._luaL_newmetatable = J("luaL_newmetatable");
				e._luaL_setmetatable = J("luaL_setmetatable");
				e._luaL_testudata = J("luaL_testudata");
				e._luaL_checkudata = J("luaL_checkudata");
				e._luaL_optlstring = J("luaL_optlstring");
				e._luaL_checklstring = J("luaL_checklstring");
				e._luaL_checkstack = J("luaL_checkstack");
				e._luaL_checktype = J("luaL_checktype");
				e._luaL_checkany = J("luaL_checkany");
				e._luaL_checknumber = J("luaL_checknumber");
				e._luaL_optnumber = J("luaL_optnumber");
				e._luaL_checkinteger = J("luaL_checkinteger");
				e._luaL_optinteger = J("luaL_optinteger");
				e._luaL_setfuncs = J("luaL_setfuncs");
				e._luaL_addlstring = J("luaL_addlstring");
				e._luaL_pushresultsize = J("luaL_pushresultsize");
				e._luaL_buffinitsize = J("luaL_buffinitsize");
				e._luaL_ref = J("luaL_ref");
				e._luaL_unref = J("luaL_unref");
				e._luaL_loadfilex = J("luaL_loadfilex");
				e._luaL_loadbufferx = J("luaL_loadbufferx");
				e._luaL_loadstring = J("luaL_loadstring");
				e._luaL_callmeta = J("luaL_callmeta");
				e._luaL_len = J("luaL_len");
				e._luaL_tolstring = J("luaL_tolstring");
				e._luaL_getsubtable = J("luaL_getsubtable");
				e._luaL_requiref = J("luaL_requiref");
				e._luaL_addgsub = J("luaL_addgsub");
				e._luaL_gsub = J("luaL_gsub");
				e._luaL_newstate = J("luaL_newstate");
				e._lua_newstate = J("lua_newstate");
				e._free = J("free");
				e._realloc = J("realloc");
				var Rb = e._fflush = J("fflush");
				e._luaL_checkversion_ = J("luaL_checkversion_");
				e._luaopen_base = J("luaopen_base");
				e._luaopen_coroutine = J("luaopen_coroutine");
				e._lua_newthread = J("lua_newthread");
				e._lua_yieldk = J("lua_yieldk");
				e._lua_isyieldable = J("lua_isyieldable");
				e._lua_resetthread = J("lua_resetthread");
				e._lua_resume = J("lua_resume");
				e._luaopen_debug = J("luaopen_debug");
				e._lua_gethookmask = J("lua_gethookmask");
				e._lua_gethook = J("lua_gethook");
				e._lua_gethookcount = J("lua_gethookcount");
				e._lua_getlocal = J("lua_getlocal");
				e._lua_sethook = J("lua_sethook");
				e._lua_setlocal = J("lua_setlocal");
				e._lua_setcstacklimit = J("lua_setcstacklimit");
				var Yb = e._malloc = J("malloc");
				e._luaL_openlibs = J("luaL_openlibs");
				e._luaopen_package = J("luaopen_package");
				e._luaopen_table = J("luaopen_table");
				e._luaopen_io = J("luaopen_io");
				e._luaopen_os = J("luaopen_os");
				e._luaopen_string = J("luaopen_string");
				e._luaopen_math = J("luaopen_math");
				e._luaopen_utf8 = J("luaopen_utf8");
				e._lua_close = J("lua_close");
				var pc = J("setThrew"), qc = () => (qc = L.emscripten_stack_init)(), Aa = () => (Aa = L.emscripten_stack_get_end)(), rc = J("stackSave"), sc = J("stackRestore"), tc = J("stackAlloc");
				function nc(a, b, c) {
					var d = rc();
					try {
						gc(a)(b, c);
					} catch (f) {
						sc(d);
						if (f !== f + 0) throw f;
						pc(1, 0);
					}
				}
				e.ENV = $b;
				e.ccall = (a, b, c, d) => {
					var f = {
						string: (q) => {
							var x = 0;
							if (null !== q && void 0 !== q && 0 !== q) {
								x = jb(q) + 1;
								var t = tc(x);
								Ub(q, t, x);
								x = t;
							}
							return x;
						},
						array: (q) => {
							var x = tc(q.length);
							ec(q, x);
							return x;
						}
					};
					a = hc(a);
					var h = [], m = 0;
					u("array" !== b, "Return type should not be \"array\".");
					if (d) for (var p = 0; p < d.length; p++) {
						var y = f[c[p]];
						y ? (0 === m && (m = rc()), h[p] = y(d[p])) : h[p] = d[p];
					}
					c = a.apply(null, h);
					return c = function(q) {
						0 !== m && sc(m);
						return "string" === b ? X(q) : "boolean" === b ? !!q : q;
					}(c);
				};
				e.addFunction = (a, b) => {
					u("undefined" != typeof a);
					if (!ic) {
						ic = /* @__PURE__ */ new WeakMap();
						var c = Z.length;
						if (ic) for (var d = 0; d < 0 + c; d++) {
							var f = gc(d);
							f && ic.set(f, d);
						}
					}
					if (c = ic.get(a) || 0) return c;
					if (jc.length) c = jc.pop();
					else {
						try {
							Z.grow(1);
						} catch (p) {
							if (!(p instanceof RangeError)) throw p;
							throw "Unable to grow wasm table. Set ALLOW_TABLE_GROWTH.";
						}
						c = Z.length - 1;
					}
					try {
						d = c, Z.set(d, a), fc[d] = Z.get(d);
					} catch (p) {
						if (!(p instanceof TypeError)) throw p;
						u("undefined" != typeof b, "Missing signature argument to addFunction: " + a);
						if ("function" == typeof WebAssembly.Function) {
							d = WebAssembly.Function;
							f = {
								i: "i32",
								j: "i64",
								f: "f32",
								d: "f64",
								e: "externref",
								p: "i32"
							};
							for (var h = {
								parameters: [],
								results: "v" == b[0] ? [] : [f[b[0]]]
							}, m = 1; m < b.length; ++m) u(b[m] in f, "invalid signature char: " + b[m]), h.parameters.push(f[b[m]]);
							b = new d(h, a);
						} else {
							d = [1];
							f = b.slice(0, 1);
							b = b.slice(1);
							h = {
								i: 127,
								p: 127,
								j: 126,
								f: 125,
								d: 124,
								e: 111
							};
							d.push(96);
							m = b.length;
							u(16384 > m);
							128 > m ? d.push(m) : d.push(m % 128 | 128, m >> 7);
							for (m = 0; m < b.length; ++m) u(b[m] in h, "invalid signature char: " + b[m]), d.push(h[b[m]]);
							"v" == f ? d.push(0) : d.push(1, h[f]);
							b = [
								0,
								97,
								115,
								109,
								1,
								0,
								0,
								0,
								1
							];
							f = d.length;
							u(16384 > f);
							128 > f ? b.push(f) : b.push(f % 128 | 128, f >> 7);
							b.push.apply(b, d);
							b.push(2, 7, 1, 1, 101, 1, 102, 0, 0, 7, 5, 1, 1, 102, 0, 0);
							b = new WebAssembly.Module(new Uint8Array(b));
							b = new WebAssembly.Instance(b, { e: { f: a } }).exports.f;
						}
						d = c;
						Z.set(d, b);
						fc[d] = Z.get(d);
					}
					ic.set(a, c);
					return c;
				};
				e.removeFunction = (a) => {
					ic.delete(gc(a));
					Z.set(a, null);
					fc[a] = Z.get(a);
					jc.push(a);
				};
				e.setValue = function(a, b, c = "i8") {
					c.endsWith("*") && (c = "*");
					switch (c) {
						case "i1":
							E[a >> 0] = b;
							break;
						case "i8":
							E[a >> 0] = b;
							break;
						case "i16":
							ua[a >> 1] = b;
							break;
						case "i32":
							F[a >> 2] = b;
							break;
						case "i64":
							wa[a >> 3] = BigInt(b);
							break;
						case "float":
							va[a >> 2] = b;
							break;
						case "double":
							xa[a >> 3] = b;
							break;
						case "*":
							G[a >> 2] = b;
							break;
						default: g(`invalid type for setValue: ${c}`);
					}
				};
				e.getValue = function(a, b = "i8") {
					b.endsWith("*") && (b = "*");
					switch (b) {
						case "i1": return E[a >> 0];
						case "i8": return E[a >> 0];
						case "i16": return ua[a >> 1];
						case "i32": return F[a >> 2];
						case "i64": return wa[a >> 3];
						case "float": return va[a >> 2];
						case "double": return xa[a >> 3];
						case "*": return G[a >> 2];
						default: g(`invalid type for getValue: ${b}`);
					}
				};
				e.stringToUTF8 = Ub;
				e.lengthBytesUTF8 = jb;
				e.stringToNewUTF8 = Zb;
				e.FS = R;
				"writeI53ToI64 writeI53ToI64Clamped writeI53ToI64Signaling writeI53ToU64Clamped writeI53ToU64Signaling readI53FromI64 readI53FromU64 convertI32PairToI53 convertI32PairToI53Checked convertU32PairToI53 inetPton4 inetNtop4 inetPton6 inetNtop6 readSockaddr writeSockaddr getHostByName getCallstack emscriptenLog convertPCtoSourceLocation readEmAsmArgs jstoi_q jstoi_s listenOnce autoResumeAudioContext getDynCaller dynCall handleException runtimeKeepalivePush runtimeKeepalivePop callUserCallback maybeExit asmjsMangle handleAllocatorInit HandleAllocator getNativeTypeSize STACK_SIZE STACK_ALIGN POINTER_SIZE ASSERTIONS cwrap reallyNegative unSign strLen reSign formatString intArrayToString AsciiToString UTF16ToString stringToUTF16 lengthBytesUTF16 UTF32ToString stringToUTF32 lengthBytesUTF32 registerKeyEventCallback maybeCStringToJsString findEventTarget findCanvasEventTarget getBoundingClientRect fillMouseEventData registerMouseEventCallback registerWheelEventCallback registerUiEventCallback registerFocusEventCallback fillDeviceOrientationEventData registerDeviceOrientationEventCallback fillDeviceMotionEventData registerDeviceMotionEventCallback screenOrientation fillOrientationChangeEventData registerOrientationChangeEventCallback fillFullscreenChangeEventData registerFullscreenChangeEventCallback JSEvents_requestFullscreen JSEvents_resizeCanvasForFullscreen registerRestoreOldStyle hideEverythingExceptGivenElement restoreHiddenElements setLetterbox softFullscreenResizeWebGLRenderTarget doRequestFullscreen fillPointerlockChangeEventData registerPointerlockChangeEventCallback registerPointerlockErrorEventCallback requestPointerLock fillVisibilityChangeEventData registerVisibilityChangeEventCallback registerTouchEventCallback fillGamepadEventData registerGamepadEventCallback registerBeforeUnloadEventCallback fillBatteryEventData battery registerBatteryEventCallback setCanvasElementSize getCanvasElementSize jsStackTrace stackTrace checkWasiClock wasiRightsToMuslOFlags wasiOFlagsToMuslOFlags createDyncallWrapper safeSetTimeout setImmediateWrapped clearImmediateWrapped polyfillSetImmediate getPromise makePromise idsToPromises makePromiseCallback setMainLoop getSocketFromFD getSocketAddress FS_unlink FS_mkdirTree _setNetworkCallback".split(" ").forEach(function(a) {
					"undefined" === typeof globalThis || Object.getOwnPropertyDescriptor(globalThis, a) || Object.defineProperty(globalThis, a, {
						configurable: !0,
						get() {
							var b = `\`${a}\` is a library symbol and not included by default; add it to your library.js __deps or to DEFAULT_LIBRARY_FUNCS_TO_INCLUDE on the command line`, c = a;
							c.startsWith("_") || (c = "$" + a);
							b += ` (e.g. -sDEFAULT_LIBRARY_FUNCS_TO_INCLUDE='${c}')`;
							Ua(a) && (b += ". Alternatively, forcing filesystem support (-sFORCE_FILESYSTEM) can export this for you");
							Wa(b);
						}
					});
					Xa(a);
				});
				"run addOnPreRun addOnInit addOnPreMain addOnExit addOnPostRun addRunDependency removeRunDependency FS_createFolder FS_createPath FS_createLazyFile FS_createLink FS_createDevice FS_readFile out err callMain abort wasmMemory wasmExports stackAlloc stackSave stackRestore getTempRet0 setTempRet0 writeStackCookie checkStackCookie MAX_INT53 MIN_INT53 bigintToI53Checked ptrToString zeroMemory exitJS getHeapMax growMemory MONTH_DAYS_REGULAR MONTH_DAYS_LEAP MONTH_DAYS_REGULAR_CUMULATIVE MONTH_DAYS_LEAP_CUMULATIVE isLeapYear ydayFromDate arraySum addDays ERRNO_CODES ERRNO_MESSAGES setErrNo DNS Protocols Sockets initRandomFill randomFill timers warnOnce UNWIND_CACHE readEmAsmArgsArray getExecutableName keepRuntimeAlive asyncLoad alignMemory mmapAlloc wasmTable noExitRuntime getCFunc uleb128Encode sigToWasmTypes generateFuncType convertJsFunctionToWasm freeTableIndexes functionsInTableMap getEmptyTableSlot updateTableMap getFunctionAddress PATH PATH_FS UTF8Decoder UTF8ArrayToString UTF8ToString stringToUTF8Array intArrayFromString stringToAscii UTF16Decoder stringToUTF8OnStack writeArrayToMemory JSEvents specialHTMLTargets currentFullscreenStrategy restoreOldWindowedStyle demangle demangleAll ExitStatus getEnvStrings doReadv doWritev promiseMap Browser wget SYSCALLS preloadPlugins FS_createPreloadedFile FS_modeStringToFlags FS_getMode FS_stdin_getChar_buffer FS_stdin_getChar FS_createDataFile MEMFS TTY PIPEFS SOCKFS".split(" ").forEach(Xa);
				var uc;
				Ja = function vc() {
					uc || wc();
					uc || (Ja = vc);
				};
				function wc() {
					if (!(0 < Ia)) {
						qc();
						var a = Aa();
						u(0 == (a & 3));
						0 == a && (a += 4);
						G[a >> 2] = 34821223;
						G[a + 4 >> 2] = 2310721022;
						G[0] = 1668509029;
						if (e.preRun) for ("function" == typeof e.preRun && (e.preRun = [e.preRun]); e.preRun.length;) a = e.preRun.shift(), Ea.unshift(a);
						for (; 0 < Ea.length;) Ea.shift()(e);
						if (!(0 < Ia)) {
							if (!uc && (uc = !0, e.calledRun = !0, !sa)) {
								u(!Ha);
								Ha = !0;
								za();
								e.noFSInit || R.R.Y || R.R();
								for (R.ta = !1; 0 < Fa.length;) Fa.shift()(e);
								aa(e);
								u(!e._main, "compiled without a main, but one is present. if you added it from JS, use Module[\"onRuntimeInitialized\"]");
								for (za(); 0 < Ga.length;) Ga.shift()(e);
							}
							za();
						}
					}
				}
				function mc() {
					var a = qa, b = z, c = !1;
					qa = z = () => {
						c = !0;
					};
					try {
						Rb(0), ["stdout", "stderr"].forEach(function(d) {
							(d = Ob("/dev/" + d)) && (d = mb[d.object.rdev]) && d.output && d.output.length && (c = !0);
						});
					} catch (d) {}
					qa = a;
					z = b;
					c && Wa("stdio streams had content in them that was not flushed. you should set EXIT_RUNTIME to 1 (see the Emscripten FAQ), or make sure to emit a newline when you printf etc.");
				}
				wc();
				return moduleArg.ready;
			});
		})();
		class LuaWasm {
			static async initialize(customWasmFileLocation, environmentVariables) {
				return new LuaWasm(await initWasmModule({
					locateFile: (path, scriptDirectory) => {
						return customWasmFileLocation || scriptDirectory + path;
					},
					preRun: (initializedModule) => {
						if (typeof environmentVariables === "object") Object.entries(environmentVariables).forEach(([k, v]) => initializedModule.ENV[k] = v);
					}
				}));
			}
			constructor(module$1) {
				this.referenceTracker = /* @__PURE__ */ new WeakMap();
				this.referenceMap = /* @__PURE__ */ new Map();
				this.availableReferences = [];
				this.module = module$1;
				this.luaL_checkversion_ = this.cwrap("luaL_checkversion_", null, [
					"number",
					"number",
					"number"
				]);
				this.luaL_getmetafield = this.cwrap("luaL_getmetafield", "number", [
					"number",
					"number",
					"string"
				]);
				this.luaL_callmeta = this.cwrap("luaL_callmeta", "number", [
					"number",
					"number",
					"string"
				]);
				this.luaL_tolstring = this.cwrap("luaL_tolstring", "string", [
					"number",
					"number",
					"number"
				]);
				this.luaL_argerror = this.cwrap("luaL_argerror", "number", [
					"number",
					"number",
					"string"
				]);
				this.luaL_typeerror = this.cwrap("luaL_typeerror", "number", [
					"number",
					"number",
					"string"
				]);
				this.luaL_checklstring = this.cwrap("luaL_checklstring", "string", [
					"number",
					"number",
					"number"
				]);
				this.luaL_optlstring = this.cwrap("luaL_optlstring", "string", [
					"number",
					"number",
					"string",
					"number"
				]);
				this.luaL_checknumber = this.cwrap("luaL_checknumber", "number", ["number", "number"]);
				this.luaL_optnumber = this.cwrap("luaL_optnumber", "number", [
					"number",
					"number",
					"number"
				]);
				this.luaL_checkinteger = this.cwrap("luaL_checkinteger", "number", ["number", "number"]);
				this.luaL_optinteger = this.cwrap("luaL_optinteger", "number", [
					"number",
					"number",
					"number"
				]);
				this.luaL_checkstack = this.cwrap("luaL_checkstack", null, [
					"number",
					"number",
					"string"
				]);
				this.luaL_checktype = this.cwrap("luaL_checktype", null, [
					"number",
					"number",
					"number"
				]);
				this.luaL_checkany = this.cwrap("luaL_checkany", null, ["number", "number"]);
				this.luaL_newmetatable = this.cwrap("luaL_newmetatable", "number", ["number", "string"]);
				this.luaL_setmetatable = this.cwrap("luaL_setmetatable", null, ["number", "string"]);
				this.luaL_testudata = this.cwrap("luaL_testudata", "number", [
					"number",
					"number",
					"string"
				]);
				this.luaL_checkudata = this.cwrap("luaL_checkudata", "number", [
					"number",
					"number",
					"string"
				]);
				this.luaL_where = this.cwrap("luaL_where", null, ["number", "number"]);
				this.luaL_fileresult = this.cwrap("luaL_fileresult", "number", [
					"number",
					"number",
					"string"
				]);
				this.luaL_execresult = this.cwrap("luaL_execresult", "number", ["number", "number"]);
				this.luaL_ref = this.cwrap("luaL_ref", "number", ["number", "number"]);
				this.luaL_unref = this.cwrap("luaL_unref", null, [
					"number",
					"number",
					"number"
				]);
				this.luaL_loadfilex = this.cwrap("luaL_loadfilex", "number", [
					"number",
					"string",
					"string"
				]);
				this.luaL_loadbufferx = this.cwrap("luaL_loadbufferx", "number", [
					"number",
					"string|number",
					"number",
					"string|number",
					"string"
				]);
				this.luaL_loadstring = this.cwrap("luaL_loadstring", "number", ["number", "string"]);
				this.luaL_newstate = this.cwrap("luaL_newstate", "number", []);
				this.luaL_len = this.cwrap("luaL_len", "number", ["number", "number"]);
				this.luaL_addgsub = this.cwrap("luaL_addgsub", null, [
					"number",
					"string",
					"string",
					"string"
				]);
				this.luaL_gsub = this.cwrap("luaL_gsub", "string", [
					"number",
					"string",
					"string",
					"string"
				]);
				this.luaL_setfuncs = this.cwrap("luaL_setfuncs", null, [
					"number",
					"number",
					"number"
				]);
				this.luaL_getsubtable = this.cwrap("luaL_getsubtable", "number", [
					"number",
					"number",
					"string"
				]);
				this.luaL_traceback = this.cwrap("luaL_traceback", null, [
					"number",
					"number",
					"string",
					"number"
				]);
				this.luaL_requiref = this.cwrap("luaL_requiref", null, [
					"number",
					"string",
					"number",
					"number"
				]);
				this.luaL_buffinit = this.cwrap("luaL_buffinit", null, ["number", "number"]);
				this.luaL_prepbuffsize = this.cwrap("luaL_prepbuffsize", "string", ["number", "number"]);
				this.luaL_addlstring = this.cwrap("luaL_addlstring", null, [
					"number",
					"string",
					"number"
				]);
				this.luaL_addstring = this.cwrap("luaL_addstring", null, ["number", "string"]);
				this.luaL_addvalue = this.cwrap("luaL_addvalue", null, ["number"]);
				this.luaL_pushresult = this.cwrap("luaL_pushresult", null, ["number"]);
				this.luaL_pushresultsize = this.cwrap("luaL_pushresultsize", null, ["number", "number"]);
				this.luaL_buffinitsize = this.cwrap("luaL_buffinitsize", "string", [
					"number",
					"number",
					"number"
				]);
				this.lua_newstate = this.cwrap("lua_newstate", "number", ["number", "number"]);
				this.lua_close = this.cwrap("lua_close", null, ["number"]);
				this.lua_newthread = this.cwrap("lua_newthread", "number", ["number"]);
				this.lua_resetthread = this.cwrap("lua_resetthread", "number", ["number"]);
				this.lua_atpanic = this.cwrap("lua_atpanic", "number", ["number", "number"]);
				this.lua_version = this.cwrap("lua_version", "number", ["number"]);
				this.lua_absindex = this.cwrap("lua_absindex", "number", ["number", "number"]);
				this.lua_gettop = this.cwrap("lua_gettop", "number", ["number"]);
				this.lua_settop = this.cwrap("lua_settop", null, ["number", "number"]);
				this.lua_pushvalue = this.cwrap("lua_pushvalue", null, ["number", "number"]);
				this.lua_rotate = this.cwrap("lua_rotate", null, [
					"number",
					"number",
					"number"
				]);
				this.lua_copy = this.cwrap("lua_copy", null, [
					"number",
					"number",
					"number"
				]);
				this.lua_checkstack = this.cwrap("lua_checkstack", "number", ["number", "number"]);
				this.lua_xmove = this.cwrap("lua_xmove", null, [
					"number",
					"number",
					"number"
				]);
				this.lua_isnumber = this.cwrap("lua_isnumber", "number", ["number", "number"]);
				this.lua_isstring = this.cwrap("lua_isstring", "number", ["number", "number"]);
				this.lua_iscfunction = this.cwrap("lua_iscfunction", "number", ["number", "number"]);
				this.lua_isinteger = this.cwrap("lua_isinteger", "number", ["number", "number"]);
				this.lua_isuserdata = this.cwrap("lua_isuserdata", "number", ["number", "number"]);
				this.lua_type = this.cwrap("lua_type", "number", ["number", "number"]);
				this.lua_typename = this.cwrap("lua_typename", "string", ["number", "number"]);
				this.lua_tonumberx = this.cwrap("lua_tonumberx", "number", [
					"number",
					"number",
					"number"
				]);
				this.lua_tointegerx = this.cwrap("lua_tointegerx", "number", [
					"number",
					"number",
					"number"
				]);
				this.lua_toboolean = this.cwrap("lua_toboolean", "number", ["number", "number"]);
				this.lua_tolstring = this.cwrap("lua_tolstring", "string", [
					"number",
					"number",
					"number"
				]);
				this.lua_rawlen = this.cwrap("lua_rawlen", "number", ["number", "number"]);
				this.lua_tocfunction = this.cwrap("lua_tocfunction", "number", ["number", "number"]);
				this.lua_touserdata = this.cwrap("lua_touserdata", "number", ["number", "number"]);
				this.lua_tothread = this.cwrap("lua_tothread", "number", ["number", "number"]);
				this.lua_topointer = this.cwrap("lua_topointer", "number", ["number", "number"]);
				this.lua_arith = this.cwrap("lua_arith", null, ["number", "number"]);
				this.lua_rawequal = this.cwrap("lua_rawequal", "number", [
					"number",
					"number",
					"number"
				]);
				this.lua_compare = this.cwrap("lua_compare", "number", [
					"number",
					"number",
					"number",
					"number"
				]);
				this.lua_pushnil = this.cwrap("lua_pushnil", null, ["number"]);
				this.lua_pushnumber = this.cwrap("lua_pushnumber", null, ["number", "number"]);
				this.lua_pushinteger = this.cwrap("lua_pushinteger", null, ["number", "number"]);
				this.lua_pushlstring = this.cwrap("lua_pushlstring", "string", [
					"number",
					"string|number",
					"number"
				]);
				this.lua_pushstring = this.cwrap("lua_pushstring", "string", ["number", "string|number"]);
				this.lua_pushcclosure = this.cwrap("lua_pushcclosure", null, [
					"number",
					"number",
					"number"
				]);
				this.lua_pushboolean = this.cwrap("lua_pushboolean", null, ["number", "number"]);
				this.lua_pushlightuserdata = this.cwrap("lua_pushlightuserdata", null, ["number", "number"]);
				this.lua_pushthread = this.cwrap("lua_pushthread", "number", ["number"]);
				this.lua_getglobal = this.cwrap("lua_getglobal", "number", ["number", "string"]);
				this.lua_gettable = this.cwrap("lua_gettable", "number", ["number", "number"]);
				this.lua_getfield = this.cwrap("lua_getfield", "number", [
					"number",
					"number",
					"string"
				]);
				this.lua_geti = this.cwrap("lua_geti", "number", [
					"number",
					"number",
					"number"
				]);
				this.lua_rawget = this.cwrap("lua_rawget", "number", ["number", "number"]);
				this.lua_rawgeti = this.cwrap("lua_rawgeti", "number", [
					"number",
					"number",
					"number"
				]);
				this.lua_rawgetp = this.cwrap("lua_rawgetp", "number", [
					"number",
					"number",
					"number"
				]);
				this.lua_createtable = this.cwrap("lua_createtable", null, [
					"number",
					"number",
					"number"
				]);
				this.lua_newuserdatauv = this.cwrap("lua_newuserdatauv", "number", [
					"number",
					"number",
					"number"
				]);
				this.lua_getmetatable = this.cwrap("lua_getmetatable", "number", ["number", "number"]);
				this.lua_getiuservalue = this.cwrap("lua_getiuservalue", "number", [
					"number",
					"number",
					"number"
				]);
				this.lua_setglobal = this.cwrap("lua_setglobal", null, ["number", "string"]);
				this.lua_settable = this.cwrap("lua_settable", null, ["number", "number"]);
				this.lua_setfield = this.cwrap("lua_setfield", null, [
					"number",
					"number",
					"string"
				]);
				this.lua_seti = this.cwrap("lua_seti", null, [
					"number",
					"number",
					"number"
				]);
				this.lua_rawset = this.cwrap("lua_rawset", null, ["number", "number"]);
				this.lua_rawseti = this.cwrap("lua_rawseti", null, [
					"number",
					"number",
					"number"
				]);
				this.lua_rawsetp = this.cwrap("lua_rawsetp", null, [
					"number",
					"number",
					"number"
				]);
				this.lua_setmetatable = this.cwrap("lua_setmetatable", "number", ["number", "number"]);
				this.lua_setiuservalue = this.cwrap("lua_setiuservalue", "number", [
					"number",
					"number",
					"number"
				]);
				this.lua_callk = this.cwrap("lua_callk", null, [
					"number",
					"number",
					"number",
					"number",
					"number"
				]);
				this.lua_pcallk = this.cwrap("lua_pcallk", "number", [
					"number",
					"number",
					"number",
					"number",
					"number",
					"number"
				]);
				this.lua_load = this.cwrap("lua_load", "number", [
					"number",
					"number",
					"number",
					"string",
					"string"
				]);
				this.lua_dump = this.cwrap("lua_dump", "number", [
					"number",
					"number",
					"number",
					"number"
				]);
				this.lua_yieldk = this.cwrap("lua_yieldk", "number", [
					"number",
					"number",
					"number",
					"number"
				]);
				this.lua_resume = this.cwrap("lua_resume", "number", [
					"number",
					"number",
					"number",
					"number"
				]);
				this.lua_status = this.cwrap("lua_status", "number", ["number"]);
				this.lua_isyieldable = this.cwrap("lua_isyieldable", "number", ["number"]);
				this.lua_setwarnf = this.cwrap("lua_setwarnf", null, [
					"number",
					"number",
					"number"
				]);
				this.lua_warning = this.cwrap("lua_warning", null, [
					"number",
					"string",
					"number"
				]);
				this.lua_error = this.cwrap("lua_error", "number", ["number"]);
				this.lua_next = this.cwrap("lua_next", "number", ["number", "number"]);
				this.lua_concat = this.cwrap("lua_concat", null, ["number", "number"]);
				this.lua_len = this.cwrap("lua_len", null, ["number", "number"]);
				this.lua_stringtonumber = this.cwrap("lua_stringtonumber", "number", ["number", "string"]);
				this.lua_getallocf = this.cwrap("lua_getallocf", "number", ["number", "number"]);
				this.lua_setallocf = this.cwrap("lua_setallocf", null, [
					"number",
					"number",
					"number"
				]);
				this.lua_toclose = this.cwrap("lua_toclose", null, ["number", "number"]);
				this.lua_closeslot = this.cwrap("lua_closeslot", null, ["number", "number"]);
				this.lua_getstack = this.cwrap("lua_getstack", "number", [
					"number",
					"number",
					"number"
				]);
				this.lua_getinfo = this.cwrap("lua_getinfo", "number", [
					"number",
					"string",
					"number"
				]);
				this.lua_getlocal = this.cwrap("lua_getlocal", "string", [
					"number",
					"number",
					"number"
				]);
				this.lua_setlocal = this.cwrap("lua_setlocal", "string", [
					"number",
					"number",
					"number"
				]);
				this.lua_getupvalue = this.cwrap("lua_getupvalue", "string", [
					"number",
					"number",
					"number"
				]);
				this.lua_setupvalue = this.cwrap("lua_setupvalue", "string", [
					"number",
					"number",
					"number"
				]);
				this.lua_upvalueid = this.cwrap("lua_upvalueid", "number", [
					"number",
					"number",
					"number"
				]);
				this.lua_upvaluejoin = this.cwrap("lua_upvaluejoin", null, [
					"number",
					"number",
					"number",
					"number",
					"number"
				]);
				this.lua_sethook = this.cwrap("lua_sethook", null, [
					"number",
					"number",
					"number",
					"number"
				]);
				this.lua_gethook = this.cwrap("lua_gethook", "number", ["number"]);
				this.lua_gethookmask = this.cwrap("lua_gethookmask", "number", ["number"]);
				this.lua_gethookcount = this.cwrap("lua_gethookcount", "number", ["number"]);
				this.lua_setcstacklimit = this.cwrap("lua_setcstacklimit", "number", ["number", "number"]);
				this.luaopen_base = this.cwrap("luaopen_base", "number", ["number"]);
				this.luaopen_coroutine = this.cwrap("luaopen_coroutine", "number", ["number"]);
				this.luaopen_table = this.cwrap("luaopen_table", "number", ["number"]);
				this.luaopen_io = this.cwrap("luaopen_io", "number", ["number"]);
				this.luaopen_os = this.cwrap("luaopen_os", "number", ["number"]);
				this.luaopen_string = this.cwrap("luaopen_string", "number", ["number"]);
				this.luaopen_utf8 = this.cwrap("luaopen_utf8", "number", ["number"]);
				this.luaopen_math = this.cwrap("luaopen_math", "number", ["number"]);
				this.luaopen_debug = this.cwrap("luaopen_debug", "number", ["number"]);
				this.luaopen_package = this.cwrap("luaopen_package", "number", ["number"]);
				this.luaL_openlibs = this.cwrap("luaL_openlibs", null, ["number"]);
			}
			lua_remove(luaState, index) {
				this.lua_rotate(luaState, index, -1);
				this.lua_pop(luaState, 1);
			}
			lua_pop(luaState, count) {
				this.lua_settop(luaState, -count - 1);
			}
			luaL_getmetatable(luaState, name) {
				return this.lua_getfield(luaState, LUA_REGISTRYINDEX, name);
			}
			lua_yield(luaState, count) {
				return this.lua_yieldk(luaState, count, 0, null);
			}
			lua_upvalueindex(index) {
				return LUA_REGISTRYINDEX - index;
			}
			ref(data) {
				const existing = this.referenceTracker.get(data);
				if (existing) {
					existing.refCount++;
					return existing.index;
				}
				const availableIndex = this.availableReferences.pop();
				const index = availableIndex === void 0 ? this.referenceMap.size + 1 : availableIndex;
				this.referenceMap.set(index, data);
				this.referenceTracker.set(data, {
					refCount: 1,
					index
				});
				this.lastRefIndex = index;
				return index;
			}
			unref(index) {
				const ref = this.referenceMap.get(index);
				if (ref === void 0) return;
				const metadata = this.referenceTracker.get(ref);
				if (metadata === void 0) {
					this.referenceTracker.delete(ref);
					this.availableReferences.push(index);
					return;
				}
				metadata.refCount--;
				if (metadata.refCount <= 0) {
					this.referenceTracker.delete(ref);
					this.referenceMap.delete(index);
					this.availableReferences.push(index);
				}
			}
			getRef(index) {
				return this.referenceMap.get(index);
			}
			getLastRefIndex() {
				return this.lastRefIndex;
			}
			printRefs() {
				for (const [key, value] of this.referenceMap.entries()) console.log(key, value);
			}
			cwrap(name, returnType, argTypes) {
				if (!argTypes.some((argType) => argType === "string|number")) return (...args) => this.module.ccall(name, returnType, argTypes, args);
				return (...args) => {
					const pointersToBeFreed = [];
					const resolvedArgTypes = argTypes.map((argType, i) => {
						var _a;
						if (argType === "string|number") if (typeof args[i] === "number") return "number";
						else if (((_a = args[i]) === null || _a === void 0 ? void 0 : _a.length) > 1024) {
							const bufferPointer = this.module.stringToNewUTF8(args[i]);
							args[i] = bufferPointer;
							pointersToBeFreed.push(bufferPointer);
							return "number";
						} else return "string";
						return argType;
					});
					try {
						return this.module.ccall(name, returnType, resolvedArgTypes, args);
					} finally {
						for (const pointer of pointersToBeFreed) this.module._free(pointer);
					}
				};
			}
		}
		var version = "1.16.0";
		class LuaFactory {
			constructor(customWasmUri, environmentVariables) {
				var _a;
				if (customWasmUri === void 0) {
					if (typeof window === "object" && typeof window.document !== "undefined" || typeof self === "object" && ((_a = self === null || self === void 0 ? void 0 : self.constructor) === null || _a === void 0 ? void 0 : _a.name) === "DedicatedWorkerGlobalScope") customWasmUri = `https://unpkg.com/wasmoon@${version}/dist/glue.wasm`;
				}
				this.luaWasmPromise = LuaWasm.initialize(customWasmUri, environmentVariables);
			}
			async mountFile(path, content) {
				this.mountFileSync(await this.getLuaModule(), path, content);
			}
			mountFileSync(luaWasm, path, content) {
				const fileSep = path.lastIndexOf("/");
				const file = path.substring(fileSep + 1);
				const body = path.substring(0, path.length - file.length - 1);
				if (body.length > 0) {
					const parts = body.split("/").reverse();
					let parent = "";
					while (parts.length) {
						const part = parts.pop();
						if (!part) continue;
						const current = `${parent}/${part}`;
						try {
							luaWasm.module.FS.mkdir(current);
						} catch (err) {}
						parent = current;
					}
				}
				luaWasm.module.FS.writeFile(path, content);
			}
			async createEngine(options = {}) {
				return new LuaEngine(await this.getLuaModule(), options);
			}
			async getLuaModule() {
				return this.luaWasmPromise;
			}
		}
		exports$1.Decoration = Decoration;
		exports$1.LUAI_MAXSTACK = LUAI_MAXSTACK;
		exports$1.LUA_MULTRET = LUA_MULTRET;
		exports$1.LUA_REGISTRYINDEX = LUA_REGISTRYINDEX;
		exports$1.LuaEngine = LuaEngine;
		exports$1.LuaFactory = LuaFactory;
		exports$1.LuaGlobal = Global;
		exports$1.LuaMultiReturn = MultiReturn;
		exports$1.LuaRawResult = RawResult;
		exports$1.LuaThread = Thread;
		exports$1.LuaTimeoutError = LuaTimeoutError;
		exports$1.LuaTypeExtension = LuaTypeExtension;
		exports$1.LuaWasm = LuaWasm;
		exports$1.PointerSize = PointerSize;
		exports$1.decorate = decorate;
		exports$1.decorateFunction = decorateFunction;
		exports$1.decorateProxy = decorateProxy;
		exports$1.decorateUserdata = decorateUserdata;
	}));
})))();
/** Data-only Dialog boundary. No Lua callbacks, DOM, or JavaScript objects cross it. */
const LUA_DIALOG_LIMITS = Object.freeze({
	controls: 64,
	bytes: 65536,
	requests: 32,
	waitMs: 12e4,
	totalWaitMs: 3e5
});
const own = (object, key) => Object.prototype.hasOwnProperty.call(object, key);
const record$1 = (value) => value && typeof value === "object" && !Array.isArray(value) && [Object.prototype, null].includes(Object.getPrototypeOf(value));
const fail$1 = (text) => {
	throw Error(`Lua Dialog: ${text}`);
};
function object(value, label) {
	if (!record$1(value)) fail$1(`${label} must be an object.`);
	return value;
}
function keys(value, allowed, label) {
	for (const key of Object.keys(value)) if (!allowed.includes(key)) fail$1(`Unsupported ${label} property: ${key}.`);
}
function text(value, label, max = 512) {
	if (typeof value !== "string" || new TextEncoder().encode(value).length > max || value.includes("\0")) fail$1(`${label} must be text of at most ${max} bytes.`);
	return value;
}
function bool(value, label, fallback = false) {
	if (value === void 0) return fallback;
	if (typeof value !== "boolean") fail$1(`${label} must be a boolean.`);
	return value;
}
function number(value, label, integer = false) {
	if (!Number.isFinite(value) || Math.abs(value) > 1e9 || integer && !Number.isInteger(value)) fail$1(`${label} must be ${integer ? "an integer" : "a finite number"} within ±1000000000.`);
	return value;
}
function color(value) {
	if (!Array.isArray(value) || value.length !== 4 || value.some((n) => !Number.isInteger(n) || n < 0 || n > 255)) fail$1("Color must contain four RGBA bytes.");
	return [...value];
}
function size(value) {
	let serialized;
	try {
		serialized = JSON.stringify(value);
	} catch {
		fail$1("Dialog data must be serializable.");
	}
	if (!serialized || new TextEncoder().encode(serialized).length > LUA_DIALOG_LIMITS.bytes) fail$1("Dialog data exceeds 64 KiB.");
}
const dataTypes = new Set([
	"entry",
	"number",
	"slider",
	"check",
	"combobox",
	"color",
	"button",
	"label"
]);
function validateDialogSchema(input) {
	object(input, "schema");
	size(input);
	keys(input, ["title", "controls"], "schema");
	const controls = Array.isArray(input.controls) ? input.controls : record$1(input.controls) && !Object.keys(input.controls).length ? [] : fail$1("Controls must be an array.");
	if (controls.length > LUA_DIALOG_LIMITS.controls) fail$1("A dialog supports at most 64 controls.");
	const seen = /* @__PURE__ */ new Set(), ids = /* @__PURE__ */ new Set();
	return {
		title: text(input.title ?? "", "title"),
		controls: controls.map((raw) => {
			object(raw, "control");
			keys(raw, [
				"key",
				"id",
				"type",
				"label",
				"text",
				"enabled",
				"visible",
				"focus",
				"hexpand",
				"vexpand",
				"value",
				"min",
				"max",
				"decimals",
				"options",
				"callback",
				"always"
			], "control");
			if (!dataTypes.has(raw.type) && !["separator", "newrow"].includes(raw.type)) fail$1(`Unsupported control: ${String(raw.type)}.`);
			const key = text(raw.key, "control key", 80);
			if (seen.has(key) || !/^w[1-9]\d*$/.test(key)) fail$1("Control keys must be unique internal widget identifiers.");
			seen.add(key);
			const control = {
				key,
				type: raw.type,
				label: text(raw.label ?? "", "label"),
				text: text(raw.text ?? "", "text", raw.type === "entry" ? 16384 : 512),
				enabled: bool(raw.enabled, "enabled", true),
				visible: bool(raw.visible, "visible", true),
				focus: bool(raw.focus, "focus"),
				hexpand: bool(raw.hexpand, "hexpand", true),
				vexpand: bool(raw.vexpand, "vexpand")
			};
			if (raw.id !== void 0) {
				const id = text(raw.id, "id", 128);
				if (!id || ids.has(id) || [
					"__proto__",
					"constructor",
					"prototype"
				].includes(id)) fail$1("Widget IDs must be unique nonempty safe strings.");
				ids.add(id);
				control.id = id;
			}
			if (raw.type === "entry") control.value = text(raw.value ?? "", "entry", 16384);
			if (raw.type === "label") control.value = text(raw.value ?? raw.text ?? "", "label text");
			if (raw.type === "number") {
				control.decimals = number(raw.decimals ?? 0, "decimals", true);
				if (control.decimals < 0 || control.decimals > 6) fail$1("Number fields support 0–6 decimal places.");
				const factor = 10 ** control.decimals;
				control.value = Math.round(number(raw.value ?? 0, "number") * factor) / factor;
			}
			if (raw.type === "slider") {
				control.min = number(raw.min ?? 0, "minimum", true);
				control.max = number(raw.max ?? 100, "maximum", true);
				if (control.min > control.max) fail$1("Slider minimum exceeds maximum.");
				control.value = number(raw.value ?? control.min, "slider", true);
				if (control.value < control.min || control.value > control.max) fail$1("Slider value is outside its range.");
			}
			if (["check", "button"].includes(raw.type)) control.value = bool(raw.value, "selected");
			if (raw.type === "button") control.callback = bool(raw.callback, "button callback");
			if (raw.type === "newrow") control.always = bool(raw.always, "always");
			if (raw.type === "color") control.value = color(raw.value ?? [
				0,
				0,
				0,
				255
			]);
			if (raw.type === "combobox") {
				if (!Array.isArray(raw.options) || !raw.options.length || raw.options.length > 128) fail$1("Combobox requires 1–128 options.");
				control.options = raw.options.map((option) => text(option, "option"));
				control.value = text(raw.value ?? control.options[0], "selected option");
				if (!control.options.includes(control.value)) fail$1("Combobox selection is not an available option.");
			}
			return control;
		})
	};
}
function validateDialogResponse(input, schema) {
	object(input, "response");
	size(input);
	keys(input, [
		"action",
		"button",
		"values"
	], "response");
	if (!["button", "close"].includes(input.action)) fail$1("Response action must be button or close.");
	const controls = new Map(schema.controls.map((control) => [control.key, control]));
	const button = input.action === "button" ? controls.get(input.button) : null;
	if (input.action === "button" && (!button || button.type !== "button" || !button.visible || !button.enabled)) fail$1("The response button is unavailable.");
	if (input.action === "close" && input.button !== void 0) fail$1("A close response cannot press a button.");
	const supplied = input.values ?? {};
	object(supplied, "values");
	for (const key of Object.keys(supplied)) if (!controls.has(key)) fail$1(`Unknown response control: ${key}.`);
	const values = {};
	for (const control of schema.controls) {
		let value = control.value;
		if (control.type === "button") value = control.key === button?.key;
		if (own(supplied, control.key)) {
			if ([
				"button",
				"label",
				"separator",
				"newrow"
			].includes(control.type) || !control.enabled || !control.visible) fail$1("The response cannot change a disabled, hidden or read-only control.");
			value = supplied[control.key];
			if (control.type === "entry") value = text(value, "entry", 16384);
			if (control.type === "number") {
				value = number(value, "number");
				const factor = 10 ** control.decimals;
				value = Math.round(value * factor) / factor;
			}
			if (control.type === "slider") {
				value = number(value, "slider", true);
				if (value < control.min || value > control.max) fail$1("Slider response is outside its range.");
			}
			if (control.type === "check") value = bool(value, "check");
			if (control.type === "combobox") {
				value = text(value, "option");
				if (!control.options.includes(value)) fail$1("Combobox response is not an available option.");
			}
			if (control.type === "color") value = color(value);
		}
		if (own(supplied, control.key)) values[control.key] = structuredClone(value);
	}
	return {
		action: input.action,
		...button ? { button: button.key } : {},
		values
	};
}
//#endregion
//#region app/lua-plugin-bootstrap.mjs
/** Explicit one-command package lifecycle; functions never cross the JSON boundary. */
const LUA_PLUGIN_BOOTSTRAP = String.raw`
local function runPlugin(environment)
  local configuration=jsonDecode(pluginConfig)
  local commands,ids={},{}
  local phase='init'
  local preferences=configuration.preferences
  local plugin
  local function preferenceSnapshot()
    local seen,nodes={},0
    local function check(value,depth)
      nodes=nodes+1
      if nodes>4096 or depth>12 then error('Plugin preferences exceed depth/value limits') end
      local kind=type(value)
      if kind=='boolean' then return end
      if kind=='number' then if value~=value or value==math.huge or value==-math.huge or math.abs(value)>9007199254740991 then error('Plugin preferences require finite exact-safe numbers') end; return end
      if kind=='string' then if #value>16384 or value:find('%z') or not utf8.len(value) then error('Plugin preference strings must be UTF-8 text of at most 16 KiB') end; return end
      if kind~='table' or getmetatable(value)~=nil or handles[value] or values[value] then error('Plugin preferences require plain Lua tables and JSON-compatible values') end
      if seen[value] then error('Plugin preferences cannot be circular') end
      seen[value]=true
      local count,maximum,array=0,0,true
      for key,item in pairs(value) do
        count=count+1
        if type(key)=='number' and key%1==0 and key>=1 then maximum=math.max(maximum,key)
        elseif type(key)=='string' then
          array=false
          if #key>128 or key:find('%z') or not utf8.len(key) or key=='__proto__' or key=='constructor' or key=='prototype' then error('Invalid plugin preference key') end
        else error('Plugin preference keys must be strings or dense array indices') end
        check(item,depth+1)
      end
      if count>0 and maximum>0 and (not array or maximum~=count) then error('Plugin preference arrays must be dense and cannot mix key types') end
      seen[value]=nil
    end
    check(preferences,0)
    for key in pairs(preferences) do if type(key)~='string' then error('Plugin preferences require a top-level string-keyed table') end end
    return preferences
  end
  local function newCommand(self,options)
    if self~=plugin or phase~='init' then error('Plugin commands can be registered only during init') end
    if type(options)~='table' or getmetatable(options)~=nil then error('Plugin:newCommand requires plain options') end
    local allowed={id=true,title=true,group=true,onclick=true,onenabled=true,onchecked=true}
    for key in pairs(options) do if not allowed[key] then error('Unsupported Plugin:newCommand option: '..tostring(key)) end end
    if #commands>=32 then error('A package supports at most 32 commands') end
    local id=options.id
    if type(id)~='string' or #id>128 or not id:match('^[%a_][%w_.:%-]*$') or ids[id] or id=='__proto__' or id=='constructor' or id=='prototype' then error('Plugin command IDs must be unique safe identifiers') end
    if type(options.onclick)~='function' then error('Plugin:newCommand requires an onclick callback') end
    for _,key in ipairs({'onenabled','onchecked'}) do if options[key]~=nil and type(options[key])~='function' then error('Plugin command '..key..' must be a function') end end
    local command={id=id,title=options.title or id,group=options.group or '',onclick=options.onclick,onenabled=options.onenabled,onchecked=options.onchecked}
    commands[#commands+1]=command;ids[id]=command
  end
  plugin=setmetatable({},{__metatable='Plugin',__index=function(_,key)
    if key=='newCommand' then return newCommand end
    if key=='name' or key=='displayName' or key=='version' then return configuration[key] end
    if key=='preferences' then return preferences end
    error('Unsupported Plugin.'..tostring(key))
  end,__newindex=function() error('Plugin identity and preferences binding are read-only; edit preferences table values instead') end})
  if type(environment.init)~='function' then error('Package source must define init(plugin)') end
  if environment.exit~=nil and type(environment.exit)~='function' then error('Package exit must be a function') end
  environment.init(plugin)
  phase='choice'
  local function state(callback,fallback,label)
    if callback==nil then return fallback end
    local value=callback(); if type(value)~='boolean' then error('Plugin '..label..' must return a boolean') end; return value
  end
  local catalog={name=configuration.name,displayName=configuration.displayName,version=configuration.version,commands={}}
  for i,command in ipairs(commands) do
    catalog.commands[i]={id=command.id,title=command.title,group=command.group,enabled=state(command.onenabled,true,'onenabled'),checked=state(command.onchecked,nil,'onchecked')}
  end
  local reply=jsonDecode(pluginBridge(jsonEncode(catalog)):await())
  if not reply.ok then error(reply.error,0) end
  if reply.value.action~='run' then error('Package command session cancelled',0) end
  local selected=ids[reply.value.commandId]
  if not selected or not state(selected.onenabled,true,'onenabled') then error('The chosen package command is no longer enabled') end
  phase='command'
  selected.onclick()
  phase='exit'
  if environment.exit then environment.exit(plugin) end
  phase='finished'
  pluginDone(jsonEncode({name=configuration.name,version=configuration.version,commandId=selected.id,preferences=preferenceSnapshot()}))
end
`;
//#endregion
//#region app/lua-dialog-bootstrap.mjs
/** Blocking Dialog subset. Every callback stays inside the same suspended Lua VM. */
const LUA_DIALOG_BOOTSTRAP = String.raw`
local Dialog
local dialogStates={}
local dialogMethods={}
local dialogCommon={id=true,label=true,enabled=true,visible=true,focus=true,hexpand=true,vexpand=true}
local dialogFields={entry={text=true},number={text=true,decimals=true},slider={min=true,max=true,value=true},check={text=true,selected=true},combobox={option=true,options=true},color={color=true},button={text=true,selected=true,onclick=true},label={text=true},separator={id=true,text=true},newrow={always=true}}
local function dialogOptions(options,allowed,common)
  options=options or {}; if type(options)~='table' then error('Dialog options must be a table') end
  for key in pairs(options) do if not allowed[key] and not (common and dialogCommon[key]) then error('Unsupported Dialog option: '..tostring(key)) end end
  return options
end
local function dialogValue(control,value)
  if control.type=='color' then return copyColor(Color(value)) end
  if control.type=='number' then
    local n=tonumber(value); if not n then error('Dialog number must be numeric') end
    local decimals=control.decimals or 0
    if type(decimals)~='number' or decimals%1~=0 or decimals<0 or decimals>6 then error('Dialog number supports 0–6 decimal places') end
    local factor=10^decimals; return math.floor(n*factor+0.5)/factor
  end
  return value
end
local function dialogSnapshot(state)
  local controls={}
  for i,control in ipairs(state.controls) do
    local item={}; for key,value in pairs(control) do if key~='onclick' then item[key]=value end end
    if item.type=='color' then item.value=colorRGBA(item.value) end
    controls[i]=item
  end
  return {title=state.title,controls=controls}
end
for kind,fields in pairs(dialogFields) do
  dialogMethods[kind]=function(self,options)
    local state=dialogStates[self]; options=dialogOptions(options,fields,kind~='newrow' and kind~='separator')
    if #state.controls>=64 then error('Dialog supports at most 64 controls') end
    local item={key='w'..tostring(#state.controls+1),type=kind}
    for key,value in pairs(options) do if key~='color' and key~='onclick' and key~='selected' and key~='option' then item[key]=value end end
    if item.id~=nil then if type(item.id)~='string' or state.ids[item.id] then error('Dialog widget IDs must be unique strings') end; state.ids[item.id]=item end
    if kind=='entry' or kind=='label' then item.value=options.text or ''
    elseif kind=='number' then item.value=dialogValue(item,options.text or '0')
    elseif kind=='slider' then item.value=options.value or options.min or 0
    elseif kind=='button' or kind=='check' then item.value=options.selected or false
    elseif kind=='combobox' then item.value=options.option or (options.options and options.options[1])
    elseif kind=='color' then item.value=Color(options.color) end
    if kind=='button' and options.onclick~=nil then if type(options.onclick)~='function' then error('Dialog onclick must be a function') end; item.onclick=options.onclick; item.callback=true end
    state.controls[#state.controls+1]=item
    return self
  end
end
function dialogMethods:close() dialogStates[self].closed=true; return self end
function dialogMethods:show(options)
  options=dialogOptions(options,{wait=true})
  if options.wait~=nil and options.wait~=true then error('Only blocking Dialog:show() is supported') end
  local state=dialogStates[self]
  if state.showing then error('This Dialog is already being shown') end
  state.showing=true; state.closed=false
  local ok,err=pcall(function()
    while not state.closed do
      local reply=jsonDecode(dialogBridge(jsonEncode(dialogSnapshot(state))):await())
      if not reply.ok then error(reply.error,0) end
      local response=reply.value
      for _,control in ipairs(state.controls) do
        local value=response.values[control.key]
        if control.type=='button' then control.value=control.key==response.button
        elseif value~=nil then control.value=control.type=='color' and colorFromRGBA(value) or value end
      end
      if response.action=='close' then state.closed=true
      else
        local selected
        for _,control in ipairs(state.controls) do if control.key==response.button then selected=control; break end end
        if not selected then error('Invalid Dialog button response') end
        if selected.onclick then selected.onclick() else state.closed=true end
      end
    end
    if state.onclose then state.onclose() end
  end)
  state.showing=false
  if not ok then error(err,0) end
  return self
end
Dialog=function(options)
  if not dialogEnabled then error('Dialog requires an interactive UI host; it is unavailable in headless Lua execution') end
  if type(options)=='string' then options={title=options} end
  options=dialogOptions(options,{title=true,onclose=true})
  if options.onclose~=nil and type(options.onclose)~='function' then error('Dialog onclose must be a function') end
  local state={title=options.title or '',controls={},ids={},onclose=options.onclose,closed=true}
  local object={}; dialogStates[object]=state
  return setmetatable(object,{__metatable='Dialog',__index=function(_,key)
    if dialogMethods[key] then return dialogMethods[key] end
    if key=='data' then
      local data={}; for _,control in ipairs(state.controls) do if control.id then data[control.id]=control.type=='color' and copyColor(control.value) or control.value end end; return data
    end
    error('Unsupported Dialog.'..tostring(key))
  end,__newindex=function(_,key,data)
    if key~='data' or type(data)~='table' then error('Only Dialog.data can be assigned a table') end
    for id,value in pairs(data) do local control=state.ids[id]; if not control then error('Unknown Dialog widget: '..tostring(id)) end; control.value=dialogValue(control,value); if control.type=='label' then control.text=control.value end end
  end})
end
`;
//#endregion
//#region app/lua-value-types.mjs
/** Pure Lua value objects used by the real VM. Kept separate from host/dialog bootstrap. */
const LUA_VALUE_TYPES = String.raw`
local function coord(v) v=v or 0; if type(v)~='number' or v~=v or math.abs(v)>2147483647 then error('Geometry component is outside the supported integer range') end; return math.floor(v) end
local function geometry(kind,data,construct)
 local value={}; values[value]=data
 return setmetatable(value,{__metatable=kind,
  __index=function(self,key)
   local d=values[self];key=({w='width',h='height'})[key] or key
   if d[key]~=nil then return d[key] end
   if key=='isEmpty' and kind~='Point' then return d.width<=0 or d.height<=0 end
   if kind=='Rectangle' then
    if key=='origin' then return Point(d.x,d.y) elseif key=='size' then return Size(d.width,d.height) end
    if key=='contains' then return function(_,other,py)
     local o=values[other] or other
     if type(o)=='table' and (o.width~=nil or o.w~=nil or o[3]~=nil) then o=Rectangle(o);return not self.isEmpty and not o.isEmpty and o.x>=d.x and o.y>=d.y and o.x+o.width<=d.x+d.width and o.y+o.height<=d.y+d.height end
     o=Point(other,py);return not self.isEmpty and o.x>=d.x and o.y>=d.y and o.x<d.x+d.width and o.y<d.y+d.height
    end end
    if key=='intersects' or key=='intersect' then return function(_,other)
     local o=Rectangle(other);local x,y=math.max(d.x,o.x),math.max(d.y,o.y);local w,h=math.min(d.x+d.width,o.x+o.width)-x,math.min(d.y+d.height,o.y+o.height)-y
     local yes=not self.isEmpty and not o.isEmpty and w>0 and h>0
     if key=='intersects' then return yes end;return yes and Rectangle(x,y,w,h) or Rectangle()
    end end
    if key=='union' then return function(_,other)
     local o=Rectangle(other);if self.isEmpty then return Rectangle(o) elseif o.isEmpty then return Rectangle(self) end
     local x,y=math.min(d.x,o.x),math.min(d.y,o.y);return Rectangle(x,y,math.max(d.x+d.width,o.x+o.width)-x,math.max(d.y+d.height,o.y+o.height)-y)
    end end
   elseif kind=='Size' and key=='union' then return function(_,other) local o=Size(other);return Size(math.max(d.width,o.width),math.max(d.height,o.height)) end end
   error('Unsupported '..kind..'.'..tostring(key))
  end,
  __newindex=function(self,key,v)
   local d=values[self];key=({w='width',h='height'})[key] or key
   if d[key]~=nil then d[key]=coord(v);return end
   if kind=='Rectangle' and key=='origin' then local p=Point(v);d.x,d.y=p.x,p.y;return end
   if kind=='Rectangle' and key=='size' then local s=Size(v);d.width,d.height=s.width,s.height;return end
   error('Unsupported '..kind..' assignment: '..tostring(key))
  end,
  __eq=function(a,b) local x,y=values[a],values[b];if not x or not y then return false end;for k,v in pairs(x) do if y[k]~=v then return false end end;for k in pairs(y) do if x[k]==nil then return false end end;return true end,
  __add=function(a,b) if kind~='Point' and kind~='Size' then error('Unsupported geometry addition') end;local x,y=values[a],values[b];if not x or not y then error('Geometry addition requires matching values') end;if kind=='Point' then return construct(x.x+y.x,x.y+y.y) else return construct(x.width+y.width,x.height+y.height) end end,
  __sub=function(a,b) if kind~='Point' and kind~='Size' then error('Unsupported geometry subtraction') end;local x,y=values[a],values[b];if not x or not y then error('Geometry subtraction requires matching values') end;if kind=='Point' then return construct(x.x-y.x,x.y-y.y) else return construct(x.width-y.width,x.height-y.height) end end,
  __tostring=function(self) local d=values[self];if kind=='Point' then return string.format('Point{ x=%d, y=%d }',d.x,d.y) elseif kind=='Size' then return string.format('Size{ width=%d, height=%d }',d.width,d.height) end;return string.format('Rectangle{ x=%d, y=%d, width=%d, height=%d }',d.x,d.y,d.width,d.height) end,
 })
end
Point=function(x,y) if type(x)=='table' then local d=values[x] or x;return Point(d.x or d[1],d.y or d[2]) end;return geometry('Point',{x=coord(x),y=coord(y)},Point) end
Size=function(w,h) if type(w)=='table' then local d=values[w] or w;return Size(d.width or d.w or d[1],d.height or d.h or d[2]) end;return geometry('Size',{width=coord(w),height=coord(h)},Size) end
Rectangle=function(x,y,w,h) if type(x)=='table' then local d=values[x] or x;return Rectangle(d.x or d[1],d.y or d[2],d.width or d.w or d[3],d.height or d.h or d[4]) end;return geometry('Rectangle',{x=coord(x),y=coord(y),width=coord(w),height=coord(h)},Rectangle) end
local function unit(v,label) if type(v)~='number' or v~=v or v<0 or v>1 then error(label..' must be from 0 to 1') end;return v end
local function hue(v) if type(v)~='number' or v~=v or v<0 or v>360 then error('Hue must be from 0 to 360; out-of-range native hues are not supported') end;return v end
local function rgbHSV(h,s,v)
 local turn=(h%360)/60;local c=v*s;local x=c*(1-math.abs(turn%2-1));local m=v-c;local r,g,b
 if turn<1 then r,g,b=c,x,0 elseif turn<2 then r,g,b=x,c,0 elseif turn<3 then r,g,b=0,c,x elseif turn<4 then r,g,b=0,x,c elseif turn<5 then r,g,b=x,0,c else r,g,b=c,0,x end
 return math.floor((r+m)*255+.5),math.floor((g+m)*255+.5),math.floor((b+m)*255+.5)
end
local function calculate(d)
 local min,max=math.min(d.red,d.green,d.blue)/255,math.max(d.red,d.green,d.blue)/255;local delta=max-min;local h=0
 if delta>0 then if max==d.red/255 then h=60*((d.green-d.blue)/255/delta%6) elseif max==d.green/255 then h=60*((d.blue-d.red)/255/delta+2) else h=60*((d.red-d.green)/255/delta+4) end end
 local l=(min+max)/2;local hsvs=max==0 and 0 or delta/max;local hsls=delta==0 and 0 or delta/(1-math.abs(2*l-1))
 return (d._kind=='hsv' or d._kind=='hsl') and d._h or h,hsvs,max,hsls,l
end
local function refresh(d)
 if d._kind=='index' then local c=rpc('colorLookup',{index=d.index});d.red,d.green,d.blue,d.alpha=c[1],c[2],c[3],d._alphaOverride or c[4] end
end
local function components(d)
 refresh(d);local h,s,v,hs,hl=calculate(d)
 return {hsvHue=h,hsvSaturation=d._kind=='hsv' and d._s or s,hsvValue=d._kind=='hsv' and d._v or v,hslHue=h,hslSaturation=d._kind=='hsl' and d._s or hs,hslLightness=d._kind=='hsl' and d._l or hl}
end
local function convert(d,kind,h,s,n)
 h=hue(h);s=unit(s,'Saturation');n=unit(n,kind=='hsl' and 'Lightness' or 'Value')
 d._kind,d._h,d._s,d.index,d._alphaOverride=kind,hue(h),unit(s,'Saturation'),nil,nil
 if kind=='hsl' then d._l=unit(n,'Lightness');d._v=nil;local v=n+s*math.min(n,1-n);d.red,d.green,d.blue=rgbHSV(h,v==0 and 0 or 2*(1-n/v),v)
 else d._v=unit(n,'Value');d._l=nil;d.red,d.green,d.blue=rgbHSV(h,s,n) end
end
local colorAliases={r='red',g='green',b='blue',a='alpha'}
local function alias(d,key)
 key=colorAliases[key] or key
 if key=='hue' then return d._kind=='hsl' and 'hslHue' or 'hsvHue' elseif key=='saturation' then return d._kind=='hsl' and 'hslSaturation' or 'hsvSaturation' elseif key=='value' then return 'hsvValue' elseif key=='lightness' then return 'hslLightness' end
 return key
end
Color=function(input)
 local d
 if values[input] and values[input].red~=nil then d={};for k,v in pairs(values[input]) do d[k]=v end
 elseif type(input)=='number' then local s=rpc('appGet',{key='sprite'});local mode=s and s.colorMode or 0;if mode==2 then return Color{index=input} elseif mode==1 then return Color{gray=pixelColor.grayaV(input),alpha=pixelColor.grayaA(input)} end;d={red=pixelColor.rgbaR(input),green=pixelColor.rgbaG(input),blue=pixelColor.rgbaB(input),alpha=pixelColor.rgbaA(input),_kind='rgb'}
 else
  input=input or {};if type(input)~='table' then error('Color requires a table, packed pixel, or Color') end
  d={red=input.red or input.r or input.gray or 0,green=input.green or input.g or input.gray or 0,blue=input.blue or input.b or input.gray or 0,alpha=input.alpha or input.a or 255,_kind=input.gray~=nil and 'gray' or 'rgb'}
  if input.tile~=nil then error('Tile Color is not supported') end
  if input.index~=nil then d.index=uint(input.index,255);d._kind='index';refresh(d)
  elseif input.h~=nil or input.hue~=nil then local h=input.h or input.hue;local s=input.s or input.saturation or 0;local l=input.l or input.lightness;convert(d,l~=nil and 'hsl' or 'hsv',h,s,l or input.v or input.value or 0) end
 end
 d.red,d.green,d.blue,d.alpha=byte(d.red),byte(d.green),byte(d.blue),byte(d.alpha)
 local value={};values[value]=d
 return setmetatable(value,{__metatable='Color',
  __index=function(_,key)
   key=alias(d,key);refresh(d)
   if key=='red' or key=='green' or key=='blue' or key=='alpha' then return d[key] end
   if key=='index' then return d.index or rpc('colorFindIndex',{red=d.red,green=d.green,blue=d.blue,alpha=d.alpha}) end
   if key=='rgbaPixel' then return pixelColor.rgba(d.red,d.green,d.blue,d.alpha) end
   if key=='gray' then return math.floor((math.max(d.red,d.green,d.blue)+math.min(d.red,d.green,d.blue))/2) end
   if key=='grayPixel' then return pixelColor.graya(math.floor((math.max(d.red,d.green,d.blue)+math.min(d.red,d.green,d.blue))/2),d.alpha) end
   local c=components(d);if c[key]~=nil then return c[key] end;error('Unsupported Color.'..tostring(key))
  end,
  __newindex=function(_,key,v)
   key=alias(d,key);refresh(d)
   if key=='index' then local index=uint(v,255);local c=rpc('colorLookup',{index=index});d._kind,d.index,d._alphaOverride='index',index,nil;d.red,d.green,d.blue,d.alpha=c[1],c[2],c[3],c[4];return end
   if key=='alpha' then d.alpha=byte(v);if d._kind=='index' then d._alphaOverride=d.alpha end;return end
   if key=='red' or key=='green' or key=='blue' then d[key]=byte(v);d._kind,d.index='rgb',nil;return end
   if key=='gray' then local gray=byte(v);d.red,d.green,d.blue,d._kind,d.index=gray,gray,gray,'gray',nil;return end
   local c=components(d)
   if key=='hsvHue' or key=='hsvSaturation' or key=='hsvValue' then convert(d,'hsv',key=='hsvHue' and v or c.hsvHue,key=='hsvSaturation' and v or c.hsvSaturation,key=='hsvValue' and v or c.hsvValue);return end
   if key=='hslHue' or key=='hslSaturation' or key=='hslLightness' then convert(d,'hsl',key=='hslHue' and v or c.hslHue,key=='hslSaturation' and v or c.hslSaturation,key=='hslLightness' and v or c.hslLightness);return end
   error('Unsupported Color assignment: '..tostring(key))
  end,
 })
end
refreshColor=function(value) local d=values[value];if d and d.red~=nil then refresh(d) end end
`;
//#endregion
//#region app/lua-bootstrap.mjs
/** Lua 5.4 compatibility objects; evaluated by the real VM, never parsed as JavaScript. */
const LUA_BOOTSTRAP = String.raw`
local bridge, source, instructionLimit = __pixelwallRpc, __pixelwallSource, __pixelwallInstructions
__pixelwallRpc, __pixelwallSource, __pixelwallInstructions = nil, nil, nil
local dialogBridge,dialogEnabled=__pixelwallDialog,__pixelwallDialogEnabled
__pixelwallDialog,__pixelwallDialogEnabled=nil,nil
local pluginConfig,pluginBridge,pluginDone=__pixelwallPluginConfig,__pixelwallPluginChoice,__pixelwallPluginDone
__pixelwallPluginConfig,__pixelwallPluginChoice,__pixelwallPluginDone=nil,nil,nil
local handles, values, cache = {}, {}, {}
local refreshColor
local function jsonEncode(value, seen, depth)
  depth = (depth or 0) + 1
  if depth > 48 then error('Lua argument nesting limit exceeded') end
  local kind = type(value)
  if kind == 'nil' then return 'null' end
  if kind == 'boolean' then return value and 'true' or 'false' end
  if kind == 'number' then if value ~= value or value == math.huge or value == -math.huge then error('JSON numbers must be finite') end return tostring(value) end
  if kind == 'string' then
    return '"' .. value:gsub('[%z\1-\31\\"]', function(c)
      local escapes = { ['"']='\\"', ['\\']='\\\\', ['\n']='\\n', ['\r']='\\r', ['\t']='\\t' }
      return escapes[c] or string.format('\\u%04x', string.byte(c))
    end) .. '"'
  end
  if kind ~= 'table' then error('Lua API arguments must be plain values') end
  if refreshColor and values[value] then refreshColor(value) end
  value = handles[value] or values[value] or value
  seen = seen or {}; if seen[value] then error('Circular Lua API argument') end; seen[value] = true
  local count, maximum, array = 0, 0, true
  for k in pairs(value) do count=count+1; if type(k) ~= 'number' or k%1~=0 or k<1 then array=false else maximum=math.max(maximum,k) end end
  array = array and count == maximum and count > 0
  local parts = {}
  if array then for n=1,count do parts[n]=jsonEncode(value[n],seen,depth) end
  else for k,v in pairs(value) do if type(k)~='string' then error('Mixed Lua tables are not supported as API arguments') end; parts[#parts+1]=jsonEncode(k,seen,depth)..':'..jsonEncode(v,seen,depth) end end
  seen[value] = nil
  return (array and '[' or '{') .. table.concat(parts,',') .. (array and ']' or '}')
end
local function jsonDecode(text)
  local pos, length = 1, #text
  local function space() local _, e=text:find('^%s*',pos); pos=(e or pos-1)+1 end
  local parse
  local function str()
    pos=pos+1; local out={}
    while pos<=length do
      local c=text:sub(pos,pos); pos=pos+1
      if c=='"' then return table.concat(out) end
      if c=='\\' then
        c=text:sub(pos,pos); pos=pos+1
        if c=='u' then
          local cp=tonumber(text:sub(pos,pos+3),16); if not cp then error('Invalid bridge JSON') end; pos=pos+4
          if cp>=0xd800 and cp<=0xdbff and text:sub(pos,pos+1)=='\\u' then local low=tonumber(text:sub(pos+2,pos+5),16); if low and low>=0xdc00 and low<=0xdfff then cp=0x10000+(cp-0xd800)*1024+low-0xdc00; pos=pos+6 end end
          out[#out+1]=utf8.char(cp)
        else local escapes={ ['"']='"', ['\\']='\\', ['/']='/', b='\b', f='\f', n='\n', r='\r', t='\t' }; if not escapes[c] then error('Invalid bridge escape') end; out[#out+1]=escapes[c] end
      else out[#out+1]=c end
    end
    error('Unterminated bridge JSON string')
  end
  parse=function(depth)
    if depth>48 then error('Bridge JSON nesting exceeded') end
    space(); local c=text:sub(pos,pos)
    if c=='"' then return str() end
    if c=='{' or c=='[' then
      local array=c=='['; local closing=array and ']' or '}'; pos=pos+1; space(); local out={}
      if text:sub(pos,pos)==closing then pos=pos+1; return out end
      while true do
        local key
        if array then key=#out+1 else space(); if text:sub(pos,pos)~='"' then error('Invalid bridge JSON key') end; key=str(); space(); if text:sub(pos,pos)~=':' then error('Invalid bridge JSON colon') end; pos=pos+1 end
        out[key]=parse(depth+1); space(); local next=text:sub(pos,pos); pos=pos+1
        if next==closing then return out end
        if next~=',' then error('Invalid bridge JSON separator') end
      end
    end
    if text:sub(pos,pos+3)=='true' then pos=pos+4; return true end
    if text:sub(pos,pos+4)=='false' then pos=pos+5; return false end
    if text:sub(pos,pos+3)=='null' then pos=pos+4; return nil end
    local number=text:match('^-?%d+%.?%d*[eE]?[+-]?%d*',pos)
    if not number then error('Invalid bridge JSON value') end; pos=pos+#number; return assert(tonumber(number))
  end
  local result=parse(0); space(); if pos<=length then error('Trailing bridge JSON') end; return result
end
local wrap
local function rpc(op,data)
  local reply=jsonDecode(bridge(op,jsonEncode(data or {})))
  if not reply.ok then error(reply.error,3) end
  return wrap(reply.value)
end
local function byte(v) v=v or 0; if type(v)~='number' or v%1~=0 or v<0 or v>255 then error('Color channel must be an integer from 0 to 255') end; return v end
local function uint(v,max) if type(v)~='number' or v%1~=0 or v<0 or v>max then error('Invalid packed pixel') end return v end
local pixelColor={
  rgba=function(r,g,b,a) return byte(r) | (byte(g)<<8) | (byte(b)<<16) | (byte(a==nil and 255 or a)<<24) end,
  rgbaR=function(p) return uint(p,0xffffffff)&255 end, rgbaG=function(p) return (uint(p,0xffffffff)>>8)&255 end,
  rgbaB=function(p) return (uint(p,0xffffffff)>>16)&255 end, rgbaA=function(p) return (uint(p,0xffffffff)>>24)&255 end,
  graya=function(g,a) return byte(g)|(byte(a==nil and 255 or a)<<8) end,
  grayaV=function(p) return uint(p,65535)&255 end, grayaA=function(p) return (uint(p,65535)>>8)&255 end,
}
local Color, Point, Size, Rectangle, Image, Sprite, Palette, Selection, Grid, ColorSpace, ImageSpec
${LUA_VALUE_TYPES}
local function gridValue(width,height,x,y)
  x=x or 0;y=y or 0;local object={};values[object]={__value='Grid',width=width,height=height,x=x,y=y}
  return setmetatable(object,{__metatable='Grid',__index=function(_,key) if key=='origin' then return Point(x,y) end;if key=='tileSize' then return Size(width,height) end;error('Unsupported Grid.'..tostring(key)) end,__newindex=function() error('Grid properties are read-only') end})
end
Grid=function(other) if other==nil then return gridValue(16,16) end;local value=values[other];if not value or value.__value~='Grid' then error('Grid expects another Grid or no arguments') end;return gridValue(value.width,value.height,value.x,value.y) end
local methods={
 Sprite={newLayer=true,newGroup=true,deleteLayer=true,newFrame=true,newEmptyFrame=true,deleteFrame=true,newCel=true,deleteCel=true,setPalette=true,resize=true,newTag=true,deleteTag=true,newSlice=true,deleteSlice=true,newTileset=true,deleteTileset=true,newTile=true,deleteTile=true,assignColorSpace=true,convertColorSpace=true},
 Tileset={tile=true,getTile=true},Tile={},
 Layer={cel=true}, Frame={}, Cel={}, Tag={}, Slice={}, Properties={},
 Selection={deselect=true,select=true,selectAll=true,add=true,subtract=true,intersect=true,contains=true},
 Range={contains=true,containsColor=true,clear=true},
 Image={clone=true,drawPixel=true,putPixel=true,getPixel=true,clear=true,drawImage=true,putImage=true,isEmpty=true,isPlain=true,isEqual=true,resize=true,flip=true,drawSprite=true,putSprite=true,shrinkBounds=true},
 Palette={getColor=true,setColor=true,resize=true},
}
wrap=function(value)
  if type(value)~='table' then return value end
  if value.__value=='Grid' then return gridValue(value.width,value.height,value.x,value.y) end
  if value.__value=='PlainData' then return value.value end
  if value.__value=='Color' then value.__value=nil; return Color(value) end
  if value.__value=='Point' then return Point(value) end
  if value.__value=='Size' then return Size(value) end
  if value.__value=='Rectangle' then return Rectangle(value) end
  if not value.__kind then for k,v in pairs(value) do value[k]=wrap(v) end; return value end
  local key=value.__kind..':'..value.id
  if cache[key] then return cache[key] end
  local object={}; handles[object]=value; cache[key]=object
  return setmetatable(object,{__metatable=value.__kind,
    __index=function(self,property)
      if methods[value.__kind] and methods[value.__kind][property] then return function(_,...) return rpc('method',{target=self,name=property,args={...}}) end end
      if value.__kind=='Image' and property=='bytes' then
        local length=self.rowStride*self.height;local chunks={}
        for offset=0,length-1,4096 do local bytes=rpc('imageBytesGet',{target=self,start=offset,count=math.min(4096,length-offset)});chunks[#chunks+1]=string.char(table.unpack(bytes)) end
        return table.concat(chunks)
      end
      if value.__kind=='Image' and property=='pixels' then
        return function(_,rect)
          rect=rect or Rectangle(0,0,self.width,self.height); local x0,y0=math.max(0,rect.x),math.max(0,rect.y); local right,bottom=math.min(self.width,rect.x+rect.width),math.min(self.height,rect.y+rect.height); local x,y=x0-1,y0
          return function()
            x=x+1; if x>=right then x=x0; y=y+1 end; if y>=bottom or right<=x0 then return nil end
            local px,py=x,y
            return setmetatable({x=px,y=py},{__metatable='Pixel',__call=function(_,color) if color==nil then return self:getPixel(px,py) end; self:drawPixel(px,py,color) end})
          end
        end
      end
      return rpc('get',{target=self,key=property})
    end,
    __newindex=function(self,property,v)
      if value.__kind=='ColorSpace' and property=='name' then
        if type(v)~='number' and type(v)~='string' then return end
        v=tostring(v):match('^[^%z]*')
      end
      if value.__kind=='Image' and property=='bytes' then
        if type(v)~='string' then error('Image.bytes requires a byte string') end
        local token=rpc('imageBytesBegin',{target=self,size=#v})
        local ok,err=pcall(function()
          for offset=1,#v,4096 do rpc('imageBytesAppend',{token=token,bytes={string.byte(v,offset,math.min(offset+4095,#v))}}) end
          rpc('imageBytesCommit',{token=token})
        end)
        if not ok then pcall(rpc,'imageBytesCancel',{token=token});error(err,2) end
        return
      end
      rpc('set',{target=self,key=property,value=v})
    end,
    __eq=function(self,other) if value.__kind=='ImageSpec' and handles[other] and handles[other].__kind=='ImageSpec' then return rpc('imageSpecEqual',{left=self,right=other}) end;if value.__kind~='ColorSpace' or not handles[other] or handles[other].__kind~='ColorSpace' then return rawequal(self,other) end;return rpc('colorSpaceEqual',{left=self,right=other}) end,
    __pairs=function(self) if value.__kind~='Properties' then error('pairs is only supported for Properties') end; return next,rpc('method',{target=self,name='entries',args={}}),nil end,
    __call=function(self,namespace,properties) if value.__kind~='Properties' then error('Only Properties can be called') end; return rpc('method',{target=self,name='namespace',args={namespace,properties}}) end,
    __len=function(self) if value.__kind=='Properties' then local count=0; for _ in pairs(self) do count=count+1 end; return count end; if value.__kind~='Palette' and value.__kind~='Tileset' then error('Length is only supported for Palette, Tileset or Properties') end return rpc('get',{target=self,key='size'}) end,
  })
end
Image=function(width,height,mode)
  if handles[width] then if mode~=nil then error('Unsupported Image copy arguments') end;return rpc('imageNew',{source=width,rectangle=height}) end
  if type(width)=='table' then if width.fromFile then error('Image file access is unavailable') end; return rpc('imageNew',width) end
  return rpc('imageNew',{width=width,height=height,colorMode=mode or 0})
end
Sprite=function(width,height,mode)
  if handles[width] and handles[width].__kind=='ImageSpec' then if height~=nil or mode~=nil then error('Sprite(spec) accepts one specification') end;return rpc('spriteNew',{spec=width}) end
  if type(width)=='table' then error('Sprite constructor requires dimensions or an ImageSpec') end
  return rpc('spriteNew',{width=width,height=height,colorMode=mode or 0})
end
Palette=function(size) if handles[size] then return rpc('paletteNew',{source=size}) end; if type(size)=='table' then if size.fromFile then error('Palette file access is unavailable') end; size=size.size end; return rpc('paletteNew',{size=size or 256}) end
Selection=function(rectangle) if handles[rectangle] then error('Selection constructor requires a Rectangle; use add to copy a selection') end; return rpc('selectionNew',{rectangle=rectangle}) end
ColorSpace=function(value)
  if handles[value] then return rpc('colorSpaceNew',{source=value}) end
  if type(value)=='table' and value.fromFile~=nil then error('ColorSpace.fromFile requires file access, which is unavailable to scripts') end
  return rpc('colorSpaceNew',{srgb=type(value)=='table' and not not value.sRGB})
end
ImageSpec=function(value)
  if handles[value] then return rpc('imageSpecNew',{source=value}) end
  if type(value)=='table' then local fields={};for _,key in ipairs{'width','height','colorMode','transparentColor'} do fields[key]=value[key] end;return rpc('imageSpecNew',{fields=fields}) end
  return rpc('imageSpecNew',{})
end
local initialColors=rpc('colorsGet')
local function colorFromRGBA(rgba) return Color{red=rgba[1],green=rgba[2],blue=rgba[3],alpha=rgba[4]} end
local function colorRGBA(color) return {color.red,color.green,color.blue,color.alpha} end
local fg,bg=colorFromRGBA(initialColors.fgColor),colorFromRGBA(initialColors.bgColor)
-- Aseprite getters return detached Color values. Preserve a selected index
-- without resolving it again against a different active sprite's palette.
local function copyColor(color) return Color(color) end

${LUA_DIALOG_BOOTSTRAP}
local appMethods={
  refresh=function() end,
  useTool=function(options) local copy={}; for k,v in pairs(options) do copy[k]=v end; if copy.color==nil then copy.color=fg end; return rpc('useTool',copy) end,
  transaction=function(label,callback)
    if type(label)=='function' then callback,label=label,'Lua transaction' end
    if type(callback)~='function' then error('app.transaction requires a function') end
    local previousFg,previousBg=fg,bg
    local function restoreColors() fg,bg=previousFg,previousBg end
    rpc('begin',{label=label}); local result=table.pack(pcall(callback))
    if result[1] then
      local ok,err=pcall(rpc,'commit',{})
      if not ok then pcall(rpc,'rollback',{}); restoreColors(); error(err,2) end
      return table.unpack(result,2,result.n)
    end
    local ok,err=pcall(rpc,'rollback',{}); restoreColors()
    if not ok then error(err,2) end
    error(result[2],2)
  end,
}
local command=setmetatable({},{__metatable='app.command',__index=function(_,name) return function(options) return rpc('command',{name=name,options=options or {}}) end end})
local app=setmetatable({},{__metatable='app',__index=function(_,key)
  if key=='isUIAvailable' then return dialogEnabled elseif key=='command' then return command elseif key=='pixelColor' then return pixelColor elseif key=='fgColor' then return copyColor(fg) elseif key=='bgColor' then return copyColor(bg) elseif appMethods[key] then return appMethods[key] end
  return rpc('appGet',{key=key})
end,__newindex=function(_,key,value)
  if key=='fgColor' then fg=Color(value) elseif key=='bgColor' then bg=Color(value) else rpc('appSet',{key=key,value=value}) end
end})
local function safeLibrary(library,deny) local result={}; for k,v in pairs(library) do if not deny or not deny[k] then result[k]=v end end return result end
local env={assert=assert,error=error,ipairs=ipairs,pairs=pairs,next=next,pcall=pcall,xpcall=xpcall,select=select,tonumber=tonumber,tostring=tostring,type=type,setmetatable=setmetatable,
  math=safeLibrary(math),table=safeLibrary(table),string=safeLibrary(string,{dump=true}),utf8=safeLibrary(utf8),
  app=app,Dialog=Dialog,Sprite=Sprite,Image=Image,Color=Color,Point=Point,Size=Size,Rectangle=Rectangle,Grid=Grid,Palette=Palette,Selection=Selection,ColorSpace=ColorSpace,ImageSpec=ImageSpec,
  AniDir={FORWARD=0,REVERSE=1,PING_PONG=2,PING_PONG_REVERSE=3},RangeType={EMPTY=0,CELS=1,FRAMES=2,LAYERS=4},
  FlipType={HORIZONTAL=0,VERTICAL=1},ColorMode={RGB=0,GRAY=1,INDEXED=2,TILEMAP=4},BlendMode={NORMAL='normal',SRC='src',MULTIPLY='multiply',SCREEN='screen',OVERLAY='overlay',DARKEN='darken',LIGHTEN='lighten',COLOR_DODGE='color-dodge',COLOR_BURN='color-burn',HARD_LIGHT='hard-light',SOFT_LIGHT='soft-light',DIFFERENCE='difference',EXCLUSION='exclusion',HSL_HUE='hue',HSL_SATURATION='saturation',HSL_COLOR='color',HSL_LUMINOSITY='luminosity',ADDITION='addition',SUBTRACT='subtract',DIVIDE='divide'},
  _VERSION=_VERSION,
  print=function(...) local parts={}; for i=1,select('#',...) do parts[i]=tostring(select(i,...)) end; rpc('print',{text=table.concat(parts,'\t')}) end,
}
env._G=env
${LUA_PLUGIN_BOOTSTRAP}
local instructions,exceeded=0,false
-- The script cannot access debug/coroutines or replace this hook. Parent worker termination is the second limit.
debug.sethook(function() instructions=instructions+1000; if instructions>instructionLimit then exceeded=true; error('Lua instruction budget exceeded',0) end end,'',1000)
local chunk,err=load(source,'@pixelwall-script','t',env)
if not chunk then error(err,0) end
chunk()
if pluginConfig~='' then runPlugin(env) end
debug.sethook()
if exceeded then error('Lua instruction budget exceeded',0) end
rpc('colorsSet',{fgColor=colorRGBA(fg),bgColor=colorRGBA(bg)})
return true
`;
//#endregion
//#region app/lua-color-commands.mjs
const fail = (message) => {
	throw Error(`Lua color command: ${message}`);
};
const record = (value) => value && typeof value === "object" && !Array.isArray(value);
const allowed = (options, names) => {
	if (!record(options)) fail("options must be a table.");
	for (const name of Object.keys(options)) if (!names.includes(name)) fail(`unsupported option ${name}.`);
	if (options.ui !== void 0 && typeof options.ui !== "boolean") fail("ui must be boolean.");
	if (options.ui) fail("parameter dialogs are unavailable; pass ui=false.");
};
const choice = (value, fallback, choices, label) => {
	const result = value ?? fallback;
	if (!choices.includes(result)) fail(`unsupported ${label}.`);
	return result;
};
const alias = (options, one, two, fallback) => {
	if (options[one] !== void 0 && options[two] !== void 0) fail(`specify only one of ${one} and ${two}.`);
	return options[one] ?? options[two] ?? fallback;
};
function createLuaColorCommands({ doc, ref, getRef, mutate, flush, frameRef, getActive, getRangeColors, retireImages }) {
	const palettes = /* @__PURE__ */ new Map();
	let sequence = 0;
	const fresh = (frameId) => ({
		frameId,
		token: ++sequence
	});
	function state(id) {
		if (!palettes.has(id)) palettes.set(id, nativePaletteKeys(doc(id)).map((key) => fresh(key.frameId)));
		return palettes.get(id);
	}
	function paletteRef(id, key = state(id)[0]) {
		return ref("Palette", {
			docId: id,
			paletteToken: key.token
		}, `palette:${id}:${key.token}`);
	}
	function keyFor(value) {
		const r = getRef(value, "Palette");
		if (!r.docId) return null;
		const key = state(r.docId).find((item) => item.token === r.paletteToken);
		if (!key) fail("this Palette was deleted.");
		return key;
	}
	function palette(value) {
		const r = getRef(value, "Palette");
		if (!r.docId) return {
			ref: r,
			colors: r.colors
		};
		const key = keyFor(value);
		const found = nativePaletteKeys(doc(r.docId), state(r.docId).map((item) => item.frameId)).find((item) => item.frameId === key.frameId);
		if (!found) fail("this Palette was deleted.");
		return {
			ref: r,
			colors: found.palette
		};
	}
	function setPalette(id, colors, key = state(id)[0]) {
		mutate(id, {
			type: "palette.nativeSet",
			frameId: key.frameId,
			paletteFrameIds: state(id).map((item) => item.frameId),
			palette: [...colors]
		});
	}
	function command(name, options = {}) {
		const { docId, frameIndex } = getActive();
		if (name === "ChangePixelFormat") {
			allowed(options, [
				"ui",
				"format",
				"colorMode",
				"dithering",
				"dithering-matrix",
				"ditheringMatrix",
				"dithering-factor",
				"ditheringFactor",
				"rgbmap",
				"fitCriteria",
				"toGray"
			]);
			const format = choice(alias(options, "format", "colorMode", "rgb"), "rgb", [
				"rgb",
				"gray",
				"indexed"
			], "format");
			const rgbmap = choice(options.rgbmap, "octree", [
				"default",
				"octree",
				"rgb5a3"
			], "RGB map");
			const fitCriteria = choice(options.fitCriteria, "default", [
				"default",
				"rgb",
				"linearizedRGB",
				"ciexyz",
				"cielab"
			], "fitting criterion");
			const toGray = choice(options.toGray, "luma", [
				"default",
				"luma",
				"hsv",
				"hsl"
			], "grayscale conversion");
			const dither = choice(options.dithering, "none", [
				"none",
				"ordered",
				"old",
				"error-diffusion"
			], "dithering");
			const matrix = choice(alias(options, "dithering-matrix", "ditheringMatrix", "bayer8x8"), "bayer8x8", [
				"bayer2x2",
				"bayer4x4",
				"bayer8x8"
			], "dithering matrix");
			const factor = alias(options, "dithering-factor", "ditheringFactor", 1);
			if (typeof factor !== "number" || !Number.isFinite(factor) || factor < 0 || factor > 1) fail("dithering factor must be from zero to one.");
			if (!docId) return false;
			const colorMode = {
				rgb: "rgba",
				gray: "grayscale",
				indexed: "indexed"
			}[format];
			flush();
			if (doc(docId).colorMode === colorMode) return true;
			mutate(docId, {
				type: "document.nativeColorMode",
				colorMode,
				rgbmap: rgbmap === "default" ? "octree" : rgbmap,
				fitCriteria,
				toGray: toGray === "default" ? "luma" : toGray,
				dithering: dither === "none" ? "none" : `aseprite-${dither}`,
				ditherMatrix: matrix,
				ditherStrength: dither === "error-diffusion" ? factor : 1
			});
			retireImages(docId);
			return true;
		}
		if (name === "ColorQuantization") {
			allowed(options, [
				"ui",
				"algorithm",
				"maxColors",
				"withAlpha",
				"useRange"
			]);
			const algorithm = choice(options.algorithm, "octree", [
				"default",
				"octree",
				"rgb5a3"
			], "quantization algorithm");
			if (options.withAlpha !== void 0 && typeof options.withAlpha !== "boolean" || options.useRange !== void 0 && typeof options.useRange !== "boolean") fail("withAlpha and useRange must be boolean.");
			const maxColors = options.maxColors ?? 256;
			if (!Number.isSafeInteger(maxColors) || maxColors < 2 || maxColors > 256) fail("maxColors must be an integer from 2 to 256.");
			if (!docId) return false;
			flush();
			const colors = options.useRange ? getRangeColors() : void 0;
			if (colors && !colors.length) return true;
			mutate(docId, {
				type: "palette.nativeGenerate",
				frameId: doc(docId).frames[frameIndex].id,
				paletteFrameIds: state(docId).map((key) => key.frameId),
				algorithm: algorithm === "default" ? "octree" : algorithm,
				maxColors,
				withAlpha: options.withAlpha ?? true,
				...colors ? { colors } : {}
			});
			return true;
		}
	}
	return {
		command,
		paletteRef,
		palette,
		list(id) {
			return state(id).map((key) => paletteRef(id, key));
		},
		frame(value) {
			const p = palette(value);
			if (!p.ref.docId) return null;
			return frameRef(p.ref.docId, doc(p.ref.docId).frames.findIndex((frame) => frame.id === keyFor(value).frameId));
		},
		setFirst(id, colors) {
			setPalette(id, colors);
		},
		set(value, colors) {
			const p = palette(value);
			if (p.ref.docId) setPalette(p.ref.docId, colors, keyFor(value));
			else p.ref.colors = [...colors];
		},
		track(next, operation) {
			const before = palettes.get(next.id);
			if (!before) return;
			const frameIds = new Set(next.frames.map((frame) => frame.id));
			if (operation.type === "document.nativeColorMode" && next.colorMode === "grayscale") palettes.set(next.id, [{
				...before[0],
				frameId: next.frames[0].id
			}]);
			else if (operation.type === "palette.update" || operation.type === "palette.replace") palettes.set(next.id, nativePaletteKeys(next).map((key) => before.find((old) => old.frameId === key.frameId) ?? fresh(key.frameId)));
			else {
				const remaining = before.filter((key, index) => index === 0 || frameIds.has(key.frameId));
				remaining[0] = {
					...remaining[0],
					frameId: next.frames[0].id
				};
				remaining.sort((a, b) => next.frames.findIndex((frame) => frame.id === a.frameId) - next.frames.findIndex((frame) => frame.id === b.frameId));
				palettes.set(next.id, remaining);
			}
		},
		snapshot() {
			return new Map([...palettes].map(([id, keys]) => [id, keys.map((key) => ({ ...key }))]));
		},
		restore(snapshot) {
			palettes.clear();
			for (const [id, keys] of snapshot) palettes.set(id, keys.map((key) => ({ ...key })));
		}
	};
}
//#endregion
//#region app/lua-image-specs.mjs
/** Worker-local value semantics. Specs and per-image profile hints never grant
* file access or change a document outside the ordinary command transaction. */
const LUA_SPEC_NOT_HANDLED = Symbol("not an image specification operation");
const MODES = {
	rgba: 0,
	grayscale: 1,
	indexed: 2
};
const modeNames = [
	"rgba",
	"grayscale",
	"indexed"
];
const NONE = Object.freeze({
	profile: Object.freeze({
		type: 0,
		flags: 0,
		gamma: 0
	}),
	name: ""
});
const int = (value, label) => {
	const n = typeof value === "number" || typeof value === "string" ? Number(value) : 0;
	if (!Number.isFinite(n) || Math.floor(n) < -2147483648 || Math.floor(n) > 2147483647) throw Error(`${label} must fit a signed 32-bit integer.`);
	return Math.floor(n);
};
const maskInt = (value) => {
	const n = typeof value === "number" || typeof value === "string" ? Number(value) : 0;
	if (!Number.isFinite(n) || Math.floor(n) < -2147483648 || Math.floor(n) > 4294967295) throw Error("Transparent color must fit a 32-bit pixel.");
	return Math.floor(n) >>> 0;
};
function createLuaImageSpecs({ ref, getRef, image, doc, colorSpaces, limits }) {
	let values = 0;
	let overrides = /* @__PURE__ */ new Map();
	const key = (docId, imageId) => JSON.stringify([docId, imageId]);
	function make(spec) {
		if (++values > 2048) throw Error("Lua ImageSpec value limit exceeded.");
		return ref("ImageSpec", { spec: { ...spec } });
	}
	function checked(value) {
		return getRef(value, "ImageSpec").spec;
	}
	function imageDescriptor(value) {
		if (!value.docId) return {
			profile: value.specProfile ?? NONE,
			transparentColor: value.transparentColor ?? 0
		};
		const override = overrides.get(key(value.docId, value.imageId));
		return {
			profile: value.tilesetId ? NONE : override?.profile ?? colorSpaces.documentValue(doc(value.docId)),
			transparentColor: override?.transparentColor ?? doc(value.docId).metadata?.aseprite?.transparentIndex ?? 0
		};
	}
	function fromImage(value) {
		const descriptor = imageDescriptor(value);
		return {
			width: value.width,
			height: value.height,
			colorMode: MODES[value.colorMode],
			...descriptor
		};
	}
	function fromSprite(value) {
		const d = doc(getRef(value, "Sprite").docId);
		return {
			width: d.width,
			height: d.height,
			colorMode: MODES[d.colorMode],
			transparentColor: d.metadata?.aseprite?.transparentIndex ?? 0,
			profile: colorSpaces.documentValue(d)
		};
	}
	function create(options = {}) {
		if (options.source) return make(checked(options.source));
		const o = options.fields ?? {};
		return make({
			width: o.width == null ? 1 : int(o.width, "Spec width"),
			height: o.height == null ? 1 : int(o.height, "Spec height"),
			colorMode: o.colorMode == null ? 0 : int(o.colorMode, "Spec color mode"),
			transparentColor: maskInt(o.transparentColor ?? 0),
			profile: NONE
		});
	}
	function options(value, { sprite = false } = {}) {
		const s = { ...checked(value) };
		if (![
			0,
			1,
			2
		].includes(s.colorMode)) throw Error("ImageSpec supports RGB, gray and indexed raster allocation; tilemap allocation is unavailable.");
		if (sprite && s.profile.profile.type === 2 && String.fromCharCode(...s.profile.profile.icc.slice(16, 20)) === "GRAY" && s.colorMode !== 1) throw Error("A gray profile requires a grayscale sprite.");
		if (!sprite) {
			s.width = Math.max(1, s.width);
			s.height = Math.max(1, s.height);
		}
		if (s.width < 1 || s.height < 1 || s.width > 2048 || s.height > 2048 || s.width * s.height > limits.pixels) throw Error("ImageSpec dimensions exceed the raster allocation budget.");
		const maximum = s.colorMode === 0 ? 4294967295 : s.colorMode === 1 ? 65535 : 255;
		if (s.transparentColor > maximum) throw Error("ImageSpec transparent color does not fit its color mode.");
		return {
			...s,
			colorMode: modeNames[s.colorMode]
		};
	}
	function attachedCopy(docId, imageId) {
		overrides.set(key(docId, imageId), {
			profile: NONE,
			transparentColor: doc(docId).metadata?.aseprite?.transparentIndex ?? 0
		});
	}
	return {
		create,
		options,
		none: NONE,
		imageDescriptor,
		fromSprite,
		mask: (value) => imageDescriptor(value).transparentColor,
		renderedProfile: (sprite) => fromSprite(sprite).profile,
		attachedCopy,
		resized(value) {
			if (value.docId && !value.tilesetId) attachedCopy(value.docId, value.imageId, value);
		},
		profileAssigned(docId) {
			for (const [id, value] of overrides) if (JSON.parse(id)[0] === docId) overrides.set(id, {
				...value,
				profile: colorSpaces.documentValue(doc(docId))
			});
		},
		snapshot: () => new Map(overrides),
		restore: (snapshot) => {
			overrides = new Map(snapshot);
		},
		equal(left, right) {
			const a = checked(left), b = checked(right);
			return [
				"width",
				"height",
				"colorMode",
				"transparentColor"
			].every((k) => a[k] === b[k]) && colorSpaces.sameValues(a.profile, b.profile);
		},
		get(target, property) {
			if (target.__kind === "ImageSpec") {
				const value = checked(target);
				if (property === "colorSpace") return colorSpaces.fromValue(value.profile);
				if ([
					"width",
					"height",
					"colorMode",
					"transparentColor"
				].includes(property)) return value[property];
				throw Error(`Unsupported ImageSpec.${property}.`);
			}
			if (property === "spec" && target.__kind === "Image") return make(fromImage(image(target)));
			if (property === "spec" && target.__kind === "Sprite") return make(fromSprite(target));
			return LUA_SPEC_NOT_HANDLED;
		},
		set(target, property, value) {
			if (target.__kind !== "ImageSpec") return LUA_SPEC_NOT_HANDLED;
			const spec = checked(target);
			if (property === "colorSpace") spec.profile = colorSpaces.capture(value);
			else if (property === "transparentColor") spec[property] = maskInt(value);
			else if ([
				"width",
				"height",
				"colorMode"
			].includes(property)) spec[property] = int(value, `Spec ${property}`);
			else throw Error(`Unsupported ImageSpec.${property}.`);
		}
	};
}
//#endregion
//#region app/lua-raster-lifetime.mjs
/** Raster handles keep engine image IDs but acquire a new Lua generation when
* ColorSpace conversion replaces their native image identity. */
function createLuaRasterLifetime({ refs, attached, doc }) {
	const epochs = /* @__PURE__ */ new Map();
	let serial = 0;
	const raster = (value) => value.kind === "Image" && value.docId && !value.tilesetId;
	function identity(docId, imageId) {
		const epoch = doc(docId).images[imageId]?.tilemap ? 0 : epochs.get(docId) ?? 0;
		return {
			key: `image:${JSON.stringify([
				docId,
				imageId,
				epoch
			])}`,
			epoch
		};
	}
	return {
		identity,
		retire(docId) {
			epochs.set(docId, ++serial);
			for (const [key, value] of refs) if (raster(value) && value.docId === docId && !doc(docId).images[value.imageId]?.tilemap) {
				value.profileRetired = true;
				value.pixels = [];
				attached.delete(key);
			}
		},
		snapshot() {
			return {
				epochs: new Map(epochs),
				refs: new Map([...refs].filter(([, value]) => raster(value)))
			};
		},
		restore(snapshot) {
			epochs.clear();
			for (const [key, value] of snapshot.epochs) epochs.set(key, value);
			for (const [key, value] of snapshot.refs) if (!refs.has(key)) refs.set(key, value);
			for (const [key, value] of refs) if (raster(value)) {
				let image;
				try {
					image = doc(value.docId).images[value.imageId];
				} catch {
					image = null;
				}
				if (image && value.profileImageEpoch === (image.tilemap ? 0 : epochs.get(value.docId) ?? 0)) {
					delete value.profileRetired;
					attached.set(key, value);
				} else {
					value.profileRetired = true;
					value.pixels = [];
					attached.delete(key);
				}
			}
		}
	};
}
//#endregion
//#region app/lua-tilesets.mjs
const LUA_TILE_NOT_HANDLED = Symbol("tileset API not handled");
const no$1 = LUA_TILE_NOT_HANDLED;
const integer$3 = (value, min, max, label) => {
	if (!Number.isSafeInteger(value) || value < min || value > max) throw Error(`${label} must be an integer from ${min} to ${max}.`);
	return value;
};
/** Native tiles remain independent resources; placements are never flattened. */
function createLuaTilesets({ doc, ref, getRef, mutate, tileImageRef, image, retireTileImage, reservePixels, limits, newId, layerRef, getActiveLayer, setActiveLayer }) {
	const tilesetRef = (docId, tilesetId) => ref("Tileset", {
		docId,
		tilesetId
	}, `tileset:${docId}:${tilesetId}`);
	const tileRef = (docId, tilesetId, index) => ref("Tile", {
		docId,
		tilesetId,
		index
	}, `tile:${docId}:${tilesetId}:${index}`);
	function owner(target) {
		const value = getRef(target, target.__kind), d = doc(value.docId), tileset = d.tilesets.find((item) => item.id === value.tilesetId);
		if (!tileset) throw Error("Tileset no longer exists.");
		return {
			...value,
			d,
			tileset
		};
	}
	function tile(target) {
		const value = owner(target), slots = tilesetSlots(value.d, value.tileset);
		if (value.index >= slots.count) throw Error("Tile no longer exists.");
		return {
			...value,
			value: slots.entries.get(value.index)
		};
	}
	function object(target) {
		if (target.__kind === "Tileset") {
			const value = owner(target);
			return {
				...value,
				value: value.tileset,
				command: {
					target: "tileset",
					tilesetId: value.tilesetId
				}
			};
		}
		if (target.__kind === "Tile") {
			const value = tile(target);
			return {
				...value,
				value: { userData: value.value?.userData ?? value.tileset.tileUserData?.[value.index] },
				command: {
					target: "tile",
					tilesetId: value.tilesetId,
					tileIndex: value.index
				}
			};
		}
		return null;
	}
	function grid(docId) {
		const g = doc(docId).metadata?.aseprite?.grid;
		return {
			x: g?.x ?? 0,
			y: g?.y ?? 0,
			width: g?.width || 16,
			height: g?.height || 16
		};
	}
	function gridBounds(value, origin = true) {
		if (!value || Object.keys(value).some((key) => ![
			"__value",
			"x",
			"y",
			"width",
			"height"
		].includes(key))) throw Error("Expected Grid or Rectangle.");
		const result = {
			x: integer$3(value.x ?? 0, -32768, 32767, "Grid x"),
			y: integer$3(value.y ?? 0, -32768, 32767, "Grid y"),
			width: integer$3(value.width, 1, 65535, "Grid width"),
			height: integer$3(value.height, 1, 65535, "Grid height")
		};
		if (!origin && (result.x || result.y)) throw Error("A tileset with an origin different from 0,0 cannot be created.");
		return result;
	}
	function reserveTiles(width, height, count) {
		integer$3(width, 1, 65535, "Tile width");
		integer$3(height, 1, 65535, "Tile height");
		integer$3(count, 1, 65536, "Tile count");
		integer$3(height * count, 1, 65535, "Tileset atlas height");
		const size = width * height * count;
		if (!Number.isSafeInteger(size) || size > limits.pixels) throw Error("Lua tileset pixel budget exceeded.");
		reservePixels(size);
	}
	function newTileset(docId, args) {
		if (!Array.isArray(args)) {
			if (!args || Object.keys(args).length) throw Error("Tileset arguments must be a contiguous argument list.");
			args = [];
		}
		if (args.length > 2) throw Error("Sprite:newTileset expects a Grid/Rectangle and optional tile count, or one same-sprite Tileset.");
		let command;
		if (args[0]?.__kind === "Tileset") {
			if (args.length !== 1) throw Error("Tileset copy expects one argument.");
			const source = owner(args[0]);
			if (source.docId !== docId) throw Error("Tileset belongs to another sprite.");
			reserveTiles(source.tileset.tileWidth, source.tileset.tileHeight, tilesetSlots(source.d, source.tileset).count);
			command = { copyTilesetId: source.tilesetId };
		} else {
			const bounds = args[0] == null ? {
				...grid(docId),
				x: 0,
				y: 0
			} : gridBounds(args[0], false), count = integer$3(args[1] ?? 1, 1, 65536, "Tile count");
			reserveTiles(bounds.width, bounds.height, count);
			command = {
				tileWidth: bounds.width,
				tileHeight: bounds.height,
				tileCount: count
			};
		}
		const tilesetId = newId("tileset");
		mutate(docId, {
			type: "tileset.create",
			tilesetId,
			...command
		});
		return tilesetRef(docId, tilesetId);
	}
	function newLayer(sprite, options) {
		if (options.tilemap !== true || options.group != null && options.group !== false) throw Error("NewLayer tilemap and group options are mutually exclusive.");
		if (options.name != null && typeof options.name !== "string") throw Error("Layer name must be a string.");
		const docId = getRef(sprite, "Sprite").docId, d = doc(docId), g = options.gridBounds ? gridBounds(options.gridBounds) : grid(docId), origin = options.gridBounds ? {
			x: g.x,
			y: g.y
		} : {
			x: (g.x % g.width + g.width) % g.width,
			y: (g.y % g.height + g.height) % g.height
		};
		reserveTiles(g.width, g.height, 1);
		const tilesetId = newId("tileset"), layerId = newId("layer"), current = d.layers.find((layer) => layer.id === getActiveLayer()), parentId = current?.type === "group" ? current.id : current?.parentId ?? null;
		const descendants = (layer) => {
			const ids = [layer.id];
			for (const child of d.layers.filter((value) => value.parentId === layer.id)) ids.push(...descendants(child));
			return ids;
		};
		const anchorIds = current ? descendants(current) : [], index = current?.type === "group" ? Math.max(d.layers.indexOf(current), ...d.layers.map((layer, at) => anchorIds.includes(layer.id) ? at : -1)) + 1 : current ? Math.max(...d.layers.map((layer, at) => anchorIds.includes(layer.id) ? at : -1)) + 1 : d.layers.length;
		let number = 1;
		while (d.layers.some((layer) => layer.name === `Tilemap ${number}`)) number++;
		mutate(docId, {
			type: "batch",
			commands: [{
				type: "tileset.create",
				tilesetId,
				tileWidth: g.width,
				tileHeight: g.height,
				tileCount: 1,
				gridOrigin: origin
			}, {
				type: "layer.add",
				index,
				layer: {
					id: layerId,
					name: options.name || `Tilemap ${number}`,
					type: "tilemap",
					tilesetId,
					parentId
				}
			}]
		});
		setActiveLayer(layerId);
		return layerRef(docId, layerId);
	}
	function get(target, key) {
		if (target.__kind === "Sprite" && key === "gridBounds") return {
			__value: "Rectangle",
			...grid(getRef(target, "Sprite").docId)
		};
		if (target.__kind === "Sprite" && key === "tilesets") {
			const d = doc(getRef(target, "Sprite").docId);
			return d.tilesets.map((value) => tilesetRef(d.id, value.id));
		}
		if (target.__kind === "Layer" && key === "tileset") {
			const value = getRef(target, "Layer"), d = doc(value.docId), layer = d.layers.find((layer) => layer.id === value.layerId);
			if (!layer) throw Error("Layer no longer exists.");
			if (layer.type !== "tilemap") return null;
			const ids = new Set([layer.tilesetId, ...Object.values(layer.tilemaps ?? {}).map((map) => map.tilesetId)].filter(Boolean));
			if (ids.size > 1) throw Error("Layer.tileset cannot represent a layer that changes tilesets between frames.");
			return ids.size ? tilesetRef(d.id, [...ids][0]) : null;
		}
		if (target.__kind === "Tileset") {
			const value = owner(target), ts = value.tileset;
			if (key === "name") return ts.name ?? "";
			if (key === "baseIndex") return ts.baseIndex ?? 1;
			if (key === "size") return tilesetSlots(value.d, ts).count;
			if (key === "grid") return {
				__value: "Grid",
				width: ts.tileWidth,
				height: ts.tileHeight,
				x: ts.gridOrigin?.x ?? 0,
				y: ts.gridOrigin?.y ?? 0
			};
		}
		if (target.__kind === "Tile") {
			const value = owner(target);
			if (key === "index") return value.index;
			if (key === "image") return value.index >= tilesetSlots(value.d, value.tileset).count ? null : tileImageRef(value.docId, value.tilesetId, value.index);
		}
		return no$1;
	}
	function set(target, key, value) {
		if (target.__kind === "Sprite" && key === "gridBounds") {
			const d = doc(getRef(target, "Sprite").docId), bounds = gridBounds(value);
			mutate(d.id, {
				type: "document.update",
				patch: { metadata: {
					...d.metadata,
					aseprite: {
						...d.metadata?.aseprite,
						grid: bounds
					}
				} }
			});
			return true;
		}
		if (target.__kind === "Tileset" && ["name", "baseIndex"].includes(key)) {
			const ownerValue = owner(target);
			if (key === "name" && (typeof value !== "string" || new TextEncoder().encode(value).length > 240 || value.includes("\0"))) throw Error("Tileset name must be a string of at most 240 bytes without NUL.");
			if (key === "baseIndex") integer$3(value, -32768, 32767, "Tileset base index");
			mutate(ownerValue.docId, {
				type: "tileset.update",
				tilesetId: ownerValue.tilesetId,
				patch: { [key]: value }
			});
			return true;
		}
		if (target.__kind === "Tile" && key === "image") {
			const ownerValue = tile(target), source = image(value);
			if (source.colorMode !== ownerValue.d.colorMode) throw Error("Tile image and sprite color modes must match.");
			if (source.width !== ownerValue.tileset.tileWidth || source.height !== ownerValue.tileset.tileHeight) throw Error("Tile image dimensions must match the tileset grid.");
			mutate(ownerValue.docId, {
				type: "tileset.tileImage",
				tilesetId: ownerValue.tilesetId,
				tileIndex: ownerValue.index,
				width: source.width,
				height: source.height,
				pixels: [...source.pixels]
			});
			retireTileImage(ownerValue.docId, ownerValue.tilesetId, ownerValue.index);
			return true;
		}
		if (target.__kind === "Layer" && key === "tileset") {
			const l = getRef(target, "Layer"), layer = doc(l.docId).layers.find((layer) => layer.id === l.layerId);
			if (!layer) throw Error("Layer no longer exists.");
			if (value == null || layer.type !== "tilemap") return true;
			getRef(value, "Tileset");
			const ts = owner(value);
			if (ts.docId !== l.docId) throw Error("Tileset belongs to another sprite.");
			mutate(l.docId, {
				type: "layer.tileset",
				layerId: l.layerId,
				tilesetId: ts.tilesetId
			});
			return true;
		}
		return false;
	}
	function method(target, name, args) {
		if (target.__kind === "Tileset" && ["tile", "getTile"].includes(name)) {
			if (args.length !== 1) throw Error(`Tileset:${name} expects one zero-based index.`);
			const value = owner(target), index = integer$3(args[0], -2147483648, 2147483647, "Tile index");
			if (index < 0 || index >= tilesetSlots(value.d, value.tileset).count) return null;
			return name === "getTile" ? tileImageRef(value.docId, value.tilesetId, index) : tileRef(value.docId, value.tilesetId, index);
		}
		if (target.__kind === "Sprite" && name === "deleteTileset") {
			if (args.length !== 1) throw Error("Sprite:deleteTileset expects a Tileset or one-based tileset index.");
			const d = doc(getRef(target, "Sprite").docId);
			const value = typeof args[0] === "number" ? d.tilesets[integer$3(args[0], 1, d.tilesets.length, "Tileset index") - 1] : owner(args[0]);
			if (value.docId && value.docId !== d.id) throw Error("Tileset belongs to another sprite.");
			mutate(d.id, {
				type: "tileset.remove",
				tilesetId: value.tilesetId ?? value.id
			});
			return;
		}
		if (target.__kind === "Sprite" && name === "newTileset") return newTileset(getRef(target, "Sprite").docId, args);
		if (target.__kind === "Sprite" && (name === "newTile" || name === "deleteTile")) {
			const docId = getRef(target, "Sprite").docId, tileArgument = name === "deleteTile" && args[0]?.__kind === "Tile";
			if (args.length < 1 || args.length > 2 || tileArgument && args.length !== 1) throw Error(`Invalid Sprite:${name} arguments.`);
			getRef(args[0], tileArgument ? "Tile" : "Tileset");
			const value = owner(args[0]);
			if (value.docId !== docId) throw Error("Tileset belongs to another sprite.");
			const count = tilesetSlots(value.d, value.tileset).count, insert = name === "newTile", index = integer$3(tileArgument ? value.index : args[1] ?? (insert ? count : NaN), 1, insert ? count : count - 1, "Tile index");
			reserveTiles(value.tileset.tileWidth, value.tileset.tileHeight, count + (insert ? 1 : -1));
			mutate(docId, {
				type: insert ? "tileset.tileInsert" : "tileset.tileRemove",
				tilesetId: value.tilesetId,
				tileIndex: index,
				...insert ? { tileId: newId("tile") } : {}
			});
			return insert ? tileRef(docId, value.tilesetId, index) : void 0;
		}
		return no$1;
	}
	return {
		get,
		set,
		method,
		object,
		newLayer
	};
}
//#endregion
//#region app/lua-image-api.mjs
const copy$2 = (value) => structuredClone(value);
const integer$2 = (value, min, max, label) => {
	if (!Number.isSafeInteger(value) || value < min || value > max) throw Error(`${label} must be an integer from ${min} to ${max}.`);
	return value;
};
const hex$1 = (bytes) => "#" + Array.from(bytes, (value) => value.toString(16).padStart(2, "0")).join("");
const LUA_IMAGE_NOT_HANDLED = Symbol("image API not handled");
/** Worker-only image operations. Mutations remain buffered until the session's normal transactional flush. */
function createLuaImageApi({ doc, image, ref, getRef, frameAt, celRef, reservePixels, flush, imagePixel, outputPixel, limits, specMask, renderedProfile, resized }) {
	let serial = 0;
	const ids = /* @__PURE__ */ new WeakMap(), transfers = /* @__PURE__ */ new Map();
	const id = (value) => {
		if (!ids.has(value)) ids.set(value, ++serial);
		return ids.get(value);
	};
	const mask = (value) => specMask(value);
	const bpp = (value) => value.colorMode === "rgba" ? 4 : value.colorMode === "grayscale" ? 2 : 1;
	const comparable = (value, pixel) => {
		const packed = outputPixel(value, pixel);
		return value.colorMode === "indexed" || Math.floor(packed / (value.colorMode === "rgba" ? 16777216 : 256)) !== 0 ? packed : 0;
	};
	const emptyPixel = (value) => mask(value);
	function editable(value) {
		if (!value.docId) return;
		const d = doc(value.docId);
		if (value.tilesetId) {
			if (value.virtualTile) throw Error("Virtual empty tile artwork cannot be edited; import an embedded native tileset first.");
			assertTilesetEditable(d, value.tilesetId);
			return;
		}
		for (const frame of d.frames) for (const [layerId, cel] of Object.entries(frame.cels)) if (cel.imageId === value.imageId) {
			let layer = d.layers.find((entry) => entry.id === layerId);
			while (layer) {
				if (layer.locked) throw Error(`Layer “${layer.name}” is locked.`);
				layer = d.layers.find((entry) => entry.id === layer.parentId);
			}
		}
	}
	function changed(value, pixels, width = value.width, height = value.height) {
		editable(value);
		value.pixels = pixels;
		value.width = width;
		value.height = height;
		value.version = (value.version ?? 0) + 1;
		value.dirty = !!value.docId;
	}
	function dimensions(width, height) {
		integer$2(width, 1, 2048, "Image width");
		integer$2(height, 1, 2048, "Image height");
		if (width * height > limits.pixels) throw Error("Lua image pixel budget exceeded.");
	}
	function crop(source, rectangle) {
		const x = integer$2(rectangle.x ?? 0, -65535, 65535, "Crop x"), y = integer$2(rectangle.y ?? 0, -65535, 65535, "Crop y"), width = integer$2(rectangle.width, -65535, 2048, "Crop width"), height = integer$2(rectangle.height, -65535, 2048, "Crop height");
		if (width <= 0 || height <= 0) return null;
		dimensions(width, height);
		reservePixels(width * height);
		const padding = imagePixel(source, mask(source));
		return ref("Image", {
			width,
			height,
			pixels: Array.from({ length: width * height }, (_, at) => {
				const sx = x + at % width, sy = y + Math.floor(at / width);
				return sx >= 0 && sy >= 0 && sx < source.width && sy < source.height ? source.pixels[sy * source.width + sx] : padding;
			}),
			colorMode: source.colorMode,
			transparentColor: mask(source),
			version: 0
		});
	}
	function get(target, key) {
		if (target.__kind !== "Image") return LUA_IMAGE_NOT_HANDLED;
		const value = image(target);
		if (key === "id") return id(value);
		if (key === "rowStride") return value.width * bpp(value);
		if (key === "cel") {
			if (value.tilesetId) throw Error("Tileset internal Cel handles are not exposed; edit Tile.image directly.");
			if (value.docId) {
				for (const frame of doc(value.docId).frames) for (const [layerId, cel] of Object.entries(frame.cels)) if (cel.imageId === value.imageId) return celRef(value.docId, layerId, frame.id);
			}
			return null;
		}
		return LUA_IMAGE_NOT_HANDLED;
	}
	function bytesGet(target, start, count) {
		const value = image(target), stride = bpp(value), size = value.width * value.height * stride;
		integer$2(start, 0, size, "Byte offset");
		integer$2(count, 0, Math.min(4096, size - start), "Byte count");
		return Array.from({ length: count }, (_, offset) => {
			const at = start + offset, packed = integer$2(outputPixel(value, value.pixels[Math.floor(at / stride)]), 0, 256 ** stride - 1, "Packed image pixel");
			return Math.floor(packed / 256 ** (at % stride)) & 255;
		});
	}
	function bytesBegin(target, size) {
		const value = image(target);
		editable(value);
		integer$2(size, value.width * value.height * bpp(value), value.width * value.height * bpp(value), "Image byte length");
		if (transfers.size) throw Error("An image byte transfer is already in progress.");
		reservePixels(value.width * value.height);
		const token = ++serial;
		transfers.set(token, {
			value,
			bytes: new Uint8Array(size),
			at: 0
		});
		return token;
	}
	function bytesAppend(token, bytes) {
		const transfer = transfers.get(token);
		if (!transfer || !Array.isArray(bytes) || !bytes.length || bytes.length > 4096 || transfer.at + bytes.length > transfer.bytes.length) throw Error("Invalid image byte transfer.");
		for (const byte of bytes) integer$2(byte, 0, 255, "Image byte");
		transfer.bytes.set(bytes, transfer.at);
		transfer.at += bytes.length;
	}
	function bytesCommit(token) {
		const transfer = transfers.get(token);
		if (!transfer || transfer.at !== transfer.bytes.length) throw Error("Incomplete image byte transfer.");
		const { value, bytes } = transfer, stride = bpp(value), pixels = new Array(value.width * value.height);
		for (let at = 0; at < pixels.length; at++) {
			const offset = at * stride;
			if (value.colorMode === "indexed") {
				const index = bytes[offset];
				if (value.docId && index >= Math.max(doc(value.docId).palette.length, ...doc(value.docId).frames.map((frame) => frame.palette?.length ?? 0))) throw Error("Indexed bytes reference a missing sprite palette entry.");
				pixels[at] = index;
			} else pixels[at] = value.colorMode === "rgba" ? hex$1(bytes.subarray(offset, offset + 4)) : hex$1([
				bytes[offset],
				bytes[offset],
				bytes[offset],
				bytes[offset + 1]
			]);
		}
		changed(value, pixels);
		transfers.delete(token);
	}
	function rendered(sprite, frameNumber, destinationMode) {
		flush();
		const source = doc(getRef(sprite, "Sprite").docId), frameIndex = frameAt(source.id, frameNumber, 0), frameId = source.frames[frameIndex].id;
		if (destinationMode !== "rgba" && destinationMode !== source.colorMode) throw Error("drawSprite supports matching color modes or an RGB destination; other cross-mode fitting is not implemented.");
		let rendering = source;
		if (destinationMode === "indexed") {
			const palette = Array.from({ length: Math.max(source.palette.length, ...source.frames.map((frame) => frame.palette?.length ?? 0)) }, (_, index) => hex$1([
				index & 255,
				index >>> 8,
				1,
				255
			]));
			rendering = {
				...source,
				palette,
				layers: source.layers.map((layer) => ({
					...layer,
					opacity: 1,
					blendMode: "normal",
					...layer.tilemaps ? { tilemaps: Object.fromEntries(Object.entries(layer.tilemaps).map(([key, map]) => [key, {
						...map,
						opacity: 1
					}])) } : {}
				})),
				frames: source.frames.map((frame) => ({
					...frame,
					palette,
					cels: Object.fromEntries(Object.entries(frame.cels).map(([key, cel]) => [key, {
						...cel,
						opacity: 1
					}]))
				}))
			};
		}
		const bytes = renderFrame(rendering, frameId), pixels = Array.from({ length: source.width * source.height }, (_, at) => {
			const c = bytes.subarray(at * 4, at * 4 + 4);
			if (!c[3]) return null;
			return destinationMode === "indexed" ? c[0] + c[1] * 256 : hex$1(c);
		});
		return {
			width: source.width,
			height: source.height,
			pixels,
			...destinationMode === "indexed" ? { coverage: Array.from({ length: pixels.length }, (_, at) => bytes[at * 4 + 3] > 0) } : {},
			colorMode: destinationMode,
			transparentColor: source.metadata?.aseprite?.transparentIndex ?? 0,
			palette: getFramePalette(source, frameId)
		};
	}
	function spriteImage(sprite) {
		const renderedImage = rendered(sprite, 1, doc(getRef(sprite, "Sprite").docId).colorMode);
		reservePixels(renderedImage.width * renderedImage.height);
		delete renderedImage.coverage;
		return ref("Image", {
			...renderedImage,
			specProfile: renderedProfile(sprite),
			version: 0
		});
	}
	function draw(value, source, position = {
		x: 0,
		y: 0
	}, opacity = 255, blendMode = "normal") {
		editable(value);
		integer$2(position.x, -65535, 65535, "Image position x");
		integer$2(position.y, -65535, 65535, "Image position y");
		integer$2(opacity, 0, 255, "Image opacity");
		if (blendMode !== "src" && !BLEND_MODES.includes(blendMode)) throw Error("Unsupported image blend mode.");
		if (source.colorMode !== value.colorMode) throw Error("Image color modes must match.");
		if (blendMode === "src") {
			const pixels = [...value.pixels];
			for (let y = 0; y < source.height; y++) for (let x = 0; x < source.width; x++) {
				const dx = position.x + x, dy = position.y + y;
				if (dx >= 0 && dy >= 0 && dx < value.width && dy < value.height) pixels[dy * value.width + dx] = source.pixels[y * source.width + x];
			}
			changed(value, pixels);
			return;
		}
		if (value.colorMode === "indexed") {
			const pixels = [...value.pixels];
			for (let y = 0; y < source.height; y++) for (let x = 0; x < source.width; x++) {
				const dx = position.x + x, dy = position.y + y, p = source.pixels[y * source.width + x];
				if (dx >= 0 && dy >= 0 && dx < value.width && dy < value.height && p !== null && (source.coverage ? source.coverage[y * source.width + x] : p !== mask(source))) pixels[dy * value.width + dx] = p;
			}
			changed(value, pixels);
			return;
		}
		const seed = createDocument({
			width: value.width,
			height: value.height
		}), first = seed.layers[0], frame = seed.frames[0];
		seed.layers = [first, {
			...first,
			id: "source",
			blendMode
		}];
		seed.images = {
			destination: {
				width: value.width,
				height: value.height,
				pixels: value.pixels
			},
			source: {
				width: source.width,
				height: source.height,
				pixels: source.pixels
			}
		};
		frame.cels = {
			[first.id]: {
				imageId: "destination",
				x: 0,
				y: 0,
				opacity: 1
			},
			source: {
				imageId: "source",
				x: position.x,
				y: position.y,
				opacity: opacity / 255
			}
		};
		const bytes = renderFrame(seed);
		changed(value, Array.from({ length: value.width * value.height }, (_, at) => bytes[at * 4 + 3] ? hex$1(bytes.subarray(at * 4, at * 4 + 4)) : null));
	}
	function method(target, name, args = []) {
		if (target.__kind !== "Image") return LUA_IMAGE_NOT_HANDLED;
		const value = image(target);
		if (name === "clear") {
			if (args.length > 2) throw Error("Unsupported Image:clear arguments.");
			const rectangle = args[0] && typeof args[0] === "object" && (args[0].width !== void 0 || args[0].height !== void 0) ? args[0] : {
				x: 0,
				y: 0,
				width: value.width,
				height: value.height
			};
			const pixel = imagePixel(value, rectangle === args[0] ? args[1] ?? mask(value) : args[0] ?? mask(value));
			const x = integer$2(rectangle.x ?? 0, -65535, 65535, "Clear x"), y = integer$2(rectangle.y ?? 0, -65535, 65535, "Clear y"), width = integer$2(rectangle.width, -65535, 65535, "Clear width"), height = integer$2(rectangle.height, -65535, 65535, "Clear height"), pixels = [...value.pixels];
			for (let py = Math.max(0, y); py < Math.min(value.height, y + height); py++) for (let px = Math.max(0, x); px < Math.min(value.width, x + width); px++) pixels[py * value.width + px] = pixel;
			changed(value, pixels);
			return;
		}
		if (name === "resize") {
			const options = typeof args[0] === "object" ? args[0] : {
				width: args[0],
				height: args[1]
			};
			if (!options || Object.keys(options).some((key) => ![
				"width",
				"height",
				"size",
				"method",
				"pivot"
			].includes(key))) throw Error("Unsupported Image:resize argument.");
			if (options.method != null && !["nearest", "nearest-neighbor"].includes(options.method)) throw Error("Image:resize currently supports nearest-neighbor only.");
			if (options.pivot && (options.pivot.x !== 0 || options.pivot.y !== 0)) throw Error("Nonzero Image:resize pivots are not implemented.");
			const width = options.size?.width ?? options.width, height = options.size?.height ?? options.height;
			dimensions(width, height);
			editable(value);
			if (value.tilesetId && (width !== value.width || height !== value.height)) throw Error("Tile image dimensions must match the tileset grid.");
			reservePixels(width * height);
			changed(value, Array.from({ length: width * height }, (_, at) => value.pixels[Math.min(value.height - 1, Math.floor(Math.floor(at / width) * value.height / height)) * value.width + Math.min(value.width - 1, Math.floor(at % width * value.width / width))]), width, height);
			resized(value);
			ids.set(value, ++serial);
			return;
		}
		if (name === "flip") {
			const axis = args[0] ?? 0;
			if (![0, 1].includes(axis) || args.length > 1) throw Error("Image:flip supports HORIZONTAL or VERTICAL.");
			changed(value, Array.from({ length: value.pixels.length }, (_, at) => {
				const x = at % value.width, y = Math.floor(at / value.width);
				return value.pixels[(axis === 1 ? value.height - 1 - y : y) * value.width + (axis === 0 ? value.width - 1 - x : x)];
			}));
			return;
		}
		if (name === "drawImage" || name === "putImage") {
			if (args.length > 4) throw Error("Unsupported Image:drawImage arguments.");
			draw(value, copy$2(image(args[0])), args[1], args[2], args[3]);
			return;
		}
		if (name === "drawSprite" || name === "putSprite") {
			if (args.length > 3 || args[1] == null) throw Error("Image:drawSprite requires a sprite and frame.");
			draw(value, rendered(args[0], args[1], value.colorMode), args[2]);
			return;
		}
		if (name === "shrinkBounds") {
			const reference = args[0] == null ? emptyPixel(value) : comparable(value, imagePixel(value, args[0]));
			let x = value.width, y = value.height, right = -1, bottom = -1;
			for (let at = 0; at < value.pixels.length; at++) if (comparable(value, value.pixels[at]) !== reference) {
				const px = at % value.width, py = Math.floor(at / value.width);
				x = Math.min(x, px);
				y = Math.min(y, py);
				right = Math.max(right, px);
				bottom = Math.max(bottom, py);
			}
			return {
				__value: "Rectangle",
				x: right < 0 ? 0 : x,
				y: bottom < 0 ? 0 : y,
				width: right < 0 ? 0 : right - x + 1,
				height: bottom < 0 ? 0 : bottom - y + 1
			};
		}
		return LUA_IMAGE_NOT_HANDLED;
	}
	return {
		crop,
		spriteImage,
		get,
		method,
		editable,
		mask,
		comparable,
		bytesGet,
		bytesBegin,
		bytesAppend,
		bytesCommit,
		bytesCancel: (token) => transfers.delete(token)
	};
}
//#endregion
//#region app/lua-colors.mjs
/** UI colors cross the worker boundary as copied, unambiguous RGBA byte arrays. */
function validateLuaColor(value, label = "Lua color") {
	if (!Array.isArray(value) || value.length !== 4 || Array.from(value).some((channel) => !Number.isInteger(channel) || channel < 0 || channel > 255)) throw Error(`${label} must be an RGBA array of four integers from 0 to 255.`);
	return [...value];
}
//#endregion
//#region app/lua-authoring.mjs
const LUA_NOT_HANDLED = Symbol("not handled");
const copy$1 = (value) => structuredClone(value), no = LUA_NOT_HANDLED;
const integer$1 = (value, min, max) => {
	if (!Number.isSafeInteger(value) || value < min || value > max) throw Error(`Expected an integer from ${min} to ${max}.`);
	return value;
};
const rect = (value) => ({
	x: integer$1(value?.x ?? 0, -65535, 65535),
	y: integer$1(value?.y ?? 0, -65535, 65535),
	width: integer$1(value?.width ?? 0, 0, 65535),
	height: integer$1(value?.height ?? 0, 0, 65535)
});
const empty = () => ({
	x: 0,
	y: 0,
	width: 0,
	height: 0,
	mask: new Uint8Array()
});
const bounds = (value) => ({
	__value: "Rectangle",
	x: value.x,
	y: value.y,
	width: value.width,
	height: value.height
});
const directions = [
	"forward",
	"reverse",
	"pingpong",
	"pingpong_reverse"
];
const array = (value) => Array.isArray(value) ? value : value && !Object.keys(value).length ? [] : (() => {
	throw Error("Expected an array.");
})();
/** Session-only selections/ranges plus command-backed native tags, slices and user properties. */
function createLuaAuthoring(api) {
	const { doc, mutate, ref, getRef, frameAt, frameRef, layerRef, celRef, imageRef, spriteRef, layer, cel, inputColor, colorValue, getActive, limits } = api;
	let selections = /* @__PURE__ */ new Map(), ranges = /* @__PURE__ */ new Map();
	const creationOrder = /* @__PURE__ */ new Map();
	let serial = 0, selectionPixels = 0;
	function track(document) {
		if (!creationOrder.has(document.id)) creationOrder.set(document.id, /* @__PURE__ */ new Map());
		const order = creationOrder.get(document.id);
		for (const item of document.layers) if (!order.has(item.id)) order.set(item.id, order.size);
	}
	function allocate(width, height) {
		if (width * height > limits.pixels || (selectionPixels += width * height) > limits.pixels * 16) throw Error("Lua selection allocation budget exceeded.");
		return new Uint8Array(width * height);
	}
	function rectangleSelection(value) {
		const result = rect(value);
		result.mask = allocate(result.width, result.height).fill(1);
		return result.width && result.height ? result : empty();
	}
	function selectionRef(docId) {
		if (!selections.has(docId)) selections.set(docId, empty());
		return ref("Selection", { docId }, `selection:${docId}`);
	}
	function selection(target) {
		const value = getRef(target, "Selection");
		return value.docId ? selections.get(value.docId) ?? empty() : value.selection;
	}
	function putSelection(target, value) {
		const state = getRef(target, "Selection");
		if (state.docId) selections.set(state.docId, value);
		else state.selection = value;
	}
	function selected(value, x, y) {
		return x >= value.x && y >= value.y && x < value.x + value.width && y < value.y + value.height && !!value.mask[(y - value.y) * value.width + x - value.x];
	}
	function combine(a, b, operation) {
		const nonempty = [a, b].filter((value) => value.width && value.height);
		if (!nonempty.length) return empty();
		const x = Math.min(...nonempty.map((value) => value.x)), y = Math.min(...nonempty.map((value) => value.y));
		const width = Math.max(...nonempty.map((value) => value.x + value.width)) - x, height = Math.max(...nonempty.map((value) => value.y + value.height)) - y;
		const mask = allocate(width, height);
		let left = width, top = height, right = -1, bottom = -1;
		for (let yy = 0; yy < height; yy++) for (let xx = 0; xx < width; xx++) if (operation(selected(a, xx + x, yy + y), selected(b, xx + x, yy + y))) {
			mask[yy * width + xx] = 1;
			left = Math.min(left, xx);
			top = Math.min(top, yy);
			right = Math.max(right, xx);
			bottom = Math.max(bottom, yy);
		}
		if (right < 0) return empty();
		const w = right - left + 1, h = bottom - top + 1, cropped = allocate(w, h);
		for (let yy = 0; yy < h; yy++) cropped.set(mask.subarray((top + yy) * width + left, (top + yy) * width + left + w), yy * w);
		return {
			x: x + left,
			y: y + top,
			width: w,
			height: h,
			mask: cropped
		};
	}
	function canvasMask(docId) {
		const d = doc(docId), value = selection(selectionRef(docId));
		if (!value.mask.length) return null;
		return Array.from({ length: d.width * d.height }, (_, index) => Number(selected(value, index % d.width, Math.floor(index / d.width))));
	}
	function rangeState(docId) {
		if (!ranges.has(docId)) ranges.set(docId, {
			type: 0,
			layers: [],
			frames: [],
			colors: [],
			slices: []
		});
		return ranges.get(docId);
	}
	function rangeValues(docId) {
		const d = doc(docId), active = getActive(), state = rangeState(docId);
		track(d);
		const layers = (state.layers.length ? state.layers : [active.layerId]).filter((id) => d.layers.some((layer) => layer.id === id)).sort((a, b) => creationOrder.get(docId).get(a) - creationOrder.get(docId).get(b));
		const frames = (state.frames.length ? state.frames : [active.frameIndex]).filter((index) => index < d.frames.length).sort((a, b) => a - b);
		return {
			d,
			state,
			layers,
			frames,
			cels: frames.flatMap((index) => layers.map((id) => celRef(docId, id, d.frames[index].id)).filter(Boolean))
		};
	}
	function object(target) {
		const kind = target.__kind;
		if (kind === "Sprite") {
			const r = getRef(target, kind);
			return {
				docId: r.docId,
				value: doc(r.docId),
				command: { target: "sprite" }
			};
		}
		if (kind === "Layer") {
			const r = layer(target);
			return {
				...r,
				command: {
					target: "layer",
					layerId: r.layerId
				}
			};
		}
		if (kind === "Cel") {
			const r = cel(target);
			return {
				...r,
				command: {
					target: "cel",
					layerId: r.layerId,
					frameId: r.frameId
				}
			};
		}
		if (kind === "Tag" || kind === "Slice") {
			const r = getRef(target, kind), key = kind === "Tag" ? "clips" : "slices", value = doc(r.docId)[key].find((value) => value.id === r.objectId);
			if (!value) throw Error(`${kind} no longer exists.`);
			return {
				...r,
				value,
				command: {
					target: kind === "Tag" ? "tag" : "slice",
					[kind === "Tag" ? "clipId" : "sliceId"]: value.id
				}
			};
		}
		return api.tileObject?.(target) ?? null;
	}
	const tagRef = (docId, id) => ref("Tag", {
		docId,
		objectId: id
	}, `tag:${docId}:${id}`);
	const sliceRef = (docId, id) => ref("Slice", {
		docId,
		objectId: id
	}, `slice:${docId}:${id}`);
	const propertiesRef = (owner, namespace = 0, extension = "") => ref("Properties", {
		owner,
		namespace,
		extension
	}, `properties:${owner.id}:${extension || namespace}`);
	function mapsFor(target) {
		return decodeAsepriteProperties(object(target).value.userData?.propertiesBytes);
	}
	function namespaceId(p) {
		return p.extension ? doc(object(p.owner).docId).metadata?.aseprite?.externalFiles?.find((v) => v.type === 2 && v.name === p.extension)?.id : p.namespace;
	}
	function propertyMap(target) {
		const p = getRef(target, "Properties"), id = namespaceId(p);
		return id == null ? {} : mapsFor(p.owner)[id] ?? {};
	}
	function setUserData(target, patch) {
		const o = object(target);
		mutate(o.docId, {
			type: "object.userData",
			...o.command,
			userData: {
				...o.value.userData,
				...patch
			}
		});
	}
	function replaceProperties(target, values) {
		if (!values || Array.isArray(values) || typeof values !== "object" || values.__kind) throw Error("Properties require a string-keyed table.");
		const p = getRef(target, "Properties"), o = object(p.owner), maps = mapsFor(p.owner), files = doc(o.docId).metadata?.aseprite?.externalFiles ?? [];
		const existing = namespaceId(p), id = existing ?? Math.max(0, ...files.map((v) => v.id)) + 1;
		integer$1(id, 0, 4294967295);
		maps[id] = copy$1(values);
		setUserData(p.owner, { propertiesBytes: encodeAsepriteProperties(maps) });
		if (existing == null) {
			const d = doc(o.docId);
			mutate(o.docId, {
				type: "document.update",
				patch: { metadata: {
					...d.metadata,
					aseprite: {
						...d.metadata?.aseprite,
						externalFiles: [...files, {
							id,
							type: 2,
							name: p.extension
						}]
					}
				} }
			});
		}
	}
	function keyAtZero(o) {
		const slice = o.value;
		if (slice.bounds) return {
			frameId: doc(o.docId).frames[0].id,
			...slice.bounds,
			...slice.pivot ? { pivot: slice.pivot } : {},
			...slice.ninePatch ? { center: slice.ninePatch } : {}
		};
		return slice.keys?.find((key) => !key.frameId || key.frameId === doc(o.docId).frames[0].id) ?? null;
	}
	function sliceKeySet(target, key, value) {
		const o = object(target), d = doc(o.docId), current = copy$1(keyAtZero(o) ?? {
			frameId: d.frames[0].id,
			x: 0,
			y: 0,
			width: 0,
			height: 0
		});
		if (key === "bounds") Object.assign(current, rect(value));
		else if (value == null) delete current[key];
		else current[key] = key === "pivot" ? {
			x: integer$1(value.x, -65535, 65535),
			y: integer$1(value.y, -65535, 65535)
		} : rect(value);
		const keys = [current, ...(o.value.keys ?? []).filter((k) => k.frameId !== d.frames[0].id && k.frameId)];
		mutate(o.docId, {
			type: "slice.update",
			sliceId: o.value.id,
			patch: { keys }
		});
	}
	function get(target, key) {
		const kind = target.__kind;
		if (kind === "Properties") {
			const values = propertyMap(target);
			return {
				__value: "PlainData",
				value: Object.hasOwn(values, key) ? values[key] : null
			};
		}
		if (kind === "Selection") {
			const value = selection(target);
			if (key === "bounds") return bounds(value);
			if (key === "origin") return {
				__value: "Point",
				x: value.x,
				y: value.y
			};
			if (key === "isEmpty") return !value.mask.length;
			return no;
		}
		if (kind === "Range") {
			const r = getRef(target, kind), { state, layers, frames, cels } = rangeValues(r.docId);
			if (key === "sprite") return spriteRef(r.docId);
			if (key === "type") return state.type;
			if (key === "isEmpty") return state.type === 0;
			if (key === "layers") return layers.map((id) => layerRef(r.docId, id));
			if (key === "frames") return frames.map((index) => frameRef(r.docId, index));
			if (key === "cels") return cels;
			if (key === "colors") return [...state.colors];
			if (key === "slices") return state.slices.filter((id) => doc(r.docId).slices.some((s) => s.id === id)).map((id) => sliceRef(r.docId, id));
			if (key === "images" || key === "editableImages") {
				const ids = /* @__PURE__ */ new Set();
				for (const target of cels) {
					const c = cel(target);
					let l = doc(r.docId).layers.find((l) => l.id === c.layerId), locked = false;
					while (l) {
						locked ||= l.locked;
						l = doc(r.docId).layers.find((v) => v.id === l.parentId);
					}
					if (key !== "editableImages" || !locked) ids.add(c.value.imageId);
				}
				return [...ids].map((id) => imageRef(r.docId, id));
			}
			return no;
		}
		const o = object(target);
		if (!o) return no;
		if (key === "properties") return propertiesRef(target);
		if (key === "data") return o.value.userData?.text ?? "";
		if (key === "color") return colorValue(o.value.userData?.color ?? (kind === "Tag" ? o.value.color ?? "#000000ff" : "#00000000"));
		if (kind === "Sprite") {
			if (key === "selection") return selectionRef(o.docId);
			if (key === "tags") return o.value.clips.map((v) => tagRef(o.docId, v.id));
			if (key === "slices") return o.value.slices.map((v) => sliceRef(o.docId, v.id));
		}
		if (kind === "Tag") {
			const d = doc(o.docId), indices = o.value.frameIds.map((id) => d.frames.findIndex((f) => f.id === id));
			const values = {
				sprite: spriteRef(o.docId),
				name: o.value.name,
				fromFrame: frameRef(o.docId, Math.min(...indices)),
				toFrame: frameRef(o.docId, Math.max(...indices)),
				frames: Math.max(...indices) - Math.min(...indices) + 1,
				aniDir: directions.indexOf(o.value.direction),
				repeats: o.value.repeat ?? (o.value.loop ? 0 : 1)
			};
			if (key in values) return values[key];
		}
		if (kind === "Slice") {
			const current = keyAtZero(o);
			if (key === "name") return o.value.name;
			if (key === "sprite") return spriteRef(o.docId);
			if (key === "bounds") return current ? bounds(current) : null;
			if (key === "pivot") return current?.pivot ? {
				__value: "Point",
				...current.pivot
			} : null;
			if (key === "center") return current?.center ? {
				__value: "Rectangle",
				...current.center
			} : null;
		}
		return no;
	}
	function set(target, key, value) {
		const kind = target.__kind;
		if (kind === "Properties") {
			const values = copy$1(propertyMap(target));
			if (value == null) delete values[key];
			else Object.defineProperty(values, key, {
				value: copy$1(value),
				enumerable: true,
				writable: true,
				configurable: true
			});
			replaceProperties(target, values);
			return true;
		}
		if (kind === "Selection" && key === "origin") {
			const current = copy$1(selection(target));
			if (current.mask.length) {
				current.x = integer$1(value.x, -65535, 65535);
				current.y = integer$1(value.y, -65535, 65535);
				putSelection(target, current);
			}
			return true;
		}
		if (kind === "Range") {
			const r = getRef(target, kind), state = rangeState(r.docId), values = array(value);
			if (key === "layers") {
				state.layers = [...new Set(values.map((value) => {
					const l = layer(value);
					if (l.docId !== r.docId) throw Error("Range layer belongs to another sprite.");
					return l.layerId;
				}))];
				state.type = values.length ? 4 : 0;
				return true;
			}
			if (key === "frames") {
				state.frames = [...new Set(values.map((value) => frameAt(r.docId, value)))].sort((a, b) => a - b);
				state.type = values.length ? 2 : 0;
				return true;
			}
			if (key === "colors") {
				state.colors = [...new Set(values.map((value) => integer$1(value, 0, doc(r.docId).palette.length - 1)))].sort((a, b) => a - b);
				return true;
			}
			if (key === "slices") {
				state.slices = [...new Set(values.map((value) => {
					const s = object(value);
					if (value.__kind !== "Slice" || s.docId !== r.docId) throw Error("Range slice belongs to another sprite.");
					return s.value.id;
				}))];
				return true;
			}
			return false;
		}
		const o = object(target);
		if (!o) return false;
		if (key === "data") {
			if (typeof value !== "string") throw Error("User data must be a string.");
			setUserData(target, { text: value });
			return true;
		}
		if (key === "color") {
			setUserData(target, { color: inputColor(value, "rgba") });
			return true;
		}
		if (key === "properties") {
			replaceProperties(propertiesRef(target), value);
			return true;
		}
		if (kind === "Sprite" && key === "selection") {
			putSelection(selectionRef(o.docId), value ? copy$1(selection(value)) : empty());
			return true;
		}
		if (kind === "Tag") {
			const d = doc(o.docId);
			let patch;
			if (key === "name") patch = { name: value };
			if (key === "aniDir") patch = { direction: directions[integer$1(value, 0, 3)] };
			if (key === "repeats") patch = {
				repeat: integer$1(value, 0, 65535),
				loop: value === 0
			};
			if (key === "fromFrame" || key === "toFrame") {
				const indices = o.value.frameIds.map((id) => d.frames.findIndex((f) => f.id === id));
				const from = key === "fromFrame" ? frameAt(o.docId, value) : Math.min(...indices), to = key === "toFrame" ? frameAt(o.docId, value) : Math.max(...indices);
				if (from > to) throw Error("Tag start must not be after its end.");
				patch = { frameIds: d.frames.slice(from, to + 1).map((f) => f.id) };
			}
			if (patch) {
				mutate(o.docId, {
					type: "clip.update",
					clipId: o.value.id,
					patch
				});
				return true;
			}
		}
		if (kind === "Slice") {
			if (key === "name") {
				mutate(o.docId, {
					type: "slice.update",
					sliceId: o.value.id,
					patch: { name: value }
				});
				return true;
			}
			if ([
				"bounds",
				"pivot",
				"center"
			].includes(key)) {
				sliceKeySet(target, key, value);
				return true;
			}
		}
		return false;
	}
	function method(target, name, args) {
		const kind = target.__kind;
		if (kind === "Properties") {
			if (name === "entries") return {
				__value: "PlainData",
				value: copy$1(propertyMap(target))
			};
			if (name === "namespace") {
				const p = getRef(target, kind), key = args[0];
				if (typeof key !== "string" || key.length > 1024 || key && !/^[^/]+\/[^/]+$/.test(key)) throw Error("Extension property namespace must be publisher/name or empty.");
				const result = propertiesRef(p.owner, 0, key);
				if (args[1] != null) replaceProperties(result, args[1]);
				return result;
			}
		}
		if (kind === "Selection") {
			if (name === "contains") {
				const point = typeof args[0] === "object" ? args[0] : {
					x: args[0],
					y: args[1]
				};
				return selected(selection(target), integer$1(point.x, -65535, 65535), integer$1(point.y, -65535, 65535));
			}
			if (name === "deselect") {
				putSelection(target, empty());
				return null;
			}
			if (name === "selectAll") {
				const r = getRef(target, kind);
				if (!r.docId) throw Error("selectAll requires a sprite selection.");
				const d = doc(r.docId);
				putSelection(target, rectangleSelection({
					x: 0,
					y: 0,
					width: d.width,
					height: d.height
				}));
				return null;
			}
			const other = args[0]?.__kind === "Selection" ? copy$1(selection(args[0])) : rectangleSelection(args[0]);
			if (name === "select") {
				if (args[0]?.__kind) throw Error("Selection:select requires a Rectangle. Use add for another selection.");
				putSelection(target, other);
				return null;
			}
			if ([
				"add",
				"subtract",
				"intersect"
			].includes(name)) {
				putSelection(target, combine(selection(target), other, name === "add" ? (a, b) => a || b : name === "subtract" ? (a, b) => a && !b : (a, b) => a && b));
				return null;
			}
		}
		if (kind === "Range") {
			const r = getRef(target, kind), values = rangeValues(r.docId);
			if (name === "clear") {
				ranges.delete(r.docId);
				return null;
			}
			if (name === "containsColor") return values.state.colors.includes(args[0]);
			if (name === "contains") {
				const value = args[0];
				if (value?.__kind === "Layer") {
					const l = layer(value);
					return l.docId === r.docId && values.layers.includes(l.layerId);
				}
				if (value?.__kind === "Frame") {
					const f = getRef(value, "Frame");
					return f.docId === r.docId && values.frames.includes(f.index);
				}
				if (value?.__kind === "Cel") return values.cels.some((c) => c.id === value.id);
				if (value?.__kind === "Slice") {
					const s = object(value);
					return s.docId === r.docId && values.state.slices.includes(s.value.id);
				}
				throw Error("Unsupported Range:contains value.");
			}
		}
		if (kind === "Sprite") {
			const o = object(target), d = doc(o.docId);
			if (name === "newTag") {
				const from = frameAt(o.docId, args[0], 0), to = frameAt(o.docId, args[1], 0);
				if (from > to) throw Error("Tag start must not be after end.");
				let id;
				do
					id = `lua-tag-${++serial}`;
				while (d.clips.some((v) => v.id === id));
				mutate(o.docId, {
					type: "clip.add",
					clip: {
						id,
						name: "Tag",
						frameIds: d.frames.slice(from, to + 1).map((f) => f.id),
						direction: "forward",
						repeat: 0,
						loop: true,
						color: "#000000ff",
						userData: { color: "#000000ff" }
					}
				});
				return tagRef(o.docId, id);
			}
			if (name === "newSlice") {
				let id;
				do
					id = `lua-slice-${++serial}`;
				while (d.slices.some((v) => v.id === id));
				const keys = args[0] == null ? [] : [{
					frameId: d.frames[0].id,
					...rect(args[0])
				}];
				mutate(o.docId, {
					type: "slice.add",
					slice: {
						id,
						name: "Slice",
						keys
					}
				});
				return sliceRef(o.docId, id);
			}
			if (name === "deleteTag" || name === "deleteSlice") {
				const isTag = name === "deleteTag", kind = isTag ? "Tag" : "Slice", values = isTag ? d.clips : d.slices;
				let value;
				if (typeof args[0] === "string") value = values.find((v) => v.name === args[0]);
				else {
					if (args[0]?.__kind !== kind) throw Error(`Expected a ${kind}.`);
					const other = object(args[0]);
					if (other.docId !== o.docId) throw Error(`${kind} belongs to another sprite.`);
					value = other.value;
				}
				if (!value) throw Error(`${kind} not found.`);
				mutate(o.docId, {
					type: isTag ? "clip.remove" : "slice.remove",
					[isTag ? "clipId" : "sliceId"]: value.id
				});
				return null;
			}
		}
		return no;
	}
	function selectionCommand(name) {
		const { docId, layerId } = getActive();
		if (!docId) throw Error("No active sprite.");
		const target = selectionRef(docId);
		if (name === "SelectAll") {
			method(target, "selectAll", []);
			return true;
		}
		if (name === "Deselect") {
			method(target, "deselect", []);
			return true;
		}
		if (name === "InvertMask") {
			const d = doc(docId);
			putSelection(target, combine(rectangleSelection({
				x: 0,
				y: 0,
				width: d.width,
				height: d.height
			}), selection(target), (a, b) => a && !b));
			return true;
		}
		if (name === "Clear") {
			const { frames, layers } = rangeValues(docId), mask = canvasMask(docId);
			for (const index of frames) for (const lid of layers.length ? layers : [layerId]) mutate(docId, {
				type: mask ? "selection.clear" : "cel.clear",
				frameId: doc(docId).frames[index].id,
				layerId: lid,
				...mask ? { selection: mask } : {}
			});
			return true;
		}
		return false;
	}
	return {
		get,
		set,
		method,
		canvasMask,
		selectionCommand,
		track,
		appGet(key) {
			const { docId } = getActive();
			return key === "range" ? docId ? ref("Range", { docId }, `range:${docId}`) : null : no;
		},
		selectionNew(value) {
			return ref("Selection", { selection: value ? rectangleSelection(value) : empty() });
		},
		initialize(docId, mask, range) {
			if (mask) {
				const d = doc(docId), value = {
					x: 0,
					y: 0,
					width: d.width,
					height: d.height,
					mask: Uint8Array.from(mask)
				};
				selections.set(docId, combine(value, empty(), (a) => a));
			}
			if (range) ranges.set(docId, {
				type: range.type,
				layers: [...range.layerIds],
				frames: range.frameIds.map((id) => doc(docId).frames.findIndex((frame) => frame.id === id)),
				colors: [...range.colors],
				slices: [...range.sliceIds]
			});
		},
		snapshot() {
			return {
				selections: copy$1(selections),
				ranges: copy$1(ranges)
			};
		},
		restore(state) {
			selections = state.selections;
			ranges = state.ranges;
		},
		finish() {
			const { docId } = getActive();
			if (!docId) return {
				selection: null,
				range: null
			};
			const { layers, frames, state } = rangeValues(docId);
			return {
				selection: canvasMask(docId),
				range: {
					type: state.type,
					layerIds: layers,
					frameIds: frames.map((index) => doc(docId).frames[index].id),
					colors: [...state.colors],
					sliceIds: [...state.slices]
				}
			};
		}
	};
}
//#endregion
//#region app/lua-session.mjs
const LUA_LIMITS = Object.freeze({
	sourceBytes: 256 * 1024,
	pixels: 1048576,
	calls: 25e4,
	commands: 4096,
	outputBytes: 32 * 1024 * 1024,
	memoryBytes: 32 * 1024 * 1024,
	timeoutMs: 3e3,
	instructions: 1e8
});
const copy = (value) => structuredClone(value);
const integer = (value, min, max, label = "Value") => {
	if (!Number.isSafeInteger(value) || value < min || value > max) throw Error(`${label} must be an integer from ${min} to ${max}.`);
	return value;
};
const packed = (bytes) => bytes[0] + bytes[1] * 256 + bytes[2] * 65536 + bytes[3] * 16777216 >>> 0;
const unpacked = (value) => {
	integer(value, 0, 4294967295, "RGBA pixel");
	return [
		value & 255,
		value >>> 8 & 255,
		value >>> 16 & 255,
		value >>> 24
	];
};
const hex = (bytes) => "#" + bytes.map((v) => integer(v, 0, 255, "Color channel").toString(16).padStart(2, "0")).join("");
const modeName = (value) => ({
	0: "rgba",
	1: "grayscale",
	2: "indexed",
	rgba: "rgba",
	rgb: "rgba",
	grayscale: "grayscale",
	gray: "grayscale",
	indexed: "indexed"
})[value] || (() => {
	throw Error("Unsupported color mode.");
})();
const modeNumber = (value) => ({
	rgba: 0,
	grayscale: 1,
	indexed: 2
})[value];
const reference = (kind, id) => ({
	__kind: kind,
	id
});
const raster = (layer) => layer.type === "image" || layer.type === "reference";
/** Isolated state: every document mutation is replayable through the shared engine. */
function createLuaSession({ document, activeFrameId, activeLayerId, selection, range, fgColor = [
	0,
	0,
	0,
	255
], bgColor = [
	255,
	255,
	255,
	255
], params = {} } = {}, { colorManager } = {}) {
	let colors = {
		fgColor: validateLuaColor(fgColor, "Initial Lua foreground color"),
		bgColor: validateLuaColor(bgColor, "Initial Lua background color")
	};
	let serial = 0, calls = 0, commandCount = 0, pixelsAllocated = 0, bytesLogged = 0;
	const tileImages = /* @__PURE__ */ new Map(), tileImageTokens = /* @__PURE__ */ new Map(), retiredTileImages = /* @__PURE__ */ new Map();
	const documents = /* @__PURE__ */ new Map(), seeds = /* @__PURE__ */ new Map(), refs = /* @__PURE__ */ new Map(), attached = /* @__PURE__ */ new Map(), logs = [], transactions = [], prints = [];
	const initial = document ? normalizeDocument(copy(document)) : null;
	if (initial) documents.set(initial.id, initial);
	let active = initial?.id ?? null, frameIndex = initial ? Math.max(0, initial.frames.findIndex((f) => f.id === activeFrameId)) : 0;
	let layerId = initial ? initial.layers.find((l) => l.id === activeLayerId)?.id ?? initial.layers.find(raster)?.id ?? initial.layers[0].id : null;
	const activeRef = () => active ? spriteRef(active) : null;
	const doc = (id = active) => {
		const d = documents.get(id);
		if (!d) throw Error("This sprite is no longer available.");
		return d;
	};
	const ref = (kind, data, key) => {
		const id = key ?? `lua-${++serial}`;
		if (!refs.has(id)) refs.set(id, {
			kind,
			...data
		});
		return reference(kind, id);
	};
	const getRef = (value, kind) => {
		const r = refs.get(value?.id);
		if (r?.profileRetired) throw Error("This Image was deleted by pixel or color-space conversion. Request the current cel image again.");
		if (!r || r.kind !== kind || value.__kind !== kind) throw Error(`Expected a valid ${kind}.`);
		return r;
	};
	const spriteRef = (id) => ref("Sprite", { docId: id }, `sprite:${id}`);
	const layerRef = (docId, lid) => ref("Layer", {
		docId,
		layerId: lid
	}, `layer:${docId}:${lid}`);
	const frameRef = (docId, index) => ref("Frame", {
		docId,
		index
	}, `frame:${docId}:${index}`);
	const frame = (value) => {
		const r = getRef(value, "Frame");
		const f = doc(r.docId).frames[r.index];
		if (!f) throw Error("Frame no longer exists.");
		return {
			...r,
			value: f
		};
	};
	const layer = (value) => {
		const r = getRef(value, "Layer");
		const l = doc(r.docId).layers.find((l) => l.id === r.layerId);
		if (!l) throw Error("Layer no longer exists.");
		return {
			...r,
			value: l
		};
	};
	function frameAt(docId, value, fallback = frameIndex) {
		return typeof value === "number" ? integer(value, 1, doc(docId).frames.length, "Frame number") - 1 : value ? frame(value).docId === docId ? frame(value).index : (() => {
			throw Error("Frame belongs to another sprite.");
		})() : fallback;
	}
	function celRef(docId, lid, fid) {
		if (!doc(docId).frames.find((f) => f.id === fid)?.cels[lid]) return null;
		return ref("Cel", {
			docId,
			layerId: lid,
			frameId: fid
		}, `cel:${docId}:${lid}:${fid}`);
	}
	function cel(value) {
		const r = getRef(value, "Cel");
		const c = doc(r.docId).frames.find((f) => f.id === r.frameId)?.cels[r.layerId];
		if (!c) throw Error("Cel no longer exists.");
		return {
			...r,
			value: c
		};
	}
	function reservePixels(count) {
		pixelsAllocated += count;
		if (pixelsAllocated > LUA_LIMITS.pixels * 4) throw Error("Lua image allocation budget exceeded.");
	}
	const rasterLifetime = createLuaRasterLifetime({
		refs,
		attached,
		doc
	});
	function imageRef(docId, imageId) {
		const { key, epoch } = rasterLifetime.identity(docId, imageId);
		if (!refs.has(key)) {
			const image = doc(docId).images[imageId];
			if (!image || image.tilemap) throw Error("Lua raster Image does not support tilemaps.");
			reservePixels(image.pixels.length);
			refs.set(key, {
				kind: "Image",
				docId,
				imageId,
				...copy(image),
				profileImageEpoch: epoch,
				colorMode: doc(docId).colorMode,
				dirty: false
			});
			attached.set(key, refs.get(key));
		}
		return reference("Image", key);
	}
	function tileSource(docId, tilesetId, index) {
		const d = doc(docId), ts = d.tilesets.find((ts) => ts.id === tilesetId);
		if (!ts) throw Error("Tileset no longer exists.");
		if (ts.tileWidth * ts.tileHeight > LUA_LIMITS.pixels) throw Error("Lua tile image pixel budget exceeded.");
		const slots = tilesetSlots(d, ts);
		if (index >= slots.count) throw Error("Tile no longer exists.");
		const tile = slots.entries.get(index);
		if (tile) return getTile(d, tilesetId, tile.id);
		if (ts.flags & 1 || slots.native) throw Error("External or missing tile artwork must be embedded before access.");
		return {
			width: ts.tileWidth,
			height: ts.tileHeight,
			pixels: Array(ts.tileWidth * ts.tileHeight).fill(null),
			virtualTile: true
		};
	}
	function tileObject(docId, tilesetId, tileIndex) {
		if (tileIndex === 0) return "@zero";
		const d = doc(docId), ts = d.tilesets.find((ts) => ts.id === tilesetId);
		return ts && tilesetSlots(d, ts).entries.get(tileIndex)?.id;
	}
	const tileTokenKey = (docId, tilesetId, objectId) => JSON.stringify([
		docId,
		tilesetId,
		objectId
	]);
	function forgetTileImage(key, value) {
		if (transactions.length && value.tilesetId) retiredTileImages.set(key, value);
		attached.delete(key);
		refs.delete(key);
	}
	function tileImageRef(docId, tilesetId, tileIndex) {
		const owner = JSON.stringify([
			docId,
			tilesetId,
			tileIndex
		]);
		let key = tileImages.get(owner);
		if (!key || !refs.has(key)) {
			const source = tileSource(docId, tilesetId, tileIndex);
			reservePixels(source.width * source.height);
			const tileObjectId = tileObject(docId, tilesetId, tileIndex);
			key = ref("Image", {
				docId,
				tilesetId,
				tileIndex,
				tileObjectId,
				tileImageToken: tileImageTokens.get(tileTokenKey(docId, tilesetId, tileObjectId)) ?? 0,
				...source,
				colorMode: doc(docId).colorMode,
				dirty: false
			}).id;
			tileImages.set(owner, key);
			attached.set(key, refs.get(key));
		}
		return reference("Image", key);
	}
	function retireTileImage(docId, tilesetId, tileIndex) {
		const owner = JSON.stringify([
			docId,
			tilesetId,
			tileIndex
		]), key = tileImages.get(owner);
		tileImageTokens.set(tileTokenKey(docId, tilesetId, tileObject(docId, tilesetId, tileIndex)), ++serial);
		if (key) {
			const value = attached.get(key);
			if (value) forgetTileImage(key, value);
			tileImages.delete(owner);
		}
	}
	function moveTileImages(docId, tilesetId, tileIndex, insert) {
		const moving = [...attached].filter(([, value]) => value.docId === docId && value.tilesetId === tilesetId);
		for (const [, value] of moving) tileImages.delete(JSON.stringify([
			docId,
			tilesetId,
			value.tileIndex
		]));
		for (const [key, value] of moving) {
			if (!insert && value.tileIndex === tileIndex) {
				forgetTileImage(key, value);
				continue;
			}
			if (value.tileIndex >= tileIndex) value.tileIndex += insert ? 1 : -1;
			tileImages.set(JSON.stringify([
				docId,
				tilesetId,
				value.tileIndex
			]), key);
		}
	}
	function snapshotTileImages() {
		return new Map(tileImageTokens);
	}
	function restoreTileImages(snapshot) {
		const candidates = new Map([...retiredTileImages, ...[...attached].filter(([, value]) => value.tilesetId)]);
		for (const [key, value] of attached) if (value.tilesetId) {
			attached.delete(key);
			refs.delete(key);
		}
		tileImages.clear();
		tileImageTokens.clear();
		for (const [key, value] of snapshot) tileImageTokens.set(key, value);
		for (const [key, value] of candidates) {
			const d = documents.get(value.docId), ts = d?.tilesets.find((ts) => ts.id === value.tilesetId);
			if (!ts) continue;
			const slots = tilesetSlots(d, ts), index = value.tileObjectId === "@zero" ? slots.count ? 0 : -1 : [...slots.entries].find(([, tile]) => tile.id === value.tileObjectId)?.[0] ?? -1;
			if (index < 0 || value.tileImageToken !== (tileImageTokens.get(tileTokenKey(value.docId, value.tilesetId, value.tileObjectId)) ?? 0)) continue;
			value.tileIndex = index;
			refs.set(key, value);
			attached.set(key, value);
			tileImages.set(JSON.stringify([
				value.docId,
				value.tilesetId,
				index
			]), key);
			retiredTileImages.delete(key);
		}
		if (!transactions.length) retiredTileImages.clear();
	}
	function image(value) {
		return getRef(value, "Image");
	}
	function invalidateImages(docId) {
		for (const [key, item] of attached) if (item.docId === docId) {
			let current;
			try {
				current = item.tilesetId ? tileSource(docId, item.tilesetId, item.tileIndex) : doc(docId).images[item.imageId];
			} catch {
				current = null;
			}
			if (current) {
				item.width = current.width;
				item.height = current.height;
				item.pixels = [...current.pixels];
				item.colorMode = doc(docId).colorMode;
				item.virtualTile = !!current.virtualTile;
				item.dirty = false;
			} else forgetTileImage(key, item);
		}
	}
	function apply(docId, command, label = command.type) {
		if (++commandCount > LUA_LIMITS.commands) throw Error("Lua command budget exceeded.");
		bytesLogged += JSON.stringify(command).length;
		if (bytesLogged > LUA_LIMITS.outputBytes) throw Error("Lua command output budget exceeded.");
		const next = applyCommand(doc(docId), command);
		if (Object.values(next.images).reduce((sum, i) => sum + i.width * i.height, 0) > LUA_LIMITS.pixels) throw Error("Lua sprite pixel budget exceeded.");
		documents.set(docId, next);
		authoring.track(next);
		colorCommands.track(next, command);
		(transactions.at(-1)?.entries ?? logs).push({
			documentId: docId,
			label,
			commands: [copy(command)]
		});
		return next;
	}
	function flush() {
		for (const value of attached.values()) if (value.dirty) {
			if (value.tilesetId) {
				apply(value.docId, {
					type: "tileset.tileImage",
					tilesetId: value.tilesetId,
					tileIndex: value.tileIndex,
					width: value.width,
					height: value.height,
					pixels: value.pixels
				}, "Edit tile image pixels");
				value.dirty = false;
				continue;
			}
			const d = doc(value.docId);
			let target;
			for (const f of d.frames) for (const [lid, c] of Object.entries(f.cels)) if (c.imageId === value.imageId) {
				target = {
					frameId: f.id,
					layerId: lid,
					...c
				};
				break;
			}
			if (!target) throw Error("The edited image is no longer attached to this sprite.");
			apply(value.docId, {
				type: "cel.set",
				frameId: target.frameId,
				layerId: target.layerId,
				width: value.width,
				height: value.height,
				pixels: value.pixels,
				x: target.x,
				y: target.y,
				opacity: target.opacity,
				editLinked: true
			}, "Edit image pixels");
			value.dirty = false;
		}
	}
	function mutate(docId, command) {
		flush();
		const result = apply(docId, command);
		if (["tileset.tileInsert", "tileset.tileRemove"].includes(command.type)) moveTileImages(docId, command.tilesetId, command.tileIndex ?? result.tilesets.find((ts) => ts.id === command.tilesetId).tileCount - 1, command.type === "tileset.tileInsert");
		invalidateImages(docId);
		if (command.type === "document.colorProfile") imageSpecs.profileAssigned(docId);
		return result;
	}
	function inputColor(value, mode = "rgba", palette = doc().palette) {
		if (value && typeof value === "object") {
			if (value.index !== void 0 && mode === "indexed") return integer(value.index, 0, Math.min(255, palette.length - 1), "Palette index");
			value = hex([
				value.red ?? value.r ?? 0,
				value.green ?? value.g ?? 0,
				value.blue ?? value.b ?? 0,
				value.alpha ?? value.a ?? 255
			]);
		}
		if (typeof value === "string") return normalizeColor(value);
		if (typeof value === "number") {
			if (mode === "indexed") return integer(value, 0, Math.min(255, palette.length - 1), "Palette index");
			if (mode === "grayscale") {
				integer(value, 0, 65535, "Gray pixel");
				return hex([
					value & 255,
					value & 255,
					value & 255,
					value >>> 8
				]);
			}
			return hex(unpacked(value));
		}
		if (value == null) return null;
		throw Error("Expected Color or packed pixel value.");
	}
	function imagePixel(value, pixel) {
		const mode = value.colorMode;
		const p = inputColor(pixel, mode, value.docId ? { length: Math.max(doc(value.docId).palette.length, ...doc(value.docId).frames.map((frame) => frame.palette?.length ?? 0)) } : Array(256).fill("#000000ff"));
		if (mode === "indexed" && typeof p !== "number" && p !== null) throw Error("Indexed Image pixels must be palette indices or Color{index=...}.");
		if (mode === "grayscale" && p !== null && typeof p === "string") {
			const channels = pixelRGBA({}, p);
			if (channels[0] !== channels[1] || channels[1] !== channels[2]) throw Error("Gray Image colors must have equal RGB channels.");
		}
		return p;
	}
	function outputPixel(value, p) {
		if (value.colorMode === "indexed") return p ?? (value.docId ? doc(value.docId).metadata?.aseprite?.transparentIndex ?? 0 : value.transparentColor ?? 0);
		const c = pixelRGBA({}, p);
		return value.colorMode === "grayscale" ? c[0] + c[3] * 256 : packed(c);
	}
	function colorValue(value) {
		const [red, green, blue, alpha] = pixelRGBA({}, value);
		return {
			__value: "Color",
			red,
			green,
			blue,
			alpha
		};
	}
	function palette(value) {
		return colorCommands.palette(value);
	}
	function imageNew(options) {
		if (options.source?.__kind === "ImageSpec") {
			if (options.rectangle != null) throw Error("Image(spec) accepts one specification.");
			const spec = imageSpecs.options(options.source);
			reservePixels(spec.width * spec.height);
			const value = {
				...spec,
				specProfile: spec.profile,
				version: 0
			};
			delete value.profile;
			const pixel = imagePixel(value, spec.transparentColor);
			return ref("Image", {
				...value,
				pixels: Array(spec.width * spec.height).fill(pixel)
			});
		}
		if (options.source?.__kind === "Image") {
			const original = image(options.source);
			return images.crop(original, options.rectangle ?? {
				x: 0,
				y: 0,
				width: original.width,
				height: original.height
			});
		}
		if (options.source?.__kind === "Sprite") {
			if (options.rectangle != null) throw Error("Image(sprite, rectangle) is not supported; crop a rendered Image instead.");
			return images.spriteImage(options.source);
		}
		if (Object.keys(options).some((key) => ![
			"width",
			"height",
			"colorMode",
			"transparentColor"
		].includes(key))) throw Error("Unsupported Image specification field.");
		const width = integer(options.width, 1, 2048, "Image width"), height = integer(options.height, 1, 2048, "Image height");
		if (width * height > LUA_LIMITS.pixels) throw Error("Lua image pixel budget exceeded.");
		reservePixels(width * height);
		if (modeName(options.colorMode ?? 0) !== "indexed" && (options.transparentColor ?? 0) !== 0) throw Error("Custom mask colors are only supported for indexed Images.");
		return ref("Image", {
			width,
			height,
			colorMode: modeName(options.colorMode ?? 0),
			transparentColor: integer(options.transparentColor ?? 0, 0, 255, "Image transparent color"),
			pixels: Array(width * height).fill(null),
			version: 0
		});
	}
	const images = createLuaImageApi({
		doc,
		image,
		ref,
		getRef,
		frameAt,
		celRef,
		reservePixels,
		flush,
		imagePixel,
		outputPixel,
		limits: LUA_LIMITS,
		specMask: (value) => imageSpecs.mask(value),
		renderedProfile: (sprite) => imageSpecs.renderedProfile(sprite),
		resized: (value) => imageSpecs.resized(value)
	});
	const colorSpaces = createLuaColorSpaces({
		ref,
		getRef,
		doc,
		flush,
		mutate,
		retireRasterImages: rasterLifetime.retire,
		colorManager
	});
	const imageSpecs = createLuaImageSpecs({
		ref,
		getRef,
		image,
		doc,
		colorSpaces,
		limits: LUA_LIMITS
	});
	const tiles = createLuaTilesets({
		doc,
		ref,
		getRef,
		mutate,
		tileImageRef,
		image,
		retireTileImage,
		reservePixels,
		limits: LUA_LIMITS,
		newId: (prefix) => `lua-${prefix}-${++serial}`,
		layerRef,
		getActiveLayer: () => layerId,
		setActiveLayer: (value) => {
			layerId = value;
		}
	});
	const authoring = createLuaAuthoring({
		tileObject: tiles.object,
		doc,
		mutate,
		ref,
		getRef,
		frameAt,
		frameRef,
		layerRef,
		celRef,
		imageRef,
		spriteRef,
		layer,
		cel,
		inputColor,
		colorValue,
		getActive: () => ({
			docId: active,
			frameIndex,
			layerId
		}),
		limits: LUA_LIMITS
	});
	const colorCommands = createLuaColorCommands({
		doc,
		ref,
		getRef,
		mutate,
		flush,
		frameRef,
		getActive: () => ({
			docId: active,
			frameIndex
		}),
		getRangeColors: () => authoring.finish().range?.colors ?? [],
		retireImages: (docId) => {
			rasterLifetime.retire(docId);
			for (const value of [...attached.values()]) if (value.docId === docId && value.tilesetId) retireTileImage(docId, value.tilesetId, value.tileIndex);
		}
	});
	if (initial) {
		authoring.track(initial);
		authoring.initialize(initial.id, selection, range);
	}
	function get(target, key) {
		const specValue = imageSpecs.get(target, key);
		if (specValue !== LUA_SPEC_NOT_HANDLED) return specValue;
		const profileValue = colorSpaces.get(target, key);
		if (profileValue !== LUA_COLOR_SPACE_NOT_HANDLED) return profileValue;
		const tileValue = tiles.get(target, key);
		if (tileValue !== LUA_TILE_NOT_HANDLED) return tileValue;
		const imageValue = images.get(target, key);
		if (imageValue !== LUA_IMAGE_NOT_HANDLED) return imageValue;
		const extra = authoring.get(target, key);
		if (extra !== LUA_NOT_HANDLED) return extra;
		const kind = target.__kind;
		if (kind === "Sprite") {
			const d = doc(getRef(target, kind).docId);
			const values = {
				id: d.id,
				width: d.width,
				height: d.height,
				filename: d.name,
				colorMode: modeNumber(d.colorMode),
				bounds: {
					__value: "Rectangle",
					x: 0,
					y: 0,
					width: d.width,
					height: d.height
				},
				isValid: true,
				isModified: d !== initial,
				hasAssociatedFile: false,
				transparentColor: d.metadata?.aseprite?.transparentIndex ?? 0
			};
			if (key in values) return values[key];
			if (key === "frames") return d.frames.map((_, i) => frameRef(d.id, i));
			if (key === "layers") return d.layers.filter((l) => !l.parentId).map((l) => layerRef(d.id, l.id));
			if (key === "palettes") return colorCommands.list(d.id);
			if (key === "cels") return d.frames.flatMap((f) => d.layers.flatMap((l) => f.cels[l.id] ? [celRef(d.id, l.id, f.id)] : []));
		} else if (kind === "Layer") {
			const l = layer(target), d = doc(l.docId), v = l.value;
			const values = {
				name: v.name,
				isVisible: v.visible,
				isEditable: !v.locked,
				opacity: Math.round(v.opacity * 255),
				isImage: raster(v),
				isGroup: v.type === "group",
				isTilemap: v.type === "tilemap",
				isReference: v.type === "reference",
				isBackground: Boolean(v.asepriteFlags & 8),
				blendMode: v.blendMode,
				stackIndex: d.layers.filter((o) => o.parentId === v.parentId).findIndex((o) => o.id === v.id) + 1,
				sprite: spriteRef(d.id),
				parent: v.parentId ? layerRef(d.id, v.parentId) : spriteRef(d.id)
			};
			if (key in values) return values[key];
			if (key === "layers") return d.layers.filter((o) => o.parentId === v.id).map((o) => layerRef(d.id, o.id));
			if (key === "cels") return d.frames.flatMap((f) => f.cels[v.id] ? [celRef(d.id, v.id, f.id)] : []);
		} else if (kind === "Frame") {
			const f = frame(target), d = doc(f.docId);
			const values = {
				frameNumber: f.index + 1,
				duration: f.value.durationMs / 1e3,
				sprite: spriteRef(f.docId),
				previous: f.index ? frameRef(d.id, f.index - 1) : null,
				next: f.index + 1 < d.frames.length ? frameRef(d.id, f.index + 1) : null
			};
			if (key in values) return values[key];
		} else if (kind === "Cel") {
			const c = cel(target), d = doc(c.docId), i = d.images[c.value.imageId];
			if (key === "image") return imageRef(d.id, c.value.imageId);
			const tileset = i.tilemap ? d.tilesets.find((t) => t.id === d.layers.find((l) => l.id === c.layerId)?.tilesetId) : null;
			const values = {
				sprite: spriteRef(d.id),
				layer: layerRef(d.id, c.layerId),
				frame: frameRef(d.id, d.frames.findIndex((f) => f.id === c.frameId)),
				frameNumber: d.frames.findIndex((f) => f.id === c.frameId) + 1,
				position: {
					__value: "Point",
					x: c.value.x,
					y: c.value.y
				},
				bounds: {
					__value: "Rectangle",
					x: c.value.x,
					y: c.value.y,
					width: i.width * (tileset?.tileWidth ?? 1),
					height: i.height * (tileset?.tileHeight ?? 1)
				},
				opacity: Math.round(c.value.opacity * 255),
				zIndex: c.value.zIndex ?? 0
			};
			if (key in values) return values[key];
		} else if (kind === "Image") {
			const i = image(target), values = {
				width: i.width,
				height: i.height,
				id: target.id,
				version: i.version ?? 0,
				colorMode: modeNumber(i.colorMode),
				bounds: {
					__value: "Rectangle",
					x: 0,
					y: 0,
					width: i.width,
					height: i.height
				},
				bytesPerPixel: i.colorMode === "rgba" ? 4 : i.colorMode === "grayscale" ? 2 : 1
			};
			if (key in values) return values[key];
		} else if (kind === "Palette") {
			if (key === "size") return palette(target).colors.length;
			if (key === "frame") return colorCommands.frame(target);
		}
		throw Error(`Unsupported ${kind}.${key}. See PixelWall Lua compatibility documentation.`);
	}
	function set(target, key, value) {
		const specValue = imageSpecs.set(target, key, value);
		if (specValue !== LUA_SPEC_NOT_HANDLED) return specValue;
		const profileValue = colorSpaces.set(target, key, value);
		if (profileValue !== LUA_COLOR_SPACE_NOT_HANDLED) return profileValue;
		if (tiles.set(target, key, value)) return;
		if (authoring.set(target, key, value)) return;
		if (target.__kind === "Sprite" && key === "transparentColor") {
			const d = doc(getRef(target, "Sprite").docId);
			if (d.colorMode !== "indexed") throw Error("transparentColor requires an indexed sprite.");
			mutate(d.id, {
				type: "document.update",
				patch: { metadata: {
					...d.metadata,
					aseprite: {
						...d.metadata?.aseprite,
						transparentIndex: integer(value, 0, d.palette.length - 1)
					}
				} }
			});
			return;
		}
		if (target.__kind === "Sprite" && key === "filename") return mutate(getRef(target, "Sprite").docId, {
			type: "document.update",
			patch: { name: String(value) }
		}).name;
		if (target.__kind === "Layer") {
			const l = layer(target), fields = {
				name: "name",
				isVisible: "visible",
				isEditable: "locked",
				opacity: "opacity",
				blendMode: "blendMode"
			};
			if (fields[key]) {
				mutate(l.docId, {
					type: "layer.update",
					layerId: l.layerId,
					patch: { [fields[key]]: key === "isEditable" ? !value : key === "opacity" ? integer(value, 0, 255) / 255 : value }
				});
				return;
			}
			if (key === "parent") {
				const parent = value.__kind === "Sprite" ? getRef(value, "Sprite") : layer(value);
				if (parent.docId !== l.docId) throw Error("Parent belongs to another sprite.");
				mutate(l.docId, {
					type: "layer.update",
					layerId: l.layerId,
					patch: { parentId: parent.layerId ?? null }
				});
				return;
			}
			if (key === "stackIndex") {
				const d = doc(l.docId), siblings = d.layers.filter((o) => o.parentId === l.value.parentId), sibling = siblings[integer(value, 1, siblings.length) - 1];
				mutate(l.docId, {
					type: "layer.reorder",
					layerId: l.layerId,
					index: d.layers.indexOf(sibling)
				});
				return;
			}
		}
		if (target.__kind === "Frame" && key === "duration") {
			const f = frame(target);
			if (typeof value !== "number" || !Number.isFinite(value)) throw Error("Frame duration must be seconds.");
			mutate(f.docId, {
				type: "frame.update",
				frameId: f.value.id,
				patch: { durationMs: integer(Math.round(value * 1e3), 1, 65535, "Frame duration in milliseconds") }
			});
			return;
		}
		if (target.__kind === "Cel") {
			const c = cel(target);
			if (key === "zIndex") {
				mutate(c.docId, {
					type: "cel.move",
					frameId: c.frameId,
					layerId: c.layerId,
					zIndex: integer(value, -2147483648, 2147483647, "Cel z-index")
				});
				return;
			}
			if (key === "position" || key === "opacity") {
				mutate(c.docId, {
					type: "cel.move",
					frameId: c.frameId,
					layerId: c.layerId,
					...key === "position" ? {
						x: value.x,
						y: value.y
					} : { opacity: integer(value, 0, 255) / 255 }
				});
				return;
			}
			if (key === "frame" || key === "frameNumber") {
				const index = frameAt(c.docId, value), fid = doc(c.docId).frames[index].id;
				if (fid === c.frameId) return;
				mutate(c.docId, {
					type: "cel.link",
					layerId: c.layerId,
					sourceFrameId: c.frameId,
					frameId: fid
				});
				mutate(c.docId, {
					type: "cel.clear",
					layerId: c.layerId,
					frameId: c.frameId
				});
				getRef(target, "Cel").frameId = fid;
				return;
			}
			if (key === "image") {
				const i = image(value);
				if (i.colorMode !== doc(c.docId).colorMode) throw Error("Image and sprite color modes must match.");
				mutate(c.docId, {
					type: "cel.set",
					frameId: c.frameId,
					layerId: c.layerId,
					width: i.width,
					height: i.height,
					pixels: [...i.pixels],
					x: c.value.x,
					y: c.value.y,
					opacity: c.value.opacity
				});
				imageSpecs.attachedCopy(c.docId, doc(c.docId).frames.find((f) => f.id === c.frameId).cels[c.layerId].imageId, i);
				return;
			}
		}
		throw Error(`Unsupported or read-only ${target.__kind}.${key}.`);
	}
	function method(target, name, args = []) {
		const profileValue = colorSpaces.method(target, name, args);
		if (profileValue !== LUA_COLOR_SPACE_NOT_HANDLED) return profileValue;
		const tileValue = tiles.method(target, name, args);
		if (tileValue !== LUA_TILE_NOT_HANDLED) return tileValue;
		const imageValue = images.method(target, name, args);
		if (imageValue !== LUA_IMAGE_NOT_HANDLED) return imageValue;
		const extra = authoring.method(target, name, args);
		if (extra !== LUA_NOT_HANDLED) return extra;
		if (target.__kind === "Sprite") {
			const docId = getRef(target, "Sprite").docId, d = doc(docId);
			if (name === "newLayer" || name === "newGroup") {
				let id;
				do
					id = `lua-layer-${++serial}`;
				while (d.layers.some((l) => l.id === id));
				mutate(docId, {
					type: "layer.add",
					layer: {
						id,
						type: name === "newGroup" ? "group" : "image"
					}
				});
				layerId = id;
				return layerRef(docId, id);
			}
			if (name === "deleteLayer") {
				const l = typeof args[0] === "string" ? d.layers.find((l) => l.name === args[0]) : layer(args[0]).value;
				if (!l) throw Error("Layer not found.");
				mutate(docId, {
					type: "layer.remove",
					layerId: l.id
				});
				if (layerId === l.id) layerId = doc(docId).layers[0].id;
				return;
			}
			if (name === "newFrame" || name === "newEmptyFrame") {
				const index = args[0] == null ? d.frames.length : typeof args[0] === "number" ? integer(args[0], 1, d.frames.length + (name === "newEmptyFrame" ? 1 : 0), "Frame number") - 1 : frameAt(docId, args[0]);
				const sourceIndex = Math.min(index, d.frames.length - 1), previousIds = new Set(d.frames.map((f) => f.id));
				mutate(docId, name === "newFrame" ? {
					type: "frame.duplicate",
					frameId: d.frames[sourceIndex].id
				} : {
					type: "frame.add",
					durationMs: d.frames[sourceIndex].durationMs
				});
				const added = doc(docId).frames.find((f) => !previousIds.has(f.id));
				if (index !== doc(docId).frames.findIndex((f) => f.id === added.id)) mutate(docId, {
					type: "frame.reorder",
					frameId: added.id,
					index
				});
				for (const clip of d.clips) {
					const current = doc(docId), indices = clip.frameIds.map((id) => current.frames.findIndex((f) => f.id === id)), previous = clip.frameIds.map((id) => d.frames.findIndex((f) => f.id === id));
					if (index > Math.min(...previous) && index <= Math.max(...previous) + 1) indices.push(index);
					const frameIds = current.frames.slice(Math.min(...indices), Math.max(...indices) + 1).map((f) => f.id);
					if (JSON.stringify(frameIds) !== JSON.stringify(clip.frameIds)) mutate(docId, {
						type: "clip.update",
						clipId: clip.id,
						patch: { frameIds }
					});
				}
				frameIndex = index;
				return frameRef(docId, index);
			}
			if (name === "deleteFrame") {
				const index = frameAt(docId, args[0]);
				mutate(docId, {
					type: "frame.remove",
					frameId: d.frames[index].id
				});
				frameIndex = Math.min(frameIndex, doc(docId).frames.length - 1);
				return;
			}
			if (name === "newCel") {
				const l = layer(args[0]);
				if (l.docId !== docId) throw Error("Layer belongs to another sprite.");
				const index = frameAt(docId, args[1]);
				const i = args[2] ? image(args[2]) : image(imageNew({
					width: d.width,
					height: d.height,
					colorMode: modeNumber(d.colorMode)
				}));
				if (i.colorMode !== d.colorMode) throw Error("Image and sprite color modes must match.");
				const position = args[3] ?? {
					x: 0,
					y: 0
				};
				mutate(docId, {
					type: "cel.set",
					layerId: l.layerId,
					frameId: d.frames[index].id,
					width: i.width,
					height: i.height,
					pixels: [...i.pixels],
					x: position.x,
					y: position.y
				});
				imageSpecs.attachedCopy(docId, doc(docId).frames[index].cels[l.layerId].imageId, i);
				return celRef(docId, l.layerId, d.frames[index].id);
			}
			if (name === "deleteCel") {
				const c = args[0]?.__kind === "Cel" ? cel(args[0]) : {
					layerId: layer(args[0]).layerId,
					frameId: d.frames[frameAt(docId, args[1])].id
				};
				mutate(docId, {
					type: "cel.clear",
					layerId: c.layerId,
					frameId: c.frameId
				});
				return;
			}
			if (name === "setPalette") {
				const p = palette(args[0]);
				colorCommands.setFirst(docId, p.colors);
				return;
			}
			if (name === "resize") {
				const value = typeof args[0] === "object" ? args[0] : {
					width: args[0],
					height: args[1]
				};
				mutate(docId, {
					type: "document.resize",
					width: value.width,
					height: value.height,
					mode: "scale"
				});
				return;
			}
		}
		if (target.__kind === "Layer" && name === "cel") {
			const l = layer(target);
			return celRef(l.docId, l.layerId, doc(l.docId).frames[frameAt(l.docId, args[0])].id);
		}
		if (target.__kind === "Image") {
			const i = image(target);
			if (name === "clone") return images.crop(i, {
				x: 0,
				y: 0,
				width: i.width,
				height: i.height
			});
			if (name === "getPixel") {
				const x = integer(args[0], -65535, 65535), y = integer(args[1], -65535, 65535);
				return outputPixel(i, x < 0 || y < 0 || x >= i.width || y >= i.height ? null : i.pixels[y * i.width + x]);
			}
			if (name === "drawPixel" || name === "putPixel") {
				images.editable(i);
				const x = integer(args[0], -65535, 65535), y = integer(args[1], -65535, 65535);
				if (x < 0 || y < 0 || x >= i.width || y >= i.height) return;
				i.pixels[y * i.width + x] = imagePixel(i, args[2]);
				i.dirty = !!i.docId;
				i.version = (i.version ?? 0) + 1;
				return;
			}
			if (name === "clear") {
				images.editable(i);
				i.pixels.fill(imagePixel(i, args[0] ?? images.mask(i)));
				i.dirty = !!i.docId;
				i.version = (i.version ?? 0) + 1;
				return;
			}
			if (name === "isEmpty") return i.pixels.every((p) => i.colorMode === "indexed" ? outputPixel(i, p) === images.mask(i) : pixelRGBA({}, p)[3] === 0);
			if (name === "isPlain") {
				const p = images.comparable(i, imagePixel(i, args[0]));
				return i.pixels.every((v) => images.comparable(i, v) === p);
			}
			if (name === "isEqual") {
				const other = image(args[0]);
				return i.width === other.width && i.height === other.height && i.colorMode === other.colorMode && i.pixels.every((p, n) => images.comparable(i, p) === images.comparable(other, other.pixels[n]));
			}
		}
		if (target.__kind === "Palette") {
			const colors = [...palette(target).colors];
			if (name === "getColor") return colorValue(colors[integer(args[0], 0, colors.length - 1, "Palette index")]);
			if (name === "setColor") colors[integer(args[0], 0, colors.length - 1, "Palette index")] = inputColor(args[1], "rgba", colors);
			else if (name === "resize") {
				const size = integer(args[0], 1, 256, "Palette size");
				colors.length = Math.min(colors.length, size);
				while (colors.length < size) colors.push("#000000ff");
			} else throw Error(`Unsupported Palette:${name}().`);
			colorCommands.set(target, colors);
			return;
		}
		throw Error(`Unsupported ${target.__kind}:${name}(). Files, exports, dialogs and extensions are unavailable in the Lua sandbox.`);
	}
	function appGet(key) {
		const extra = authoring.appGet(key);
		if (extra !== LUA_NOT_HANDLED) return extra;
		key = {
			activeSprite: "sprite",
			activeFrame: "frame",
			activeLayer: "layer",
			activeCel: "cel",
			activeImage: "image"
		}[key] ?? key;
		if (key === "sprite") return activeRef();
		if (key === "sprites") return [...documents.keys()].map(spriteRef);
		if (key === "params") return copy(params);
		if (key === "isUIAvailable") return false;
		if (key === "pixelwallApiVersion") return 1;
		if (!active) return null;
		if (key === "frame") return frameRef(active, frameIndex);
		if (key === "layer") return layerRef(active, layerId);
		if (key === "cel" || key === "image") {
			const c = celRef(active, layerId, doc().frames[frameIndex].id);
			return key === "image" ? c && imageRef(active, cel(c).value.imageId) : c;
		}
		throw Error(`Unsupported app.${key}.`);
	}
	function appSet(key, value) {
		key = {
			activeSprite: "sprite",
			activeFrame: "frame",
			activeLayer: "layer"
		}[key] ?? key;
		if (key === "sprite") {
			active = getRef(value, "Sprite").docId;
			frameIndex = 0;
			layerId = doc().layers[0].id;
			return;
		}
		if (key === "frame") {
			frameIndex = frameAt(active, value);
			return;
		}
		if (key === "layer") {
			const l = layer(value);
			if (l.docId !== active) throw Error("Layer belongs to another sprite.");
			layerId = l.layerId;
			return;
		}
		throw Error(`Unsupported app.${key} assignment.`);
	}
	function command(name, options = {}) {
		if (name === "ChangePixelFormat" || name === "ColorQuantization") return colorCommands.command(name, options);
		if ([
			"SelectAll",
			"Deselect",
			"InvertMask",
			"Clear"
		].includes(name)) {
			if (Object.keys(options).some((key) => key !== "ui")) throw Error(`Unsupported options for app.command.${name}.`);
			authoring.selectionCommand(name);
			return;
		}
		const d = doc(), fid = d.frames[frameIndex].id;
		const allowed = {
			NewLayer: [
				"name",
				"group",
				"tilemap",
				"gridBounds"
			],
			NewFrame: ["content"],
			NewEmptyFrame: [],
			RemoveFrame: [],
			RemoveLayer: [],
			MergeDownLayer: [],
			MergeDown: [],
			DuplicateLayer: ["name"],
			ClearCel: [],
			UnlinkCel: [],
			SpriteSize: [
				"width",
				"height",
				"method"
			],
			CanvasSize: ["width", "height"]
		}[name];
		if (allowed && Object.keys(options).some((key) => key !== "ui" && !allowed.includes(key))) throw Error(`Unsupported options for app.command.${name}.`);
		if (name === "SpriteSize" && options.method !== void 0 && !["nearest", "nearest-neighbor"].includes(options.method)) throw Error("Lua SpriteSize currently supports nearest-neighbor only.");
		if (name === "NewFrame" && options.content !== void 0 && !["empty", "current"].includes(options.content)) throw Error("Unsupported NewFrame content option.");
		if (name === "NewLayer" && options.tilemap) {
			tiles.newLayer(activeRef(), options);
			return true;
		}
		if (name === "NewLayer" && options.gridBounds != null) throw Error("gridBounds requires a tilemap layer.");
		if (name === "NewLayer") {
			const result = method(activeRef(), options.group ? "newGroup" : "newLayer");
			if (options.name) set(result, "name", options.name);
			return result;
		}
		if (name === "NewFrame") return method(activeRef(), options.content === "empty" ? "newEmptyFrame" : "newFrame");
		if (name === "NewEmptyFrame") return method(activeRef(), "newEmptyFrame");
		if (name === "RemoveFrame") return method(activeRef(), "deleteFrame", [frameIndex + 1]);
		if (name === "RemoveLayer") return method(activeRef(), "deleteLayer", [layerRef(active, layerId)]);
		if (name === "MergeDownLayer" || name === "MergeDown") {
			mutate(active, {
				type: "layer.mergeDown",
				layerId
			});
			layerId = doc().layers[0].id;
			return;
		}
		if (name === "DuplicateLayer") {
			const ids = new Set(d.layers.map((l) => l.id));
			mutate(active, {
				type: "layer.duplicate",
				layerId,
				name: options.name
			});
			layerId = doc().layers.find((l) => !ids.has(l.id)).id;
			return;
		}
		if (name === "ClearCel") return mutate(active, {
			type: "cel.clear",
			layerId,
			frameId: fid
		}), void 0;
		if (name === "UnlinkCel") return mutate(active, {
			type: "cel.unlink",
			layerId,
			frameId: fid
		}), void 0;
		if (name === "SpriteSize" || name === "CanvasSize") {
			mutate(active, {
				type: "document.resize",
				width: options.width ?? d.width,
				height: options.height ?? d.height,
				mode: name === "SpriteSize" ? "scale" : "canvas"
			});
			return;
		}
		throw Error(`Unsupported app.command.${name}. Saving and exporting must use PixelWall's normal entitlement-checked UI/API.`);
	}
	function performTool(options) {
		if (Object.keys(options).some((key) => ![
			"tool",
			"color",
			"points",
			"layer",
			"frame",
			"opacity",
			"tolerance",
			"contiguous"
		].includes(key))) throw Error("Unsupported app.useTool option.");
		if (options.layer && layer(options.layer).docId !== active) throw Error("Tool layer belongs to another sprite.");
		const d = doc(), points = options.points;
		if (!Array.isArray(points) || !points.length) throw Error("app.useTool requires points.");
		const base = {
			layerId: options.layer ? layer(options.layer).layerId : layerId,
			frameId: d.frames[frameAt(active, options.frame)].id,
			selection: authoring.canvasMask(active),
			color: inputColor(options.color ?? {
				red: 0,
				green: 0,
				blue: 0
			}),
			size: options.brush?.size ?? 1,
			opacity: (options.opacity ?? 255) / 255
		};
		const tool = options.tool ?? "pencil";
		let c;
		if (tool === "pencil" || tool === "eraser") c = {
			type: "draw.stroke",
			...base,
			points,
			...tool === "eraser" ? { color: null } : {}
		};
		else if (tool === "line") c = {
			type: "draw.line",
			...base,
			from: points[0],
			to: points.at(-1)
		};
		else if ([
			"rectangle",
			"filled_rectangle",
			"ellipse",
			"filled_ellipse"
		].includes(tool)) {
			const a = points[0], b = points.at(-1);
			c = {
				type: tool.includes("ellipse") ? "draw.ellipse" : "draw.rect",
				...base,
				x: Math.min(a.x, b.x),
				y: Math.min(a.y, b.y),
				width: Math.abs(a.x - b.x) + 1,
				height: Math.abs(a.y - b.y) + 1,
				filled: tool.startsWith("filled_")
			};
		} else if (tool === "paint_bucket") c = {
			type: "draw.fill",
			...base,
			...points[0],
			tolerance: options.tolerance ?? 0,
			contiguous: options.contiguous !== false
		};
		else throw Error(`Unsupported Lua tool: ${tool}.`);
		mutate(active, c);
	}
	function dispatch(op, data = {}) {
		if (++calls > LUA_LIMITS.calls) throw Error("Lua API call budget exceeded.");
		if (op === "colorSpaceNew") return colorSpaces.create(data);
		if (op === "colorSpaceEqual") return colorSpaces.equal(data.left, data.right);
		if (op === "colorLookup") {
			const entries = getFramePalette(doc(), doc().frames[frameIndex].id);
			return pixelRGBA({}, entries[integer(data.index, 0, Math.min(entries.length - 1, 255), "Palette index")]);
		}
		if (op === "colorFindIndex") {
			const entries = getFramePalette(doc(), doc().frames[frameIndex].id), channels = [
				data.red,
				data.green,
				data.blue,
				data.alpha
			];
			let best = 0, distance = Infinity;
			for (let index = 0; index < Math.min(entries.length, 256); index++) {
				const c = pixelRGBA({}, entries[index]), d = channels.reduce((sum, value, channel) => sum + (value - c[channel]) ** 2 * (channel === 3 ? 2 : 1), 0);
				if (d < distance) {
					best = index;
					distance = d;
				}
			}
			return best;
		}
		if (op === "imageBytesGet") return images.bytesGet(data.target, data.start, data.count);
		if (op === "imageBytesBegin") return images.bytesBegin(data.target, data.size);
		if (op === "imageBytesAppend") return images.bytesAppend(data.token, data.bytes);
		if (op === "imageBytesCommit") return images.bytesCommit(data.token);
		if (op === "imageBytesCancel") return images.bytesCancel(data.token);
		if (op === "get") return get(data.target, data.key);
		if (op === "set") return set(data.target, data.key, data.value);
		if (op === "method") return method(data.target, data.name, data.args ?? []);
		if (op === "colorsGet") return copy(colors);
		if (op === "colorsSet") {
			colors = {
				fgColor: validateLuaColor(data.fgColor, "Lua foreground color"),
				bgColor: validateLuaColor(data.bgColor, "Lua background color")
			};
			return;
		}
		if (op === "appGet") return appGet(data.key);
		if (op === "appSet") return appSet(data.key, data.value);
		if (op === "command") return command(data.name, data.options);
		if (op === "useTool") return performTool(data);
		if (op === "imageSpecNew") return imageSpecs.create(data);
		if (op === "imageSpecEqual") return imageSpecs.equal(data.left, data.right);
		if (op === "imageNew") return imageNew(data);
		if (op === "selectionNew") return authoring.selectionNew(data.rectangle);
		if (op === "paletteNew") return ref("Palette", { colors: data.source ? [...palette(data.source).colors] : Array(integer(data.size ?? 256, 1, 256, "Palette size")).fill("#000000ff") });
		if (op === "spriteNew") {
			const spec = data.spec ? imageSpecs.options(data.spec, { sprite: true }) : null;
			if (spec) data = {
				width: spec.width,
				height: spec.height,
				colorMode: spec.colorMode
			};
			flush();
			if (documents.size >= 8) throw Error("Lua sprite limit reached.");
			const width = integer(data.width, 1, 2048, "Sprite width"), height = integer(data.height, 1, 2048, "Sprite height");
			if (width * height > LUA_LIMITS.pixels) throw Error("Lua sprite pixel budget exceeded.");
			let id;
			do
				id = `lua-sprite-${++serial}`;
			while (documents.has(id));
			const seed = createDocument({
				id,
				width,
				height,
				colorMode: modeName(data.colorMode ?? 0),
				palette: modeName(data.colorMode ?? 0) === "indexed" ? [spec?.transparentColor ? "#000000ff" : "#00000000", ...Array(255).fill("#000000ff")] : void 0
			});
			seed.clips = [];
			documents.set(id, seed);
			seeds.set(id, seed);
			authoring.track(seed);
			active = id;
			frameIndex = 0;
			layerId = seed.layers[0].id;
			if (seed.colorMode === "indexed") mutate(id, {
				type: "document.update",
				patch: { metadata: { aseprite: { transparentIndex: 0 } } }
			});
			if (spec) {
				const metadata = { aseprite: { transparentIndex: spec.transparentColor } };
				mutate(id, {
					type: "document.update",
					patch: { metadata }
				});
				colorSpaces.set(spriteRef(id), "colorSpace", colorSpaces.fromValue(spec.profile));
			}
			mutate(id, {
				type: "cel.set",
				frameId: seed.frames[0].id,
				layerId,
				width,
				height,
				pixels: Array(width * height).fill(seed.colorMode === "indexed" ? 0 : null)
			});
			return spriteRef(id);
		}
		if (op === "begin") {
			flush();
			if (transactions.length >= 16) throw Error("Lua transaction nesting limit reached.");
			transactions.push({
				label: String(data.label ?? "Lua transaction").slice(0, 100),
				documents: new Map(documents),
				seeds: new Map(seeds),
				active,
				frameIndex,
				layerId,
				authoring: authoring.snapshot(),
				tileImages: snapshotTileImages(),
				rasterImages: rasterLifetime.snapshot(),
				imageSpecs: imageSpecs.snapshot(),
				palettes: colorCommands.snapshot(),
				entries: []
			});
			return;
		}
		if (op === "commit") {
			flush();
			const transaction = transactions.pop();
			if (!transaction) throw Error("No Lua transaction.");
			const entries = [];
			for (const entry of transaction.entries) {
				const previous = entries.at(-1);
				if (previous?.documentId === entry.documentId) previous.commands.push(...entry.commands);
				else entries.push({
					...entry,
					label: transaction.label
				});
			}
			(transactions.at(-1)?.entries ?? logs).push(...entries);
			if (!transactions.length) retiredTileImages.clear();
			return;
		}
		if (op === "rollback") {
			const transaction = transactions.pop();
			if (!transaction) throw Error("No Lua transaction.");
			documents.clear();
			for (const [id, d] of transaction.documents) documents.set(id, d);
			seeds.clear();
			for (const [id, d] of transaction.seeds) seeds.set(id, d);
			active = transaction.active;
			frameIndex = transaction.frameIndex;
			layerId = transaction.layerId;
			authoring.restore(transaction.authoring);
			restoreTileImages(transaction.tileImages);
			rasterLifetime.restore(transaction.rasterImages);
			imageSpecs.restore(transaction.imageSpecs);
			colorCommands.restore(transaction.palettes);
			for (const [key, item] of attached) {
				const d = documents.get(item.docId);
				let source;
				try {
					source = item.tilesetId ? tileSource(item.docId, item.tilesetId, item.tileIndex) : d?.images[item.imageId];
				} catch {
					source = null;
				}
				if (source) {
					Object.assign(item, copy(source));
					item.virtualTile = !!source.virtualTile;
					item.dirty = false;
					item.colorMode = d.colorMode;
				} else {
					attached.delete(key);
					refs.delete(key);
				}
			}
			return;
		}
		if (op === "print") {
			const text = String(data.text).slice(0, 4096);
			if (prints.join("").length + text.length > 32768) throw Error("Lua log budget exceeded.");
			prints.push(text);
			return;
		}
		throw Error("Unsupported Lua bridge operation.");
	}
	return {
		rpc(op, json) {
			try {
				if (typeof json !== "string" || json.length > LUA_LIMITS.outputBytes) throw Error("Lua argument size limit exceeded.");
				const value = dispatch(op, JSON.parse(json));
				return JSON.stringify({
					ok: true,
					value: value ?? null
				});
			} catch (error) {
				return JSON.stringify({
					ok: false,
					error: String(error.message).slice(0, 1024)
				});
			}
		},
		finish() {
			if (calls > LUA_LIMITS.calls || commandCount > LUA_LIMITS.commands || pixelsAllocated > LUA_LIMITS.pixels * 4 || bytesLogged > LUA_LIMITS.outputBytes) throw Error("Lua execution budget exceeded.");
			flush();
			if (transactions.length) throw Error("Unfinished Lua transaction.");
			const result = {
				format: "pixelwall-lua-result",
				version: 1,
				document: active ? doc() : null,
				documents: [...documents.values()],
				created: [...seeds.values()],
				transactions: logs,
				active: {
					documentId: active,
					frameId: active ? doc().frames[frameIndex].id : null,
					layerId
				},
				prints,
				...colors,
				...authoring.finish(),
				stats: {
					calls,
					commands: commandCount
				}
			};
			if (JSON.stringify(result).length > LUA_LIMITS.outputBytes) throw Error("Lua output size limit exceeded.");
			return copy(result);
		}
	};
}
//#endregion
//#region app/lua-runtime.mjs
/** Worker-internal only: never execute untrusted scripts on the editor/main thread. */
async function executeLuaInWorker(request, wasmUri, { requestDialog, requestCommand, colorManager } = {}) {
	const session = createLuaSession(request, { colorManager });
	const plugin = createLuaPluginSession(request.plugin, requestCommand);
	const lua = await new import_dist.LuaFactory(wasmUri, {}).createEngine({
		injectObjects: false,
		enableProxy: false,
		traceAllocations: true
	});
	try {
		lua.global.setMemoryMax(LUA_LIMITS.memoryBytes);
		lua.global.set("__pixelwallRpc", (op, json) => session.rpc(op, json));
		let dialogCount = 0;
		lua.global.set("__pixelwallDialogEnabled", typeof requestDialog === "function");
		lua.global.set("__pixelwallDialog", async (json) => {
			try {
				if (typeof requestDialog !== "function") throw Error("Dialog requires an interactive UI host.");
				if (++dialogCount > LUA_DIALOG_LIMITS.requests) throw Error("Lua Dialog request limit exceeded.");
				if (typeof json !== "string" || new TextEncoder().encode(json).length > LUA_DIALOG_LIMITS.bytes) throw Error("Lua Dialog data exceeds 64 KiB.");
				const schema = validateDialogSchema(JSON.parse(json));
				const response = validateDialogResponse(await requestDialog(schema), schema);
				return JSON.stringify({
					ok: true,
					value: response
				});
			} catch (error) {
				return JSON.stringify({
					ok: false,
					error: String(error?.message ?? error).slice(0, 4096)
				});
			}
		});
		lua.global.set("__pixelwallPluginConfig", plugin?.configuration ?? "");
		lua.global.set("__pixelwallPluginChoice", plugin?.choose ?? (() => {
			throw Error("No package session.");
		}));
		lua.global.set("__pixelwallPluginDone", plugin?.complete ?? (() => {
			throw Error("No package session.");
		}));
		lua.global.set("__pixelwallSource", request.source);
		lua.global.set("__pixelwallInstructions", request.instructionLimit);
		await lua.doString(LUA_BOOTSTRAP);
		if (dialogCount > LUA_DIALOG_LIMITS.requests) throw Error("Lua Dialog request limit exceeded.");
		return {
			...session.finish(),
			...plugin ? { plugin: plugin.finish() } : {}
		};
	} finally {
		lua.global.close();
	}
}
//#endregion
//#region app/lua-dialog-channel.mjs
/** Worker-local rendezvous: one live VM, one outstanding request, monotonic IDs. */
function createLuaDialogChannel(postMessage) {
	let serial = 0, pending = null;
	return {
		requestDialog(schema) {
			if (pending) return Promise.reject(Error("A Lua dialog response is already pending."));
			if (++serial > LUA_DIALOG_LIMITS.requests) return Promise.reject(Error("Lua Dialog request limit exceeded."));
			schema = validateDialogSchema(schema);
			return new Promise((resolve, reject) => {
				pending = {
					id: serial,
					schema,
					resolve,
					reject
				};
				try {
					postMessage({
						type: "dialog-request",
						id: serial,
						dialog: schema
					});
				} catch (error) {
					pending = null;
					reject(error);
				}
			});
		},
		receive(message) {
			if (message?.type !== "dialog-response" || !pending || message.id !== pending.id) return false;
			const current = pending;
			pending = null;
			try {
				current.resolve(validateDialogResponse(message.response, current.schema));
			} catch (error) {
				current.reject(error);
			}
			return true;
		}
	};
}
//#endregion
//#region app/lua-node-worker.mjs
const channel = createLuaDialogChannel((message) => parentPort.postMessage(message));
const pluginChannel = createLuaPluginChannel((message) => parentPort.postMessage(message), workerData.request.plugin);
const receive = (message) => channel.receive(message) || pluginChannel.receive(message);
parentPort.on("message", receive);
let colorManager;
try {
	if (needsLuaColorManager(workerData.request)) colorManager = await loadNodeColorManager();
	parentPort.postMessage({
		ok: true,
		result: await executeLuaInWorker(workerData.request, workerData.wasmUri, {
			requestDialog: workerData.dialogs === true ? channel.requestDialog : void 0,
			requestCommand: workerData.request.plugin ? pluginChannel.requestCommand : void 0,
			colorManager
		})
	});
} catch (error) {
	parentPort.postMessage({
		ok: false,
		error: String(error?.message ?? error).slice(0, 4096)
	});
} finally {
	colorManager?.close();
	parentPort.off("message", receive);
}
//#endregion
export {};
