# PixelWall CLI

Requires Node.js 22.13 or newer. Run `node pixelwall.mjs help`. No npm dependencies or server are required. Premium exports require your downloaded PW2 ownership license; pass `--license /path/license.txt`.

For local desktop MCP, enable “Allow local agent connection” in PixelWall 0.5.0, choose the approved export folder, then configure your MCP client to run `node pixelwall-mcp.mjs` from this folder. The launcher requires Node.js 22.13 or newer. It controls one opted-in local window only; disable the menu option or close the window to disconnect. `pixelwall_save_artifact` writes verified generated files into the approved folder. Hosted browser sessions and remote connections are unsupported.

The included `agent-ninja-panda-commands.json` is a complete 63-command example. Try it with:

```sh
node pixelwall.mjs new --width 24 --height 24 --name "Ninja Panda Idle" --out ninja-panda.pixelwall
node pixelwall.mjs apply ninja-panda.pixelwall --commands agent-ninja-panda-commands.json --out ninja-panda.pixelwall
node pixelwall.mjs render ninja-panda.pixelwall --frame 0 --scale 8 --out ninja-panda.png
```

Documentation: https://www.pixelwall.dev/guides/ai-agents
