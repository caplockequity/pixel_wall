# PixelWall CLI

Requires Node.js 22.13 or newer. Run `node pixelwall.mjs help`. No npm dependencies or server are required. Premium exports require your downloaded PW2 ownership license; pass `--license /path/license.txt`.
