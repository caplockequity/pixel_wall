# PixelWall CLI

Requires Node.js 22.13 or newer. Run `node pixelwall.mjs help`. No npm dependencies or server are required. Premium exports require your downloaded PW2 ownership license; pass `--license /path/license.txt`.

The included `agent-ninja-panda-commands.json` is a complete 63-command example. Try it with:

```sh
node pixelwall.mjs new --width 24 --height 24 --name "Ninja Panda Idle" --out ninja-panda.pixelwall
node pixelwall.mjs apply ninja-panda.pixelwall --commands agent-ninja-panda-commands.json --out ninja-panda.pixelwall
node pixelwall.mjs render ninja-panda.pixelwall --frame 0 --scale 8 --out ninja-panda.png
```

Documentation: https://www.pixelwall.dev/guides/ai-agents
